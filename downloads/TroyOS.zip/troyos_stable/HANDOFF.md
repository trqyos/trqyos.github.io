# Handoff: where the project stands

> **STATUS: COMPLETE** — everything in "Still to do" below is done (2026-10-17).
> 407 backend tests pass (was 329) + 87/87 Electron UI checks. One real bug
> was found and fixed on the way (troy/tls.py built SANs as strings instead
> of x509 GeneralName objects — HTTPS would never have started). This file
> is kept as the historical record of what the last stretch involved.

Zip = TroyOS (Python backend `troy/` + Electron UI `electron/` + phone page `troy/web/phone/`).
Run: `pip install -r requirements.txt`, then `cd electron && npm install && npm start`.
Tests: `pip install -r requirements-dev.txt && pytest` (329 passed at the last full run, BEFORE the voice_mode work below).
UI tests (need Electron): `cd electron && npm install && xvfb-run -a npm run test:ui`.

## Native function calling round (latest)
- See README "Newest: native function calling". Files: `tool_schema.py`, `tool_history.py`, `native_loop.py` (mixin of `TroyAgent`),
  `llm_client.chat_tools`, `system_prompt.build_native_prompt`, setting `TOOL_CALLING` (auto | native | text; Settings UI row added).
- The text protocol is untouched and is both the `text` mode and the `auto` fallback (`agent._switch_to_text`).
- Verified: pytest 680 passed; Electron `test:ui` 132/132, `test:widget` 33/33, `test:shell` 19/19 (run with `xvfb-run -a npx electron --no-sandbox test/<file>.js`).
- NOT verified: a live run against the real providers (no API keys here). Tool-call behaviour differs between models; first things to try:
  Groq `openai/gpt-oss-*` and Gemini via the compat endpoint. Watch `troy_logs` for "rejected native tool calls" / "malformed tool call".
  Gemini's compat endpoint gets the tool name on `tool` messages (`keep_tool_name`), the others don't.
- Also changed: two timing-dependent scheduler tests made deterministic; `*.pem` added to `.gitignore`.
- Security: the uploaded zip contained `troy_key.pem` (TLS private key) and `troy_mobile_token.txt` (phone login). Both are regenerated
  automatically if missing; rotate them if the zip was shared.
- Ideas: capability table + success-rate metrics per model, cheap-model routing, real per-tool JSON schemas, MCP client.

## Widget, redesign, self-control, power saving (added after the project was marked COMPLETE)
- **Modes** (`main.js` `setMode`): widget | app | hidden, never widget + app together. Startup = the full app only (the widget appears when the app window is closed).
  App close button = back to the widget. `Ctrl+Alt+T` (prefs `widgetHotkey`) toggles the widget. The Python
  hotkey (`troy/hotkey.py`, `HOTKEY_COMBO`) was deleted; "keep on top" / "close to tray" were removed from the app.
- **Widget**: `electron/renderer/widget/` (see `electron/README.md` > The widget). Settings > Widget and > Power in the app.
- **Redesign**: `renderer/styles.css` is a full liquid-glass rewrite (same class names / ids), `avatar.js` has the new
  animations (copied to `troy/web/phone/avatar.js`, a test keeps them identical).
- **Troy controls his own app**: `troy/tools_app.py` (category `app`) -> `troy/ui_bridge.py` -> `ui.command` events ->
  `main.js` (`handleUiCommand`) + renderers (`applyCommand`). Electron reports back with the `ui.report` IPC method.
- **Power saving**: `troy/power.py` (`POWER_SAVING` off|auto|on; Electron reports the battery via `power.report`),
  `power.state` event -> `body.saver` + `face.setOptions({saver})`.
- Tests: pytest 422, `npm run test:ui` 107, `test:widget` 33, `test:shell` 18 (real main.js + fake backend).

## Phone redesign + voice fix + sync (latest)
- **Voice bug:** `VoiceMode` calls `host.start_turn`; `IPCHost.start_turn` now exists (tests/test_phone_app.py).
- **Phone page** (`troy/web/phone/`): liquid-glass redesign in the widget's style. Tabs: Chat, Chats, Tasks, Screen, Settings
  (`views.js` = chats/tasks/settings + bottom sheet; `phone.js` = shell, chat, voice, screen). The phone calls the PC app through
  `POST /api/rpc` (allow-list `mobile_server.PHONE_METHODS`; only `PHONE_SETTINGS` may be changed; never API keys).
- **Sync:** `ipc_host._emit` mirrors `task.*`, `session.changed`, `settings.changed`, `model.changed`, `power.state`, `face.*` to phones.
  `avatar.js` `setSync()` = shared-clock blinks/glances/winks; pokes/wakes relayed with the `face.relay` method and `face.event`.
  The phone measures the PC clock offset from `/api/state.now`. PC mic level + wake state reach the phone as `voice` events.
- Heart-eye expression removed from avatar.js. Startup mode is now the full app only (main.js; `maximize()` on a hidden window used to show it).
- Tests: pytest 591. Electron suites (test:ui / test:widget / test:shell) were NOT run after these changes.

## Scheduled tasks + on-demand extra tools (added later)
- **Design:** `schedule_spec.py` (pure parsing/maths) <- `scheduler.py` (thread, persistence, retries; knows nothing about
  models) <- `task_runner.py` (drives a fresh `TroyAgent` under the host's `_turn_lock`) <- `ipc_host._init_tasks` (events,
  reporting into the originating chat, `tasks.*` methods). `tools_tasks.py` are the model-facing tools.
- **Safety rule to keep:** unattended runs may only execute commands pre-approved for that task (`task_context`,
  checked in `tools_all.run`; `confirmation.request` itself refuses inside a run). Don't add a path that raises an Approve card
  from a scheduled run.
- **Extra tools:** `extra_tools.py`. "Extra" = registered tool whose name isn't in the system prompt (+ the per-turn hint).
  The agent wraps each request in `extra_tools.activate(...)` and calls `collapse()` in `_run_step_loop`'s `finally`.
  `context_budget.EXTRA_LIST_MARKER` exempts the list from the per-message cap. Prompt tests for the old "every tool named
  in the compact prompt" behaviour now run with `EXTRA_TOOLS_ENABLED=False`.
- Tests: pytest 578 (156 new: test_schedule_spec, test_scheduler, test_task_runner, test_tools_tasks, test_extra_tools,
  test_ipc_tasks), `test:ui` 132, `test:widget` 33, `test:shell` 18.
- Not done:  natural-language parsing is English only; local clock only (no time zones).

## Finished this session
* **Troy can change its own model mid-chat**: tools `set_model` (name | provider|model | fast/strong/local), `list_models`,
  `current_model`, `reset_model`, `set_vision_model` (troy/tools_all.py). Applies and persists via the new `troy/settings_store.py`
  (settings code moved out of ipc_host.py). Local -> cloud switch needs approval. Setting `ALLOW_MODEL_SWITCH`.
  The agent re-reads the prompt when the model changes mid-turn. IPC event `model.changed`. Tests: tests/test_model_switch.py.
* **Voice building blocks (all tested except voice_mode.py)**:
  - `troy/speech_text.py` clean_for_speech / split_sentences / end & stop phrases / noise filter
  - `troy/audio_in.py` Endpointer (adaptive VAD, pre-roll, calibration), resample, wav helpers, has_speech
  - `troy/tts.py` engines (sapi via pyttsx3->WAV, edge-tts, piper), WindowsPlayer/SoundDevicePlayer, `Speaker`
    (sentence-streaming, prefetch, instant stop, sink for phone)
  - `troy/wake_listener.py` now uses the Endpointer; adds hooks (`set_hooks`), conversation mode (`set_conversation`,
    no wake word, idle timeout), barge-in, mic pause (`set_paused`), input device choice (`VOICE_INPUT_DEVICE`)
  - agent: streams `speak:` lines early (`_early_speak`) and adds a spoken-style hint (`voice_style` / `voice_forced`);
    `llm_client.chat(..., on_text=cb)`
  - new config + settings keys: TTS_ENGINE, EDGE_VOICE, PIPER_MODEL, VOICE_CONVERSATION_IDLE_SECONDS, VOICE_BARGE_IN,
    VOICE_INPUT_DEVICE, VOICE_SPOKEN_STYLE, STT_LANGUAGE, MOBILE_VOICE_ENABLED, VOICE_PHONE_SPEAKER, MOBILE_HTTPS_ENABLED
* `troy/voice_mode.py` (orchestrator) is WRITTEN BUT NOT WIRED IN and has no tests yet.

## Still to do (in this order)
1. **Wire voice_mode into `troy/ipc_host.py`**: `self.voice = VoiceMode(host)` where host exposes `start_turn(text, source)`
   (= `_start_turn`), `stop_turn()` (stop_control.request_stop), `emit`, `broadcast` (mobile_server.broadcast), `agent`.
   In `_on_speak` replace the `voice.speak(text)` block with `self.voice.speak(text)`; in `_on_state` call
   `self.voice.agent_state(state, detail)`; make `_m_wake_listener_start` call `self.voice.install_listener()`.
   New IPC methods: voice.mode_start / voice.mode_stop / voice.mode_status (= `info()` + tts.engine_report() +
   voice.stt_status()), voice.mute {muted}, voice.interrupt, voice.devices, voice.test_mic {seconds},
   voice.list_voices {engine} (tts.list_voices). Events already emitted by VoiceMode: voice.state, voice.level,
   voice.transcript, voice.ended, voice.phone.
2. **Phone mic + speaker, server side** (`troy/mobile_server.py`): extend `Bridge` with voice_start/voice_stop/voice_interrupt/
   voice_event/voice_audio(pcm, rate)/voice_audio_get(id). Routes: POST /api/voice/start|stop|interrupt|event (JSON),
   POST /api/voice/utterance?rate=16000 (raw PCM16 body, raise the 64 KB limit to ~2 MB for it), GET /api/voice/audio/<id>.
   Add `voice-worklet.js` to `_STATIC` if used. Include `voice` info (enabled, speaker, https links) in /api/state.
3. **HTTPS for the phone microphone** (browsers only allow getUserMedia on HTTPS): add `troy/tls.py` (self-signed cert via
   `cryptography`, SANs = localhost, LAN IP, hostname), serve a second `_Server` on MOBILE_UI_PORT+1 with ssl, add a
   `lan-https` entry in `troy/remote.py: access_urls`. Tailscale HTTPS (already there) also works.
4. **Phone voice UI** (`troy/web/phone/phone.js/.css/index.html`): full-screen voice overlay with a NovaFace, state label, live
   transcript, level ring, End/Mute/Stop. getUserMedia({echoCancellation,noiseSuppression}) -> client-side endpointer
   (port of audio_in.Endpointer; raise threshold while playing for barge-in) -> downsample to 16 kHz PCM16 -> POST utterance ->
   show returned text; handle {action: ignored|turn|stop|end}. Play replies from SSE `{"type":"voice","action":"speak"}`:
   `speechSynthesis` for speaker=phone, or fetch `audio` URL for speaker=troy. If not a secure context, show the HTTPS links.
5. **Desktop UI** (`electron/renderer`): voice-mode overlay (big avatar, state, transcript, mic level from `voice.level`,
   End/Mute/Stop; header button + Ctrl+Shift+V), Settings > Voice additions (TTS engine + voices per engine with availability
   hints, Edge voice, Piper model path, microphone picker, "test microphone", conversation timeout, barge-in switch,
   spoken-style switch, STT language), Settings > Phone additions (phone voice on/off, phone speaker phone|troy, HTTPS link),
   Models pane switch for ALLOW_MODEL_SWITCH, toast on `model.changed`. Update `mock-backend.js` for all new methods and
   extend `electron/test/ui-smoke.js`.
6. Tests for voice_mode.py (fake host + fake speakers + monkeypatched wake_listener/voice.transcribe), docs in README.md and
   electron/README.md, requirements (cryptography, optional edge-tts / piper-tts), `.env.example` entries for the new settings.

## Gotchas
* `tests/test_ipc_*` patch `settings_store.SETTINGS_FILE`, not ipc_host.
* `avatar.js` must stay byte-identical in `electron/renderer/` and `troy/web/phone/` (a test checks).
* Electron for UI tests is not bundled: `mkdir /tmp/el && cd /tmp/el && npm i electron@31`, run with `xvfb-run -a electron --no-sandbox --disable-gpu <script>`.
* API keys/.env/tokens are intentionally not in the zip.
