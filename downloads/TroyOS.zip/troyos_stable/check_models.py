"""
Troy Assistant - Model Availability Checker

Groq (especially) retires free model slugs often. Run this any time Troy
complains it can't reach a model, to see the actual current list your keys
have access to, then update GROQ_TEXT_MODELS / GROQ_VISION_MODELS /
OPENROUTER_TEXT_MODELS / OPENROUTER_VISION_MODELS / NVIDIA_TEXT_MODELS /
NVIDIA_VISION_MODELS in troy/config.py.

Usage:
    python check_models.py
"""

import requests

from troy import config


def list_models(label, base_url, api_key):
    print(f"\n=== {label} ({base_url}) ===")
    if not api_key:
        print("  (no API key set in .env -- skipping)")
        return

    try:
        response = requests.get(
            f"{base_url}/models",
            headers={"Authorization": f"Bearer {api_key}"},
            timeout=15,
        )
        response.raise_for_status()
        data = response.json()
        model_ids = sorted(m["id"] for m in data.get("data", []))
        if not model_ids:
            print("  No models returned -- check your API key.")
            return
        for model_id in model_ids:
            print(f"  {model_id}")
    except Exception as exc:  # noqa: BLE001
        print(f"  Failed to list models: {exc}")


def main():
    list_models("Groq", config.GROQ_BASE_URL, config.GROQ_API_KEY)
    list_models("OpenRouter", config.OPENROUTER_BASE_URL, config.OPENROUTER_API_KEY)
    list_models("NVIDIA NIM", config.NVIDIA_BASE_URL, config.NVIDIA_API_KEY)
    print(
        "\nTip: OpenRouter's and NVIDIA's lists are huge -- look for ':free' "
        "suffixes on OpenRouter, or filter visually at "
        "https://openrouter.ai/models or https://build.nvidia.com/models"
    )


if __name__ == "__main__":
    main()
