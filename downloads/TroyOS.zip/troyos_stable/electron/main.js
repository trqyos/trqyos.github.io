// TroyOS Electron main process.
//
// Owns three things:
//   1. The window (frameless-style glass UI, remembered size/position, tray,
//      always-on-top, hide-to-tray, global-hotkey show/hide).
//   2. A child Python process (../main.py --ipc) that this file talks to over
//      plain stdin/stdout -- newline-delimited JSON, real OS-level IPC. This is
//      the replacement for the earlier http://127.0.0.1:8000-style approach,
//      which did not work reliably here. There is no network involved at all.
//   3. A small set of "shell" IPC channels the renderer needs that Python can't
//      do (window controls, opening links in the real browser, backend restart).
//
// Backend protocol (mirrors troy/ipc_host.py's docstring exactly):
//   we write   {"id": <n>, "method": "<name>", "params": {...}}      to child.stdin
//   child writes either
//     {"type": "response", "id": <n>, "ok": true,  "result": {...}}
//     {"type": "response", "id": <n>, "ok": false, "error": "..."}
//   or, unsolicited,
//     {"type": "event", "event": "<name>", "data": {...}}
//   to its stdout, one JSON object per line.
//
// Two IPC layers are stacked here, neither of them HTTP:
//   renderer  <--Electron IPC-->  this file  <--stdio IPC-->  Python backend
// Renderer-facing channels (see preload.js):
//   "troy:request"  renderer -> here -> python   (request/response)
//   "troy:event"    here -> renderer              (push, whenever python emits one)
//   "troy:window"   renderer -> here              (window/shell actions)
//   "troy:external" renderer -> here              (open an http(s) URL in the real browser)
//   "troy:widget"   widget/app -> here           (mode, size, focus and options of the always-on-top widget)
//
// Troy has two windows but only ever shows ONE of them (see setMode below):
// the WIDGET, a small transparent always-on-top glass pill at the top centre of the
// primary display (right under a laptop webcam), or the full APP window. Both use
// the same preload and the same backend, and every backend event goes to both.

const {
  app, BrowserWindow, ipcMain, Tray, Menu, nativeImage, screen, shell, globalShortcut, powerMonitor,
} = require("electron");
const { spawn } = require("child_process");
const fs = require("fs");
const path = require("path");

const PYTHON_CMD = process.env.TROY_PYTHON || (process.platform === "win32" ? "python" : "python3");
const REQUEST_TIMEOUT_MS = 60_000;
const IS_MAC = process.platform === "darwin";
const IS_LINUX = process.platform === "linux";

let mainWindow = null;
let widgetWindow = null;
let tray = null;
let pythonProcess = null;
let stdoutBuffer = "";
let nextRequestId = 1;
let isQuitting = false;
const pendingRequests = new Map(); // id -> { resolve, reject, timer }

// ---------------------------------------------------------------------------
// Single instance: two Troys would mean two Python backends fighting over the
// microphone, the global hotkey and the same session files.
// ---------------------------------------------------------------------------
if (!app.requestSingleInstanceLock()) {
  app.quit();
} else {
  app.on("second-instance", () => setMode("app"));      // launching Troy again = open the full app
}

// ---------------------------------------------------------------------------
// Small persisted preferences (window bounds + a couple of shell options)
// ---------------------------------------------------------------------------
const PREFS_FILE = () => path.join(app.getPath("userData"), "window-state.json");
const DEFAULT_PREFS = {
  bounds: null, maximized: false,
  widgetOnTop: true,                       // keep the widget above every other window (incl. full-screen apps)
  widgetAutoCollapse: true,                // the widget's panel folds away after a reply
  widgetHotkey: "CommandOrControl+Alt+T",  // shows / hides the widget from anywhere
  language: "en",                          // "en" | "tr" | "auto": mirrors the UI_LANGUAGE setting (kept here so the tray is right before the backend is up)
};

// The only interface text that lives in the main process.
const TRAY_TEXT = {
  en: { tip: "Troy", ask: "Ask Troy (widget)", open: "Open full app", hide: "Hide Troy", stop: "Stop current task", quit: "Quit Troy" },
  tr: { tip: "Troy", ask: "Troy'a sor (widget)", open: "Tam uygulamayı aç", hide: "Troy'u gizle", stop: "Geçerli görevi durdur", quit: "Troy'dan çık" },
};
function activeLanguage() {
  const p = prefs.language;
  if (p === "tr" || p === "en") return p;
  return String(app.getLocale() || "en").toLowerCase().startsWith("tr") ? "tr" : "en";
}
let prefs = { ...DEFAULT_PREFS };

function loadPrefs() {
  try {
    prefs = { ...DEFAULT_PREFS, ...JSON.parse(fs.readFileSync(PREFS_FILE(), "utf8")) };
    delete prefs.alwaysOnTop; delete prefs.closeToTray; delete prefs.widgetEnabled;   // retired options
  } catch {
    prefs = { ...DEFAULT_PREFS };
  }
}

function savePrefs() {
  try {
    fs.mkdirSync(path.dirname(PREFS_FILE()), { recursive: true });
    fs.writeFileSync(PREFS_FILE(), JSON.stringify(prefs, null, 2));
  } catch (err) {
    console.error("Couldn't save window prefs:", err.message);
  }
}

function visibleBounds(bounds) {
  // Ignore remembered bounds that would put the window off-screen (e.g. a
  // monitor that's since been unplugged).
  if (!bounds) return null;
  const ok = screen.getAllDisplays().some((d) => {
    const a = d.workArea;
    return bounds.x < a.x + a.width - 80 && bounds.x + bounds.width > a.x + 80
        && bounds.y < a.y + a.height - 80 && bounds.y + bounds.height > a.y;
  });
  return ok ? bounds : null;
}

// ---------------------------------------------------------------------------
// Python backend
// ---------------------------------------------------------------------------
function backendDir() {
  // Dev: this repo's project root (one level up from electron/).
  // Packaged: electron-builder copies the backend into resources/backend
  // (see package.json's "extraResources").
  return app.isPackaged
    ? path.join(process.resourcesPath, "backend")
    : path.join(__dirname, "..");
}

function startPythonBackend() {
  stdoutBuffer = "";
  const cwd = backendDir();
  const child = spawn(PYTHON_CMD, ["-u", "main.py", "--ipc"], {
    cwd,
    // Force UTF-8 for every stream the child opens. Without this, Python on
    // Windows falls back to the legacy ANSI codepage for pipes and crashes with
    // "'charmap' codec can't encode character ..." on any non-ASCII text.
    // main.py also reconfigures its own streams -- this is the second layer.
    env: { ...process.env, PYTHONUTF8: "1", PYTHONIOENCODING: "utf-8" },
  });
  pythonProcess = child;

  child.stdout.setEncoding("utf8");
  child.stdout.on("data", (chunk) => {
    stdoutBuffer += chunk;
    let newlineIndex;
    while ((newlineIndex = stdoutBuffer.indexOf("\n")) !== -1) {
      const line = stdoutBuffer.slice(0, newlineIndex).trim();
      stdoutBuffer = stdoutBuffer.slice(newlineIndex + 1);
      if (line) handleBackendLine(line);
    }
  });

  child.stderr.setEncoding("utf8");
  child.stderr.on("data", (chunk) => {
    // Python's own logger already writes to troy_logs/troy.log; this is just so
    // a crash traceback is also visible in Electron's console during development.
    console.error("[python]", chunk);
    sendEventToRenderer("backend.stderr", { text: chunk });
  });

  // Without this, "python not found" (ENOENT) is an unhandled 'error' event
  // and takes the whole Electron main process down with a crash dialog.
  child.on("error", (err) => {
    console.error("Couldn't start the Python backend:", err.message);
    sendEventToRenderer("backend.error", {
      message: `Couldn't start Python ("${PYTHON_CMD}"): ${err.message}. ` +
               "Install Python, or set TROY_PYTHON to the full path of your interpreter.",
    });
  });
  child.stdin.on("error", () => { /* backend gone; the 'exit' handler reports it */ });

  child.on("exit", (code, signal) => {
    if (pythonProcess !== child) return; // an old process we replaced on purpose
    console.error(`Python backend exited (code=${code}, signal=${signal}).`);
    sendEventToRenderer("backend.exited", { code, signal });
    failAllPending("Python backend process exited.");
  });
}

function failAllPending(message) {
  for (const [, pending] of pendingRequests) {
    clearTimeout(pending.timer);
    pending.reject(new Error(message));
  }
  pendingRequests.clear();
}

function restartPythonBackend() {
  const old = pythonProcess;
  pythonProcess = null;
  failAllPending("Python backend is restarting.");
  if (old && old.exitCode === null) old.kill();
  startPythonBackend();
  sendEventToRenderer("backend.restarted", {});
}

function handleBackendLine(line) {
  let message;
  try {
    message = JSON.parse(line);
  } catch {
    console.error("Malformed line from Python backend, ignoring:", line);
    return;
  }

  if (message.type === "response") {
    const pending = pendingRequests.get(message.id);
    if (!pending) return; // late/duplicate response, or we've already timed out
    pendingRequests.delete(message.id);
    clearTimeout(pending.timer);
    if (message.ok) pending.resolve(message.result);
    else pending.reject(new Error(message.error || "Unknown backend error"));
    return;
  }

  if (message.type === "event") {
    // Window-level commands from Troy's own tools are carried out right here
    // (both windows may be hidden) and still forwarded to the renderers.
    if (message.event === "ui.command") handleUiCommand(message.data);
    if (message.event === "app.ready") {
      reportPower();
      sendRequestToPython("ui.report", { mode, widget_visible: mode === "widget" }).catch(() => {});
    }
    sendEventToRenderer(message.event, message.data);
    return;
  }

  console.warn("Unrecognized message type from Python backend:", message);
}

// Backend events go to BOTH windows (main UI + widget) so they never disagree.
function sendEventToRenderer(event, data) {
  for (const win of [mainWindow, widgetWindow]) {
    if (win && !win.isDestroyed()) win.webContents.send("troy:event", { event, data });
  }
}

// Shell events that only make sense for the main window (shown/hidden/focused).
function sendEventToMain(event, data) {
  if (mainWindow && !mainWindow.isDestroyed()) mainWindow.webContents.send("troy:event", { event, data });
}

function sendRequestToPython(method, params) {
  return new Promise((resolve, reject) => {
    if (!pythonProcess || pythonProcess.exitCode !== null || !pythonProcess.stdin.writable) {
      reject(new Error("Python backend is not running."));
      return;
    }
    const id = nextRequestId++;
    const timer = setTimeout(() => {
      pendingRequests.delete(id);
      reject(new Error(`Request '${method}' timed out after ${REQUEST_TIMEOUT_MS / 1000}s.`));
    }, REQUEST_TIMEOUT_MS);
    pendingRequests.set(id, { resolve, reject, timer });
    pythonProcess.stdin.write(JSON.stringify({ id, method, params: params || {} }) + "\n");
  });
}

// ---------------------------------------------------------------------------
// Renderer-facing IPC
// ---------------------------------------------------------------------------
ipcMain.handle("troy:request", (_event, { method, params }) => sendRequestToPython(method, params));

ipcMain.handle("troy:external", (_event, url) => {
  // Only ever hand real web links to the OS -- never file:, javascript:, etc.
  try {
    const u = new URL(String(url));
    if (u.protocol === "http:" || u.protocol === "https:") {
      shell.openExternal(u.toString());
      return true;
    }
  } catch { /* fall through */ }
  return false;
});

ipcMain.handle("troy:window", (_event, { action, value } = {}) => {
  const win = mainWindow;
  switch (action) {
    case "minimize": win?.minimize(); break;
    case "toggleMaximize": win && (win.isMaximized() ? win.unmaximize() : win.maximize()); break;
    case "hide": setMode("widget"); break;          // "close" the app window = back to the widget
    case "show": setMode("app"); break;
    case "quit": quitApp(); break;
    case "setTheme":
      // Keep the native min/max/close glyphs readable on light/dark themes.
      try { win?.setTitleBarOverlay?.({ symbolColor: String(value || "#e6ebf5") }); } catch { /* not supported here */ }
      break;
    case "restartBackend": restartPythonBackend(); break;
    case "reload": win?.webContents.reloadIgnoringCache(); break;
    case "devtools": win?.webContents.toggleDevTools(); break;
    case "getPrefs": break;
    case "setLanguage":
      if (["en", "tr", "auto"].includes(value) && prefs.language !== value) { prefs.language = value; savePrefs(); applyTrayMenu(); }
      break;
    default: throw new Error(`Unknown window action: ${action}`);
  }
  return {
    ...prefs,
    mode,
    maximized: !!win?.isMaximized(),
    visible: !!win?.isVisible(),
    platform: process.platform,
    version: app.getVersion(),
    electron: process.versions.electron,
    packaged: app.isPackaged,
    python: PYTHON_CMD,
  };
});


// ---------------------------------------------------------------------------
// Modes: Troy is either the WIDGET (always visible, top centre of the screen),
// the full APP window, or hidden. Never the widget and the app at once.
// Troy STARTS as the full app (the widget only takes over when the app window is closed).
//   widget -> the small glass pill is showing, the app window is hidden
//   app    -> the app window is showing, the widget is hidden
//   hidden -> neither (the tray icon / the hotkey brings the widget back)
// The Python side can switch modes too (Troy's show_widget / open_full_app tools
// arrive as `ui.command` events), and is told what we show via `ui.report`.
// ---------------------------------------------------------------------------
let mode = "app";            // startup = the full app only; the widget appears when the app is closed

function setMode(next) {
  if (next === "toggle") next = mode === "hidden" ? "widget" : "hidden";
  if (!["widget", "app", "hidden"].includes(next)) return mode;
  mode = next;
  if (mode === "app") {
    hideWidgetWindow();
    showMainWindow();
  } else {
    if (mainWindow && !mainWindow.isDestroyed() && mainWindow.isVisible()) mainWindow.hide();
    if (mode === "widget") showWidgetWindow(); else hideWidgetWindow();
  }
  sendEventToRenderer("ui.mode", { mode });
  sendRequestToPython("ui.report", { mode, widget_visible: mode === "widget" }).catch(() => {});
  return mode;
}

let restoreMaximized = false;   // the saved "maximized" state is applied when the window is first SHOWN (see createWindow)

function showMainWindow() {
  if (!mainWindow || mainWindow.isDestroyed()) createWindow();
  if (restoreMaximized) { restoreMaximized = false; mainWindow.maximize(); }   // maximize() also shows the window
  if (mainWindow.isMinimized()) mainWindow.restore();
  mainWindow.show();
  mainWindow.focus();
}

// The global hotkey (default Ctrl+Alt+T): opens the widget AND closes it again.
function onWidgetHotkey() {
  if (mode === "widget") setMode("hidden");
  else { setMode("widget"); focusWidget(); }
}

let registeredHotkey = null;
function registerWidgetHotkey(accelerator) {
  const wanted = accelerator || prefs.widgetHotkey;
  try {
    if (registeredHotkey) globalShortcut.unregister(registeredHotkey);
    registeredHotkey = null;
    if (!globalShortcut.register(wanted, onWidgetHotkey)) throw new Error(`${wanted} is already used by another app.`);
    registeredHotkey = wanted;
    return { ok: true, hotkey: wanted };
  } catch (err) {
    if (prefs.widgetHotkey && wanted !== prefs.widgetHotkey) { try { globalShortcut.register(prefs.widgetHotkey, onWidgetHotkey); registeredHotkey = prefs.widgetHotkey; } catch { /* keep none */ } }
    return { ok: false, error: String(err.message || err), hotkey: registeredHotkey };
  }
}

// ---------------------------------------------------------------------------
// Widget (always-visible glass pill at the top centre of the screen)
// ---------------------------------------------------------------------------
// The window is transparent and is resized to hug whatever the widget is
// currently showing (renderer/widget/widget.js asks for sizes via "fit"), so it
// never sits invisibly on top of other apps' title bars. On Windows/macOS the
// transparent margin is additionally click-through.
const WIDGET_DEFAULT = { w: 576, h: 114 };   // = compact pill (520 x 68) + the shadow margin widget.js keeps around it
let widgetSize = { ...WIDGET_DEFAULT };

function widgetBounds(w, h) {
  const wa = screen.getPrimaryDisplay().workArea;   // below the menu bar / notch area on macOS
  return { x: Math.round(wa.x + (wa.width - w) / 2), y: wa.y, width: Math.round(w), height: Math.round(h) };
}

function fitWidget(w, h) {
  w = Math.max(320, Math.min(960, Number(w) || widgetSize.w));
  h = Math.max(60, Math.min(900, Number(h) || widgetSize.h));
  widgetSize = { w, h };
  if (widgetWindow && !widgetWindow.isDestroyed()) widgetWindow.setBounds(widgetBounds(w, h));
}

function applyWidgetTopmost() {
  if (!widgetWindow || widgetWindow.isDestroyed()) return;
  if (prefs.widgetOnTop) {
    // "screen-saver" is the level that stays above full-screen windows and the Windows taskbar.
    widgetWindow.setAlwaysOnTop(true, "screen-saver");
    try { widgetWindow.setVisibleOnAllWorkspaces(true, { visibleOnFullScreen: true, skipTransformProcessType: true }); } catch { /* not supported here */ }
  } else {
    widgetWindow.setAlwaysOnTop(false);
    try { widgetWindow.setVisibleOnAllWorkspaces(false); } catch { /* not supported here */ }
  }
}

function createWidget() {
  if (widgetWindow && !widgetWindow.isDestroyed()) return;
  widgetWindow = new BrowserWindow({
    ...widgetBounds(widgetSize.w, widgetSize.h),
    frame: false,
    transparent: true,
    backgroundColor: "#00000000",
    hasShadow: false,                  // the glass draws its own shadow
    resizable: IS_LINUX,               // Linux WMs ignore setBounds on fixed-size windows; Win/mac keep an invisible resize border away
    movable: false,
    minimizable: false,
    maximizable: false,
    fullscreenable: false,
    skipTaskbar: true,
    focusable: true,
    show: false,
    title: "Troy Widget",
    icon: path.join(__dirname, "assets", "icon.png"),
    webPreferences: {
      preload: path.join(__dirname, "preload.js"),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true,
      backgroundThrottling: false,     // keep the face animating even when other windows cover it
    },
  });
  applyWidgetTopmost();
  widgetWindow.loadFile(path.join(__dirname, "renderer", "widget", "widget.html"));
  // Never steal focus on startup: the widget just appears.
  widgetWindow.once("ready-to-show", () => { if (mode === "widget") widgetWindow.showInactive(); });

  widgetWindow.webContents.setWindowOpenHandler(({ url }) => {
    if (/^https?:/i.test(url)) shell.openExternal(url);
    return { action: "deny" };
  });
  widgetWindow.webContents.on("will-navigate", (event, url) => {
    if (!url.startsWith("file://")) {
      event.preventDefault();
      if (/^https?:/i.test(url)) shell.openExternal(url);
    }
  });
  widgetWindow.on("closed", () => { widgetWindow = null; });
}

function showWidgetWindow() {
  if (!widgetWindow || widgetWindow.isDestroyed()) { createWidget(); return; }
  widgetWindow.setBounds(widgetBounds(widgetSize.w, widgetSize.h));
  widgetWindow.showInactive();
}

function hideWidgetWindow() {
  if (widgetWindow && !widgetWindow.isDestroyed()) widgetWindow.hide();
}

function focusWidget() {
  if (mode !== "widget") setMode("widget");
  if (!widgetWindow || widgetWindow.isDestroyed()) return;
  widgetWindow.setIgnoreMouseEvents(false);
  if (IS_MAC) app.focus({ steal: true });
  widgetWindow.show();
  widgetWindow.focus();
  widgetWindow.webContents.send("troy:event", { event: "widget.focus", data: {} });
}

function widgetInfo() {
  return {
    mode, onTop: !!prefs.widgetOnTop, autoCollapse: !!prefs.widgetAutoCollapse,
    hotkey: prefs.widgetHotkey, hotkeyActive: registeredHotkey === prefs.widgetHotkey,
    visible: !!widgetWindow?.isVisible(), platform: process.platform, size: widgetSize,
  };
}

/** Applies one widget option (from the widget, Settings, or Troy's own tool) and tells every window. */
function setWidgetOption(key, value) {
  let result = { ok: true };
  if (key === "onTop") { prefs.widgetOnTop = !!value; applyWidgetTopmost(); }
  else if (key === "autoCollapse") prefs.widgetAutoCollapse = !!value;
  else if (key === "hotkey") {
    result = registerWidgetHotkey(String(value || "").trim());
    if (result.ok) prefs.widgetHotkey = result.hotkey;
  } else throw new Error(`Unknown widget option: ${key}`);
  savePrefs();
  sendEventToRenderer("widget.options", widgetInfo());
  return { ...widgetInfo(), ...result };
}

ipcMain.handle("troy:widget", (_event, { action, value } = {}) => {
  switch (action) {
    case "fit": fitWidget(value?.w, value?.h); break;
    case "passthrough":
      // Click-through for the transparent margin. `forward` keeps mousemove
      // flowing so the renderer notices when the pointer re-enters the glass.
      // (Not available on Linux, where the margin simply stays small.)
      if (!IS_LINUX && widgetWindow && !widgetWindow.isDestroyed()) widgetWindow.setIgnoreMouseEvents(!!value, { forward: true });
      break;
    case "focus": focusWidget(); break;
    case "blur": widgetWindow?.blur(); break;
    case "openMain": setMode("app"); break;
    case "show": setMode("widget"); break;
    case "hide": setMode("hidden"); break;
    case "toggle": setMode("toggle"); break;
    case "setMode": setMode(String(value)); break;
    case "setOption": return setWidgetOption(value?.key, value?.value);
    case "setOnTop": return setWidgetOption("onTop", value);
    case "quit": quitApp(); break;
    case "getInfo": break;
    default: throw new Error(`Unknown widget action: ${action}`);
  }
  return widgetInfo();
});

// ---------------------------------------------------------------------------
// Power: the backend decides what "power saving" means; we only report the battery.
// ---------------------------------------------------------------------------
function reportPower() {
  try {
    const onBattery = powerMonitor.isOnBatteryPower();
    sendRequestToPython("power.report", { on_battery: onBattery }).catch(() => {});
  } catch { /* powerMonitor not available (some Linux setups): the backend keeps "unknown" */ }
}

// ---------------------------------------------------------------------------
// Commands from Troy itself (his app-control tools): handled here when they are
// window-level, forwarded to the renderers either way.
// ---------------------------------------------------------------------------
function handleUiCommand(cmd) {
  if (!cmd || typeof cmd !== "object") return;
  try {
    if (cmd.action === "mode") setMode(String(cmd.mode));
    else if (cmd.action === "widget_option") setWidgetOption(cmd.key, cmd.value);
    else if (cmd.action === "view" && mode !== "app") setMode("app");   // "open settings" means the full app
  } catch (err) { console.warn("ui.command failed:", err.message); }
}

// ---------------------------------------------------------------------------
// Window + tray
// ---------------------------------------------------------------------------
function quitApp() {
  isQuitting = true;
  app.quit();
}

function createTray() {
  if (tray) return;
  const iconPath = path.join(__dirname, "assets", "tray.png");
  if (!fs.existsSync(iconPath)) return;
  tray = new Tray(nativeImage.createFromPath(iconPath));
  applyTrayMenu();
  tray.on("click", () => (mode === "hidden" ? focusWidget() : setMode("toggle")));
}

function applyTrayMenu() {
  if (!tray) return;
  const x = TRAY_TEXT[activeLanguage()];
  tray.setToolTip(x.tip);
  tray.setContextMenu(Menu.buildFromTemplate([
    { label: x.ask, click: focusWidget },
    { label: x.open, click: () => setMode("app") },
    { label: x.hide, click: () => setMode("hidden") },
    { label: x.stop, click: () => sendRequestToPython("chat.stop", {}).catch(() => {}) },
    { type: "separator" },
    { label: x.quit, click: quitApp },
  ]));
}

function createWindow() {
  const saved = visibleBounds(prefs.bounds);
  mainWindow = new BrowserWindow({
    width: saved?.width ?? 1280,
    height: saved?.height ?? 820,
    x: saved?.x,
    y: saved?.y,
    minWidth: 760,
    minHeight: 520,
    show: false,                       // only ever shown by setMode("app") / ready-to-show below: never next to the widget
    backgroundColor: "#0b0e17",
    title: "Troy",
    icon: path.join(__dirname, "assets", "icon.png"),
    // Custom glass title bar: the renderer draws the drag region; on Windows and
    // Linux the OS paints only the min/max/close buttons on top of it.
    titleBarStyle: IS_MAC ? "hiddenInset" : "hidden",
    ...(IS_MAC
      ? { trafficLightPosition: { x: 16, y: 14 } }
      : { titleBarOverlay: { color: "#00000000", symbolColor: "#e6ebf5", height: 44 } }),
    webPreferences: {
      preload: path.join(__dirname, "preload.js"),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true,
      spellcheck: true,
    },
  });

  // NOTE: BrowserWindow.maximize() on a hidden window SHOWS it (documented Electron behaviour on
  // Windows). Calling it here, while the widget was the startup mode, put the full app on screen
  // right next to the widget whenever the last session ended maximized. It is applied in
  // showMainWindow() instead, i.e. only when the app is really meant to be visible.
  restoreMaximized = !!prefs.maximized;
  mainWindow.loadFile(path.join(__dirname, "renderer", "index.html"));
  // Startup: show the app as soon as it has painted (no white flash); the widget stays hidden.
  mainWindow.once("ready-to-show", () => { if (mode === "app") showMainWindow(); });

  // Links in chat output open in the real browser, never inside Troy; and the
  // window can never be navigated away from the bundled UI.
  mainWindow.webContents.setWindowOpenHandler(({ url }) => {
    if (/^https?:/i.test(url)) shell.openExternal(url);
    return { action: "deny" };
  });
  mainWindow.webContents.on("will-navigate", (event, url) => {
    if (!url.startsWith("file://")) {
      event.preventDefault();
      if (/^https?:/i.test(url)) shell.openExternal(url);
    }
  });

  const remember = () => {
    if (!mainWindow || mainWindow.isDestroyed() || mainWindow.isMinimized()) return;
    prefs.maximized = mainWindow.isMaximized();
    if (!prefs.maximized) prefs.bounds = mainWindow.getBounds();
    savePrefs();
  };
  let saveTimer = null;
  const rememberSoon = () => { clearTimeout(saveTimer); saveTimer = setTimeout(remember, 400); };
  mainWindow.on("resize", rememberSoon);
  mainWindow.on("move", rememberSoon);
  mainWindow.on("maximize", rememberSoon);
  mainWindow.on("unmaximize", rememberSoon);

  mainWindow.on("show", () => sendEventToMain("window.shown", {}));
  mainWindow.on("hide", () => sendEventToMain("window.hidden", {}));
  mainWindow.on("focus", () => sendEventToMain("window.focused", {}));

  // The close button never quits: it hands the screen back to the widget, so
  // wake-word listening and the widget keep working. Quit Troy lives in the
  // widget's menu and the tray menu.
  mainWindow.on("close", (event) => {
    if (isQuitting) return;
    event.preventDefault();
    setMode("widget");
  });
  mainWindow.on("closed", () => { mainWindow = null; });
}

if (app.hasSingleInstanceLock()) {
  app.whenReady().then(() => {
    loadPrefs();
    if (app.isPackaged) Menu.setApplicationMenu(null);
    startPythonBackend();
    createTray();
    createWindow();
    createWidget();
    const hk = registerWidgetHotkey();
    if (!hk.ok) console.warn(`Widget hotkey unavailable: ${hk.error}`);

    // Keep the widget centred when monitors are added/removed or the resolution changes.
    const refit = () => fitWidget(widgetSize.w, widgetSize.h);
    screen.on("display-metrics-changed", refit);
    screen.on("display-added", refit);
    screen.on("display-removed", refit);

    powerMonitor.on("on-battery", reportPower);
    powerMonitor.on("on-ac", reportPower);

    app.on("activate", () => { if (mode === "hidden") setMode("widget"); });
  });

  app.on("window-all-closed", () => {
    if (!IS_MAC) app.quit();
  });

  app.on("will-quit", () => globalShortcut.unregisterAll());

  app.on("before-quit", () => {
    isQuitting = true;
    const child = pythonProcess;
    pythonProcess = null;
    if (child && child.exitCode === null) child.kill();
  });
}
