// Exposes a small, safe `window.troy` API to the renderer. contextIsolation is
// on and nodeIntegration is off (see main.js), so this contextBridge call is the
// ONLY way the renderer can reach the backend or the OS.
//
//   window.troy.request(method, params) -> Promise<result>
//       Calls a backend method (see README.md / troy/ipc_host.py). Rejects if the
//       backend returns ok:false or the call times out.
//   window.troy.on(eventName, callback) -> unsubscribe function
//       Subscribes to a push event. Several listeners per event are fine.
//   window.troy.off(eventName, callback)
//   window.troy.window(action, value) -> Promise<prefs>
//       Shell actions: minimize | toggleMaximize | hide | show | quit |
//       setAlwaysOnTop(bool) | setCloseToTray(bool) | setTheme(symbolColor) |
//       restartBackend | reload | devtools | getPrefs
//       Always resolves with {alwaysOnTop, closeToTray, maximized, visible,
//       platform, version, electron, packaged, python}.
//   window.troy.widget(action, value) -> Promise<{enabled, onTop, visible, platform, size}>
//       Used by the always-on-top widget window: fit({w,h}) | passthrough(bool) |
//       focus | blur | openMain | hide | show | toggle | setOnTop(bool) | quit | getInfo
//   window.troy.openExternal(url) -> Promise<boolean>   (http/https only)
//   window.troy.platform -> "win32" | "darwin" | "linux"

const { contextBridge, ipcRenderer } = require("electron");

const listeners = new Map(); // eventName -> Set<callback>

ipcRenderer.on("troy:event", (_event, { event, data }) => {
  const callbacks = listeners.get(event);
  if (!callbacks) return;
  for (const callback of [...callbacks]) {
    try {
      callback(data);
    } catch (err) {
      console.error(`troy event listener for '${event}' threw:`, err);
    }
  }
});

contextBridge.exposeInMainWorld("troy", {
  platform: process.platform,

  request: (method, params) => ipcRenderer.invoke("troy:request", { method, params }),

  on: (eventName, callback) => {
    if (!listeners.has(eventName)) listeners.set(eventName, new Set());
    listeners.get(eventName).add(callback);
    return () => listeners.get(eventName)?.delete(callback);
  },

  off: (eventName, callback) => {
    listeners.get(eventName)?.delete(callback);
  },

  window: (action, value) => ipcRenderer.invoke("troy:window", { action, value }),

  widget: (action, value) => ipcRenderer.invoke("troy:widget", { action, value }),

  openExternal: (url) => ipcRenderer.invoke("troy:external", url),
});
