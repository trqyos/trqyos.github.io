// Opens the UI against the built-in demo backend (no Python, no keys): handy for
// restyling the interface. Run with: npm run demo
const { app, BrowserWindow } = require("electron");
const path = require("path");
app.whenReady().then(() => {
  const win = new BrowserWindow({ width: 1280, height: 820, backgroundColor: "#070911", webPreferences: { contextIsolation: true } });
  win.loadFile(path.join(__dirname, "..", "renderer", "index.html"));
});
app.on("window-all-closed", () => app.quit());
