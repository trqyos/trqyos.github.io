// Opens ONLY the widget, docked top-centre like the real thing, against the demo
// backend (no Python, no keys): handy for restyling it. Run with: npm run demo:widget
const { app, BrowserWindow, screen } = require("electron");
const path = require("path");
app.whenReady().then(() => {
  const wa = screen.getPrimaryDisplay().workArea;
  const win = new BrowserWindow({
    width: 656, height: 520, x: Math.round(wa.x + (wa.width - 656) / 2), y: wa.y,
    frame: false, transparent: true, backgroundColor: "#00000000", hasShadow: false, alwaysOnTop: true,
    webPreferences: { contextIsolation: true, sandbox: false },
  });
  win.loadFile(path.join(__dirname, "..", "renderer", "widget", "widget.html"));
});
app.on("window-all-closed", () => app.quit());
