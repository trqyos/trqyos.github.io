// End-to-end UI smoke test. Loads the real renderer in Electron against the
// built-in demo backend (renderer/mock-backend.js) and drives it like a user.
//   npm run test:ui          (on Linux CI: xvfb-run -a npm run test:ui)
// Exits 0 when every check passes, 1 otherwise.
const { app, BrowserWindow } = require("electron");
const path = require("path");
app.disableHardwareAcceleration();
app.setPath("userData", path.join(require("os").tmpdir(), `troy-ui-test-${Date.now()}`));

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const results = [];
const check = (name, ok, extra = "") => { results.push({ name, ok: !!ok }); console.log(`${ok ? "PASS" : "FAIL"}  ${name}${ok ? "" : `  ${extra}`}`); };

app.whenReady().then(async () => {
  const win = new BrowserWindow({ width: 1280, height: 820, show: false, webPreferences: { contextIsolation: true, sandbox: false } });
  const pageErrors = [];
  win.webContents.on("console-message", (_e, level, msg) => { if (level >= 3) pageErrors.push(msg); });
  win.webContents.on("render-process-gone", () => { console.log("renderer crashed"); process.exit(1); });
  await win.loadFile(path.join(__dirname, "..", "renderer", "index.html"));
  const js = (code) => win.webContents.executeJavaScript(code);
  const $ = (sel) => js(`!!document.querySelector(${JSON.stringify(sel)})`);
  const text = (sel) => js(`document.querySelector(${JSON.stringify(sel)})?.textContent ?? null`);
  const count = (sel) => js(`document.querySelectorAll(${JSON.stringify(sel)}).length`);
  const until = async (fn, ms = 8000) => { const end = Date.now() + ms; while (Date.now() < end) { if (await fn()) return true; await sleep(100); } return false; };
  // Clicks wait for the element first: panes and lists render asynchronously.
  const click = async (sel) => { if (!(await until(() => $(sel), 4000))) throw new Error(`Element never appeared: ${sel}`); return js(`document.querySelector(${JSON.stringify(sel)}).click()`); };
  const type = (sel, v) => js(`(()=>{const e=document.querySelector(${JSON.stringify(sel)}); e.value=${JSON.stringify(v)}; e.dispatchEvent(new Event('input',{bubbles:true})); e.dispatchEvent(new Event('change',{bubbles:true}));})()`);
  const send = async (t) => { await type("#inp", t); await click("#sendBtn"); };

  try {
    check("boots and reports the backend ready", await until(() => js("window.__troyReady === true")) && (await text("#statePill span")) === "Ready");
    check("sessions are listed and grouped", (await count("#sessions .sess")) === 2 && (await count("#sessions .sgrp")) >= 1);
    check("empty state shows suggestions and the user's name", (await count(".s-card")) === 6 && (await text(".empty h2")).includes("Alex"));
    check("avatar canvas has a size", await js("(()=>{const c=document.getElementById('face');return c.width>50&&c.height>50})()"));
    check("header shows the primary provider", (await text("#modelLabel")).includes("NVIDIA NIM"));

    // --- a normal turn
    await send("What's the weather forecast for London?");
    check("user bubble appears immediately", (await count(".msg.user")) === 1);
    check("busy state shows the stop button", await until(async () => !(await js("document.getElementById('stopBtn').classList.contains('hidden')"))));
    check("tool steps are grouped", await until(async () => (await count(".steps")) === 1 && (await count(".step.ok")) === 1));
    check("assistant reply renders markdown", await until(async () => (await count(".msg.assistant li")) === 3 && (await count(".msg.assistant strong")) >= 1));
    check("turn completes and stop hides", await until(() => js("document.getElementById('stopBtn').classList.contains('hidden')")));
    check("new chat gets an auto title in the sidebar", await until(async () => (await count("#sessions .sess")) === 3) && (await text("#sessionTitle")).startsWith("What's the weather"));
    check("caption flattened the list for the avatar", !(await text("#caption")).includes("- Mon"));

    // --- failures render as failed steps
    await send("make it fail");
    check("failed tool is marked", await until(async () => (await count(".step.fail")) === 1));
    await until(() => js("document.getElementById('stopBtn').classList.contains('hidden')"));

    // --- approvals
    await send("please delete my old report");
    check("approval card appears", await until(() => $(".conf")));
    await click('.conf [data-ok="0"]');
    check("denying removes the card", await until(async () => !(await $(".conf"))));
    await until(() => js("document.getElementById('stopBtn').classList.contains('hidden')"));

    // --- slash commands and palette
    await type("#inp", "/re");
    check("slash menu filters commands", (await count("#slash .it")) === 1 && !(await js("document.getElementById('slash').classList.contains('hidden')")));
    await type("#inp", "");
    await js("document.getElementById('slash').classList.add('hidden')");
    await js("document.dispatchEvent(new KeyboardEvent('keydown',{key:'k',ctrlKey:true,bubbles:true}))");
    check("Ctrl+K opens the command palette", await until(() => $(".palette")));
    await type(".palette input", "model");
    check("palette filters and offers 'Ask Troy'", (await count(".palette .it")) >= 2 && (await js("[...document.querySelectorAll('.palette .it')].pop().textContent")).includes("Ask Troy"));
    await js("document.querySelector('.palette input').dispatchEvent(new KeyboardEvent('keydown',{key:'Escape',bubbles:true}))");
    check("Escape closes the palette", await until(async () => !(await $(".palette"))));

    // --- model picker
    await click("#modelBtn");
    check("model picker lists NVIDIA models", await until(() => $(".pop .it")) && (await js("[...document.querySelectorAll('.pop .it')].some(e=>e.textContent.includes('z-ai/glm-5.3'))")));
    await js("[...document.querySelectorAll('.pop .it')].find(e=>e.textContent.includes('z-ai/glm-5.3-flash')).click()");
    check("picking a model pins it", await until(async () => (await text("#modelLabel")).includes("z-ai/glm-5.3-flash")));

    // --- layouts and theme
    await click('#modeSeg [data-mode="focus"]');
    check("focus mode hides the transcript", await js("getComputedStyle(document.getElementById('messages')).display") === "none");
    await click('#modeSeg [data-mode="chat"]');
    check("chat-only hides the avatar", await js("getComputedStyle(document.getElementById('avatarCard')).display") === "none");
    await click('#modeSeg [data-mode="split"]');
    const dark = await js("document.body.classList.contains('theme-dark')");
    await click("#themeBtn");
    check("theme toggles", (await js("document.body.classList.contains('theme-dark')")) !== dark);

    // --- memory
    await click('#nav [data-view="memory"]');
    check("memory lists facts", await until(async () => (await count("#memList .item")) === 2));
    await type("#memIn", "Likes jazz"); await click("#memAdd");
    check("memory add", await until(async () => (await count("#memList .item")) === 3));
    await type("#memQ", "jazz");
    check("memory filter", await until(async () => (await count("#memList .item")) === 1));
    await type("#memQ", "");
    await click("#memList [data-del]");
    check("memory delete", await until(async () => (await count("#memList .item")) === 2));

    // --- tools
    await click('#nav [data-view="tools"]');
    check("tools render with categories", await until(async () => (await count("#toolList .tool-card")) === 11 && (await count("#toolCats .chip")) >= 4));
    await type("#toolQ", "currency");
    check("tool search", await until(async () => (await count("#toolList .tool-card")) === 1));
    check("risky tools are flagged", (await js("document.querySelectorAll('.badge.warn').length")) === 0);
    await type("#toolQ", "");
    check("approval badge shown for risky tools", await until(async () => (await js("document.querySelectorAll('#toolList .badge.warn').length")) === 2));

    // --- logs
    await click('#nav [data-view="logs"]');
    check("logs render with level styling", await until(async () => (await count("#logOut .ll.INFO")) >= 1 && (await count("#logOut .ll.WARNING")) === 1));
    await click('#logLvl [data-v="ERROR"]');
    check("log level filter", await until(async () => (await count("#logOut .ll.INFO")) === 0));

    // --- settings
    await click('#nav [data-view="settings"]');
    check("provider cards render", await until(async () => (await count(".prov")) === 5));
    check("configured provider shows ready", (await js("document.querySelector('.prov[data-p=nvidia] .badge').textContent")).includes("ready"));
    await type('.prov[data-p="groq"] input[data-key]', "gsk_test_key_123");
    await click('.prov[data-p="groq"] [data-act="savekey"]');
    check("saving a key flips the provider to ready", await until(async () => (await js("document.querySelector('.prov[data-p=groq] .badge')?.textContent || ''")).includes("ready")));
    await click('.prov[data-p="groq"] [data-act="fetch"]');
    check("fetching models lists them", await until(async () => (await count('.prov[data-p="groq"] .fm')) >= 3));
    await click('#setNav [data-pane="models"]');
    check("models pane has text + vision selects", await until(async () => (await count("#setPane select[data-model]")) === 2));
    await click('#setNav [data-pane="general"]');
    check("general pane renders and persists a name", await until(() => $('[data-set="USER_NAME"]')));
    await type('[data-set="USER_NAME"]', "Sam");
    await sleep(300);
    await click('#setNav [data-pane="appearance"]');
    await click('[data-accent="rose"]');
    check("accent colour changes", (await js("getComputedStyle(document.body).getPropertyValue('--acc').trim()")) === "#ff7aa8");
    await click('#setNav [data-pane="voice"]');
    check("voice pane lists voices", await until(async () => (await count('select[data-set="TTS_VOICE_ID"] option')) === 3));
    check("voice pane has engine, mic and conversation settings", await until(async () =>
      $('[data-set="TTS_ENGINE"]') && $('[data-set="VOICE_INPUT_DEVICE"]') && $('[data-set="VOICE_BARGE_IN"]') &&
      $('[data-set="VOICE_CONVERSATION_IDLE_SECONDS"]') && $('[data-set="VOICE_SPOKEN_STYLE"]') && $('[data-act="test-mic"]')));

    // --- full voice mode overlay (troy/voice_mode.py behind it)
    await click('#nav [data-view="chat"]');
    await click("#voiceModeBtn");
    check("voice mode starts and shows the overlay", await until(() => js("!document.getElementById('voiceOverlay').classList.contains('hidden')")));
    check("the header button lights up", await js("document.getElementById('voiceModeBtn').classList.contains('on')"));
    check("the state chip says listening", await until(async () => (await text("#vChip span")) === "Listening…"));
    await js("window.troy.__emit('voice.state', {active: true, state: 'thinking', muted: false})");
    check("voice.state events drive the chip", await until(async () => (await text("#vChip span")) === "Thinking…"));
    await js("window.troy.__emit('voice.transcript', {text: 'what time is it', source: 'pc'})");
    check("live transcripts appear with their source", await until(async () => (await text("#vTranscript p.you")) === "(PC) what time is it"));
    await js("window.troy.__emit('voice.level', {level: 90000, state: 'listening'})");
    check("the mic level bar fills", await until(async () => (await js("document.getElementById('vLevel').querySelector('i').style.width")) !== "0%" && (await js("document.getElementById('vLevel').querySelector('i').style.width")) !== ""));
    await js("window.troy.__emit('voice.state', {active: true, state: 'listening', muted: true})");
    check("muting flips the chip and the mute button", await until(async () => (await text("#vChip span")) === "Muted" && (await text("#vMuteBtn")) === "Unmute"));
    await click("#vMuteBtn");
    check("unmute asks the backend and reflects it", await until(async () => (await text("#vMuteBtn")) === "Mute"));
    await click("#vEndBtn");
    check("End closes the overlay", await until(() => js("document.getElementById('voiceOverlay').classList.contains('hidden')")));
    check("the header button resets", await until(async () => !(await js("document.getElementById('voiceModeBtn').classList.contains('on')"))));
    await js("document.dispatchEvent(new KeyboardEvent('keydown', {key: 'v', ctrlKey: true, shiftKey: true, bubbles: true}))");
    check("Ctrl+Shift+V also starts voice mode", await until(() => js("!document.getElementById('voiceOverlay').classList.contains('hidden')")));
    await js("window.troy.__emit('voice.ended', {reason: 'goodbye'})");
    check("saying goodbye closes voice mode with a toast", await until(async () => ((await text(".toast")) || "").toLowerCase().includes("goodbye") && (await js("document.getElementById('voiceOverlay').classList.contains('hidden')"))));
    // --- speed pane
    await click('#setNav [data-pane="performance"]');
    check("speed pane reports the compact prompt", await until(async () => ((await text("#setPane .row .lab")) || "").includes("Compact") || (await text("#setPane")).includes("Compact")));
    await type('[data-set="CONTEXT_BUDGET_TOKENS"]', "4000");
    check("context budget saves", await until(() => js("window.troy.request('settings.get',{}).then(r=>r.values.CONTEXT_BUDGET_TOKENS===4000)")));

    // --- models pane: local vision models
    await click('#setNav [data-pane="models"]');
    await js("window.troy.request('settings.update',{changes:{LMSTUDIO_ENABLED:true}})");
    await click('#setNav [data-pane="providers"]'); await click('#setNav [data-pane="models"]');
    check("LM Studio block lists vision models with tags", await until(async () => (await text("#setPane")).includes("qwen2.5-vl-7b-instruct · vision · loaded · 8k ctx")));
    check("vision select only offers vision models", (await js("[...document.querySelectorAll('[data-set=LMSTUDIO_VISION_MODEL] option')].map(o=>o.value).filter(Boolean).join()")) === "qwen2.5-vl-7b-instruct");
    await js("(()=>{const s=document.querySelector('[data-set=LMSTUDIO_VISION_MODEL]'); s.value='qwen2.5-vl-7b-instruct'; s.dispatchEvent(new Event('change',{bubbles:true}));})()");
    check("choosing a local vision model saves", await until(() => js("window.troy.request('settings.get',{}).then(r=>r.values.LMSTUDIO_VISION_MODEL==='qwen2.5-vl-7b-instruct')")));

    // --- general: app launching
    await click('#setNav [data-pane="general"]');
    check("app launch mode select present", await until(() => $('[data-set="APP_LAUNCH_MODE"]')));
    await js("(()=>{const s=document.querySelector('[data-set=APP_LAUNCH_MODE]'); s.value='direct'; s.dispatchEvent(new Event('change',{bubbles:true}));})()");
    check("launch mode saves", await until(() => js("window.troy.request('settings.get',{}).then(r=>r.values.APP_LAUNCH_MODE==='direct')")));
    await type("#appTest", "spotify"); await click('[data-act="app-test"]');
    check("app test reports success as a toast", await until(async () => ((await text(".toast")) || "").includes("Opened 'spotify' directly")));

    // --- integrations: YouTube OAuth flow
    await click('#setNav [data-pane="integrations"]');
    check("connect is disabled until credentials exist", await until(() => js("document.querySelector('[data-act=yt-connect]')?.disabled === true")));
    await type('[data-set="YOUTUBE_CLIENT_ID"]', "123-abc.apps.googleusercontent.com");
    await until(() => $('[data-key="YOUTUBE_CLIENT_SECRET"]'));
    await type('[data-key="YOUTUBE_CLIENT_SECRET"]', "GOCSPX-secret"); await click('[data-yt] [data-act="savekey"]');
    check("with id + secret saved, Connect is enabled", await until(() => js("document.querySelector('[data-act=yt-connect]')?.disabled === false")));
    await click('[data-act="yt-connect"]');
    check("connect shows the waiting state with a paste fallback", await until(() => $("#ytPaste")));
    await type("#ytPaste", "http://127.0.0.1:5555/callback?code=x&state=y"); await click('[data-act="yt-paste"]');
    check("pasting the redirect completes the sign-in", await until(async () => ((await text("[data-yt]")) || "").includes("Signed in as Alex")));
    await click('[data-act="yt-test"]');
    check("test shows the latest liked video and its link", await until(async () => ((await text("#ytTest")) || "").includes("Lo-fi beats to study to") && ((await text("#ytTest")) || "").includes("watch?v=")));
    await click('[data-act="yt-disconnect"]'); await click(".modal [data-a=ok]");
    check("disconnect returns to the connect state", await until(() => $('[data-act="yt-connect"]')));

    // --- phone page, Tailscale
    await click('#setNav [data-pane="remote"]');
    await click('[data-act="mobile"]');
    check("phone page start lists Tailscale and Wi-Fi links", await until(async () => (await count(".urlrow")) === 2 && ((await text(".urlrow.rec")) || "").includes("100.64.0.5")));
    check("the Tailscale link is marked best", ((await text(".urlrow.rec")) || "").includes("best"));
    check("tailscale peers are listed", (await text("#setPane")).includes("pixel-8"));
    await click('[data-act="ts-serve"]');
    check("HTTPS option adds the secure link as best", await until(async () => ((await text(".urlrow.rec")) || "").includes("https://desktop.tail1234.ts.net")));
    await js("window.troy.__emit('mobile_ui.viewers', {count: 1})");
    check("a watching phone shows a notice chip", await until(() => js("!document.getElementById('viewerChip').classList.contains('hidden')")));
    await js("window.troy.__emit('mobile_ui.viewers', {count: 0})");
    check("the chip goes away again", await until(() => js("document.getElementById('viewerChip').classList.contains('hidden')")));
    await click('#setNav [data-pane="about"]');
    check("about pane shows the version", await until(async () => ((await text(".kv dd")) || "").includes("TROYOS")));

    // --- search: titles, messages, and find-in-chat
    await click('#nav [data-view="chat"]');
    await type("#sessQ", "firefox");
    check("sidebar search finds messages inside chats", await until(async () => (await count("#sessions .sres")) >= 1 && (await count("#sessions .sres .h mark")) >= 1));
    await type("#sessQ", "convert");
    check("title matches are highlighted too", await until(async () => ((await js("document.querySelector('#sessions .sres b mark')?.textContent || ''")).toLowerCase() === "convert")));
    await type("#sessQ", "carrot-unicorn");
    check("no match says so", await until(async () => ((await text("#sessions .side-empty")) || "").includes("No chats or messages match")));
    await type("#sessQ", "ecb");
    await until(() => $("#sessions .sres .h"));
    await js("document.querySelector('#sessions .sres .h').click()");
    check("clicking a hit opens the chat, opens the step and highlights the text", await until(async () => (await count("#messages mark.hit")) >= 1 && (await js("document.querySelector('.steps details').open")) === true));
    await js("document.getElementById('sessQ').dispatchEvent(new KeyboardEvent('keydown',{key:'Escape'}))");
    check("Escape clears the search", await until(async () => (await count("#sessions .sess")) >= 3));
    await js("window.dispatchEvent(new KeyboardEvent('keydown',{key:'f',ctrlKey:true}))");
    check("Ctrl+F opens find-in-chat", await until(() => js("!document.getElementById('findBar').classList.contains('hidden')")));
    await type("#findIn", "usd");
    check("find counts matches", await until(async () => /^1\/\d+$/.test((await text("#findCount")) || "")));
    await js("document.getElementById('findClose').click()");
    check("closing find removes the highlights", await until(async () => (await count("#messages mark.hit")) === 0));

    // --- new chat + load old chat
    await click('#nav [data-view="chat"]');
    await click("#newChat");
    check("new chat clears the transcript", await until(async () => (await count(".empty")) === 1 && (await text("#sessionTitle")) === "New chat"));
    await js("document.querySelector('#sessions .sess[data-id=\"s-demo-2\"]').click()");
    check("opening a saved chat restores it", await until(async () => (await count(".msg")) === 2 && (await count(".steps")) === 1));
    // --- redesign leftovers: no pin button, no hotkey / tray options in General
    check("the keep-on-top pin button is gone from the title bar", !(await $("#pinBtn")));
    await click('#nav [data-view="settings"]'); await click('#setNav [data-pane="general"]');
    check("General no longer has keep-on-top, tray or hotkey options", await until(async () => (await $("#setPane .row")) && !/Keep on top|hides to the tray|Global hotkey/i.test(await text("#setPane"))));

    // --- Settings > Widget
    await click('#setNav [data-pane="widget"]');
    check("Widget pane shows the shortcut, always-on-top and auto-collapse", await until(async () => (await $("#wHotkey")) && (await count('[data-widget]')) === 2));
    check("shortcut is shown in a friendly form", (await js("document.getElementById('wHotkey').value")) === "Ctrl+Alt+T");
    await js("(()=>{const i=document.getElementById('wHotkey'); i.value='Ctrl+Alt+K'; i.dispatchEvent(new Event('change',{bubbles:true}));})()");
    check("changing the shortcut reaches the shell", await until(() => js("window.troy.__widgetCalls.some(c => c.action === 'setOption' && c.value.key === 'hotkey' && c.value.value === 'Ctrl+Alt+K')")));
    await js("(()=>{const i=document.querySelector('[data-widget=\"onTop\"]'); i.checked=false; i.dispatchEvent(new Event('change',{bubbles:true}));})()");
    check("the always-on-top switch reaches the shell", await until(() => js("window.troy.__widgetCalls.some(c => c.action === 'setOption' && c.value.key === 'onTop' && c.value.value === false)")));
    await click("[data-act='to-widget']");
    check("'Switch to the widget' asks the shell to show the widget", await until(() => js("window.troy.__widgetCalls.some(c => c.action === 'show')")));
    await click("#widgetBtn");
    check("the title-bar Widget button does the same", await until(() => js("window.troy.__widgetCalls.filter(c => c.action === 'show').length >= 2")));

    // --- Settings > Power + the calm look
    await click('#setNav [data-pane="power"]');
    check("Power pane has Off / Auto / On, Auto selected", await until(async () => (await count("[data-power-seg] button")) === 3 && (await js("document.querySelector('[data-power-seg] .on').dataset.v")) === "auto"));
    await click('[data-power-seg] [data-v="on"]');
    check("choosing On activates power saving everywhere", await until(() => js("document.body.classList.contains('saver') && window.troy && true")));
    check("the avatar is told to save power", await js("document.body.classList.contains('saver')"));
    await click('[data-power-seg] [data-v="auto"]');
    check("Auto on mains power turns the calm look off again", await until(() => js("!document.body.classList.contains('saver')")));
    await js("window.troy.__emit('power.state', { mode: 'auto', on_battery: true, active: true })");
    check("running on battery (Auto) turns it on by itself", await until(() => js("document.body.classList.contains('saver')")));
    await js("window.troy.__emit('power.state', { mode: 'auto', on_battery: false, active: false })");

    // --- Troy driving his own app (ui.command from the tools)
    await js("window.troy.__emit('ui.command', { action: 'appearance', key: 'theme', value: 'light' })");
    check("Troy can switch the theme", await until(() => js("document.body.classList.contains('theme-light')")));
    await js("window.troy.__emit('ui.command', { action: 'appearance', key: 'accent', value: 'rose' })");
    check("...the accent colour", await until(() => js("getComputedStyle(document.body).getPropertyValue('--acc').trim() === '#ff7aa8'")));
    await js("window.troy.__emit('ui.command', { action: 'appearance', key: 'layout', value: 'focus' })");
    check("...and the layout", await until(() => js("document.body.dataset.mode === 'focus'")));
    await js("window.troy.__emit('ui.command', { action: 'appearance', key: 'theme', value: 'dark' })");
    await js("window.troy.__emit('ui.command', { action: 'appearance', key: 'layout', value: 'split' })");
    await js("window.troy.__emit('ui.command', { action: 'view', view: 'memory' })");
    check("Troy can open a screen", await until(() => js("document.body.dataset.view === 'memory'")));
    await js("window.troy.__emit('ui.command', { action: 'view', view: 'settings', pane: 'voice' })");
    check("...and a settings pane", await until(async () => (await js("document.body.dataset.view")) === "settings" && (await js("document.querySelector('#setNav .on').dataset.pane")) === "voice"));
    await click('#nav [data-view="chat"]');
    await js("window.troy.__emit('ui.command', { action: 'new_chat' })");
    check("Troy can start a new chat", await until(async () => (await count(".empty")) === 1 && (await text("#sessionTitle")) === "New chat"));

    // --- scheduled tasks
    check("nav has a Tasks button with the active count", (await text('#nav [data-view="tasks"] span')) === "Tasks" && await until(async () => (await text("#taskCount")) === "2"));
    check("chats that created tasks carry the task icon in the sidebar", await until(async () => (await count("#sessions .sess.has-tasks .tk")) === 1));
    await js("document.dispatchEvent(new KeyboardEvent('keydown',{key:'6',ctrlKey:true,bubbles:true}))");
    check("Ctrl+6 opens Tasks", await until(() => js("document.body.dataset.view === 'tasks'")));
    check("active tasks are listed with their schedule", await until(async () => (await count("#taskList .task")) === 2) && (await text("#taskList .task .when")).includes("Every"));
    check("each task links to the chat that created it", (await count("#taskList .task [data-a='chat']")) === 2 && (await text("#taskList .task [data-a='chat'] span")).length > 3);
    check("a refused command shows an Approve button", (await count("#taskList .approval [data-a='approve']")) === 1 && (await text("#taskList .approval")).includes("run_shell_command"));
    await click("#taskList .approval [data-a='approve']");
    check("approving runs it and the card clears", await until(async () => (await count("#taskList .approval")) === 0, 6000));
    check("the result is announced", await until(async () => (await count("#toasts .toast")) >= 1));
    check("a task note was added to that chat (not the open one)", await js("true"));
    await click("#taskList .task:first-child [data-a='chat']");
    check("the chat link opens the chat that created the task", await until(async () => (await js("document.body.dataset.view")) === "chat" && (await text("#sessionTitle")).includes("Open Firefox")));
    check("...and that chat shows the task-creation step with the task mark", await until(async () => (await count(".step .nm-task")) === 1));
    await click('#nav [data-view="tasks"]');
    await click("#taskNew");
    check("New task opens a form", await until(() => $(".tform")));
    await type("#tfWhen", "whenever");
    check("an unreadable time is explained live", await until(async () => (await count(".tform .pv.bad")) === 1));
    await type("#tfWhen", "every day at 22:00");
    check("a readable time is previewed with the next runs", await until(async () => (await count(".tform .pv.ok")) === 1) && (await text(".tform .pv")).includes("Every day at 22:00"));
    await type("#tfPrompt", "Put the computer to sleep.");
    await type("#tfApprove", "sleep_computer");
    await click(".tform [data-a='ok']");
    check("creating adds the task to the list", await until(async () => (await count("#taskList .task")) === 3));
    check("pre-approved commands are shown on the card", (await text("#taskList")).includes("Pre-approved to run unattended"));
    await click("#taskFilter [data-v='finished']");
    check("Finished shows the completed task", await until(async () => (await count("#taskList .task")) === 1) && (await text("#taskList .badge.ok")).includes("Done"));
    await click("#taskClear");
    await click(".modal [data-a='ok']");
    check("Clear finished removes it", await until(async () => (await count("#taskList .task")) === 0 && (await count("#taskList .placeholder")) === 1));
    await click("#taskFilter [data-v='active']");
    await until(async () => (await count("#taskList .task")) === 3);
    await click("#taskList .task:last-child [data-a='pause']");
    check("pausing marks the task paused", await until(async () => (await count("#taskList .task .badge")) >= 3 && (await js("[...document.querySelectorAll('#taskList .badge')].some(b => b.textContent === 'Paused')"))));
    await click("#taskList .task:last-child [data-a='cancel']");
    await click(".modal [data-a='ok']");
    check("cancelling needs a confirmation and moves it to Finished", await until(async () => (await count("#taskList .task")) === 2));
    await click("#taskList .task [data-a='log']");
    check("the log can be expanded", await until(async () => (await count("#taskList .tlog")) === 1 && (await text("#taskList .tlog")).includes("created")));
    await click('#nav [data-view="chat"]');
    await click("#newChat");
    await until(async () => (await count(".empty")) === 1);
    await send("remind me to stretch every day at 9");
    check("asking Troy to schedule shows the task mark on the step", await until(async () => (await count(".step .nm-task")) === 1, 8000));
    check("...and the new chat gets the task icon", await until(async () => (await count("#sessions .sess.has-tasks .tk")) === 2, 8000));
    await until(() => js("document.getElementById('stopBtn').classList.contains('hidden')"));
    await js("window.troy.__emit('task.finished', { task: { id: 'x', title: 'Demo', status: 'completed', schedule_text: 'Every day', prompt: 'p', grants: [], needs_approval: [] }, ok: true, text: 'Scheduled task \u201CDemo\u201D is done: ok', in_current_chat: true, entry: { role: 'task', text: 'Scheduled task \u201CDemo\u201D is done: ok', task_id: 'x', ok: true } })");
    check("a finished task reports back inside its chat", await until(async () => (await count(".msg.task-note")) === 1));
    await js("window.troy.__emit('ui.command', { action: 'view', view: 'tasks' })");
    check("Troy can open the Tasks screen", await until(() => js("document.body.dataset.view === 'tasks'")));
    await click('#nav [data-view="chat"]');

    // --- new avatar expressions
    check("the avatar knows its new expressions", await js("NovaFace.EXPRESSIONS.join() === 'wink,curious,proud' && NovaFace.STATES.length === 9"));

    check("no uncaught page errors", pageErrors.length === 0, pageErrors.join(" | "));
  } catch (e) {
    check("test run completed without throwing", false, e.stack || e.message);
  }

  const failed = results.filter((r) => !r.ok).length;
  console.log(`\n${results.length - failed}/${results.length} checks passed`);
  app.exit(failed ? 1 : 0);
});
