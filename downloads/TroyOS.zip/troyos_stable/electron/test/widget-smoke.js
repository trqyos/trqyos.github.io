// Widget smoke test. Loads renderer/widget/widget.html in Electron against the
// demo backend (renderer/mock-backend.js) and drives it like a user.
//   npm run test:widget       (on Linux CI: xvfb-run -a npm run test:widget)
// Exits 0 when every check passes, 1 otherwise.
const { app, BrowserWindow } = require("electron");
const path = require("path");
app.disableHardwareAcceleration();
app.setPath("userData", path.join(require("os").tmpdir(), `troy-widget-test-${Date.now()}`));

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const results = [];
const check = (name, ok, extra = "") => { results.push({ name, ok: !!ok }); console.log(`${ok ? "PASS" : "FAIL"}  ${name}${ok ? "" : `  ${extra}`}`); };

app.whenReady().then(async () => {
  const win = new BrowserWindow({ width: 760, height: 620, show: false, webPreferences: { contextIsolation: true, sandbox: false, backgroundThrottling: false } });
  const pageErrors = [];
  win.webContents.on("console-message", (_e, level, msg) => { if (level >= 3) pageErrors.push(msg); });
  win.webContents.on("render-process-gone", () => { console.log("renderer crashed"); process.exit(1); });
  await win.loadFile(path.join(__dirname, "..", "renderer", "widget", "widget.html"));
  const js = (code) => win.webContents.executeJavaScript(code);
  const $ = (sel) => js(`!!document.querySelector(${JSON.stringify(sel)})`);
  const text = (sel) => js(`document.querySelector(${JSON.stringify(sel)})?.textContent ?? null`);
  const count = (sel) => js(`document.querySelectorAll(${JSON.stringify(sel)}).length`);
  const attr = (sel, a) => js(`document.querySelector(${JSON.stringify(sel)})?.getAttribute(${JSON.stringify(a)})`);
  const until = async (fn, ms = 8000) => { const end = Date.now() + ms; while (Date.now() < end) { if (await fn()) return true; await sleep(100); } return false; };
  const click = async (sel) => { if (!(await until(() => $(sel), 4000))) throw new Error(`Element never appeared: ${sel}`); return js(`document.querySelector(${JSON.stringify(sel)}).click()`); };
  const fits = () => js("window.troy.__widgetCalls.filter(c => c.action === 'fit').map(c => c.value)");
  const emit = (ev, d) => js(`window.troy.__emit(${JSON.stringify(ev)}, ${JSON.stringify(d || {})})`);
  const isOpen = () => attr("#glass", "data-open");

  try {
    check("boots, backend ready, status reads Ready.", await until(() => js("window.__widgetReady === true")) && (await text("#status")) === "Ready.");
    check("status dot is green (idle)", (await attr("#dot", "data-s")) === "idle");
    check("avatar canvas has a size and a live face", await js("(() => { const c = document.getElementById('face'); return c.width > 50 && c.height > 50 && !!window.__widget.face; })()"));
    check("starts compact (panel closed)", (await isOpen()) === "0");
    check("input has the placeholder", (await attr("#inp", "placeholder")).startsWith("Ask me anything"));

    // --- typing shows the send button
    await js("(() => { const i = document.getElementById('inp'); i.value = 'hello'; i.dispatchEvent(new Event('input', { bubbles: true })); })()");
    check("typing reveals the send button", await js("document.getElementById('field').classList.contains('has-text')"));
    await js("(() => { const i = document.getElementById('inp'); i.value = ''; i.dispatchEvent(new Event('input', { bubbles: true })); })()");

    // --- a normal turn
    await js("window.__widget.send('What is the weather forecast for London?')");
    check("panel opens and the user bubble appears", await until(async () => (await isOpen()) === "1" && (await count(".msg.user")) === 1));
    check("status flips to a working state", await until(async () => ["thinking", "executing"].includes(await attr("#glass", "data-state"))));
    check("stop button shows while busy", await until(() => js("getComputedStyle(document.getElementById('stopBtn')).display !== 'none'")));
    check("tool step chip appears", await until(async () => (await count(".step.ok")) === 1));
    check("reply renders markdown", await until(async () => (await count(".msg.troy li")) === 3 && (await count(".msg.troy strong")) >= 1));
    check("turn completes, stop hides", await until(() => js("getComputedStyle(document.getElementById('stopBtn')).display === 'none'")));
    const grew = await fits();
    check("window was asked to grow before the glass opened", grew.some((f) => f.h > 200 && f.w > 600), JSON.stringify(grew));

    // --- activity view
    await click("#termBtn");
    check("activity view lists the tool call", await until(async () => (await $("#viewAct:not([hidden])")) && (await js("document.getElementById('activity').textContent.includes('get_weather_forecast')"))));

    // --- menu
    await click("#gearBtn");
    check("menu view opens", await until(() => $("#viewMenu:not([hidden])")));
    await click('[data-act="onTop"]');
    check("always-on-top switch reaches the shell", await until(() => js("window.troy.__widgetCalls.some(c => c.action === 'setOption' && c.value.key === 'onTop' && c.value.value === false)")));
    await click('[data-act="autoCollapse"]');
    check("auto-collapse switch reaches the shell", await until(() => js("window.troy.__widgetCalls.some(c => c.action === 'setOption' && c.value.key === 'autoCollapse' && c.value.value === false)")));
    await emit("widget.options", { onTop: true, autoCollapse: true, hotkey: "CommandOrControl+Alt+K" });
    check("settings changed elsewhere update the menu and the hotkey hint", await until(async () => (await attr('[data-act="onTop"]', "aria-checked")) === "true" && (await text("#hotkeyHint")) === "Ctrl+Alt+K"));
    await emit("power.state", { mode: "on", on_battery: null, active: true });
    check("power saving switches the widget to the calm look", await until(() => js("document.body.classList.contains('saver') && window.__widget.face.options.saver === true")));
    await emit("power.state", { mode: "auto", on_battery: false, active: false });
    check("and back again", await until(() => js("!document.body.classList.contains('saver') && window.__widget.face.options.saver === false")));
    await click('[data-act="newChat"]');
    check("new chat clears the thread", await until(async () => (await count(".msg")) === 0 && (await count(".empty")) === 1));
    await js("window.__widget.send('What is the weather forecast for London?')");
    await until(async () => (await count(".msg.troy")) >= 1);
    await emit("ui.command", { action: "new_chat" });
    check("Troy starting a new chat himself clears the widget too", await until(async () => (await count(".msg")) === 0 && (await count(".empty")) === 1));
    await until(() => js("getComputedStyle(document.getElementById('stopBtn')).display === 'none'"));

    // --- approvals
    await js("window.__widget.send('please delete my old report')");
    check("approval card appears and status asks for OK", await until(async () => (await $(".conf")) && (await text("#status")) === "Needs your OK"));
    await click('.conf [data-ok="0"]');
    check("denying removes the card", await until(async () => !(await $(".conf"))));
    await until(() => js("getComputedStyle(document.getElementById('stopBtn')).display === 'none'"));

    // --- voice mode
    await click("#micBtn");
    check("mic button starts voice mode", await until(() => js("document.getElementById('micBtn').classList.contains('on')")));
    check("live row is shown with Mute / End", await until(() => js("!document.getElementById('live').hidden")));
    await emit("voice.level", { level: 150000, state: "listening" });
    check("voice level pulses the avatar halo", await until(() => js("parseFloat(document.getElementById('glass').style.getPropertyValue('--lvl')) > 0.1")));
    await click("#muteBtn");
    check("mute is reflected", await until(() => text("#status").then((t) => t === "Mic muted")));
    await click("#endBtn");
    check("End leaves voice mode", await until(() => js("!document.getElementById('micBtn').classList.contains('on')")));

    // --- keyboard
    await js("document.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape' }))");
    check("Esc closes the panel", await until(async () => (await isOpen()) === "0"));
    // the OS window only shrinks once the glass has finished closing (~0.7s), so wait for it
    const shrunk = await until(async () => { const f = await fits(); return f.length && f[f.length - 1].h < 200; }, 5000);
    check("window shrinks back after the glass closes", shrunk, JSON.stringify((await fits()).slice(-2)));

    // --- backend loss
    await emit("backend.exited", { code: 1 });
    check("backend loss turns the dot red", (await attr("#dot", "data-s")) === "offline");

    check("no uncaught page errors", pageErrors.length === 0, pageErrors.join(" | "));
  } catch (err) {
    check(`unexpected error: ${err.message}`, false);
  }

  const failed = results.filter((r) => !r.ok).length;
  console.log(`\n${results.length - failed}/${results.length} checks passed`);
  app.exit(failed ? 1 : 0);
});
