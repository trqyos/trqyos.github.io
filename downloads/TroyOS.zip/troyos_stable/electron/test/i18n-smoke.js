// Interface-language smoke test (Electron, mock backend):  xvfb-run -a electron --no-sandbox test/i18n-smoke.js
const { app, BrowserWindow } = require("electron");
const path = require("path");
app.disableHardwareAcceleration();
app.setPath("userData", path.join(require("os").tmpdir(), `troy-i18n-test-${Date.now()}`));
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const results = [];
const check = (name, ok, extra = "") => { results.push(!!ok); console.log(`${ok ? "PASS" : "FAIL"}  ${name}${ok ? "" : "  " + extra}`); };
// Phrases that are meant to stay as-is: brands, model ids, shortcuts, dates, numbers, the mock backend's sample chats and tasks.
const FINE = /^(Troy|Groq|OpenRouter|Google Gemini|NVIDIA NIM|Firefox|Chrome|Edge|Brave|Ctrl.*|Esc|Enter|Shift.*|.*(?:gpt|llama|qwen|gemini|kimi|glm|nemotron|gemma|deepseek|mistral).*|\/\w+|[\d\s:.,/%·×x-]+|.*\d{1,2}:\d{2}.*|English|Türkçe|Alex|Zira.*|Microsoft.*|piper|edge|v\d.*|Open Firefox.*|Convert 250.*|Sleep the PC.*|Put the computer.*|What's the weather.*|.*\.(onnx|exe|json).*|C:\\.*|[a-z]{2}-[A-Z]{2}.*|.*Neural|ready|primary|.*Microphone.*|.*Mic|\d+\s?(px|fps)|(android|linux|windows|ios|mac)\b.*|[a-z0-9]+-[a-z0-9-]+|TROYOS STABLE.*|Electron demo.*|python \(demo\)|\w+_\w+.*|.*googleusercontent.*|GOCSPX.*|json|csv|Weekly report|Open the report folder.*|[\w.-]+\/[\w.-]+)$/i;

app.whenReady().then(async () => {
  const win = new BrowserWindow({ width: 1280, height: 820, show: false, webPreferences: { contextIsolation: true, sandbox: false } });
  let step = "start"; const errors = []; win.webContents.on("console-message", (_e, level, msg) => { if (level >= 3) errors.push(`[${step}] ${msg}`); });
  const file = path.join(__dirname, "..", "renderer", "index.html");
  const js = (c) => win.webContents.executeJavaScript(c);
  const until = async (fn, ms = 8000) => { const end = Date.now() + ms; while (Date.now() < end) { if (await fn()) return true; await sleep(100); } return false; };
  const ready = async () => { await until(() => js("window.__troyReady === true").catch(() => false)); await sleep(400); };
  const text = (sel) => js(`document.querySelector(${JSON.stringify(sel)})?.textContent ?? null`);
  const click = (sel) => js(`document.querySelector(${JSON.stringify(sel)}).click()`);
  const mark = (n) => { step = n; };
  try {
    await win.loadFile(file); await ready(); mark("english");
    check("English is the default and is untouched", (await text('#nav [data-view="memory"]')).trim().startsWith("Memory") && (await js("I18N.lang")) === "en");

    mark("switch-to-tr");
    // switch through the real Settings control
    await click('#nav [data-view="settings"]'); await until(() => js(`!!document.querySelector('#setNav [data-pane="general"]')`));
    await click('#setNav [data-pane="general"]'); await until(() => js(`!!document.querySelector('select[data-set="UI_LANGUAGE"]')`));
    check("General has a language picker with English / Türkçe / Automatic", (await js(`[...document.querySelectorAll('select[data-set="UI_LANGUAGE"] option')].map(o=>o.value).join()`)) === "en,tr,auto");
    await js(`(()=>{const s=document.querySelector('select[data-set="UI_LANGUAGE"]'); s.value="tr"; s.dispatchEvent(new Event("change",{bubbles:true}))})()`);
    await sleep(1800); await ready();
    check("choosing Türkçe reloads into Turkish", (await js("I18N.lang")) === "tr" && (await text('#nav [data-view="memory"]')).trim().startsWith("Hafıza"));
    check("the choice is remembered by the backend and the page", (await js("localStorage.getItem('troy.lang')")) === "tr");
    check("status and title bar are translated", (await text("#statePill span")) === "Hazır");

    mark("after-tr");
    // user content must never be translated
    await js(`(()=>{const e=document.getElementById("inp"); e.value="Settings"; e.dispatchEvent(new Event("input",{bubbles:true}))})()`);
    await click("#sendBtn"); await until(() => js(`!!document.querySelector(".msg.user .body")`));
    check("a chat message that equals a menu label stays as typed", (await text(".msg.user .body")).trim() === "Settings");

    mark("vacuum");
    // vacuum card
    await click('#nav [data-view="settings"]'); await sleep(300); await click('#setNav [data-pane="integrations"]'); await until(() => js(`!!document.querySelector("[data-vac]")`));
    check("the robot vacuum card exists and is Turkish", (await js(`document.querySelector("[data-vac]").innerText.includes("Robot IP adresi")`)));
    await click('[data-act="vac-test"]'); await until(() => js(`!!document.querySelector("#vacTest .vac-res")`));
    check("Test connection reports the problem in plain words", (await text("#vacTest .vac-res")).includes("isn't set up"));
    await click('[data-act="vac-find"]'); await until(() => js(`!!document.querySelector("#vacFound .u")`));
    check("Find on network lists devices", (await text("#vacFound .u b")) === "192.168.1.50");

    mark("sweep");
    // sweep every screen: anything still English must be an allowed leftover
    for (const v of ["memory", "tasks", "tools", "logs"]) { await click(`#nav [data-view="${v}"]`); await sleep(400); }
    await click('#nav [data-view="settings"]');
    for (const p of await js(`[...document.querySelectorAll("#setNav button[data-pane]")].map(b=>b.dataset.pane)`)) { await click(`#setNav [data-pane="${p}"]`); await sleep(500); }
    const left = (await js("I18N.misses()")).filter((m) => !FINE.test(m));
    check("no unexplained English left on any screen", left.length === 0, JSON.stringify(left.slice(0, 8)));

    mark("back-to-en");
    // back to English
    await click('#setNav [data-pane="general"]'); await until(() => js(`!!document.querySelector('select[data-set="UI_LANGUAGE"]')`));
    await js(`(()=>{const s=document.querySelector('select[data-set="UI_LANGUAGE"]'); s.value="en"; s.dispatchEvent(new Event("change",{bubbles:true}))})()`);
    await sleep(1800); await ready();
    check("switching back restores English", (await js("I18N.lang")) === "en" && (await text('#nav [data-view="memory"]')).trim().startsWith("Memory"));
    check("no uncaught page errors", errors.length === 0, errors.join(" | "));
  } catch (e) { check("test run completed", false, e.message); }
  const failed = results.filter((x) => !x).length;
  console.log(`\n${results.length - failed}/${results.length} checks passed`);
  app.exit(failed ? 1 : 0);
});
