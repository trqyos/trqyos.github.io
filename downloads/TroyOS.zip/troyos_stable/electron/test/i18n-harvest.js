// Drives the real UI in a given language and prints every visible phrase that had no translation.
//   xvfb-run -a electron --no-sandbox test/i18n-harvest.js [tr] [--json out.json] [--shots dir]
// Used to build the dictionary (i18n-tr.js) and by i18n-smoke.js as a coverage gate.
const { app, BrowserWindow } = require("electron");
const path = require("path");
const fs = require("fs");
app.disableHardwareAcceleration();
app.setPath("userData", path.join(require("os").tmpdir(), `troy-i18n-${Date.now()}`));
const lang = process.argv.find((a) => a === "tr" || a === "en") || "tr";
const jsonOut = process.argv.includes("--json") ? process.argv[process.argv.indexOf("--json") + 1] : null;
const shots = process.argv.includes("--shots") ? process.argv[process.argv.indexOf("--shots") + 1] : null;
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

app.whenReady().then(async () => {
  const win = new BrowserWindow({ width: 1280, height: 820, show: false, webPreferences: { contextIsolation: true, sandbox: false } });
  const file = path.join(__dirname, "..", "renderer", "index.html");
  await win.loadFile(file);
  const js = (code) => win.webContents.executeJavaScript(code);
  await js(`localStorage.setItem("troy.lang", ${JSON.stringify(lang)})`);
  await win.loadFile(file);
  const until = async (fn, ms = 8000) => { const end = Date.now() + ms; while (Date.now() < end) { if (await fn()) return true; await sleep(100); } return false; };
  await until(() => js("window.__troyReady === true"));
  const shot = async (name) => { if (!shots) return; fs.mkdirSync(shots, { recursive: true }); const img = await win.webContents.capturePage(); fs.writeFileSync(path.join(shots, `${name}.png`), img.toPNG()); };
  const click = (sel) => js(`(()=>{const e=document.querySelector(${JSON.stringify(sel)}); if(e){e.click(); return true} return false})()`);
  const key = (k, mods = []) => { win.webContents.sendInputEvent({ type: "keyDown", keyCode: k, modifiers: mods }); win.webContents.sendInputEvent({ type: "keyUp", keyCode: k, modifiers: mods }); };

  await sleep(600); await shot("00-chat");
  for (const v of ["memory", "tasks", "tools", "logs"]) { await click(`#nav [data-view="${v}"]`); await sleep(500); await shot(`01-${v}`); }
  await click('#nav [data-view="settings"]'); await sleep(400);
  const panes = await js(`[...document.querySelectorAll("#setNav button[data-pane]")].map(b=>b.dataset.pane)`);
  for (const p of panes) { await click(`#setNav [data-pane="${p}"]`); await sleep(700); await shot(`02-settings-${p}`); }
  // overlays and forms
  await click('#nav [data-view="chat"]'); await sleep(300);
  key("K", ["control"]); await sleep(400); await shot("03-palette"); key("Escape"); await sleep(200);
  await click("#modelBtn"); await sleep(400); await shot("04-model-picker"); key("Escape"); await sleep(200);
  await click('#nav [data-view="tasks"]'); await sleep(300); await click("#taskNew"); await sleep(500); await shot("05-task-form"); key("Escape"); await sleep(200);
  await click('#nav [data-view="chat"]'); await sleep(200);
  await click("#voiceModeBtn"); await sleep(600); await shot("06-voice"); await click("#vEndBtn"); await sleep(300);
  await js(`(()=>{const i=document.getElementById("inp"); i.value="/"; i.dispatchEvent(new Event("input",{bubbles:true}))})()`); await sleep(300); await shot("07-slash");

  const misses = await js("I18N.misses()");
  if (jsonOut) fs.writeFileSync(jsonOut, JSON.stringify(misses, null, 1));
  else console.log(misses.map((m) => JSON.stringify(m)).join("\n"));
  console.log(`\n${misses.length} untranslated phrases in lang=${lang}`);
  app.exit(0);
});
