// Shell test: runs the REAL main.js (window modes, hotkey, power report, prefs) against a tiny
// fake Python backend, so no Python packages or API keys are needed.
//   npm run test:shell        (Linux CI: xvfb-run -a npm run test:shell; skipped on Windows)
const os = require("os");
const path = require("path");
const fs = require("fs");
const { app, BrowserWindow, screen, globalShortcut } = require("electron");
if (process.platform === "win32") { console.log("skipped on Windows (uses a shell-script fake backend)"); app.exit(0); }
app.disableHardwareAcceleration();
const tmp = fs.mkdtempSync(path.join(os.tmpdir(), "troy-shell-"));
app.setPath("userData", path.join(tmp, "user"));
const LOG = path.join(tmp, "backend.log");
fs.writeFileSync(path.join(tmp, "fake.py"), `import sys, json
LOG = open(${JSON.stringify(LOG)}, "w")
def out(o): print(json.dumps(o), flush=True)
out({"type":"event","event":"app.ready","data":{"version":"v1"}})
for line in sys.stdin:
    try: m=json.loads(line)
    except Exception: continue
    LOG.write(json.dumps({"method": m["method"], "params": m.get("params")}) + "\\n"); LOG.flush()
    if m["method"] == "debug.emit":
        p = m["params"]; out({"type":"event","event":p["event"],"data":p["data"]})
    out({"type":"response","id":m["id"],"ok":True,"result":{"pong":True,"busy":False,"pending_confirmations":0,"state":{"state":"idle"},"mode":"auto","on_battery":None,"active":False}})
`);
fs.writeFileSync(path.join(tmp, "fake.sh"), `#!/bin/bash\nexec python3 -u ${path.join(tmp, "fake.py")}\n`, { mode: 0o755 });
process.env.TROY_PYTHON = path.join(tmp, "fake.sh");
require("../main.js");
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const results = [];
const check = (n, ok, x = "") => { results.push(ok); console.log(`${ok ? "PASS" : "FAIL"}  ${n}${ok ? "" : "  " + x}`); };
app.whenReady().then(async () => {
  await sleep(4000);
  const wins = BrowserWindow.getAllWindows();
  const widget = wins.find((w) => w.getTitle() === "Troy Widget"), main = wins.find((w) => w.getTitle() === "Troy");
  check("startup: the full app is showing", main.isVisible());
  check("startup: the widget is NOT showing next to it", !widget.isVisible());
  check("hotkey Ctrl+Alt+T registered", globalShortcut.isRegistered("CommandOrControl+Alt+T"));
  // hand the screen to the widget so the widget checks below still run (this is what the close button does)
  main.close();
  await sleep(600);
  const b = widget.getBounds();
  const wa = screen.getPrimaryDisplay().workArea;
  check("widget docked top-centre", Math.abs(b.x + b.width / 2 - (wa.x + wa.width / 2)) <= 1 && b.y === wa.y);
  check("widget visible, always on top, not focused", widget.isVisible() && widget.isAlwaysOnTop() && !widget.isFocused());
  const js = (c) => widget.webContents.executeJavaScript(c);
  const emit = (event, data) => js(`window.troy.request('debug.emit', ${JSON.stringify({ event, data })})`);
  const widgetCall = (a, v) => js(`window.troy.widget(${JSON.stringify(a)}, ${JSON.stringify(v)})`);
  check("widget renderer ready", await js("window.__widgetReady === true"));

  let info = await widgetCall("openMain");
  await sleep(600);
  check("opening the full app hides the widget", main.isVisible() && !widget.isVisible() && info.mode === "app");

  main.close();                                   // the close button
  await sleep(600);
  check("closing the app brings the widget back (app hidden, not quit)", !main.isDestroyed() && !main.isVisible() && widget.isVisible());

  await emit("ui.command", { action: "mode", mode: "hidden" });
  await sleep(500);
  check("Troy: hide_widget hides everything", !widget.isVisible() && !main.isVisible());
  await emit("ui.command", { action: "mode", mode: "app" });
  await sleep(500);
  check("Troy: open_full_app shows only the app", main.isVisible() && !widget.isVisible());
  await emit("ui.command", { action: "mode", mode: "widget" });
  await sleep(500);
  check("Troy: show_widget shows only the widget", widget.isVisible() && !main.isVisible());
  await emit("ui.command", { action: "view", view: "settings", pane: "power" });
  await sleep(500);
  check("Troy opening Settings brings up the app (and hides the widget)", main.isVisible() && !widget.isVisible());
  await widgetCall("show").catch(() => {});
  await main.webContents.executeJavaScript("window.troy.widget('show')");
  await sleep(500);

  // the hotkey handler: toggles the widget open / closed
  const hk = await main.webContents.executeJavaScript("window.troy.widget('toggle')");
  await sleep(400);
  check("toggle closes the widget", !widget.isVisible() && hk.mode === "hidden");
  await main.webContents.executeJavaScript("window.troy.widget('toggle')");
  await sleep(400);
  check("toggle opens it again", widget.isVisible());

  const opt = await main.webContents.executeJavaScript("window.troy.widget('setOption', {key:'hotkey', value:'Ctrl+Alt+J'})");
  check("changing the hotkey re-registers it", opt.ok && globalShortcut.isRegistered("Ctrl+Alt+J") && !globalShortcut.isRegistered("CommandOrControl+Alt+T"), JSON.stringify(opt));
  const off = await main.webContents.executeJavaScript("window.troy.widget('setOption', {key:'onTop', value:false})");
  check("stay-above can be turned off", off.onTop === false && !widget.isAlwaysOnTop());

  const prefs = JSON.parse(fs.readFileSync(app.getPath("userData") + "/window-state.json", "utf8"));
  check("choices are remembered, retired options are gone", prefs.widgetHotkey === "Ctrl+Alt+J" && prefs.widgetOnTop === false && !("alwaysOnTop" in prefs) && !("closeToTray" in prefs));

  const log = fs.readFileSync(LOG, "utf8");
  check("battery state is reported to the backend", /power\.report/.test(log));
  check("current mode is reported to the backend", /"method": "ui\.report".*"mode": "(widget|app|hidden)"/.test(log));
  console.log(`\n${results.filter(Boolean).length}/${results.length} checks passed`);
  app.exit(results.every(Boolean) ? 0 : 1);
});
