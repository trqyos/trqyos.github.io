/* Small, dependency-free UI helpers shared by app.js: DOM shortcuts, a safe
 * markdown-lite renderer, toasts, modals, popover menus and a command palette.
 * Everything that puts text into the page goes through esc() first. */
"use strict";

const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => Array.from(r.querySelectorAll(s));
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
const ic = (name, cls = "") => `<svg class="i ${cls}"><use href="#i-${name}"/></svg>`;
const ESC = { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" };
const esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ESC[c]);
const debounce = (fn, ms) => { let t; return (...a) => { clearTimeout(t); t = setTimeout(() => fn(...a), ms); }; };

function fmtTime(ts) {
  const d = new Date(ts);
  if (isNaN(d)) return String(ts || "");
  return d.toLocaleString([], { dateStyle: "medium", timeStyle: "short" });
}

async function copyText(text, quiet) {
  try {
    await navigator.clipboard.writeText(text);
  } catch {
    const ta = Object.assign(document.createElement("textarea"), { value: text });
    ta.style.cssText = "position:fixed;opacity:0";
    document.body.append(ta); ta.select();
    try { document.execCommand("copy"); } catch { /* nothing else to try */ }
    ta.remove();
  }
  if (!quiet) toast("Copied to clipboard", "ok", 1600);
}

/* ---------------------------------------------------------------- markdown */
// Escapes first, then adds a small set of formatting: code fences, `code`,
// **bold**, *italic*, [text](url), bare links, bullet/numbered lists, headings.
// Links never navigate inside the app: they carry data-href and app.js hands
// them to the OS browser.
function inlineMd(escaped) {
  const stash = [];
  const keep = (html) => `\u0000${stash.push(html) - 1}\u0000`;
  let s = escaped.replace(/`([^`\n]+)`/g, (_, c) => keep(`<code>${c}</code>`));
  s = s.replace(/\[([^\]\n]+)\]\((https?:\/\/[^)\s]+)\)/g, (_, t, u) => keep(`<a data-href="${u}" href="#">${t}</a>`));
  s = s.replace(/\bhttps?:\/\/[^\s<]*[^\s<.,;:!?)'"\]]/g, (u) => keep(`<a data-href="${u}" href="#">${u}</a>`));
  s = s.replace(/\*\*([^*\n]+)\*\*/g, "<strong>$1</strong>");
  s = s.replace(/(^|[^*\w])\*([^*\n]+)\*(?![\w*])/g, "$1<em>$2</em>");
  return s.replace(/\u0000(\d+)\u0000/g, (_, i) => stash[+i]);
}

function mdBlocks(text) {
  const out = [];
  let para = [], list = null;
  const flushP = () => { if (para.length) { out.push(`<p>${inlineMd(para.join("<br>"))}</p>`); para = []; } };
  const flushL = () => { if (list) { out.push(`<${list.t}>${list.items.map((x) => `<li>${inlineMd(x)}</li>`).join("")}</${list.t}>`); list = null; } };
  for (const line of esc(text).split("\n")) {
    let m;
    if ((m = line.match(/^\s*[-*\u2022]\s+(.*)$/))) { flushP(); if (!list || list.t !== "ul") { flushL(); list = { t: "ul", items: [] }; } list.items.push(m[1]); }
    else if ((m = line.match(/^\s*\d+[.)]\s+(.*)$/))) { flushP(); if (!list || list.t !== "ol") { flushL(); list = { t: "ol", items: [] }; } list.items.push(m[1]); }
    else if ((m = line.match(/^#{1,4}\s+(.*)$/))) { flushP(); flushL(); out.push(`<h4>${inlineMd(m[1])}</h4>`); }
    else if (!line.trim()) { flushP(); flushL(); }
    else { flushL(); para.push(line); }
  }
  flushP(); flushL();
  return out.join("");
}

function md(src) {
  return String(src ?? "").split("```").map((part, i) => {
    if (i % 2 === 0) return mdBlocks(part);
    const nl = part.indexOf("\n");
    const code = nl >= 0 && /^[\w+#.-]*$/.test(part.slice(0, nl).trim()) ? part.slice(nl + 1) : part;
    return `<pre><button class="icon-btn sm pre-copy" data-copy title="Copy">${ic("copy")}</button><code>${esc(code.replace(/\n$/, ""))}</code></pre>`;
  }).join("");
}

/* ------------------------------------------------------------------ toasts */
function toast(message, kind = "bad", ms) {
  const box = $("#toasts");
  const el = document.createElement("div");
  el.className = `toast ${kind === "bad" ? "" : kind}`;
  el.innerHTML = `<span>${esc(message)}</span>`;
  const gone = () => { el.classList.add("out"); setTimeout(() => el.remove(), 260); };
  el.onclick = gone;
  box.append(el);
  while (box.children.length > 4) box.firstChild.remove();
  setTimeout(gone, ms || (kind === "bad" ? 6500 : 3800));
}

/* ------------------------------------------------------------------ modals */
let modalStack = [];
function modal(innerHtml, { cls = "", onClose } = {}) {
  const scrim = document.createElement("div");
  scrim.className = "scrim";
  scrim.innerHTML = `<div class="modal ${cls}" role="dialog" aria-modal="true">${innerHtml}</div>`;
  $("#overlay").append(scrim);
  const box = scrim.firstElementChild;
  const api = {
    el: box,
    close(value) {
      if (!scrim.isConnected) return;
      scrim.remove();
      modalStack = modalStack.filter((m) => m !== api);
      if (onClose) onClose(value);
    },
  };
  scrim.addEventListener("pointerdown", (e) => { if (e.target === scrim) api.close(null); });
  modalStack.push(api);
  return api;
}
const topModal = () => modalStack[modalStack.length - 1];

function confirmBox({ title, text = "", okText = "OK", danger = false }) {
  return new Promise((resolve) => {
    let settled = false;
    const done = (v) => { if (!settled) { settled = true; resolve(!!v); } };
    const m = modal(`<h3>${esc(title)}</h3><p>${esc(text)}</p>
      <div class="ma"><button class="btn" data-a="no">Cancel</button><button class="btn ${danger ? "bad" : "pri"}" data-a="ok">${esc(okText)}</button></div>`, { onClose: done });
    m.el.addEventListener("click", (e) => { const a = e.target.closest("[data-a]")?.dataset.a; if (a) m.close(a === "ok"); });
    m.el.addEventListener("keydown", (e) => { if (e.key === "Enter") m.close(true); });
    m.el.querySelector('[data-a="ok"]').focus();
  });
}

function promptBox({ title, value = "", placeholder = "", okText = "Save" }) {
  return new Promise((resolve) => {
    let settled = false;
    const done = (v) => { if (!settled) { settled = true; resolve(v); } };
    const m = modal(`<h3>${esc(title)}</h3><input type="text" style="width:100%;margin-top:10px" value="${esc(value)}" placeholder="${esc(placeholder)}" />
      <div class="ma"><button class="btn" data-a="no">Cancel</button><button class="btn pri" data-a="ok">${esc(okText)}</button></div>`, { onClose: (v) => done(v === undefined ? null : v) });
    const input = m.el.querySelector("input");
    const submit = () => m.close(input.value.trim());
    m.el.addEventListener("click", (e) => { const a = e.target.closest("[data-a]")?.dataset.a; if (a === "ok") submit(); else if (a) m.close(null); });
    input.addEventListener("keydown", (e) => { if (e.key === "Enter") submit(); });
    input.focus(); input.select();
  });
}

/* -------------------------------------------------------------- popovers */
let pop = null;
function closePop() {
  if (!pop) return;
  pop.cleanup();
  pop.el.remove();
  pop = null;
}
const popOpenFor = (anchor) => !!pop && pop.anchor === anchor;

function openPop(anchor, build, { align = "left" } = {}) {
  if (popOpenFor(anchor)) { closePop(); return null; }
  closePop();
  const el = document.createElement("div");
  el.className = "pop";
  document.body.append(el);
  build(el, closePop);

  const place = () => {
    const r = anchor.getBoundingClientRect(), p = el.getBoundingClientRect();
    const left = clamp(align === "right" ? r.right - p.width : r.left, 8, innerWidth - p.width - 8);
    let top = r.bottom + 8;
    if (top + p.height > innerHeight - 8) top = Math.max(8, r.top - p.height - 8);
    el.style.left = `${left}px`; el.style.top = `${top}px`;
  };
  place();

  const onDown = (e) => { if (!el.contains(e.target) && !anchor.contains(e.target)) closePop(); };
  const onKey = (e) => { if (e.key === "Escape") { e.stopPropagation(); closePop(); } };
  const t = setTimeout(() => document.addEventListener("pointerdown", onDown, true));
  document.addEventListener("keydown", onKey, true);
  window.addEventListener("resize", closePop);
  pop = {
    el, anchor, place,
    cleanup() {
      clearTimeout(t);
      document.removeEventListener("pointerdown", onDown, true);
      document.removeEventListener("keydown", onKey, true);
      window.removeEventListener("resize", closePop);
    },
  };
  return el;
}

/* A searchable list menu. items: {group} | {label, sub, cur, disabled, onPick}
 * (onPick may return false to keep the menu open). */
function menuPop(anchor, items, { search = false, align = "left", empty = "Nothing here", placeholder = "Search" } = {}) {
  return openPop(anchor, (el) => {
    el.innerHTML = (search ? `<label class="search">${ic("search")}<input type="text" placeholder="${esc(placeholder)}" autocomplete="off" /></label>` : "") + `<div class="mlist"></div>`;
    const list = $(".mlist", el), input = $("input", el);
    let shown = [], sel = 0;
    const render = () => {
      const q = (input?.value || "").trim().toLowerCase();
      shown = [];
      let html = "", pendingGroup = null;
      for (const it of items) {
        if (it.group !== undefined) { pendingGroup = it; continue; }
        if (q && !(`${it.label} ${it.sub || ""}`.toLowerCase().includes(q))) continue;
        if (pendingGroup) { html += `<div class="grp">${esc(pendingGroup.group)}${pendingGroup.badge ? `<span class="badge pri">${esc(pendingGroup.badge)}</span>` : ""}</div>`; pendingGroup = null; }
        html += `<div class="it${it.cur ? " cur" : ""}${it.disabled ? " dis" : ""}${shown.length === sel ? " sel" : ""}" data-i="${shown.length}">${it.icon ? ic(it.icon, "sm") : ""}<span>${esc(it.label)}</span>${it.sub ? `<small style="color:var(--faint)">${esc(it.sub)}</small>` : ""}${it.cur ? ic("check", "sm") : ""}</div>`;
        shown.push(it);
      }
      list.innerHTML = html || `<div class="none">${esc(empty)}</div>`;
      pop && pop.place();
    };
    const pick = (i) => { const it = shown[i]; if (!it || it.disabled) return; if (it.onPick() !== false) closePop(); };
    list.addEventListener("click", (e) => { const row = e.target.closest(".it"); if (row) pick(+row.dataset.i); });
    list.addEventListener("pointermove", (e) => { const row = e.target.closest(".it"); if (row && +row.dataset.i !== sel) { sel = +row.dataset.i; $$(".it", list).forEach((n, k) => n.classList.toggle("sel", k === sel)); } });
    const keys = (e) => {
      if (e.key === "ArrowDown" || e.key === "ArrowUp") {
        e.preventDefault();
        sel = (sel + (e.key === "ArrowDown" ? 1 : -1) + shown.length) % Math.max(1, shown.length);
        $$(".it", list).forEach((n, k) => { n.classList.toggle("sel", k === sel); if (k === sel) n.scrollIntoView({ block: "nearest" }); });
      } else if (e.key === "Enter") { e.preventDefault(); pick(sel); }
    };
    (input || el).addEventListener("keydown", keys);
    if (input) { input.addEventListener("input", () => { sel = 0; render(); }); }
    render();
    if (input) input.focus();
  }, { align });
}

/* ------------------------------------------------------- command palette */
// getItems(query) -> [{label, hint, icon, run}]. Enter runs the highlighted one.
function openPalette(getItems, { placeholder = "Type a command or ask Troy…" } = {}) {
  const m = modal(`<div class="search">${ic("search")}<input type="text" placeholder="${esc(placeholder)}" autocomplete="off" /></div><div class="list scroll"></div>`, { cls: "palette" });
  const input = $("input", m.el), list = $(".list", m.el);
  let items = [], sel = 0;
  const render = () => {
    items = getItems(input.value.trim());
    sel = clamp(sel, 0, Math.max(0, items.length - 1));
    list.innerHTML = items.map((it, i) => `<div class="it${i === sel ? " sel" : ""}" data-i="${i}">${ic(it.icon || "chevron-r")}<span>${esc(it.label)}</span>${it.hint ? `<small>${esc(it.hint)}</small>` : ""}</div>`).join("") || `<div class="none" style="padding:14px;text-align:center;color:var(--faint)">No matches</div>`;
  };
  const run = (i) => { const it = items[i]; if (!it) return; m.close(); it.run(); };
  input.addEventListener("input", () => { sel = 0; render(); });
  input.addEventListener("keydown", (e) => {
    if (e.key === "ArrowDown" || e.key === "ArrowUp") {
      e.preventDefault();
      sel = (sel + (e.key === "ArrowDown" ? 1 : -1) + items.length) % Math.max(1, items.length);
      $$(".it", list).forEach((n, k) => { n.classList.toggle("sel", k === sel); if (k === sel) n.scrollIntoView({ block: "nearest" }); });
    } else if (e.key === "Enter") { e.preventDefault(); run(sel); }
  });
  list.addEventListener("click", (e) => { const row = e.target.closest(".it"); if (row) run(+row.dataset.i); });
  list.addEventListener("pointermove", (e) => { const row = e.target.closest(".it"); if (row && +row.dataset.i !== sel) { sel = +row.dataset.i; $$(".it", list).forEach((n, k) => n.classList.toggle("sel", k === sel)); } });
  render();
  input.focus();
  return m;
}

/* Global Escape: topmost modal first. (Popovers handle their own Escape.) */
document.addEventListener("keydown", (e) => {
  if (e.key === "Escape" && !pop) { const m = topModal(); if (m) { e.preventDefault(); m.close(null); } }
});
