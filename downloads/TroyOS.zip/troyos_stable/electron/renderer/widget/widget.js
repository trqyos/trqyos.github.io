/* Troy Widget — logic.
 *
 * An always-visible glass pill docked at the top centre of the screen. It talks
 * to the same Python backend as the main window (window.troy.request / .on) and
 * receives the same events, so both surfaces always agree.
 *
 *   bar    avatar orb · name + status · [wave | input] · >_ · gear · status dot
 *   panel  melts out of the bar: chat (replies, tool steps, approvals, live
 *          voice row) · activity log · menu
 *
 * The Electron window is transparent and sized to hug the pill. This file asks
 * main.js to resize it (window.troy.widget("fit", {w, h})): BEFORE the glass
 * grows, and AFTER it has finished shrinking, so nothing is ever clipped.
 *
 * Visuals live in widget.css; nothing here depends on the main app's code.
 */
(() => {
  "use strict";

  const T = window.troy;
  const $ = (s, r = document) => r.querySelector(s);
  const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  const ESC = { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" };
  const esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ESC[c]);
  const IS_MAC = (T && T.platform) === "darwin";
  const fmtHotkey = (h) => String(h || "Ctrl+Alt+T").replace(/CommandOrControl|CmdOrCtrl/g, IS_MAC ? "\u2318" : "Ctrl").replace(/\bControl\b/g, "Ctrl");

  /* Geometry. Must match widget.css (--bar-h) and #stage padding. */
  const G = { bar: 68, padX: 28, padTop: 10, padBot: 36, wCompact: 520, wOpen: 600, maxBody: 430 };

  const el = {
    glass: $("#glass"), orb: $("#orb"), face: $("#face"), status: $("#status"), field: $("#field"),
    inp: $("#inp"), mic: $("#micBtn"), send: $("#sendBtn"), stop: $("#stopBtn"),
    term: $("#termBtn"), gear: $("#gearBtn"), dot: $("#dot"),
    body: $("#body"), bodyIn: $("#bodyIn"),
    vChat: $("#viewChat"), vAct: $("#viewAct"), vMenu: $("#viewMenu"),
    confs: $("#confs"), thread: $("#thread"), activity: $("#activity"),
    live: $("#live"), liveText: $("#liveText"), mute: $("#muteBtn"), end: $("#endBtn"), pin: $("#pinBtn"),
    bars: Array.from(document.querySelectorAll("#micBtn i")),
  };
  el.bars.forEach((b) => b.style.setProperty("--h", ".3"));
  const setHotkeyHint = (h) => { $("#hotkeyHint").textContent = fmtHotkey(h); $("#hotkeyHint2").textContent = fmtHotkey(h); };
  setHotkeyHint("");

  /* ------------------------------------------------------------------ state */
  const S = {
    booting: true, backend: false,
    agent: "idle", detail: "", busy: false,
    voice: { active: false, state: "off", muted: false },
    wake: "idle",
    open: false, view: "chat", pinned: false, hover: false,
    autoCollapse: true, onTop: true, saver: false,
    confs: new Map(),
    speakUntil: 0, errUntil: 0, errText: "", flashFace: null, flashUntil: 0,
    lvlTarget: 0, lvl: 0, lvlAt: 0, grow: 0,
    liveUntil: 0, lastReplyLen: 0,
    cur: { st: "idle", label: "", face: "idle", dot: "idle" },
    stepsEl: null, typingEl: null,
  };
  const hist = []; let histIdx = -1;

  const cleanErr = (e) => String(e?.message || e || "Something went wrong.").replace(/^Error invoking remote method '[^']+':\s*(Error:\s*)?/, "");

  /* ------------------------------------------------------------ the avatar */
  let lastTint = "";
  const face = window.NovaFace.mount(el.face, {
    onTint: (r, g, b) => {
      const t = `${r},${g},${b}`;
      if (t !== lastTint) { lastTint = t; el.glass.style.setProperty("--tint", t); }
    },
  });
  const FACE_BASE = 0.64;                                   // fits the 56px orb
  face.setOptions({ scale: FACE_BASE, gap: 120, tracking: true, sleep: false });
  face.locked = false;
  // Blink / glance / wink in step with the app and the phone (shared clock); pokes are passed on and replayed.
  const FACE_ID = `widget-${Math.random().toString(36).slice(2, 8)}`;
  face.setSync({ now: Date.now, id: FACE_ID, send: (evt) => T.request("face.relay", evt).catch(() => {}) });
  T.on("face.event", (d) => { if (d && d.origin !== FACE_ID) face.applyRemote(d); });
  // The orb grows and shrinks with a CSS transform, and the stock resize() measures
  // getBoundingClientRect() (which includes that transform). Measure the LAYOUT size
  // instead and render at 1.25x so the face stays crisp when the orb is scaled up.
  face.resize = function () {
    const box = this.cv.parentElement, k = Math.min(window.devicePixelRatio || 1, 2) * 1.25;
    const w = box.offsetWidth, h = box.offsetHeight;
    this.cv.width = Math.max(1, Math.round(w * k)); this.cv.height = Math.max(1, Math.round(h * k));
    if (this.ctx) this.ctx.setTransform(k, 0, 0, k, 0, 0);
    this.W = w; this.H = h;
  };
  face.resize();

  /* ----------------------------------------------------------- power saving
   * body.saver (see widget.css) stops the drifting liquid and the sheen; the face
   * drops to 20 fps without glow or particles. Triggered by the backend's power.state. */
  function applySaver(active) {
    S.saver = !!active;
    document.body.classList.toggle("saver", S.saver);
    face.setOptions({ saver: S.saver });
  }

  /* ------------------------------------------------- status -> look & label */
  function derive() {
    const now = Date.now(), v = S.voice;
    if (!S.backend) return S.booting
      ? { st: "idle", label: "Starting…", face: "idle", dot: "busy" }
      : { st: "offline", label: "Backend offline", face: "error", dot: "offline" };   // beats any transient error
    if (S.errUntil > now) return { st: "error", label: S.errText || "Something went wrong", face: "error", dot: "busy" };
    if (S.confs.size) return { st: "waiting", label: "Needs your OK", face: "listening", dot: "busy" };

    let r = { st: "idle", label: "Ready.", face: "idle", dot: "idle" };
    if (S.agent === "executing") r = { st: "executing", label: "Working…", face: "executing", dot: "busy", title: S.detail ? `Running ${S.detail}` : "Working…" };
    else if (S.agent === "thinking") r = { st: "thinking", label: "Thinking…", face: "thinking", dot: "busy" };
    else if (S.agent === "speaking" || S.speakUntil > now) r = { st: "speaking", label: "Speaking…", face: "speaking", dot: v.active ? "listening" : "busy" };
    else if (S.busy) r = { st: "thinking", label: "Thinking…", face: "thinking", dot: "busy" };
    else if (S.agent === "error") r = { st: "error", label: "Something went wrong", face: "error", dot: "busy" };
    else if (S.agent === "stopped") r = { st: "idle", label: "Stopped.", face: "idle", dot: "idle" };
    else if (v.active) {
      const m = { listening: "Listening…", hearing: "Hearing you…", transcribing: "Transcribing…", muted: "Mic muted" }[v.state];
      r = { st: v.state === "muted" ? "idle" : "listening", label: m || "Listening…", face: v.state === "muted" ? "idle" : "listening", dot: "listening" };
    } else if (S.wake === "hearing" || S.wake === "awake") r = { st: "listening", label: "Listening…", face: "listening", dot: "listening" };
    if (v.active && v.muted && r.st === "idle") r.label = "Mic muted";
    return r;
  }

  function applyStatus() {
    const r = derive();
    if (r.label !== S.cur.label) {
      el.status.textContent = r.label; el.status.title = r.title || r.label;
      el.status.classList.remove("swap"); void el.status.offsetWidth; el.status.classList.add("swap");
    }
    el.glass.dataset.state = r.st;
    el.glass.dataset.voice = S.voice.active ? "1" : "0";
    el.dot.dataset.s = r.dot;
    el.dot.title = S.backend ? "Backend connected" : (S.booting ? "Starting the backend…" : "Backend offline");
    const f = S.flashFace && S.flashUntil > Date.now() ? S.flashFace : r.face;
    face.locked = S.busy;
    face.setState(f);
    S.cur = r;
    el.mic.classList.toggle("on", S.voice.active);
    el.mic.classList.toggle("muted", S.voice.active && S.voice.muted);
    el.mute.classList.toggle("on", S.voice.muted);
    $("span", el.mute).textContent = S.voice.muted ? "Unmute" : "Mute";
    syncField();
  }
  function flash(f, ms) { S.flashFace = f; S.flashUntil = Date.now() + ms; applyStatus(); setTimeout(applyStatus, ms + 30); }
  function showError(text, ms = 4200) { S.errText = String(text).slice(0, 60); S.errUntil = Date.now() + ms; applyStatus(); setTimeout(applyStatus, ms + 30); }
  function syncField() {
    el.field.classList.toggle("has-text", !!el.inp.value.trim());
    el.field.classList.toggle("busy", S.busy);
  }

  /* ------------------------------------------------------ animation loop
   * One rAF loop drives everything that has to feel alive: the orb grows and
   * shrinks with mood + voice level, the halo breathes, the 5 wave bars dance.
   */
  const BAR_W = [0.72, 0.92, 1, 0.9, 0.7];
  let lastT = performance.now();
  function frame(now) {
    requestAnimationFrame(frame);
    if (S.saver && now - lastT < 48) return;                      // ~20 fps while saving power
    const dt = Math.min(0.1, (now - lastT) / 1000); lastT = now;
    const t = now / 1000, st = S.cur.st, stale = Date.now() - S.lvlAt > 380;

    let tgt = stale ? 0 : S.lvlTarget;
    if (st === "speaking" && stale) tgt = 0.22 + 0.36 * Math.abs(Math.sin(t * 6.3)) * (0.62 + 0.38 * Math.sin(t * 2.1 + 1));
    else if ((st === "thinking" || st === "executing") && stale) tgt = 0.1 + 0.07 * Math.sin(t * 3.2);
    S.lvl += (tgt - S.lvl) * Math.min(1, dt * (tgt > S.lvl ? 14 : 5.5));

    const active = S.open || S.voice.active || S.busy || st !== "idle";
    S.grow += ((active ? 1 : 0) - S.grow) * Math.min(1, dt * 5);

    el.glass.style.setProperty("--lvl", S.lvl.toFixed(3));
    el.glass.style.setProperty("--os", (0.86 + 0.1 * S.grow + S.lvl * 0.12).toFixed(3));
    face.setOptions({ scale: FACE_BASE * (0.95 + 0.09 * S.grow + S.lvl * 0.17) });
    face.setLevel(S.lvl);

    const muted = S.voice.active && S.voice.muted;
    for (let i = 0; i < 5; i++) {
      let h;
      if (muted) h = 0.2;
      else if (st === "listening" || st === "speaking" || S.lvl > 0.03) h = 0.2 + S.lvl * 0.95 * (0.55 + 0.45 * Math.sin(t * 9 + i * 1.4)) * BAR_W[i] + 0.1 * BAR_W[i];
      else h = 0.28 + 0.1 * BAR_W[i] * (1 + Math.sin(t * 1.7 + i * 0.9));
      el.bars[i].style.setProperty("--h", clamp(h, 0.18, 1).toFixed(3));
    }
  }
  requestAnimationFrame(frame);
  setInterval(applyStatus, 400);                    // expires speaking / error / flash timers

  /* ------------------------------------------------------------ markdown */
  function inlineMd(s) {
    const stash = [];
    const keep = (h) => `\u0000${stash.push(h) - 1}\u0000`;
    s = s.replace(/`([^`\n]+)`/g, (_, c) => keep(`<code>${c}</code>`));
    s = s.replace(/\[([^\]\n]+)\]\((https?:\/\/[^)\s]+)\)/g, (_, t, u) => keep(`<a data-href="${u}">${t}</a>`));
    s = s.replace(/\bhttps?:\/\/[^\s<]*[^\s<.,;:!?)'"\]]/g, (u) => keep(`<a data-href="${u}">${u}</a>`));
    s = s.replace(/\*\*([^*\n]+)\*\*/g, "<strong>$1</strong>");
    s = s.replace(/(^|[^*\w])\*([^*\n]+)\*(?![\w*])/g, "$1<em>$2</em>");
    return s.replace(/\u0000(\d+)\u0000/g, (_, i) => stash[+i]);
  }
  function md(src) {
    const parts = esc(src).split(/```[a-z0-9_-]*\n?([\s\S]*?)```/gi);
    const out = [];
    parts.forEach((chunk, i) => {
      if (i % 2) { out.push(`<pre><code>${chunk.replace(/\n$/, "")}</code></pre>`); return; }
      let para = [], list = null;
      const fp = () => { if (para.length) { out.push(`<p>${inlineMd(para.join("<br>"))}</p>`); para = []; } };
      const fl = () => { if (list) { out.push(`<${list.t}>${list.i.map((x) => `<li>${inlineMd(x)}</li>`).join("")}</${list.t}>`); list = null; } };
      for (const line of chunk.split("\n")) {
        let m;
        if ((m = line.match(/^\s*[-*\u2022]\s+(.*)$/))) { fp(); if (!list || list.t !== "ul") { fl(); list = { t: "ul", i: [] }; } list.i.push(m[1]); }
        else if ((m = line.match(/^\s*\d+[.)]\s+(.*)$/))) { fp(); if (!list || list.t !== "ol") { fl(); list = { t: "ol", i: [] }; } list.i.push(m[1]); }
        else if ((m = line.match(/^#{1,4}\s+(.*)$/))) { fp(); fl(); out.push(`<h4>${inlineMd(m[1])}</h4>`); }
        else if (!line.trim()) { fp(); fl(); }
        else { fl(); para.push(line); }
      }
      fp(); fl();
    });
    return out.join("");
  }
  document.addEventListener("click", (e) => {
    const a = e.target.closest("a[data-href]");
    if (!a) return;
    e.preventDefault();
    T.openExternal(a.dataset.href.replace(/&amp;/g, "&"));
  });

  /* -------------------------------------------------------------- thread */
  const svg = (id) => `<svg><use href="#w-${id}"/></svg>`;
  function scrollDown() { const sc = el.thread; sc.scrollTop = sc.scrollHeight; }
  function clearEmpty() { $(".empty", el.thread)?.remove(); }
  function place(node) {
    clearEmpty();
    if (S.typingEl) el.thread.insertBefore(node, S.typingEl); else el.thread.append(node);
    while (el.thread.children.length > 60) el.thread.firstElementChild.remove();
    requestAnimationFrame(() => { layout(); scrollDown(); });
  }
  function addMsg(role, text, opts = {}) {
    const d = document.createElement("div");
    d.className = `msg ${role === "user" ? "user" : "troy"}${opts.error ? " error" : ""}`;
    d.innerHTML = role === "user" ? esc(text) : md(text);
    S.stepsEl = null;
    place(d);
    return d;
  }
  function addStep(d) {
    if (!S.stepsEl || !S.stepsEl.isConnected) {
      S.stepsEl = document.createElement("div"); S.stepsEl.className = "steps";
      place(S.stepsEl);
    }
    const s = document.createElement("div");
    s.className = `step ${d.success ? "ok" : "fail"}`;
    s.title = String(d.message || "");
    s.innerHTML = `${svg(d.success ? "check" : "x")}<span>${esc(d.name)}${d.arg ? ` · ${esc(String(d.arg).slice(0, 40))}` : ""}</span>`;
    S.stepsEl.append(s);
    layout();
  }
  function showTyping() {
    if (S.typingEl) return;
    clearEmpty();
    S.typingEl = document.createElement("div"); S.typingEl.className = "typing"; S.typingEl.innerHTML = "<i></i><i></i><i></i>";
    el.thread.append(S.typingEl);
    requestAnimationFrame(() => { layout(); scrollDown(); });
  }
  function hideTyping() { S.typingEl?.remove(); S.typingEl = null; }
  function emptyHint() {
    if (el.thread.children.length) return;
    el.thread.innerHTML = `<div class="empty"><b>Hi, I'm Troy.</b>Ask me to open apps, search the web, control your PC<br>— or press the wave and just talk.</div>`;
  }

  /* ----------------------------------------------------------- activity */
  const time = () => new Date().toTimeString().slice(0, 8);
  function logLine(kind, glyph, title, msg) {
    msg = String(msg ?? "").replace(/\*\*|`/g, "").replace(/\s+/g, " ").trim();
    const d = document.createElement("div");
    d.className = `ln ${kind}`;
    d.innerHTML = `<time>${time()}</time><span class="g">${glyph}</span><span><span class="t">${esc(title)}</span>${msg ? ` <span class="m">${esc(msg.slice(0, 220))}</span>` : ""}</span>`;
    el.activity.append(d);
    while (el.activity.children.length > 300) el.activity.firstElementChild.remove();
    if (S.open && S.view === "act") requestAnimationFrame(() => { layout(); el.activity.scrollTop = el.activity.scrollHeight; });
  }

  /* ---------------------------------------------------------- approvals */
  function confCard(p) {
    if (S.confs.has(p.id)) return;
    const d = document.createElement("div");
    d.className = "conf"; d.id = `conf-${p.id}`;
    const high = /high|critical/i.test(p.risk_level || "");
    d.innerHTML = `${svg("shield")}<div class="cb"><div class="ct">Troy needs your approval <span class="badge ${high ? "bad" : ""}">${esc(p.risk_level || "risk")}</span></div>
      <code>${esc(p.name)}${p.arg ? `:${esc(p.arg)}` : ""}</code><div class="cd">${esc(p.description || "")}</div>
      <div class="ca"><button class="btn pri" data-ok="1" type="button">${svg("check")}Approve</button><button class="btn" data-ok="0" type="button">Deny</button></div></div>`;
    d.addEventListener("click", async (e) => {
      const b = e.target.closest("[data-ok]"); if (!b) return;
      const approved = b.dataset.ok === "1";
      dropConf(p.id);
      try { await T.request("confirmation.resolve", { id: p.id, approved }); }
      catch (err) { showError(cleanErr(err)); }
    });
    S.confs.set(p.id, d);
    el.confs.append(d);
    logLine("ev", "!", `approval needed: ${p.name}`, p.arg || "");
    setOpen(true, "chat"); flash("surprised", 900); applyStatus();
  }
  function dropConf(id) {
    const d = S.confs.get(id); if (!d) return;
    d.remove(); S.confs.delete(id); applyStatus(); layout();
    if (!S.confs.size) bumpCollapse(6000);
  }

  /* ------------------------------------------------------- voice live row */
  function updateLive() {
    const show = S.voice.active;
    el.live.hidden = !show;
    if (!show) return;
    const now = Date.now();
    el.liveText.textContent = S.liveText && S.liveUntil > now ? `“${S.liveText}”` : S.cur.label || "Listening…";
  }
  setInterval(() => { if (S.voice.active) updateLive(); }, 500);

  /* ---------------------------------------------------- panel open / close */
  function setView(v) {
    S.view = v;
    el.vChat.hidden = v !== "chat"; el.vAct.hidden = v !== "act"; el.vMenu.hidden = v !== "menu";
    el.term.classList.toggle("active", S.open && v === "act");
    el.gear.classList.toggle("active", S.open && v === "menu");
    if (v === "chat") emptyHint();
    if (v === "act") requestAnimationFrame(() => { el.activity.scrollTop = el.activity.scrollHeight; });
  }
  function setOpen(open, view) {
    if (view) setView(view);
    if (open === S.open) { layout(); bumpCollapse(); return; }
    S.open = open;
    el.glass.dataset.open = open ? "1" : "0";
    el.term.classList.toggle("active", open && S.view === "act");
    el.gear.classList.toggle("active", open && S.view === "menu");
    layout();
    if (open) { if (S.view === "chat") requestAnimationFrame(scrollDown); bumpCollapse(); }
    else { clearTimeout(S.collapseT); }
  }
  function toggleView(v) {
    if (S.open && S.view === v) setOpen(false); else setOpen(true, v);
  }
  function canCollapse() {
    return S.open && S.autoCollapse && !S.pinned && S.view === "chat" && !S.hover
      && !S.confs.size && !S.busy && !S.voice.active && !el.inp.value.trim();
  }
  function bumpCollapse(ms = 7000) {
    clearTimeout(S.collapseT);
    if (!S.open || S.pinned || !S.autoCollapse || S.view !== "chat") return;
    S.collapseT = setTimeout(() => { if (canCollapse()) setOpen(false); else if (S.open) bumpCollapse(3500); }, ms);
  }
  el.glass.addEventListener("mouseenter", () => { S.hover = true; clearTimeout(S.collapseT); });
  el.glass.addEventListener("mouseleave", () => { S.hover = false; bumpCollapse(3200); });

  /* ------------------------------------------------- layout + window fit
   * The glass animates (CSS); the OS window follows it. Grow: resize the
   * window first, then let the glass expand into it. Shrink: let the glass
   * finish, then shrink the window. `win` is the window size we last asked for.
   */
  let win = { w: G.wCompact + G.padX * 2, h: G.padTop + G.bar + G.padBot };
  let shrinkTimer = null, layoutQueued = false, lastBody = -1, lastW = -1, layoutSeq = 0;
  function fitWindow(w, h) {
    win = { w, h };
    return T.widget("fit", { w, h }).catch(() => {});
  }
  function measureBody() {
    const view = S.view === "chat" ? el.vChat : S.view === "act" ? el.vAct : el.vMenu;
    const sc = S.view === "chat" ? el.thread : S.view === "act" ? el.activity : null;
    if (sc) sc.style.maxHeight = "none";
    const natural = el.bodyIn.offsetHeight;
    if (!sc) return Math.min(G.maxBody, natural);
    const other = natural - sc.offsetHeight;
    const room = Math.max(150, G.maxBody - other);
    sc.style.maxHeight = `${room}px`;
    void view;
    return Math.min(G.maxBody, other + Math.min(sc.scrollHeight, room));
  }
  function layout() {
    if (layoutQueued) return;
    layoutQueued = true;
    requestAnimationFrame(async () => {
      layoutQueued = false;
      const W = S.open ? G.wOpen : G.wCompact;
      const Hb = S.open ? Math.ceil(measureBody()) : 0;
      if (W === lastW && Hb === lastBody) return;
      lastW = W; lastBody = Hb;
      const seq = ++layoutSeq;
      const needW = W + G.padX * 2, needH = G.padTop + G.bar + Hb + G.padBot;
      clearTimeout(shrinkTimer);
      if (needW > win.w || needH > win.h) await fitWindow(Math.max(needW, win.w), Math.max(needH, win.h));
      if (seq !== layoutSeq) return;          // a newer layout (e.g. closed again while the window was growing) supersedes this one
      el.glass.style.setProperty("--w", `${W}px`);
      el.body.style.height = `${Hb}px`;
      if (needW < win.w || needH < win.h) shrinkTimer = setTimeout(() => fitWindow(needW, needH), 700);
    });
  }
  new ResizeObserver(() => { if (S.open) layout(); }).observe(el.bodyIn);

  /* ---------------------------------------------- click-through margins */
  let pass = null;
  function setPass(v) { if (pass === v) return; pass = v; T.widget("passthrough", v).catch(() => {}); }
  document.addEventListener("mousemove", (e) => setPass(!e.target.closest("#glass")), { passive: true });
  document.addEventListener("mouseleave", () => setPass(true));
  setPass(true);

  /* --------------------------------------------------------------- actions */
  async function send(text) {
    text = String(text || "").trim();
    if (!text) return;
    if (hist[0] !== text) hist.unshift(text);
    histIdx = -1; el.inp.value = ""; syncField();
    try { await T.request("chat.send", { text, source: "widget" }); }
    catch (e) { showError(cleanErr(e)); setOpen(true, "chat"); addMsg("troy", `⚠ ${cleanErr(e)}`, { error: true }); }
  }
  async function toggleVoice() {
    try {
      if (S.voice.active) await T.request("voice.mode_stop", {});
      else await T.request("voice.mode_start", {});
    } catch (e) { showError(cleanErr(e)); setOpen(true, "chat"); addMsg("troy", `⚠ ${cleanErr(e)}`, { error: true }); }
  }
  async function newChat() {
    try { await T.request("session.reset", {}); }
    catch (e) { showError(cleanErr(e)); return; }
    el.thread.innerHTML = ""; S.stepsEl = null; hideTyping(); emptyHint();
    setView("chat"); layout(); flash("done", 900);
  }
  function setBusy(b) {
    if (S.busy === b) return;
    S.busy = b; if (b) showTyping(); else hideTyping();
    applyStatus();
  }

  el.inp.addEventListener("input", () => { syncField(); histIdx = -1; });
  el.inp.addEventListener("keydown", (e) => {
    if (e.key === "Enter" && !e.shiftKey && !e.isComposing) { e.preventDefault(); send(el.inp.value); }
    else if (e.key === "ArrowUp" && hist.length) { e.preventDefault(); histIdx = Math.min(hist.length - 1, histIdx + 1); el.inp.value = hist[histIdx]; syncField(); }
    else if (e.key === "ArrowDown" && histIdx >= 0) { e.preventDefault(); histIdx -= 1; el.inp.value = histIdx >= 0 ? hist[histIdx] : ""; syncField(); }
  });
  el.inp.addEventListener("focus", () => { setPass(false); if (S.open) bumpCollapse(); });
  el.send.addEventListener("click", () => send(el.inp.value));
  el.stop.addEventListener("click", () => T.request("chat.stop", {}).catch((e) => showError(cleanErr(e))));
  el.mic.addEventListener("click", toggleVoice);
  el.end.addEventListener("click", toggleVoice);
  el.mute.addEventListener("click", () => T.request("voice.mute", { muted: !S.voice.muted }).catch((e) => showError(cleanErr(e))));
  el.term.addEventListener("click", () => toggleView("act"));
  el.gear.addEventListener("click", () => toggleView("menu"));
  el.orb.addEventListener("click", () => { el.inp.focus(); });
  el.pin.addEventListener("click", () => {
    S.pinned = !S.pinned; el.pin.setAttribute("aria-pressed", String(S.pinned));
    $("span", el.pin).textContent = S.pinned ? "Pinned" : "Pin";
    if (S.pinned) clearTimeout(S.collapseT); else bumpCollapse(3000);
  });

  function paintSwitches() {
    $('[data-act="autoCollapse"]').setAttribute("aria-checked", String(S.autoCollapse));
    $('[data-act="onTop"]').setAttribute("aria-checked", String(S.onTop));
  }
  el.vMenu.addEventListener("click", async (e) => {
    const row = e.target.closest("[data-act]"); if (!row) return;
    switch (row.dataset.act) {
      case "openMain": T.widget("openMain"); setOpen(false); break;
      case "newChat": await newChat(); break;
      case "autoCollapse": S.autoCollapse = !S.autoCollapse; paintSwitches(); T.widget("setOption", { key: "autoCollapse", value: S.autoCollapse }).catch(() => {}); break;
      case "onTop": S.onTop = !S.onTop; paintSwitches(); T.widget("setOption", { key: "onTop", value: S.onTop }).catch(() => {}); break;
      case "hide": setOpen(false); setTimeout(() => T.widget("hide"), 450); break;
      case "quit": T.widget("quit"); break;
    }
  });

  document.addEventListener("keydown", (e) => {
    if (e.key !== "Escape") return;
    if (document.activeElement === el.inp && el.inp.value) { el.inp.value = ""; syncField(); return; }
    if (S.open) { setOpen(false); return; }
    el.inp.blur(); T.widget("blur").catch(() => {});
  });

  /* -------------------------------------------------------------- events */
  function wire() {
    T.on("app.ready", () => { S.booting = false; S.backend = true; applyStatus(); });
    T.on("agent.state", (d) => {
      S.agent = d.state; S.detail = d.detail || "";
      logLine("st", "·", d.state === "executing" ? `running ${d.detail || ""}` : d.state);
      if (d.state === "error" || d.state === "stopped") setTimeout(() => { if (S.agent === d.state) { S.agent = "idle"; applyStatus(); } }, 3200);
      if (d.state === "error") flash("error", 2800);
      applyStatus();
    });
    T.on("chat.user_message", (d) => {
      addMsg("user", d.text);
      logLine("st", "›", `you (${d.source || "typed"})`, d.text);
      setOpen(true, "chat");
    });
    T.on("chat.turn_started", () => { setBusy(true); if (!S.open) setOpen(true, "chat"); });
    T.on("agent.speak", (d) => {
      hideTyping();
      const err = /^\(Troy couldn't reach|^\u26A0/.test(String(d.text || ""));
      addMsg("troy", d.text, { error: err });
      if (S.busy) showTyping();
      S.lastReplyLen = String(d.text || "").length;
      S.speakUntil = Date.now() + clamp(S.lastReplyLen * 60, 1400, 14000);
      logLine("st", "‹", "troy", d.text);
      applyStatus(); setOpen(true, "chat");
    });
    T.on("agent.tool_result", (d) => {
      addStep(d);
      logLine(d.success ? "ok" : "fail", d.success ? "✓" : "✗", `${d.name}${d.arg ? ` ${String(d.arg).slice(0, 60)}` : ""}`, d.message);
    });
    T.on("agent.error", (d) => {
      hideTyping(); addMsg("troy", `⚠ ${d.message}`, { error: true });
      logLine("fail", "✗", "error", d.message); flash("error", 2800); showError(d.message); setOpen(true, "chat");
    });
    T.on("chat.turn_complete", (d) => {
      if (d && d.pending > 0) return;
      setBusy(false); hideTyping();
      if (S.agent !== "error") flash("done", 1400);
      bumpCollapse(clamp(5200 + S.lastReplyLen * 45, 6500, 20000));
    });
    T.on("confirmation.request", confCard);
    T.on("confirmation.resolved", (d) => dropConf(d.id));

    T.on("voice.state", (d) => {
      S.voice = { active: !!d.active, state: d.state || "off", muted: !!d.muted };
      if (!S.voice.active) { S.lvlTarget = 0; el.live.hidden = true; bumpCollapse(4000); }
      else { updateLive(); if (!S.open) setOpen(true, "chat"); }
      applyStatus(); layout();
    });
    T.on("voice.level", (d) => {
      S.lvlTarget = Math.min(1, Math.sqrt(Math.max(0, Number(d.level) || 0) / 240000)); S.lvlAt = Date.now();
    });
    T.on("voice.transcript", (d) => { S.liveText = String(d.text || "").slice(0, 120); S.liveUntil = Date.now() + 3500; updateLive(); });
    T.on("voice.ended", (d) => {
      S.voice = { active: false, state: "off", muted: false }; S.lvlTarget = 0; el.live.hidden = true;
      if (d?.reason === "goodbye") logLine("ev", "·", "voice mode ended", "you said goodbye");
      applyStatus(); layout(); bumpCollapse(4000);
    });
    T.on("wake_listener.state", (d) => { S.wake = d.state || "idle"; applyStatus(); });

    T.on("backend.exited", () => { S.backend = false; S.booting = false; S.busy = false; hideTyping(); applyStatus();  });
    T.on("backend.error", (d) => { S.backend = false; S.booting = false; applyStatus(); setOpen(true, "chat"); addMsg("troy", `⚠ ${d.message}`, { error: true }); });
    T.on("backend.restarted", () => { S.backend = false; S.booting = true; applyStatus(); hydrate(); });
    let langTimer = null;
    T.on("settings.changed", () => { clearTimeout(langTimer); langTimer = setTimeout(() => I18N.sync((m, p) => T.request(m, p)), 300); });
    T.on("widget.options", (d) => {
      if (typeof d.onTop === "boolean") S.onTop = d.onTop;
      if (typeof d.autoCollapse === "boolean") S.autoCollapse = d.autoCollapse;
      if (d.hotkey) setHotkeyHint(d.hotkey);
      paintSwitches();
    });
    T.on("power.state", (d) => applySaver(d.active));
    T.on("ui.command", (d) => {
      if (d?.action === "new_chat") { el.thread.innerHTML = ""; S.stepsEl = null; hideTyping(); emptyHint(); layout(); }
    });
    T.on("widget.focus", () => { setPass(false); el.inp.focus(); el.inp.select(); if (!S.open && el.thread.children.length) bumpCollapse(); });
  }

  /* ----------------------------------------------------------------- boot */
  async function hydrate() {
    for (let i = 0; i < 160; i++) {
      try { await T.request("app.ping", {}); S.backend = true; S.booting = false; break; }
      catch { await sleep(500); }
    }
    if (!S.backend) { S.booting = false; applyStatus(); return; }
    applyStatus();
    try {
      const st = await T.request("agent.status", {});
      if (st?.busy) setBusy(true);
      if (st?.state?.state) { S.agent = st.state.state === "idle" ? "idle" : st.state.state; }
      if (st?.pending_confirmations) {
        const r = await T.request("confirmation.list", {});
        (r?.pending || []).forEach(confCard);
      }
    } catch { /* optional */ }
    try { const v = await T.request("voice.mode_status", {}); S.voice = { active: !!v.active, state: v.state || "off", muted: !!v.muted }; } catch { /* optional */ }
    try { const w = await T.request("wake_listener.status", {}); S.wake = w?.state || "idle"; } catch { /* optional */ }
    try {
      const info = await T.widget("getInfo");
      if (typeof info?.onTop === "boolean") S.onTop = info.onTop;
      if (typeof info?.autoCollapse === "boolean") S.autoCollapse = info.autoCollapse;
      if (info?.hotkey) setHotkeyHint(info.hotkey);
    } catch { /* optional */ }
    try { applySaver((await T.request("power.status", {})).active); } catch { /* optional */ }
    I18N.sync((m, p) => T.request(m, p));                                  // follow the language chosen in the app's Settings
    paintSwitches(); applyStatus(); updateLive();
  }

  wire(); paintSwitches(); setView("chat"); applyStatus(); layout();
  hydrate().then(() => { window.__widgetReady = true; });

  // Handy for tests and for whoever restyles this next.
  window.__widget = { S, el, face, setOpen, setView, layout, send, addMsg, G };
})();
