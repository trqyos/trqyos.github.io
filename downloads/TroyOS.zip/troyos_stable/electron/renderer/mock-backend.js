/* Demo backend. Only activates when there is no real window.troy (i.e. the page
 * was opened in a normal browser, or loaded by a UI test). Inside Electron,
 * preload.js defines window.troy first and this file does nothing.
 *
 * It implements the same methods and events as troy/ipc_host.py with fake data,
 * so the whole interface -- chat, approvals, sessions, settings, tools -- can be
 * designed and tested without Python, API keys or a microphone.
 */
(() => {
  "use strict";
  if (window.troy) return;

  const listeners = {};
  const emit = (event, data = {}) => (listeners[event] || []).slice().forEach((cb) => { try { cb(data); } catch (e) { console.error(e); } });
  const powerChanged = () => {
    const p = db.power, was = p.active;
    p.active = p.mode === "on" || (p.mode === "auto" && !!p.on_battery);
    emit("power.state", { ...p }); void was;
  };
  const later = (ms, fn) => setTimeout(fn, ms);
  const now = () => new Date().toISOString().slice(0, 19);

  const db = {
    sessionId: null, log: [], busy: 0, pendingConf: [], confId: 1,
    sessions: [
      { id: "s-demo-2", title: "Convert 250 USD to EUR", updated_at: new Date(Date.now() - 36e5 * 30).toISOString().slice(0, 19), log: [
        { role: "user", text: "How much is 250 USD in EUR?" },
        { role: "tool", name: "convert_currency", arg: "250|USD|EUR", success: true, message: "250 USD = 231.4 EUR (ECB rate for 2026-09-25)." },
        { role: "assistant", text: "250 USD is **231.40 EUR** at the latest ECB rate." } ] },
      { id: "s-demo-1", title: "Open Firefox and search", updated_at: new Date(Date.now() - 36e5 * 52).toISOString().slice(0, 19), log: [
        { role: "user", text: "Open Firefox" }, { role: "tool", name: "open_app", arg: "firefox", success: true, message: "Opened firefox." },
        { role: "assistant", text: "Firefox is open." },
        { role: "user", text: "Put the computer to sleep every night at 22:00" },
        { role: "tool", name: "schedule_task", arg: "every day at 22:00|Put the computer to sleep.|Sleep the PC|sleep_computer", success: true, message: "Scheduled task t-demo-1 \u201CSleep the PC\u201D: Every day at 22:00." },
        { role: "assistant", text: "Done: I'll put the computer to sleep every night at 22:00. Approve the card so it can run while you're away." } ], task_ids: ["t-demo-1"] },
    ],
    tasks: [],
    memories: [
      { timestamp: "2026-09-20T10:12:00", fact: "Prefers Firefox over Chrome" },
      { timestamp: "2026-09-21T18:40:00", fact: "Likes short, direct answers" },
    ],
    settings: {
      USER_NAME: "Alex", PRIMARY_PROVIDER: "nvidia", TEXT_MODEL_OVERRIDE: "", VISION_MODEL_OVERRIDE: "", ESCALATION_ENABLED: true,
      LMSTUDIO_ENABLED: false, VOICE_INPUT_ENABLED: false, VOICE_OUTPUT_ENABLED: false, POWER_SAVING: "auto", WAKE_WORD: "troy",
      STT_ENGINE: "google", TTS_RATE: 175, TTS_VOICE_ID: "", MAX_STEPS_PER_TURN: 12, BROWSER_HEADLESS: true,
      TTS_ENGINE: "auto", EDGE_VOICE: "", PIPER_MODEL: "", STT_LANGUAGE: "",
      VOICE_BARGE_IN: true, VOICE_CONVERSATION_IDLE_SECONDS: 30, VOICE_INPUT_DEVICE: "", VOICE_SPOKEN_STYLE: true,
      MOBILE_VOICE_ENABLED: true, VOICE_PHONE_SPEAKER: "phone", MOBILE_HTTPS_ENABLED: true, ALLOW_MODEL_SWITCH: true,
      PROMPT_MODE: "auto", CONTEXT_BUDGET_TOKENS: 5500, LLM_MAX_OUTPUT_TOKENS: 1200, LLM_FAST: true,
      LMSTUDIO_CONTEXT_TOKENS: 4096, LMSTUDIO_TEXT_MODEL: "", LMSTUDIO_VISION_MODEL: "",
      APP_LAUNCH_MODE: "auto", MOBILE_SCREEN_ENABLED: true, MOBILE_SCREEN_MAX_FPS: 10,
      YOUTUBE_CLIENT_ID: "", YOUTUBE_BROWSER: "firefox",
      UI_LANGUAGE: (() => { try { return localStorage.getItem("troy.lang") || "en"; } catch { return "en"; } })(), VACUUM_ENABLED: false, VACUUM_HOST: "", VACUUM_ROOM_ENCODING: "auto",
      TASKS_ENABLED: true, TASK_MAX_RETRIES: 2, TASK_RETRY_DELAY_SECONDS: 30, TASK_MISSED_GRACE_MINUTES: 10, EXTRA_TOOLS_ENABLED: true, TOOL_CALLING: "auto",
    },
    yt: { connected: false, waiting: false },
    secrets: { GROQ_API_KEY: false, OPENROUTER_API_KEY: false, GEMINI_API_KEY: false, NVIDIA_API_KEY: true, NEWSAPI_KEY: false, YOUTUBE_CLIENT_SECRET: false, VACUUM_TOKEN: false },
    wake: { running: false, state: "idle" }, mobile: { running: false }, ts: { serving: false }, viewers: 0,
    voice: { active: false, state: "off", source: "pc", muted: false, phone: { connected: false, voice: false, speaker: "phone" }, listener: false, conversation: false },
    widget: { mode: "app", onTop: true, autoCollapse: true, hotkey: "CommandOrControl+Alt+T", hotkeyActive: true, visible: true, platform: "win32", size: { w: 576, h: 114 } },
    power: { mode: "auto", on_battery: null, active: false },
    shell: { alwaysOnTop: false, closeToTray: true, platform: "win32", version: "demo", electron: "demo", packaged: false, python: "python (demo)" },
    logs: [
      "2026-09-27 21:44:57 [INFO] troy: IPC host ready, listening on stdin.",
      "2026-09-27 21:45:03 [INFO] troy: User turn (typed): Open Firefox",
      "2026-09-27 21:45:04 [WARNING] troy: Global hotkey disabled: 'pynput' isn't installed (pip install pynput).",
    ],
  };
  const PROVIDERS = {
    groq: { label: "Groq", secret: "GROQ_API_KEY", text: ["llama-3.3-70b-versatile", "openai/gpt-oss-120b", "qwen/qwen3-32b"], vision: ["meta-llama/llama-4-scout-17b-16e-instruct"] },
    openrouter: { label: "OpenRouter", secret: "OPENROUTER_API_KEY", text: ["openai/gpt-oss-20b:free", "z-ai/glm-4.5-air:free"], vision: ["google/gemma-3-27b-it:free"] },
    gemini: { label: "Google Gemini", secret: "GEMINI_API_KEY", text: ["gemini-2.5-flash", "gemini-2.0-flash"], vision: ["gemini-2.5-flash"] },
    nvidia: { label: "NVIDIA NIM", secret: "NVIDIA_API_KEY", text: ["nvidia/nemotron-3-super-120b-a12b", "z-ai/glm-5.3", "nvidia/nemotron-3.5-lightning-30b-a3b", "z-ai/glm-5.3-flash", "openai/gpt-oss-20b", "meta/muse-glimmer-30b", "mistralai/mistral-nemotron", "poolside/laguna-xs-2.1", "google/gemma-4-31b-it"], vision: ["moonshotai/kimi-k3", "google/diffusiongemma-26b-a4b-it"] },
    lmstudio: { label: "LM Studio (local)", secret: null, text: ["qwen2.5-vl-7b-instruct", "llama-3.2-3b-instruct"], vision: ["qwen2.5-vl-7b-instruct"] },
  };
  const TOOLS = [
    ["open_url", "Opens a URL in your own browser.", "system", "<url>"], ["get_weather_forecast", "Open-Meteo: multi-day forecast for a place.", "api", "<place>|<days=3>"],
    ["convert_currency", "Frankfurter (ECB rates): converts an amount between two currencies.", "api", "<amount>|<from>|<to>"],
    ["wikipedia_summary", "Wikipedia article summary by title or loose topic text.", "api", "<topic_or_title>"],
    ["news_top_headlines", "NewsAPI: current top headlines (needs TROY_NEWSAPI_KEY).", "api", "<country=us>|<category>|<keyword>"],
    ["web_open", "Navigates Troy's own background research browser to a URL.", "web", "<url>"], ["web_read_page", "Returns the page title, URL, and visible text.", "web", ""],
    ["inspect_window", "Lists a window's real controls from the accessibility tree.", "desktop", "<window_title>"],
    ["delete_file", "Deletes a file.", "filesystem", "<path>", true], ["run_shell_command", "Runs a shell command and returns its output.", "system", "<command>", true],
    ["get_full_system_report", "CPU, memory, disk, battery and network in one call.", "system", ""],
  ].map(([name, description, category, arg_hint, conf]) => ({ name, description, category, arg_hint, risk_level: conf ? "high" : "low", requires_confirmation: !!conf }));

  const LM_DETAILS = { "qwen2.5-vl-7b-instruct": { vision: true, loaded: true, context: 8192, max_context: 32768 }, "llama-3.2-3b-instruct": { vision: false, loaded: false, context: 0, max_context: 131072 } };
  const configured = (id) => (id === "lmstudio" ? db.settings.LMSTUDIO_ENABLED : db.secrets[PROVIDERS[id].secret]);
  const ok = (v) => v;
  const infoShape = () => ({ active: db.voice.active, state: db.voice.state, source: db.voice.source, muted: db.voice.muted,
    phone: { connected: db.voice.phone.connected, voice: db.voice.phone.voice, speaker: db.settings.VOICE_PHONE_SPEAKER },
    listener: db.wake.running, conversation: db.wake.running && db.voice.active });

  function startTurn(text, source) {
    db.busy++;
    emit("chat.turn_started", { source });
    const lower = text.toLowerCase();
    const steps = [];
    let reply;
    if (/delete|shutdown|format/.test(lower)) {
      reply = "That needs your approval first \u2014 I've asked below.";
      steps.push({ state: "thinking", ms: 600 });
      steps.push({ run: () => { const c = { id: db.confId++, name: "delete_file", arg: "C:\\Users\\you\\old-report.docx", risk_level: "high", description: "Permanently deletes this file. It can't be undone." }; db.pendingConf.push(c); emit("confirmation.request", c); } });
    } else if (/weather|forecast/.test(lower)) {
      steps.push({ state: "thinking", ms: 500 }, { state: "executing", detail: "get_weather_forecast", ms: 900, tool: { name: "get_weather_forecast", arg: "London|3", success: true, message: "London, England, United Kingdom -- 2026-09-28: Partly cloudy, 9-17\u00B0C, rain 0 mm | 2026-09-29: Light rain, 10-15\u00B0C, rain 3 mm | 2026-09-30: Overcast, 8-14\u00B0C, rain 0.4 mm" } });
      reply = "Here's the outlook for **London**:\n\n- **Mon** \u2014 partly cloudy, 9\u201317\u00B0C\n- **Tue** \u2014 light rain, 10\u201315\u00B0C\n- **Wed** \u2014 overcast, 8\u201314\u00B0C\n\nTake an umbrella on Tuesday.";
    } else if (/screen|see/.test(lower)) {
      steps.push({ state: "thinking", ms: 500 }, { state: "executing", detail: "screenshot", ms: 800, tool: { name: "screenshot", arg: "", success: true, message: "Screenshot analysed." } },
        { state: "executing", detail: "read_screen_text", ms: 700, tool: { name: "read_screen_text", arg: "", success: true, message: "Visual Studio Code \u2014 main.py; terminal showing pytest output." } });
      reply = "You have **VS Code** open with `main.py`, and the terminal shows a passing pytest run.";
    } else if (/\b(sleep|remind|schedule)\b.*\b(at|in|every)\b|\bevery\b.*\bat\b/.test(lower)) {
      steps.push({ state: "thinking", ms: 500 }, { state: "executing", detail: "schedule_task", ms: 600, run: () => {
        autosave();
        const s = db.sessions.find((x) => x.id === db.sessionId); const t = mkTask({ title: "Demo task", prompt: text, schedule_text: "Every day at 22:00", next_run: at(22, 0), session_id: db.sessionId, message_index: db.log.length - 1 });
        db.tasks.unshift(t); (s.task_ids = s.task_ids || []).push(t.id); taskChanged(t);
      }, tool: { name: "schedule_task", arg: "every day at 22:00|" + text, success: true, message: "Scheduled task: Every day at 22:00; first run tonight 22:00." } });
      reply = "Scheduled: I'll do that every day at **22:00**. You can change or cancel it under Tasks.";
    } else if (/fail|error/.test(lower)) {
      steps.push({ state: "thinking", ms: 500 }, { state: "executing", detail: "open_app", ms: 700, tool: { name: "open_app", arg: "nonexistent", success: false, message: "Couldn't find an app called 'nonexistent'." } });
      reply = "I couldn't find that app. Want me to search for it instead?";
    } else {
      steps.push({ state: "thinking", ms: 700 });
      reply = `You said: \u201C${text}\u201D. I'm the demo backend, so I can't really act \u2014 but the real one can open apps, search the web, convert currencies and a lot more.\n\n\`\`\`js\nwindow.troy.request("chat.send", { text })\n\`\`\``;
    }
    let t = 0;
    for (const s of steps) {
      later(t += 50, () => {});
      if (s.state) later(t, () => emit("agent.state", { state: s.state, detail: s.detail || "" }));
      if (s.run) later(t, s.run);
      t += s.ms || 0;
      if (s.tool) later(t, () => { db.log.push({ role: "tool", ...s.tool }); emit("agent.tool_result", s.tool); });
    }
    later(t += 100, () => emit("agent.state", { state: "speaking", detail: "" }));
    later(t += 100, () => { db.log.push({ role: "assistant", text: reply }); emit("agent.speak", { text: reply }); });
    later(t += 150, () => {
      emit("agent.state", { state: "idle", detail: "" });
      db.busy--; autosave();
      emit("chat.turn_complete", { pending: db.busy });
    });
  }

  function autosave() {
    const first = db.log.find((e) => e.role === "user");
    let s = db.sessions.find((x) => x.id === db.sessionId);
    if (!s) { s = { id: db.sessionId, title: "New session", log: [] }; db.sessions.push(s); }
    s.log = db.log.slice(); s.updated_at = now();
    if (first && /^New session$/.test(s.title)) s.title = first.text.slice(0, 48);
  }

  // ---- scheduled tasks (same shapes as troy/ipc_host.py tasks.*)
  const iso = (d) => new Date(d.getTime() - d.getTimezoneOffset() * 6e4).toISOString().slice(0, 19);
  const at = (h, min, addDays = 0) => { const d = new Date(); d.setDate(d.getDate() + addDays); d.setHours(h, min, 0, 0); if (addDays === 0 && d < new Date()) d.setDate(d.getDate() + 1); return iso(d); };
  const mkTask = (o) => ({ id: `t-${Math.random().toString(16).slice(2, 8)}`, title: "", prompt: "", schedule: { kind: "once" }, schedule_text: "", status: "scheduled", created_at: now(), updated_at: now(),
    next_run: null, last_run: null, last_outcome: null, last_summary: "", last_error: "", run_count: 0, fail_count: 0, session_id: null, message_index: null,
    max_retries: null, retry_delay: null, grants: [], needs_approval: [], known_tools: {}, run: null, manual: false, recurring: true, effective_max_retries: 2, effective_retry_delay: 30, ...o });
  db.tasks = [
    mkTask({ id: "t-demo-1", title: "Sleep the PC", prompt: "Put the computer to sleep.", schedule_text: "Every day at 22:00", next_run: at(22, 0), session_id: "s-demo-1", message_index: 3, grants: [], needs_approval: [], run_count: 3, last_outcome: "success", last_summary: "Put the computer to sleep." }),
    mkTask({ id: "t-demo-2", title: "Weekly report", prompt: "Open the report folder and list the newest file.", schedule_text: "Every Monday at 09:00", next_run: at(9, 0, 3), session_id: "s-demo-2", message_index: 0, run_count: 1, last_outcome: "failed", last_error: "Not pre-approved for unattended runs: run_shell_command.", needs_approval: ["run_shell_command"], status: "scheduled" }),
    mkTask({ id: "t-demo-3", title: "Stretch break", prompt: "Show a reminder to stand up.", schedule_text: "Once, yesterday", status: "completed", recurring: false, run_count: 1, last_outcome: "success", last_summary: "Reminded you to stand up.", updated_at: now() }),
  ];
  const taskView = (t) => { const s = db.sessions.find((x) => x.id === t.session_id); return { ...t, chat_exists: !!s, chat_title: s ? s.title : "" }; };
  const taskById = (id) => { const t = db.tasks.find((x) => x.id === id); if (!t) throw new Error("That task no longer exists."); return t; };
  const taskChanged = (t) => { t.updated_at = now(); emit("task.changed", { task: taskView(t) }); return { task: taskView(t) }; };
  const describeWhen = (w) => {
    const text = String(w || "").trim().toLowerCase();
    const m = /^every (day|night|monday|tuesday|wednesday|thursday|friday|saturday|sunday|weekday)s?(?: at (\d{1,2})(?::(\d{2}))?\s*(am|pm)?)?$/.exec(text);
    if (m) { let h = +(m[2] || 9); const mi = +(m[3] || 0); if (m[4] === "pm" && h < 12) h += 12; const clock = `${pad(h)}:${pad(mi)}`; const d = m[1]; return { text: d === "day" || d === "night" ? `Every day at ${clock}` : `Every ${d[0].toUpperCase() + d.slice(1)} at ${clock}`, h, mi }; }
    const dl = /^every ((?:(?:mon|tues|wednes|thurs|fri|satur|sun)day(?:,? and |, | and )?)+)(?: at (\d{1,2})(?::(\d{2}))?\s*(am|pm)?)?$/.exec(text);
    if (dl) { let h = +(dl[2] || 9); const mi = +(dl[3] || 0); if (dl[4] === "pm" && h < 12) h += 12; const days = dl[1].match(/[a-z]+day/g).map((d) => d[0].toUpperCase() + d.slice(1)); return { text: `Every ${days.length > 1 ? `${days.slice(0, -1).join(", ")} and ${days.slice(-1)}` : days[0]} at ${pad(h)}:${pad(mi)}`, h, mi }; }
    const r = /^in (\d+) (minute|hour)s?$/.exec(text);
    if (r) return { text: `Once, in ${r[1]} ${r[2]}${+r[1] === 1 ? "" : "s"}`, once: +r[1] * (r[2] === "hour" ? 60 : 1) };
    throw new Error("I couldn't read that as a time. Supported: 'in 30 minutes', 'tomorrow at 9am', 'every day at 22:00', 'every monday at 9am', ...");
  };
  const pad = (n) => String(n).padStart(2, "0");
  function demoRun(t) {
    t.status = "running"; t.run = { attempt: 1, done_actions: [] }; db.busyTasks = (db.busyTasks || 0) + 1;
    emit("task.started", { task: taskView(t) });
    later(500, () => emit("agent.state", { state: "thinking", detail: "" }));
    later(800, () => { emit("agent.state", { state: "executing", detail: t.prompt.includes("sleep") ? "sleep_computer" : "get_time" }); emit("task.step", { id: t.id, name: t.prompt.includes("sleep") ? "sleep_computer" : "get_time", arg: "", success: true, message: "ok" }); });
    later(1700, () => {
      const needs = t.needs_approval.length && !t.grants.length;
      t.run = null; t.run_count++; t.manual = false;
      if (needs) { t.last_outcome = "failed"; t.last_error = `Not pre-approved for unattended runs: ${t.needs_approval.join(", ")}.`; t.last_summary = `Needs your approval to run unattended: ${t.needs_approval.join(", ")}.`; t.fail_count++; }
      else { t.last_outcome = "success"; t.last_error = ""; t.last_summary = "Done."; t.needs_approval = []; }
      t.status = t.recurring ? "scheduled" : (needs ? "failed" : "completed");
      if (t.recurring) t.next_run = at(22, 0);
      const ok = !needs, text = ok ? `Scheduled task \u201C${t.title}\u201D is done: ${t.last_summary}` : `Scheduled task \u201C${t.title}\u201D didn't succeed: ${t.last_summary} Open Tasks and press Approve to let it run those commands unattended.`;
      const entry = { role: "task", text, task_id: t.id, title: t.title, ok, kind: "finished" };
      const current = !!t.session_id && t.session_id === db.sessionId;
      if (current) db.log.push(entry);
      else { const s = db.sessions.find((x) => x.id === t.session_id); if (s) s.log.push(entry); }
      emit("agent.state", { state: "idle", detail: "" });
      emit("task.finished", { task: taskView(t), ok, text, kind: "finished", session_id: t.session_id, in_current_chat: current, entry, attempts: 1 });
      emit("task.changed", { task: taskView(t) });
    });
  }
  const isFin = (t) => ["completed", "failed", "cancelled", "missed"].includes(t.status);

  const handlers = {
    "app.ping": () => ({ pong: true, version: "v1.0.0", version_label: "TROYOS STABLE" }),
    "agent.status": () => ({ state: { state: "idle" }, session_id: db.sessionId, busy: db.busy > 0, pending_confirmations: db.pendingConf.length, wake_listener: db.wake.running ? db.wake.state : "off" }),
    "chat.send": (p) => {
      if (!String(p.text || "").trim()) throw new Error("Nothing to send -- the message is empty.");
      if (!db.sessionId) { db.sessionId = `s-${Date.now()}`; db.log = []; }
      db.log.push({ role: "user", text: p.text.trim() });
      // like the real host: every surface hears about every user message (the main UI skips "typed" ones it drew itself)
      emit("chat.user_message", { text: p.text.trim(), source: p.source || "typed" });
      startTurn(p.text.trim(), p.source || "typed");
      return { accepted: true, session_id: db.sessionId };
    },
    "chat.stop": () => { emit("agent.state", { state: "stopped", detail: "" }); return { stopped: true }; },
    "session.reset": () => { if (db.busy) throw new Error("Troy is busy with a request -- stop it or wait for it to finish first."); db.sessionId = null; db.log = []; return { id: null }; },
    "session.new": () => { db.sessionId = `s-${Date.now()}`; db.log = []; return { id: db.sessionId }; },
    "session.list": () => ({ sessions: db.sessions.map(({ id, title, updated_at, task_ids }) => ({ id, title, updated_at, has_tasks: !!(task_ids && task_ids.length), task_count: (task_ids || []).length })) }),
    "tasks.list": () => ({ tasks: db.tasks.map(taskView), enabled: db.settings.TASKS_ENABLED, scheduler_running: db.settings.TASKS_ENABLED, defaults: { max_retries: db.settings.TASK_MAX_RETRIES, retry_delay: db.settings.TASK_RETRY_DELAY_SECONDS, grace_minutes: db.settings.TASK_MISSED_GRACE_MINUTES } }),
    "tasks.get": (p) => ({ task: taskView(taskById(p.id)) }),
    "tasks.preview": (p) => { try { const d = describeWhen(p.when); return { ok: true, spec: {}, text: d.text, next: [d.once ? iso(new Date(Date.now() + d.once * 6e4)) : at(d.h, d.mi), at(d.h ?? 9, d.mi ?? 0, 1), at(d.h ?? 9, d.mi ?? 0, 2)].slice(0, d.once ? 1 : 3) }; } catch (e) { return { ok: false, error: e.message }; } },
    "tasks.create": (p) => {
      if (!String(p.prompt || "").trim()) throw new Error("The task needs an instruction (what Troy should do when it's time).");
      const d = describeWhen(p.when);
      const grants = String(p.approve || "").split(";").map((x) => x.trim()).filter(Boolean);
      const bad = grants.find((g) => !/^(sleep_computer|shutdown_computer|restart_computer|delete_file|run_shell_command)/.test(g));
      if (bad) throw new Error(`'${bad}' isn't a tool, so it can't be pre-approved. Use exact tool names (list_extra_tools shows them).`);
      const t = mkTask({ title: p.title || String(p.prompt).slice(0, 50), prompt: p.prompt, schedule_text: d.text, recurring: !d.once, next_run: d.once ? iso(new Date(Date.now() + d.once * 6e4)) : at(d.h, d.mi), grants });
      db.tasks.unshift(t); return taskChanged(t);
    },
    "tasks.modify": (p) => { const t = taskById(p.id); if (p.title) t.title = p.title; if (p.prompt != null && p.prompt !== t.prompt) { t.prompt = p.prompt; t.grants = []; } if (p.when) { const d = describeWhen(p.when); t.schedule_text = d.text; t.next_run = d.once ? iso(new Date(Date.now() + d.once * 6e4)) : at(d.h, d.mi); t.recurring = !d.once; if (isFin(t)) t.status = "scheduled"; } if (p.max_retries != null) t.max_retries = p.max_retries; if (p.default_retries) t.max_retries = null; if (p.retry_delay != null) t.retry_delay = p.retry_delay; return taskChanged(t); },
    "tasks.cancel": (p) => { const t = taskById(p.id); t.status = "cancelled"; t.next_run = null; return taskChanged(t); },
    "tasks.pause": (p) => { const t = taskById(p.id); t.status = "paused"; t.next_run = null; return taskChanged(t); },
    "tasks.resume": (p) => { const t = taskById(p.id); t.status = "scheduled"; t.next_run = at(22, 0); return taskChanged(t); },
    "tasks.run_now": (p) => { const t = taskById(p.id); t.manual = true; taskChanged(t); demoRun(t); return { task: taskView(t) }; },
    "tasks.approve": (p) => { const t = taskById(p.id); if (!t.needs_approval.length) throw new Error("Nothing is waiting for approval on that task."); t.grants = [...new Set([...t.grants, ...t.needs_approval])]; t.needs_approval = []; taskChanged(t); demoRun(t); return { task: taskView(t) }; },
    "tasks.delete": (p) => { db.tasks = db.tasks.filter((t) => t.id !== p.id); emit("task.deleted", { id: p.id }); return { ok: true }; },
    "tasks.clear_finished": () => { const gone = db.tasks.filter(isFin); db.tasks = db.tasks.filter((t) => !isFin(t)); gone.forEach((t) => emit("task.deleted", { id: t.id })); return { cleared: gone.length }; },
    "tasks.logs": (p) => ({ entries: [{ ts: now(), task_id: p.id, event: "created", level: "info", message: "Created by the demo backend." }, ...(taskById(p.id).run_count ? [{ ts: now(), task_id: p.id, event: "success", level: "info", message: taskById(p.id).last_summary || "Done." }] : [])] }),
    "session.load": (p) => {
      if (db.busy) throw new Error("Troy is busy with a request -- stop it or wait for it to finish first.");
      const s = db.sessions.find((x) => x.id === p.id); if (!s) throw new Error(`No such session: ${p.id}`);
      db.sessionId = s.id; db.log = s.log.slice(); return { id: s.id, title: s.title, display_log: db.log };
    },
    "session.rename": (p) => { const s = db.sessions.find((x) => x.id === p.id); if (s) s.title = p.title; return { ok: !!s }; },
    "session.delete": (p) => { db.sessions = db.sessions.filter((x) => x.id !== p.id); const cur = p.id === db.sessionId; if (cur) { db.sessionId = null; db.log = []; } return { ok: true, was_current: cur }; },
    "memory.list": () => ({ memories: db.memories.slice() }),
    "memory.add": (p) => { db.memories.push({ timestamp: now(), fact: p.fact }); return { message: `Remembered: ${p.fact}` }; },
    "memory.delete": (p) => { db.memories.splice(p.index, 1); return { ok: true }; },
    "memory.clear": () => { const n = db.memories.length; db.memories = []; return { cleared: n }; },
    "context.get": () => ({ success: true, message: `Time: ${new Date().toLocaleString([], { weekday: "short", month: "short", day: "numeric", hour: "2-digit", minute: "2-digit", second: "2-digit" })} | Active window: 'Troy' (electron.exe) | 7 window(s) open | CPU 14% / RAM 52% | Web research browser: not started yet (starts automatically on first web_* call)` }),
    "confirmation.list": () => ({ pending: db.pendingConf.slice() }),
    "confirmation.resolve": (p) => {
      db.pendingConf = db.pendingConf.filter((c) => c.id !== p.id);
      const result = { success: !!p.approved, name: "delete_file", arg: "old-report.docx", message: p.approved ? "Deleted old-report.docx" : "Cancelled by user" };
      emit("confirmation.resolved", { id: p.id, approved: !!p.approved, result });
      db.busy++; emit("chat.turn_started", { source: "confirmation" });
      later(500, () => emit("agent.state", { state: "thinking", detail: "" }));
      later(1200, () => { const t = p.approved ? "Done \u2014 the file is deleted." : "Okay, I left it alone."; db.log.push({ role: "assistant", text: t }); emit("agent.speak", { text: t }); });
      later(1500, () => { emit("agent.state", { state: "idle", detail: "" }); db.busy--; emit("chat.turn_complete", { pending: db.busy }); });
      return { result };
    },
    "power.status": () => ({ ...db.power }),
    "power.report": (p) => { db.power.on_battery = p.on_battery; powerChanged(); return { ...db.power }; },
    "ui.report": (p) => { db.ui = { ...(db.ui || {}), ...p }; return db.ui; },
    "settings.get": () => ({ values: { ...db.settings }, secrets_configured: { ...db.secrets }, assistant_name: "Troy", version: "v1.0.0", version_label: "TROYOS STABLE", restart_required_keys: ["BROWSER_HEADLESS"] }),
    "settings.update": (p) => {
      const applied = [];
      for (const [k, v] of Object.entries(p.changes || {})) {
        if (k === "UI_LANGUAGE") { try { localStorage.setItem("troy.lang", v); } catch { /* ignore */ } }   // the real backend persists it; the page caches it
        if (k in db.settings) { if (k === "TTS_RATE" && (v < 50 || v > 400)) throw new Error("TTS_RATE must be between 50 and 400."); db.settings[k] = v; }
        else if (k in db.secrets) { db.secrets[k] = !!String(v).trim(); if (k === "YOUTUBE_CLIENT_SECRET" && !db.secrets[k]) db.yt.connected = false; }
        else throw new Error(`Unknown or read-only setting: ${k}`);
        applied.push(k);
      }
      if (applied.includes("POWER_SAVING")) { db.power.mode = db.settings.POWER_SAVING; powerChanged(); }
      emit("settings.changed", { keys: applied.sort() });
      return { applied: applied.sort(), restart_required: applied.filter((k) => k === "BROWSER_HEADLESS") };
    },
    "vacuum.test": () => (db.settings.VACUUM_ENABLED && db.settings.VACUUM_HOST && db.secrets.VACUUM_TOKEN
      ? { success: true, message: "Connected to xiaomi.vacuum.b108gl (firmware 4.5.0); it is charging on the dock, battery 87%.", model: "xiaomi.vacuum.b108gl", battery: 87 }
      : { success: false, message: "The robot vacuum isn't set up yet: it needs its IP address and device token." }),
    "vacuum.discover": () => ({ devices: [{ ip: "192.168.1.50", did: 123456789 }] }),
    "provider.list": () => ({
      providers: Object.entries(PROVIDERS).map(([id, p]) => ({ id, label: p.label, configured: !!configured(id), primary: db.settings.PRIMARY_PROVIDER === id, models: { text: p.text, vision: p.vision }, ...(id === "lmstudio" ? { details: LM_DETAILS } : {}) })),
      overrides: { text: db.settings.TEXT_MODEL_OVERRIDE, vision: db.settings.VISION_MODEL_OVERRIDE },
    }),
    "provider.set_primary": (p) => { if (!PROVIDERS[p.provider]) throw new Error(`Unknown provider: ${p.provider}`); return handlers["settings.update"]({ changes: { PRIMARY_PROVIDER: p.provider } }); },
    "provider.fetch_models": (p) => {
      if (p.provider === "lmstudio") return { models: Object.keys(LM_DETAILS), details: LM_DETAILS };
      if (!configured(p.provider)) throw new Error("Provider not available (enable/configure it first).");
      return { models: PROVIDERS[p.provider].text.concat(PROVIDERS[p.provider].vision, ["extra/model-a", "extra/model-b", "extra/model-c"]).sort(), details: {} };
    },
    "model.set": (p) => handlers["settings.update"]({ changes: { [`${p.kind.toUpperCase()}_MODEL_OVERRIDE`]: p.provider && p.model ? `${p.provider}:${p.model}` : "" } }),
    "tools.list": () => ({ tools: TOOLS }),
    "voice.list_voices": (p) => (p && p.engine === "edge"
      ? { voices: [{ id: "en-US-AriaNeural", name: "Aria (en-US)" }, { id: "en-GB-SoniaNeural", name: "Sonia (en-GB)" }, { id: "tr-TR-EmelNeural", name: "Emel (tr-TR)" }] }
      : { voices: [{ id: "v1", name: "Microsoft Zira" }, { id: "v2", name: "Microsoft David" }] }),
    "voice.speak": () => ({ queued: true }),
    "voice.mode_start": (p) => {
      db.voice = { ...db.voice, active: true, state: "listening", muted: false };
      later(60, () => emit("voice.state", { ...infoShape() }));
      return { started: true };
    },
    "voice.mode_stop": (p) => {
      const was = db.voice.active;
      db.voice = { ...db.voice, active: false, state: "off", muted: false };
      if (was) { later(60, () => { emit("voice.state", { ...infoShape() }); emit("voice.ended", { reason: p.reason || "user" }); }); }
      return { stopped: true };
    },
    "voice.mode_status": () => ({ ...infoShape(), engines: [
      { id: "piper", available: !!db.settings.PIPER_MODEL, reason: db.settings.PIPER_MODEL ? "" : "no voice model set" },
      { id: "edge", available: true, reason: "" },
      { id: "sapi", available: true, reason: "" }],
      stt: { engine: db.settings.STT_ENGINE, available: true, reason: "" } }),
    "voice.mute": (p) => {
      db.voice.muted = !!p.muted; if (db.voice.active) db.voice.state = db.voice.muted ? "muted" : "listening";
      later(60, () => emit("voice.state", { ...infoShape() }));
      return { ...infoShape() };
    },
    "voice.interrupt": () => { later(60, () => emit("voice.state", { ...infoShape() })); return { ok: true }; },
    "voice.devices": () => ({ devices: [
      { index: 0, name: "Built-in Microphone", default: true },
      { index: 2, name: "USB Conference Mic", default: false }] }),
    "voice.test_mic": () => {
      for (let i = 0; i < 20; i++) later(i * 200, () => emit("voice.level", { level: 4000 + 60000 * Math.abs(Math.sin(i / 3)), state: "test" }));
      return { ok: true, peak: 0.31, heard: "hello from the demo microphone", silent: false };
    },
    "wake_listener.start": () => { db.wake = { running: true, state: "idle" }; later(300, () => emit("wake_listener.state", { state: "idle" })); return { started: true }; },
    "wake_listener.stop": () => { db.wake = { running: false, state: "idle" }; return { stopped: true }; },
    "wake_listener.status": () => ({ ...db.wake }),
    "mobile_ui.start": () => { db.mobile = { running: true }; return handlers["mobile_ui.status"](); },
    "mobile_ui.stop": () => { db.mobile = { running: false }; return { stopped: true }; },
    "mobile_ui.regenerate_token": () => handlers["mobile_ui.status"](),
    "mobile_ui.status": () => {
      const urls = db.mobile.running ? [
        ...(db.ts.serving ? [{ kind: "tailscale-https", label: "Tailscale (HTTPS, from anywhere)", url: "https://desktop.tail1234.ts.net/?t=demo-token", detail: "Encrypted, works on mobile data, allows voice input.", recommended: true }] : []),
        { kind: "tailscale", label: "Tailscale (from anywhere)", url: "http://100.64.0.5:8765/?t=demo-token", detail: "Needs Tailscale on the phone (me.ts.net).", recommended: !db.ts.serving },
        { kind: "lan", label: "Wi-Fi (same network)", url: "http://192.168.1.20:8765/?t=demo-token", detail: "Only works while the phone is on the same Wi-Fi.", recommended: false }] : [];
      return { running: !!db.mobile.running, url: urls[0]?.url || "", urls, viewers: db.viewers, screen_enabled: db.settings.MOBILE_SCREEN_ENABLED, port: 8765, tailscale: handlers["remote.tailscale"]() };
    },
    "remote.tailscale": () => ({ installed: true, running: true, state: "Running", ip: "100.64.0.5", dns_name: "desktop.tail1234.ts.net", tailnet: "me.ts.net", hostname: "DESKTOP", serving: db.ts.serving, error: "",
      peers: [{ name: "pixel-8", ip: "100.64.0.9", os: "android", online: true }, { name: "old-laptop", ip: "100.64.0.7", os: "linux", online: false }] }),
    "remote.tailscale_serve": (p) => { db.ts.serving = !!p.enable; return { success: true, message: p.enable ? "HTTPS sharing is on." : "HTTPS sharing turned off." }; },
    "session.search": (p) => {
      const words = String(p.query || "").toLowerCase().split(/\s+/).filter(Boolean); if (!words.length) return { results: [], total_chats: 0 };
      const results = [];
      for (const s of db.sessions) {
        const titleMatch = words.every((w) => s.title.toLowerCase().includes(w)); const hits = []; let n = 0;
        (s.log || []).forEach((e, index) => {
          const t = e.role === "tool" ? `${e.name} ${e.arg} ${e.message}` : e.text || "";
          if (words.every((w) => t.toLowerCase().includes(w))) { n++; if (hits.length < 3) { const pos = Math.max(0, t.toLowerCase().indexOf(words[0])); hits.push({ index, role: e.role, snippet: t.slice(Math.max(0, pos - 30), pos + 60), start: Math.min(30, pos), length: words[0].length }); } }
        });
        if (titleMatch || n) results.push({ id: s.id, title: s.title, updated_at: s.updated_at, title_match: titleMatch, hit_count: n, hits });
      }
      results.sort((a, b) => (b.title_match - a.title_match) || (b.hit_count - a.hit_count));
      return { results, total_chats: results.length };
    },
    "prompt.info": () => ({ mode: "compact", setting: db.settings.PROMPT_MODE, prompt_tokens: 2100, budget_tokens: db.settings.CONTEXT_BUDGET_TOKENS, lmstudio_context: db.settings.LMSTUDIO_ENABLED ? 8192 : null }),
    "youtube.status": () => ({ configured: !!db.settings.YOUTUBE_CLIENT_ID && db.secrets.YOUTUBE_CLIENT_SECRET, connected: db.yt.connected, signing_in: db.yt.waiting, error: "", channel: db.yt.connected ? { id: "UC1", title: "Alex", thumbnail: "" } : null }),
    "youtube.connect": () => { if (!(db.settings.YOUTUBE_CLIENT_ID && db.secrets.YOUTUBE_CLIENT_SECRET)) throw new Error("Add your Google OAuth client id and secret first (Settings > Integrations)."); db.yt.waiting = true; return { auth_url: "https://accounts.google.com/o/oauth2/v2/auth?demo", port: 5555 }; },
    "youtube.complete": () => { db.yt = { connected: true, waiting: false }; later(100, () => emit("youtube.connected", { channel: { title: "Alex" } })); return { message: "Troy is connected to YouTube." }; },
    "youtube.cancel": () => { db.yt.waiting = false; return { cancelled: true }; },
    "youtube.disconnect": () => { db.yt = { connected: false, waiting: false }; return { ok: true }; },
    "youtube.test": () => { if (!db.yt.connected) throw new Error("YouTube isn't connected. Open Settings > Integrations and press Connect YouTube."); return { success: true, message: "", video: { title: "Lo-fi beats to study to", channel: "Chillhop", added_at: "2026-10-01T09:00:00Z", url: "https://www.youtube.com/watch?v=jfKfPfyJRdk", playlist: "Liked videos" } }; },
    "browser.open": (p) => ({ success: true, message: `Opened ${p.url} in a new firefox tab.` }),
    "apps.test": (p) => ({ success: /spotify|notepad|calculator/i.test(p.name), message: /spotify|notepad|calculator/i.test(p.name) ? `Opened '${p.name}' directly (demo).` : `Couldn't find an app called '${p.name}' to launch directly.` }),
    "logs.tail": (p) => ({ lines: db.logs.slice(-(p.lines || 200)) }),
  };

  window.troy = {
    platform: "win32",
    demo: true,
    __emit: emit,                                   // lets tests and designers fire backend events by hand
    request: (method, params) => new Promise((resolve, reject) => {
      later(40, () => {
        try {
          const h = handlers[method];
          if (!h) throw new Error(`Unknown method: ${method}`);
          resolve(ok(JSON.parse(JSON.stringify(h(params || {})))));
        } catch (e) { reject(e); }
      });
    }),
    on: (event, cb) => { (listeners[event] = listeners[event] || []).push(cb); return () => { listeners[event] = listeners[event].filter((x) => x !== cb); }; },
    off: (event, cb) => { listeners[event] = (listeners[event] || []).filter((x) => x !== cb); },
    window: async (action, value) => {
      if (action === "setAlwaysOnTop") db.shell.alwaysOnTop = !!value;
      if (action === "setCloseToTray") db.shell.closeToTray = !!value;
      return { ...db.shell };
    },
    // Stand-in for the always-on-top widget window (main.js "troy:widget"); calls are recorded for tests.
    widget: async (action, value) => {
      (window.troy.__widgetCalls = window.troy.__widgetCalls || []).push({ action, value });
      const w = db.widget;
      if (action === "setOnTop") w.onTop = !!value;
      if (action === "setOption") {
        if (value.key === "hotkey") {
          if (/taken/i.test(value.value)) return { ...w, ok: false, error: "That shortcut is already used by another app." };
          w.hotkey = value.value; w.hotkeyActive = true;
        } else w[value.key] = value.value;
        emit("widget.options", { ...w });
        return { ...w, ok: true };
      }
      if (action === "show") { w.mode = "widget"; emit("ui.mode", { mode: "widget" }); }
      if (action === "openMain") { w.mode = "app"; emit("ui.mode", { mode: "app" }); }
      if (action === "hide") { w.mode = "hidden"; emit("ui.mode", { mode: "hidden" }); }
      return { ...w };
    },
    openExternal: async (url) => { window.open(url, "_blank", "noopener"); return true; },
  };
  console.info("Troy UI running against the demo backend (no Electron / Python detected).");
})();
