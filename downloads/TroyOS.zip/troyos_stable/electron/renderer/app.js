/* Troy renderer.
 *
 * Talks to the Python backend only through window.troy (see preload.js):
 *   troy.request(method, params) -> Promise     troy.on(event, cb)
 *   troy.window(action, value)                  troy.openExternal(url)
 * Every backend method/event used here is documented in electron/README.md.
 * Depends on ui-kit.js (helpers, markdown, modals, popovers) and avatar.js.
 */
"use strict";

(() => {
const T = window.troy;

/* =========================================================== preferences */
const UI_KEY = "troy.ui.v2";
const ACCENTS = [
  { id: "periwinkle", name: "Periwinkle", a: "#7c9dff", b: "#b48cff" },
  { id: "aqua", name: "Aqua", a: "#38c9e0", b: "#7c9dff" },
  { id: "mint", name: "Mint", a: "#34d399", b: "#38c9e0" },
  { id: "rose", name: "Rose", a: "#ff7aa8", b: "#b48cff" },
  { id: "amber", name: "Amber", a: "#f5b13d", b: "#ff7aa8" },
];
const UI_DEFAULT = {
  theme: "dark", accent: "periwinkle", blur: 26, reduceMotion: false, sidebar: true, mode: "split",
  avatar: { scale: 1, gap: 130, tracking: true, sound: false, sleep: true },
};
function loadUI() {
  try {
    const s = JSON.parse(localStorage.getItem(UI_KEY) || "{}");
    return { ...UI_DEFAULT, ...s, avatar: { ...UI_DEFAULT.avatar, ...(s.avatar || {}) } };
  } catch { return JSON.parse(JSON.stringify(UI_DEFAULT)); }
}
const UI = loadUI();
const saveUI = () => { try { localStorage.setItem(UI_KEY, JSON.stringify(UI)); } catch { /* storage may be unavailable */ } };
const hexRgb = (h) => [1, 3, 5].map((i) => parseInt(h.substr(i, 2), 16)).join(", ");

/* ================================================================ state */
const S = {
  view: "chat", pane: "providers",
  sid: null, title: "New chat", log: [], busy: false, loading: false,
  state: "starting", stateDetail: "",
  sessions: [], sessQ: "", provs: [], overrides: { text: "", vision: "" }, settings: null,
  tools: [], toolCat: "all", toolQ: "", memories: [], memQ: "",
  wake: { running: false, state: "idle" }, mobile: { running: false, url: "" }, shell: {},
  flash: null, speechUntil: 0, lastDesired: "", unseen: 0, lastUser: "",
  consoleLines: [], logSrc: "file", logLvl: "", logQ: "", fetched: {}, muteSettingsEvent: 0,
  banner: null, backendUp: false, ping: null,
  tasks: [], taskFilter: "active", taskQ: "", taskOpen: {}, taskStep: {}, tasksInfo: { enabled: true, scheduler_running: true, defaults: {} },
  mode: "app", widget: {}, power: { mode: "auto", on_battery: null, active: false },
};
const els = {};
for (const id of ["bg", "titlebar", "sbToggle", "sessionTitle", "statePill", "voiceModeBtn", "modelBtn", "modelLabel", "modeSeg", "cmdBtn", "widgetBtn",
  "sidebar", "nav", "memCount", "newChat", "sessQ", "sessions", "beDot", "beText", "themeBtn", "banner", "bannerText", "bannerBtn",
  "avatarCard", "stateChip", "focusBtn", "face", "caption", "ctxChips", "micBtn", "speakBtn", "ctxBtn", "chatCard", "messages", "jump", "jumpN",
  "confs", "slash", "inp", "stopBtn", "sendBtn", "memIn", "memAdd", "memQ", "memClear", "memList", "toolsH", "toolQ", "toolCats", "toolList",
  "logSrc", "logLvl", "logQ", "logAuto", "logRef", "logCopy", "logOut", "setNav", "setPane", "viewerChip",
  "taskCount", "taskList", "taskNew", "taskFilter", "taskQ", "taskClear", "taskOff", "taskOn",
  "voiceOverlay", "voiceFace", "vLevel", "vChip", "vTranscript", "vMuteBtn", "vStopBtn", "vEndBtn"]) els[id] = document.getElementById(id);

const cleanErr = (e) => String(e?.message || e).replace(/^Error invoking remote method '[^']+': (Error: )?/, "");
async function call(method, params, { quiet = false } = {}) {
  try { return await T.request(method, params || {}); }
  catch (e) { if (!quiet) toast(cleanErr(e)); throw e; }
}
const shell = async (action, value) => { try { const r = await T.window(action, value); S.shell = r || S.shell; return r; } catch { return null; } };

/* ================================================================= theme */
const resolvedTheme = () => (UI.theme === "auto" ? (matchMedia("(prefers-color-scheme: light)").matches ? "light" : "dark") : UI.theme);
let face = null;

function applyUI() {
  const b = document.body, th = resolvedTheme(), ac = ACCENTS.find((a) => a.id === UI.accent) || ACCENTS[0];
  b.classList.toggle("theme-light", th === "light");
  b.classList.toggle("theme-dark", th === "dark");
  b.style.setProperty("--acc", ac.a); b.style.setProperty("--acc-rgb", hexRgb(ac.a)); b.style.setProperty("--acc2", ac.b);
  b.style.setProperty("--blur", `${UI.blur}px`);
  b.classList.toggle("reduce-motion", !!UI.reduceMotion);
  b.classList.toggle("sb-collapsed", !UI.sidebar);
  b.dataset.mode = UI.mode;
  b.dataset.view = S.view;
  b.classList.toggle("saver", !!S.power.active);          // power saving: calmer visuals (see styles.css)
  $$("#modeSeg button").forEach((x) => x.classList.toggle("on", x.dataset.mode === UI.mode));
  els.themeBtn.innerHTML = ic(th === "light" ? "sun" : "moon");
  els.themeBtn.title = th === "light" ? "Switch to dark" : "Switch to light";
  if (face) face.setOptions({ ...UI.avatar, light: th === "light", saver: !!S.power.active });
  shell("setTheme", th === "light" ? "#1a2038" : "#e6ebf5");
  reportUI();
}
// Tell the backend what the interface looks like, so Troy can answer "what theme am I on?".
let reportTimer = null;
function reportUI() {
  clearTimeout(reportTimer);
  reportTimer = setTimeout(() => T.request("ui.report", { view: S.view, theme: resolvedTheme(), layout: UI.mode }).catch(() => {}), 400);
}
const platformClass = () => document.body.classList.add(`plat-${T.platform || "win32"}`);
matchMedia("(prefers-color-scheme: light)").addEventListener?.("change", () => UI.theme === "auto" && applyUI());

/* ===================================================== avatar + captions */
const FACE_LABEL = { idle: "Ready", listening: "Listening", thinking: "Thinking", executing: "Working", speaking: "Speaking", done: "Done", error: "Problem", sleeping: "Asleep", surprised: "Oh!", wink: "Ready", curious: "Ready", proud: "Done" };
let captionTimer = null;
const FACE_ID = `app-${Math.random().toString(36).slice(2, 8)}`;

function mountFace() {
  if (typeof NovaFace === "undefined") return;
  try {
    const bg = els.bg, card = els.avatarCard;
    let last = "";
    face = NovaFace.mount(els.face, {
      onTint: (r, g, b) => {
        const v = `${r}, ${g}, ${b}`;
        if (v === last) return;
        last = v;
        bg.style.setProperty("--tint-rgb", v);
        card.style.setProperty("--tint-rgb", v);
      },
    });
    face.onStateChange = (s) => {
      els.stateChip.dataset.s = s;
      $("span", els.stateChip).textContent = FACE_LABEL[s] || s;
    };
    face.setOptions({ ...UI.avatar, light: resolvedTheme() === "light", saver: !!S.power.active });
    // Same blinks, glances and expressions as the widget and the phone, at the same moment (shared clock);
    // a poke or wake-up on any of them is passed on through the backend and replayed on the others.
    face.setSync({ now: Date.now, id: FACE_ID, send: (evt) => T.request("face.relay", evt).catch(() => {}) });
  } catch (e) { console.error("Avatar failed to start:", e); }
}

function setCaption(text, hold = false) {
  clearTimeout(captionTimer);
  const plain = String(text || "").replace(/```[\s\S]*?```/g, " (code) ").replace(/\n\s*[-*\u2022]\s+/g, " \u00B7 ").replace(/^\s*[-*\u2022]\s+/, "").replace(/[*_`#>]/g, "").replace(/\s+/g, " ").trim();
  els.caption.textContent = plain.length > 240 ? `${plain.slice(0, 237)}…` : plain;
  els.caption.classList.toggle("show", !!plain);
  if (plain && !hold && UI.mode !== "focus") captionTimer = setTimeout(() => els.caption.classList.remove("show"), 4200 + plain.length * 45);
}

function flash(state, ms) {
  if (S.flash && S.flash.state === "error" && S.flash.until > Date.now() && state !== "error") return;
  S.flash = { state, until: Date.now() + ms };
  applyAvatar();
}

function desiredFace() {
  const now = Date.now();
  if (S.flash && S.flash.until > now) return S.flash.state;
  if (S.wake.state === "hearing") return "listening";
  if (S.speechUntil > now) return "speaking";
  switch (S.state) {
    case "thinking": return "thinking";
    case "executing": return "executing";
    case "speaking": return "speaking";
    case "error": return "error";
    default: return S.busy ? "thinking" : "idle";
  }
}
function applyAvatar() {
  if (!face) return;
  face.locked = S.busy || S.speechUntil > Date.now();
  const want = desiredFace();
  // Only push a change: re-asserting "idle" every tick would keep waking a sleeping face.
  if (want !== S.lastDesired) { S.lastDesired = want; face.setState(want); }
}

/* ============================================================ agent state */
const PILL = {
  starting: "Starting…", offline: "Backend offline", idle: "Ready", thinking: "Thinking…", speaking: "Replying…",
  stopped: "Stopped", error: "Something went wrong",
};
function setAgentState(state, detail = "") {
  S.state = state; S.stateDetail = detail;
  const pill = els.statePill;
  pill.dataset.s = state;
  $("span", pill).textContent = state === "executing" ? `Running ${detail || "…"}` : (PILL[state] || state);
  updateTyping();
  if (state === "executing" && detail) setCaption(`Running ${detail}…`, true);
  if (state === "error") flash("error", 2800);
  applyAvatar();
}

function setBusy(b) {
  if (S.busy === b) return;
  S.busy = b;
  els.stopBtn.classList.toggle("hidden", !b);
  if (b) updateTyping(); else hideTyping();
  applyAvatar();
}

/* ============================================================= messages */
let typingEl = null;
const nearBottom = () => els.messages.scrollHeight - els.messages.scrollTop - els.messages.clientHeight < 90;
function scrollBottom(smooth = true) {
  els.messages.classList.toggle("nosmooth", !smooth);
  els.messages.scrollTop = els.messages.scrollHeight;
  S.unseen = 0; updateJump();
}
function updateJump() {
  const away = !nearBottom() && UI.mode !== "focus";
  els.jump.classList.toggle("hidden", !away);
  els.jumpN.textContent = S.unseen ? `${S.unseen} new` : "";
}
function place(node, { force = false } = {}) {
  const stick = force || S.loading || nearBottom();
  if (typingEl) els.messages.insertBefore(node, typingEl); else els.messages.append(node);
  if (S.loading) return;
  if (stick) scrollBottom(true); else { S.unseen++; updateJump(); }
}
const clearEmpty = () => $(".empty", els.messages)?.remove();
const looksLikeError = (t) => /^\(Troy couldn't reach|^\u26A0/.test(String(t || ""));

function addMsg(role, text, opt = {}) {
  clearEmpty();
  const el = document.createElement("div");
  el.className = `msg ${role}${opt.error ? " error" : ""}`;
  if (opt.noAnim) el.style.animation = "none";
  el.innerHTML = `<div class="body">${role === "user" ? esc(text) : md(text)}</div>${opt.src ? `<small class="src">via ${esc(opt.src)}</small>` : ""}<button class="icon-btn sm copy" title="Copy" data-copy-msg>${ic("copy")}</button>`;
  el._raw = text;
  if (opt.idx != null) el.dataset.i = opt.idx;
  place(el, { force: role === "user" });
  return el;
}

function addStep(e, opt = {}) {
  clearEmpty();
  const last = typingEl ? typingEl.previousElementSibling : els.messages.lastElementChild;
  let g = last && last.classList.contains("steps") ? last : null;
  if (!g) {
    g = document.createElement("div");
    g.className = "steps";
    g.innerHTML = `<details><summary>${ic("bolt", "sm")}<span class="sum"></span>${ic("chevron", "sm chev")}</summary><div class="slist"></div></details>`;
    g._n = 0; g._fail = 0; g._names = [];
    if (opt.noAnim) g.style.animation = "none";
    if (opt.idx != null) g.dataset.i = opt.idx;
    place(g);
  }
  const arg = String(e.arg || "").replace(/\s+/g, " ").trim();
  const row = document.createElement("div");
  row.className = `step ${e.success ? "ok" : "fail"}`;
  row.innerHTML = `<span class="mark">${ic(e.success ? "check" : "x", "sm")}</span><div class="tx"><span class="nm${e.name === "schedule_task" ? " nm-task" : ""}">${e.name === "schedule_task" ? `${ic("tasks", "sm")} ` : ""}${esc(e.name)}</span>${arg ? ` <span class="arg">${esc(arg.length > 90 ? `${arg.slice(0, 90)}…` : arg)}</span>` : ""}<div class="res">${esc(e.message || "")}</div></div>`;
  $(".slist", g).append(row);
  g._n++; if (!e.success) g._fail++;
  if (!g._names.includes(e.name)) g._names.push(e.name);
  const names = g._names.slice(0, 3).join(", ") + (g._names.length > 3 ? "…" : "");
  $(".sum", g).innerHTML = `${g._n} action${g._n > 1 ? "s" : ""}: ${esc(names)} · ${g._fail ? `<span class="sum-bad">${g._fail} failed</span>` : '<span class="sum-ok">ok</span>'}`;
}

function showTyping(label) {
  if (!typingEl) {
    typingEl = document.createElement("div");
    typingEl.className = "typing";
    typingEl.innerHTML = '<span class="dots"><i></i><i></i><i></i></span><span class="tl"></span>';
    clearEmpty();
    const stick = nearBottom();
    els.messages.append(typingEl);
    if (stick) scrollBottom(true);
  }
  $(".tl", typingEl).textContent = label;
}
function hideTyping() { typingEl?.remove(); typingEl = null; }
function updateTyping() {
  if (!S.busy) return;
  showTyping(S.state === "executing" ? `Running ${S.stateDetail}…` : S.state === "speaking" ? "Replying…" : "Thinking…");
}

const SUGGESTIONS = [
  { i: "eye", t: "What's on my screen?", p: "Look at my screen and tell me what you see." },
  { i: "globe", t: "Open my browser", p: "Open Firefox." },
  { i: "sparkles", t: "Weather this week", p: "What's the weather forecast for London for the next 3 days?" },
  { i: "bolt", t: "Convert currency", p: "How much is 250 USD in EUR and GBP right now?" },
  { i: "cpu", t: "Check my PC", p: "How are my CPU, memory and disk doing?" },
  { i: "memory", t: "Teach Troy something", p: "Remember that I like short, direct answers." },
];
function renderEmpty() {
  const name = S.settings?.values?.USER_NAME;
  els.messages.innerHTML = `<div class="empty"><h2>${name ? `How can I help, ${esc(name)}?` : "How can I help?"}</h2>
    <p>Ask Troy to open apps, manage files, look things up, or control your PC. Type <b>/</b> for shortcuts.</p>
    <div class="sugg">${SUGGESTIONS.map((s, i) => `<button class="s-card" data-sugg="${i}">${ic(s.i)}<div><b>${esc(s.t)}</b><span>${esc(s.p)}</span></div></button>`).join("")}</div></div>`;
  typingEl = null;
}

function renderLog(entries) {
  S.loading = true;
  els.messages.innerHTML = ""; typingEl = null; S.log = [];
  if (!entries.length) renderEmpty();
  entries.forEach((e, idx) => {
    if (e.role === "task") addTaskNote(e, { noAnim: true, idx });
    else if (e.role === "tool") { addStep(e, { noAnim: true, idx }); const g = els.messages.lastElementChild; if (g && g.classList.contains("steps")) g.dataset.i = g.dataset.i ?? idx; const rows = $$(".step", g); if (rows.length) rows[rows.length - 1].dataset.i = idx; }
    else addMsg(e.role === "user" ? "user" : "assistant", e.text || "", { noAnim: true, error: looksLikeError(e.text), idx });
    S.log.push(e);
  });
  S.loading = false;
  scrollBottom(false);
}

/* ================================================================== chat */
const SLASH = [
  { cmd: "/new", desc: "Start a new chat", run: () => newChat() },
  { cmd: "/remember", desc: "Save a fact to memory", arg: true, run: (a) => remember(a) },
  { cmd: "/model", desc: "Choose provider and model", run: () => openModelPicker() },
  { cmd: "/voice", desc: "Toggle hands-free voice mode", run: () => toggleVoiceMode() },
  { cmd: "/focus", desc: "Toggle avatar focus mode", run: () => setMode(UI.mode === "focus" ? "split" : "focus") },
  { cmd: "/stop", desc: "Stop the current task", run: () => stopTurn() },
  { cmd: "/context", desc: "Refresh what Troy can see", run: () => refreshCtx(true) },
  { cmd: "/export", desc: "Export this chat as Markdown", run: () => exportChat() },
  { cmd: "/memory", desc: "Open memory", run: () => setView("memory") },
  { cmd: "/tools", desc: "Browse tools", run: () => setView("tools") },
  { cmd: "/tasks", desc: "Open scheduled tasks", run: () => setView("tasks") },
  { cmd: "/logs", desc: "Open logs", run: () => setView("logs") },
  { cmd: "/settings", desc: "Open settings", run: () => setView("settings") },
];
let slashSel = 0, slashShown = [];

function updateSlash() {
  const v = els.inp.value;
  if (!v.startsWith("/") || /\s/.test(v)) { els.slash.classList.add("hidden"); return; }
  slashShown = SLASH.filter((s) => s.cmd.startsWith(v.toLowerCase()));
  if (!slashShown.length) { els.slash.classList.add("hidden"); return; }
  slashSel = clamp(slashSel, 0, slashShown.length - 1);
  els.slash.innerHTML = slashShown.map((s, i) => `<div class="it${i === slashSel ? " sel" : ""}" data-i="${i}"><b>${esc(s.cmd)}</b><span>${esc(s.desc)}</span></div>`).join("");
  els.slash.classList.remove("hidden");
}
function runSlash(s) {
  els.slash.classList.add("hidden");
  if (s.arg) { els.inp.value = `${s.cmd} `; els.inp.focus(); autosize(); return; }
  els.inp.value = ""; autosize(); s.run();
}

function autosize() {
  els.inp.style.height = "auto";
  els.inp.style.height = `${Math.min(els.inp.scrollHeight, 190)}px`;
}

async function sendMessage(raw) {
  const text = String(raw ?? els.inp.value).trim();
  if (!text) return;
  if (text.startsWith("/")) {
    const [cmd, ...rest] = text.split(/\s+/);
    const s = SLASH.find((x) => x.cmd === cmd.toLowerCase());
    if (s) { els.inp.value = ""; autosize(); els.slash.classList.add("hidden"); s.run(rest.join(" ")); return; }
  }
  if (!S.backendUp) { toast("The backend isn't running yet."); return; }
  els.inp.value = ""; autosize(); els.slash.classList.add("hidden");
  S.lastUser = text;
  if (UI.mode === "focus") setCaption(`You: ${text}`, true);
  const wasBusy = S.busy;
  const el = addMsg("user", text);
  S.log.push({ role: "user", text });
  setBusy(true);
  try {
    const r = await T.request("chat.send", { text });
    if (r?.session_id && r.session_id !== S.sid) { S.sid = r.session_id; loadSessions(); }
  } catch (e) {
    el.remove(); S.log.pop();
    if (!wasBusy) setBusy(false);
    els.inp.value = text; autosize();
    toast(cleanErr(e));
  }
}

async function stopTurn() {
  if (!S.busy) return;
  try { await T.request("chat.stop", {}); toast("Stopping…", "info", 1500); } catch (e) { toast(cleanErr(e)); }
}

async function newChat() {
  if (S.busy) { toast("Troy is busy — stop the current task first."); return; }
  if (!S.sid && !S.log.some((e) => e.role === "user")) { setView("chat"); els.inp.focus(); return; }
  try { await call("session.reset"); } catch { return; }
  S.sid = null; S.title = "New chat"; S.log = [];
  renderEmpty(); updateTitle(); loadSessions(); setCaption("");
  setView("chat"); els.inp.focus();
}

async function openSession(id, opts = {}) {
  if (S.busy) { toast("Troy is busy — stop the current task first."); return; }
  try {
    const r = await call("session.load", { id });
    S.sid = id; S.title = r.title || "Chat";
    renderLog(r.display_log || []);
    S.log = (r.display_log || []).slice();
    updateTitle(); setView("chat"); setCaption("");
    if (S.sessQ.trim()) renderSessions(); else loadSessions();
    if (opts.query || opts.focus != null) {                 // coming from a search or a task: show where it is
      if (opts.query) openFind(opts.query, { silent: true });
      if (opts.focus != null) {
        const matches = els.messages.querySelectorAll(`[data-i="${opts.focus}"]`);
        const el = matches[matches.length - 1];                // the most specific one (a step row, not just its group)
        if (el) {
          const d = el.closest("details"); if (d) d.open = true;       // a tool-step hit lives inside a collapsed group
          el.scrollIntoView({ block: "center" }); el.classList.add("flash"); setTimeout(() => el.classList.remove("flash"), 2000);
        }
      }
    }
  } catch { /* toast already shown */ }
}

/* ---------------------------------------------------------- find in chat */
const F = { marks: [], cur: -1 };
function clearMarks() {
  $$("mark.hit", els.messages).forEach((m) => { const p = m.parentNode; p.replaceChild(document.createTextNode(m.textContent), m); p.normalize(); });
  F.marks = []; F.cur = -1;
}
function markAll(query) {
  clearMarks();
  const words = String(query).trim().split(/\s+/).filter(Boolean).map((w) => w.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"));
  if (!words.length) { $("#findCount").textContent = ""; return; }
  const re = new RegExp(words.join("|"), "gi");
  for (const body of $$(".msg .body, .step .tx", els.messages)) {
    const walker = document.createTreeWalker(body, NodeFilter.SHOW_TEXT), nodes = [];
    while (walker.nextNode()) nodes.push(walker.currentNode);
    for (const node of nodes) {
      if (!re.test(node.nodeValue)) { re.lastIndex = 0; continue; }
      re.lastIndex = 0;
      const frag = document.createDocumentFragment(); let last = 0, m;
      while ((m = re.exec(node.nodeValue))) {
        frag.append(document.createTextNode(node.nodeValue.slice(last, m.index)));
        const mk = document.createElement("mark"); mk.className = "hit"; mk.textContent = m[0]; frag.append(mk);
        last = m.index + m[0].length; if (m[0].length === 0) re.lastIndex++;
      }
      frag.append(document.createTextNode(node.nodeValue.slice(last)));
      node.parentNode.replaceChild(frag, node);
    }
  }
  F.marks = $$("mark.hit", els.messages);
  $("#findCount").textContent = F.marks.length ? `1/${F.marks.length}` : "0/0";
  if (F.marks.length) stepFind(0, true);
}
function stepFind(delta, first) {
  if (!F.marks.length) return;
  F.marks[F.cur]?.classList.remove("cur");
  F.cur = first ? 0 : (F.cur + delta + F.marks.length) % F.marks.length;
  const m = F.marks[F.cur]; m.classList.add("cur"); m.scrollIntoView({ block: "center" });
  $("#findCount").textContent = `${F.cur + 1}/${F.marks.length}`;
}
function openFind(query, { silent } = {}) {
  $("#findBar").classList.remove("hidden");
  const input = $("#findIn");
  if (query != null) input.value = query;
  if (!silent) { input.focus(); input.select(); }
  markAll(input.value);
}
function closeFind() { $("#findBar").classList.add("hidden"); clearMarks(); $("#findCount").textContent = ""; els.inp.focus(); }

function updateTitle() {
  const s = S.sessions.find((x) => x.id === S.sid);
  if (s) S.title = s.title;
  els.sessionTitle.textContent = S.sid ? S.title : "New chat";
}

async function renameCurrent() {
  if (!S.sid) { toast("Send a message first — then you can name the chat.", "info"); return; }
  const t = await promptBox({ title: "Rename chat", value: S.title, placeholder: "Chat name" });
  if (t) { await call("session.rename", { id: S.sid, title: t }); S.title = t; await loadSessions(); }
}

function exportChat() {
  if (!S.log.length) { toast("Nothing to export yet.", "info"); return; }
  const lines = [`# ${S.sid ? S.title : "Troy chat"}`, ""];
  for (const e of S.log) {
    if (e.role === "user") lines.push(`**You:** ${e.text}`, "");
    else if (e.role === "assistant") lines.push(`**Troy:** ${e.text}`, "");
    else if (e.role === "tool") lines.push(`> \`${e.name}${e.arg ? `:${e.arg}` : ""}\` ${e.success ? "✓" : "✗"} ${String(e.message || "").replace(/\n/g, " ").slice(0, 300)}`, "");
  }
  const a = document.createElement("a");
  a.href = URL.createObjectURL(new Blob([lines.join("\n")], { type: "text/markdown" }));
  a.download = `troy-chat-${new Date().toISOString().slice(0, 10)}.md`;
  document.body.append(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(a.href), 4000);
  toast("Chat exported", "ok");
}

/* ----------------------------------------------------------- approvals */
function confCard(p) {
  if (document.getElementById(`conf-${p.id}`)) return;
  const d = document.createElement("div");
  d.className = "conf"; d.id = `conf-${p.id}`;
  const high = /high|critical/i.test(p.risk_level || "");
  d.innerHTML = `${ic("shield")}<div class="cb"><div class="ct">Troy needs your approval <span class="badge ${high ? "bad" : "warn"}">${esc(p.risk_level || "risk")}</span></div>
    <code>${esc(p.name)}${p.arg ? `:${esc(p.arg)}` : ""}</code><div class="cd">${esc(p.description || "")}</div>
    <div class="ca"><button class="btn pri" data-ok="1">${ic("check", "sm")}Approve</button><button class="btn" data-ok="0">Deny</button></div></div>`;
  d.addEventListener("click", async (e) => {
    const b = e.target.closest("[data-ok]"); if (!b) return;
    const approved = b.dataset.ok === "1";
    d.remove();
    try {
      const r = await T.request("confirmation.resolve", { id: p.id, approved });
      const res = r?.result;
      if (approved && res) toast(`${res.success ? "Done" : "Failed"}: ${String(res.message || "").slice(0, 140)}`, res.success ? "ok" : "bad");
    } catch (err) { toast(cleanErr(err)); }
  });
  els.confs.append(d);
  flash("surprised", 900);
  setCaption("I need your OK for something — check the prompt below.", true);
}

/* ======================================================= context + quick */
const CTX_ICON = [[/^Time/, "clock"], [/^Active window|window/i, "window"], [/^CPU/, "cpu"], [/^Web/, "globe"]];
async function refreshCtx(announce) {
  try {
    const r = await T.request("context.get", {});
    const parts = String(r.message || "").split(" | ").filter(Boolean);
    els.ctxChips.innerHTML = parts.map((p) => {
      const icon = (CTX_ICON.find(([re]) => re.test(p)) || [0, "info"])[1];
      const txt = p.replace(/^(Time|Active window):\s*/i, "").replace(/^Web research browser:\s*/i, "Browser: ");
      return `<span class="c" title="${esc(p)}">${ic(icon)}<span>${esc(txt)}</span></span>`;
    }).join("");
    if (announce) toast("Context refreshed", "ok", 1400);
  } catch { /* backend may be restarting */ }
}

function updateQuick() {
  const v = S.settings?.values || {};
  const speak = !!v.VOICE_OUTPUT_ENABLED;
  els.speakBtn.classList.toggle("on", speak);
  els.speakBtn.innerHTML = `${ic(speak ? "volume" : "volume-off")}<span>Voice</span>`;
  els.micBtn.classList.toggle("on", S.wake.running);
  els.micBtn.classList.toggle("hot", S.wake.running && (S.wake.state === "hearing" || S.wake.state === "awake"));
  els.micBtn.title = S.wake.running ? `Listening for the wake word — click to stop (${S.wake.state})` : "Start listening for the wake word";
  els.voiceModeBtn.classList.toggle("on", VM.active);
}

async function toggleListening() {
  try {
    if (S.wake.running) {
      await call("wake_listener.stop"); S.wake = { running: false, state: "idle" };
      await saveSetting("VOICE_INPUT_ENABLED", false, true);
    } else {
      const r = await call("wake_listener.start");
      if (!r.started) { toast("Voice input isn't available — it needs a microphone and the 'sounddevice' package. See Logs.", "bad", 8000); return; }
      S.wake.running = true;
      await saveSetting("VOICE_INPUT_ENABLED", true, true);
      toast(`Say “${S.settings?.values?.WAKE_WORD || "Troy"}” to talk`, "info");
    }
  } catch { /* toast shown */ }
  updateQuick(); if (S.view === "settings") renderPane();
}

async function toggleSpeak() {
  const next = !S.settings?.values?.VOICE_OUTPUT_ENABLED;
  await saveSetting("VOICE_OUTPUT_ENABLED", next);
  toast(next ? "Troy will speak replies" : "Voice replies off", "info", 1800);
}

/* ========================================================== voice mode */
/* Hands-free overlay: the backend's VoiceMode (troy/voice_mode.py) does the
 * work; this is just the big face + live transcript + mic level + controls. */
const VM = { active: false, open: false, state: "off", muted: false, face: null, lastFace: "" };
const VM_LABEL = { off: "Off", listening: "Listening…", hearing: "Listening…", transcribing: "Heard you…",
  thinking: "Thinking…", executing: "Working…", speaking: "Speaking…", muted: "Muted" };
const VM_FACE = { off: "idle", listening: "listening", hearing: "listening", transcribing: "thinking",
  thinking: "thinking", executing: "executing", speaking: "speaking", muted: "sleeping" };

function mountVoiceFace() {
  if (VM.face || typeof NovaFace === "undefined") return;
  try {
    VM.face = NovaFace.mount(els.voiceFace, { onTint: (r, g, b) => els.voiceOverlay.style.setProperty("--tint-rgb", `${r}, ${g}, ${b}`) });
    VM.face.setOptions({ ...UI.avatar, sleep: false, tracking: false, light: resolvedTheme() === "light" });
  } catch (e) { console.error("Voice avatar failed to start:", e); }
}

function setVoiceUI() {
  els.voiceModeBtn.classList.toggle("on", VM.active);
  els.voiceModeBtn.title = VM.active ? `Voice mode is on (${VM.state}) — click to end` : "Voice mode: talk hands-free (Ctrl+Shift+V)";
  els.vMuteBtn.textContent = VM.muted ? "Unmute" : "Mute";
  const chip = els.vChip;
  chip.dataset.s = VM.muted ? "muted" : VM.state;
  $("span", chip).textContent = VM.muted ? "Muted" : (VM_LABEL[VM.state] || VM.state);
  if (VM.face) {
    const want = VM.muted ? "sleeping" : (VM_FACE[VM.state] || "idle");
    if (want !== VM.lastFace) { VM.lastFace = want; VM.face.setState(want); }
  }
}

function addVTranscript(who, text, opt = {}) {
  const p = document.createElement("p");
  p.className = who;
  p.textContent = `${opt.pc ? "(PC) " : ""}${String(text || "")}`;
  els.vTranscript.append(p);
  while (els.vTranscript.children.length > 60) els.vTranscript.firstElementChild.remove();
  els.vTranscript.scrollTop = els.vTranscript.scrollHeight;
}

function showVoiceOverlay() {
  VM.open = true;
  els.vTranscript.innerHTML = "";
  els.voiceOverlay.classList.remove("hidden");
  mountVoiceFace();
  setVoiceUI();
}

function hideVoiceOverlay() {
  VM.open = false;
  els.voiceOverlay.classList.add("hidden");
}

async function startVoiceMode() {
  try {
    const r = await T.request("voice.mode_start", {});
    if (!r?.started) { toast(r?.error || "Couldn't start voice mode — check the microphone and Settings › Voice."); return; }
    VM.active = true; VM.muted = false;
    showVoiceOverlay();
    toast("Voice mode on — just talk", "info", 2600);
  } catch (e) { toast(cleanErr(e)); }
}

async function endVoiceMode(reason = "user") {
  const was = VM.active;
  VM.active = false; VM.state = "off";
  try { await T.request("voice.mode_stop", { reason }); } catch (e) { toast(cleanErr(e)); }
  hideVoiceOverlay();
  setVoiceUI();
  if (was) toast("Voice mode off", "info", 1800);
}

function toggleVoiceMode() {
  if (!VM.active) startVoiceMode();
  else if (!VM.open) showVoiceOverlay();
  else endVoiceMode();
}

async function setVoiceMuted(next) {
  try {
    const r = await T.request("voice.mute", { muted: !!next });
    VM.muted = !!r.muted;
    setVoiceUI();
  } catch (e) { toast(cleanErr(e)); }
}

async function remember(fact) {
  fact = String(fact || "").trim();
  if (!fact) { toast("Tell me what to remember: /remember <something>", "info"); return; }
  const r = await call("memory.add", { fact });
  toast(r.message || "Remembered", "ok"); loadMemory();
}

/* ================================================================ models */
const providerLabel = (id) => S.provs.find((p) => p.id === id)?.label || id;
let provInflight = null;
async function loadProviders() {
  // Several things ask for the provider list at once (header, settings pane,
  // settings.changed events); share one request instead of stacking them.
  if (provInflight) return provInflight;
  provInflight = (async () => {
    try {
      const r = await T.request("provider.list", {});
      S.provs = r.providers; S.overrides = r.overrides;
      updateModelLabel();
      return r;
    } finally { provInflight = null; }
  })();
  return provInflight;
}
function updateModelLabel() {
  const ready = S.provs.filter((p) => p.configured);
  const btn = els.modelBtn;
  btn.classList.remove("warn");
  if (!ready.length) { els.modelLabel.textContent = "Set up a provider"; btn.title = "No AI provider is configured yet"; return; }
  const [op, om] = String(S.overrides.text || "").split(/:(.+)/);
  const prim = S.provs.find((p) => p.primary && p.configured) || ready[0];
  els.modelLabel.textContent = om ? `${providerLabel(op)} · ${om}` : `${prim.label} · auto`;
  btn.title = om ? "Pinned model — click to change" : "Automatic model choice — click to pin one";
}

async function selectModel(pid, model) {
  const p = S.provs.find((x) => x.id === pid);
  try {
    if (!p?.primary) await call("provider.set_primary", { provider: pid });
    await call("model.set", { kind: "text", provider: pid, model });
    await loadProviders();
    toast(`Using ${p?.label || pid} · ${model}`, "ok");
  } catch { /* toast shown */ }
}
async function selectAuto() {
  try { await call("model.set", { kind: "text" }); await loadProviders(); toast("Model choice is automatic", "ok"); } catch { /* shown */ }
}
function openModelPicker() {
  const ready = S.provs.filter((p) => p.configured);
  const [op, om] = String(S.overrides.text || "").split(/:(.+)/);
  const items = [{ label: "Automatic", sub: "provider order", cur: !om, onPick: selectAuto }];
  for (const p of ready) {
    items.push({ group: p.label, badge: p.primary ? "primary" : "" });
    for (const m of p.models.text) items.push({ label: m, cur: op === p.id && om === m, onPick: () => selectModel(p.id, m) });
  }
  if (!ready.length) items.push({ label: "Add an API key in Settings…", icon: "key", onPick: () => openSettings("providers") });
  else items.push({ group: "More" }, { label: "Vision model, API keys…", icon: "settings", onPick: () => openSettings("models") });
  menuPop(els.modelBtn, items, { search: ready.reduce((n, p) => n + p.models.text.length, 0) > 8, align: "right", placeholder: "Search models" });
}

/* ================================================================ sessions */
async function loadSessions() {
  try { S.sessions = (await T.request("session.list", {})).sessions || []; } catch { return; }
  S.sessions.sort((a, b) => String(b.updated_at).localeCompare(String(a.updated_at)));
  renderSessions(); updateTitle();
}
function groupLabel(iso) {
  const d = new Date(iso); if (isNaN(d)) return "Earlier";
  const day = (x) => new Date(x.getFullYear(), x.getMonth(), x.getDate()).getTime();
  const diff = Math.round((day(new Date()) - day(d)) / 864e5);
  return diff <= 0 ? "Today" : diff === 1 ? "Yesterday" : diff < 8 ? "Previous 7 days" : "Earlier";
}
/* Searching: titles instantly (client side), then messages through the backend. */
const searchDebounced = debounce(async () => {
  const q = S.sessQ.trim();
  if (!q) { S.search = null; renderSessions(); return; }
  try { S.search = { q, ...(await T.request("session.search", { query: q, limit: 30 })) }; } catch { S.search = null; }
  if (S.sessQ.trim() === q) renderSessions();
}, 220);
const hl = (text, start, length) => `${esc(text.slice(0, start))}<mark>${esc(text.slice(start, start + length))}</mark>${esc(text.slice(start + length))}`;
function renderSearchResults() {
  const r = S.search;
  if (!r.results.length) { els.sessions.innerHTML = `<div class="side-empty">No chats or messages match “${esc(r.q)}”.</div>`; return; }
  els.sessions.innerHTML = `<div class="sgrp">${r.total_chats} chat${r.total_chats > 1 ? "s" : ""} found</div>` + r.results.map((c) => `<div class="sres" data-id="${esc(c.id)}">
    <div class="t"><b>${c.title_match ? hl(c.title, c.title.toLowerCase().indexOf(r.q.split(/\s+/)[0].toLowerCase()), r.q.split(/\s+/)[0].length) : esc(c.title)}</b><small>${esc(String(c.updated_at).slice(0, 10))}</small></div>
    ${c.hits.map((h) => `<div class="h" data-i="${h.index}"><i>${h.role === "user" ? "You" : h.role === "tool" ? "Tool" : "Troy"}</i>${hl(h.snippet, h.start, h.length)}</div>`).join("")}
    ${c.hit_count > c.hits.length ? `<div class="more">+${c.hit_count - c.hits.length} more message${c.hit_count - c.hits.length > 1 ? "s" : ""}</div>` : ""}</div>`).join("");
}
function renderSessions() {
  if (S.sessQ.trim() && S.search && S.search.q === S.sessQ.trim()) { renderSearchResults(); return; }
  const q = S.sessQ.trim().toLowerCase();
  const list = S.sessions.filter((s) => !q || String(s.title).toLowerCase().includes(q));
  if (!list.length) { els.sessions.innerHTML = `<div class="side-empty">${q ? "No chats match." : "Your chats will appear here."}</div>`; return; }
  let html = "", last = "";
  for (const s of list) {
    const g = groupLabel(s.updated_at);
    if (g !== last) { html += `<div class="sgrp">${g}</div>`; last = g; }
    html += `<div class="sess${s.id === S.sid ? " on" : ""}${s.has_tasks ? " has-tasks" : ""}" data-id="${esc(s.id)}">${s.has_tasks ? `<span class="tk" title="${s.task_count > 1 ? `${s.task_count} scheduled tasks were created in this chat` : "A scheduled task was created in this chat"}">${ic("tasks", "sm")}</span>` : ""}<span class="t">${esc(s.title || "Untitled")}</span>
      <span class="acts"><button class="icon-btn sm" data-a="ren" title="Rename">${ic("pencil", "sm")}</button><button class="icon-btn sm" data-a="del" title="Delete">${ic("trash", "sm")}</button></span></div>`;
  }
  els.sessions.innerHTML = html;
}
async function sessionClick(e) {
  const res = e.target.closest(".sres");
  if (res) {
    const hit = e.target.closest(".h");
    openSession(res.dataset.id, { focus: hit ? +hit.dataset.i : null, query: S.search?.q || S.sessQ });
    return;
  }
  const row = e.target.closest(".sess"); if (!row) return;
  const id = row.dataset.id, act = e.target.closest("[data-a]")?.dataset.a;
  if (act === "del") {
    const title = S.sessions.find((s) => s.id === id)?.title || "this chat";
    if (!(await confirmBox({ title: "Delete chat?", text: `“${title}” will be permanently deleted.`, okText: "Delete", danger: true }))) return;
    try {
      const r = await call("session.delete", { id });
      if (r.was_current) { S.sid = null; S.log = []; renderEmpty(); }
    } catch { return; }
    loadSessions();
  } else if (act === "ren") {
    const span = $(".t", row);
    const input = Object.assign(document.createElement("input"), { type: "text", value: span.textContent });
    span.replaceWith(input); input.focus(); input.select();
    let done = false;
    const finish = async (save) => {
      if (done) return; done = true;
      const t = input.value.trim();
      if (save && t) await call("session.rename", { id, title: t }).catch(() => {});
      loadSessions();
    };
    input.addEventListener("blur", () => finish(true));
    input.addEventListener("keydown", (k) => { if (k.key === "Enter") finish(true); if (k.key === "Escape") finish(false); });
    input.addEventListener("click", (k) => k.stopPropagation());
  } else if (id !== S.sid) openSession(id);
  else setView("chat");
}

/* ================================================================== views */
const VIEWS = ["chat", "memory", "tasks", "tools", "logs", "settings"];
const SHORTCUT_VIEWS = ["chat", "memory", "tools", "logs", "settings", "tasks"];     // Ctrl+1 ... Ctrl+6 (Tasks added last so the old numbers keep working)
let logTimer = null, ctxTimer = null, taskTimer = null;
function setView(v) {
  if (!VIEWS.includes(v)) return;
  closePop();
  S.view = v;
  VIEWS.forEach((x) => document.getElementById(`v-${x}`).classList.toggle("on", x === v));
  $$("#nav button").forEach((b) => b.classList.toggle("on", b.dataset.view === v));
  document.body.dataset.view = v;
  reportUI();
  clearInterval(logTimer);
  clearInterval(taskTimer);
  if (v === "memory") loadMemory();
  if (v === "tasks") { loadTasks(); taskTimer = setInterval(() => S.view === "tasks" && renderTasks(), 20000); }
  if (v === "tools") loadTools();
  if (v === "settings") renderPane();
  if (v === "logs") { loadLogs(); logTimer = setInterval(() => els.logAuto.checked && loadLogs(), 2500); }
  if (v === "chat") { refreshCtx(); setTimeout(() => { if (nearBottom()) scrollBottom(false); }, 0); }
}
function setMode(m) {
  UI.mode = m; saveUI(); applyUI();
  if (S.view !== "chat") setView("chat");
  if (m === "focus") { els.caption.classList.add("show"); } else updateJump();
  els.inp.focus();
}
function openSettings(pane) { S.pane = pane || S.pane; setView("settings"); }

/* ---------------------------------------------------------------- memory */
async function loadMemory() {
  try { S.memories = (await T.request("memory.list", {})).memories || []; } catch { return; }
  els.memCount.textContent = S.memories.length ? String(S.memories.length) : "";
  if (S.view !== "memory") return;
  const q = S.memQ.trim().toLowerCase();
  const rows = S.memories.map((m, i) => ({ ...m, i })).filter((m) => !q || String(m.fact).toLowerCase().includes(q));
  els.memList.innerHTML = rows.length
    ? rows.slice().reverse().map((m) => `<div class="item"><div class="tx">${esc(m.fact)}<small>${esc(fmtTime(m.timestamp))}</small></div><button class="icon-btn sm" data-del="${m.i}" title="Forget this">${ic("trash", "sm")}</button></div>`).join("")
    : `<div class="placeholder">${S.memories.length ? "No memories match." : "Nothing remembered yet. Tell Troy things you want it to keep in mind."}</div>`;
}

/* ----------------------------------------------------------------- tools */
const CAT_NAME = { api: "Web APIs", web: "Research browser", desktop: "Desktop apps", vision: "Vision", windows: "Windows", system: "System", filesystem: "Files", network: "Network", process: "Processes" };
const catName = (c) => CAT_NAME[c] || c[0].toUpperCase() + c.slice(1);
async function loadTools() {
  if (!S.tools.length) { try { S.tools = (await T.request("tools.list", {})).tools || []; } catch { return; } }
  const cats = [...new Set(S.tools.map((t) => t.category))].sort();
  els.toolCats.innerHTML = [`<button class="chip${S.toolCat === "all" ? " on" : ""}" data-cat="all">All ${S.tools.length}</button>`]
    .concat(cats.map((c) => `<button class="chip${S.toolCat === c ? " on" : ""}" data-cat="${esc(c)}">${esc(catName(c))} ${S.tools.filter((t) => t.category === c).length}</button>`)).join("");
  const q = S.toolQ.trim().toLowerCase();
  const list = S.tools.filter((t) => (S.toolCat === "all" || t.category === S.toolCat) && (!q || `${t.name} ${t.description} ${t.category}`.toLowerCase().includes(q)));
  els.toolsH.textContent = `${S.tools.length} extended tools in ${cats.length} groups. Troy also has built-in basics like opening apps, typing, clicking and screenshots. Click “Try” to start a request.`;
  els.toolList.innerHTML = list.length ? list.map((t) => `<div class="tool-card"><div class="nm mono">${esc(t.name)}</div><div class="ds">${esc(t.description)}</div>
      ${t.arg_hint ? `<div class="ar mono">${esc(t.arg_hint)}</div>` : ""}
      <div class="tf"><span class="badge">${esc(catName(t.category))}</span>${t.requires_confirmation ? `<span class="badge warn">${ic("shield", "sm")}needs approval</span>` : ""}<span class="sp"></span><button class="btn sm" data-try="${esc(t.name)}">Try</button></div></div>`).join("")
    : `<div class="placeholder" style="grid-column:1/-1">No tools match.</div>`;
}

/* ----------------------------------------------------------------- tasks */
const pad2 = (n) => String(n).padStart(2, "0");
function fmtWhen(iso) {
  const d = new Date(iso); if (isNaN(d)) return "";
  const day0 = (x) => new Date(x.getFullYear(), x.getMonth(), x.getDate()).getTime();
  const diff = Math.round((day0(d) - day0(new Date())) / 864e5);
  const dayTxt = diff === 0 ? "Today" : diff === 1 ? "Tomorrow" : diff === -1 ? "Yesterday" : d.toLocaleDateString([], { weekday: "short", month: "short", day: "numeric" });
  return `${dayTxt} ${pad2(d.getHours())}:${pad2(d.getMinutes())}`;
}
function fmtIn(iso) {
  const ms = new Date(iso) - Date.now(); if (isNaN(ms)) return "";
  const past = ms < 0, mins = Math.round(Math.abs(ms) / 60000);
  if (mins < 1) return past ? "just now" : "in under a minute";
  const txt = mins < 60 ? `${mins} min` : mins < 2880 ? `${Math.floor(mins / 60)}h ${pad2(mins % 60)}m` : `${Math.round(mins / 1440)} days`;
  return past ? `${txt} ago` : `in ${txt}`;
}
const TASK_STATUS = { scheduled: ["Scheduled", "pri"], running: ["Running now", "run"], retrying: ["Retrying", "warn"], paused: ["Paused", ""], completed: ["Done", "ok"], failed: ["Failed", "bad"], cancelled: ["Cancelled", ""], missed: ["Missed", "warn"] };
const TASK_FINISHED = ["completed", "failed", "cancelled", "missed"];
const isFinished = (t) => TASK_FINISHED.includes(t.status);

function taskCard(t) {
  const [label, tone] = TASK_STATUS[t.status] || [t.status, ""];
  const finished = isFinished(t), running = t.status === "running";
  const next = t.next_run ? `<span>${ic("clock", "sm")}${esc(fmtWhen(t.next_run))}</span><em>${esc(fmtIn(t.next_run))}</em>` : "";
  const attempt = (t.status === "retrying" || running) && t.run ? `<span>Attempt ${t.run.attempt} of ${1 + t.effective_max_retries}</span>` : "";
  let last = "";
  if (running && S.taskStep[t.id]) last = `<div class="last"><b>Now:</b> ${esc(S.taskStep[t.id])}</div>`;
  else if (t.last_outcome === "success") last = `<div class="last ok"><b>Last run: done.</b> ${esc(t.last_summary || "")}</div>`;
  else if (t.last_outcome === "missed") last = `<div class="last warn"><b>Missed.</b> ${esc(t.last_summary || "")}</div>`;
  else if (t.last_outcome) last = `<div class="last bad"><b>Last run ${t.last_outcome === "stopped" ? "stopped" : "failed"}.</b> ${esc(t.last_error || t.last_summary || "")}</div>`;
  const chat = t.session_id
    ? (t.chat_exists ? `<button class="btn sm chatlink" data-a="chat" title="Open the chat where this task was created: ${esc(t.chat_title)}">${ic("chat", "sm")}<span>${esc(t.chat_title || "Open chat")}</span></button>`
      : `<span class="badge" title="The chat that created this task was deleted">Chat deleted</span>`)
    : `<span class="badge" title="Added from the Tasks screen">Added here</span>`;
  const approve = (t.needs_approval || []).length
    ? `<div class="approval">${ic("shield", "sm")}<span>Needs your approval to run unattended: ${t.needs_approval.map((c) => `<code>${esc(c)}</code>`).join(" ")}</span><button class="btn sm pri" data-a="approve">Approve and run now</button></div>` : "";
  const grants = (t.grants || []).length ? `<div class="grants">Pre-approved to run unattended: ${t.grants.map((c) => `<code>${esc(c)}</code>`).join(" ")}</div>` : "";
  const btn = (a, icon, text, cls = "") => `<button class="btn sm ${cls}" data-a="${a}">${ic(icon, "sm")}<span>${text}</span></button>`;
  const acts = running ? btn("stop", "stop", "Stop", "bad")
    : [btn("run", "play", finished ? "Run again" : "Run now"),
       t.status === "paused" ? btn("resume", "play", "Resume") : (!finished ? btn("pause", "pause", "Pause") : ""),
       btn("edit", "pencil", finished ? "Reschedule" : "Edit"),
       finished ? btn("delete", "trash", "Delete", "bad") : btn("cancel", "x", "Cancel", "bad")].join("");
  return `<div class="task st-${t.status}" data-task="${esc(t.id)}">
    <div class="th"><b>${esc(t.title)}</b><span class="badge ${tone}">${label}</span></div>
    <div class="when"><span>${ic("tasks", "sm")}${esc(t.schedule_text || "")}</span>${next}${attempt}</div>
    <div class="prompt">${esc(t.prompt)}</div>${last}${approve}${grants}
    <div class="acts">${acts}<span class="sp"></span>${chat}<button class="btn sm" data-a="log">${ic("logs", "sm")}<span>${S.taskOpen[t.id] ? "Hide log" : "Log"}</span></button></div>
    ${S.taskOpen[t.id] ? '<div class="tlog">Loading…</div>' : ""}</div>`;
}

function renderTasks() {
  const active = S.tasks.filter((t) => !isFinished(t));
  els.taskCount.textContent = active.length ? String(active.length) : "";
  els.taskOff.classList.toggle("hidden", S.tasksInfo.enabled !== false);
  $$("#taskFilter button").forEach((b) => b.classList.toggle("on", b.dataset.v === S.taskFilter));
  els.taskClear.classList.toggle("hidden", !S.tasks.some(isFinished));
  if (S.view !== "tasks") return;
  const q = S.taskQ.trim().toLowerCase();
  const list = S.tasks.filter((t) => (S.taskFilter === "all" || (S.taskFilter === "active") === !isFinished(t))
    && (!q || `${t.title} ${t.prompt} ${t.schedule_text} ${t.chat_title || ""}`.toLowerCase().includes(q)));
  const focus = document.activeElement?.closest?.(".task")?.dataset.task;
  els.taskList.innerHTML = list.length ? list.map(taskCard).join("")
    : `<div class="placeholder">${S.tasks.length ? "No tasks here." : "No tasks yet. Tell Troy “put the computer to sleep at 10 PM”, or press New task."}</div>`;
  void focus;
  for (const id of Object.keys(S.taskOpen)) if (S.taskOpen[id]) fillTaskLog(id);
}
async function fillTaskLog(id) {
  const box = $(`.task[data-task="${id}"] .tlog`); if (!box) return;
  try {
    const { entries } = await T.request("tasks.logs", { id, limit: 40 });
    box.innerHTML = entries.length ? entries.map((e) => `<div class="${esc(e.level)}">${esc(String(e.ts).slice(5, 16).replace("T", " "))}  ${esc(e.event)}: ${esc(e.message)}</div>`).join("") : "No log entries yet.";
    box.scrollTop = box.scrollHeight;
  } catch (e) { box.textContent = cleanErr(e); }
}
async function loadTasks() {
  try {
    const r = await T.request("tasks.list", {});
    S.tasks = r.tasks || [];
    S.tasksInfo = { enabled: r.enabled, scheduler_running: r.scheduler_running, defaults: r.defaults || {} };
  } catch { return; }
  renderTasks();
}
function upsertTask(t) {
  const i = S.tasks.findIndex((x) => x.id === t.id);
  const keep = i >= 0 ? S.tasks[i] : {};
  const merged = { chat_exists: keep.chat_exists, chat_title: keep.chat_title, ...t };
  if (i >= 0) S.tasks[i] = merged; else S.tasks.unshift(merged);
  if (t.status !== "running") delete S.taskStep[t.id];
  renderTasks();
  if (!merged.chat_title && merged.session_id) loadTasks();           // a new task: learn the chat's title
}
function addTaskNote(e, opt = {}) {
  clearEmpty();
  const el = document.createElement("div");
  el.className = `msg task-note${e.ok === false ? " bad" : ""}`;
  if (opt.noAnim) el.style.animation = "none";
  if (opt.idx != null) el.dataset.i = opt.idx;
  el.innerHTML = `${ic(e.ok === false ? "alert" : "tasks")}<div class="body">${esc(e.text || "")}</div><button class="btn sm" data-task-open="${esc(e.task_id || "")}">View task</button>`;
  place(el);
  return el;
}
function flashTask(id) {
  const el = $(`.task[data-task="${id}"]`); if (!el) return;
  el.scrollIntoView({ block: "center" }); el.classList.add("flash"); setTimeout(() => el.classList.remove("flash"), 1900);
}

async function taskForm(task) {
  const editing = !!task, d = S.tasksInfo.defaults || {};
  const m = modal(`<h3>${editing ? "Edit task" : "New task"}</h3>
    <p>${editing ? "Change what Troy does or when." : "Troy will do this at the time you give, with nobody watching."}</p>
    <form class="tform-body" onsubmit="return false">
    <label>Name <small>Optional: shown in the list.</small><input id="tfTitle" type="text" maxlength="60" value="${esc(task?.title || "")}" placeholder="e.g. Sleep the PC"></label>
    <label>When <small>“in 30 minutes”, “tomorrow at 9am”, “every Monday, Wednesday and Friday at 22:00”, “October 25 2026 at 14:30”, “every 2 days”</small>
      <input id="tfWhen" type="text" value="${esc(editing ? "" : "")}" placeholder="${editing ? `Now: ${esc(task.schedule_text)} (leave empty to keep)` : "every day at 22:00"}"></label>
    <div id="tfPv" class="pv"></div>
    <label>What Troy should do <small>A short instruction, as if telling a person.</small><textarea id="tfPrompt" placeholder="Put the computer to sleep.">${esc(task?.prompt || "")}</textarea></label>
    ${editing ? "" : `<label>Allow without asking <small>Commands that normally need your approval, exact names separated by “;” (for example <code>sleep_computer</code>). Leave empty if the task needs none.</small><input id="tfApprove" type="text" placeholder="sleep_computer"></label>`}
    <div class="two"><label>Retries <small>Default ${d.max_retries ?? 2}</small><input id="tfRetries" type="number" min="0" max="10" value="${task?.max_retries ?? ""}" placeholder="default"></label>
      <label>Seconds between retries <small>Default ${d.retry_delay ?? 30}</small><input id="tfDelay" type="number" min="5" max="3600" value="${task?.retry_delay ?? ""}" placeholder="default"></label></div>
    <div id="tfErr" class="form-err"></div></form>
    <div class="ma"><button class="btn" data-a="no">Cancel</button><button class="btn pri" data-a="ok">${editing ? "Save" : "Create task"}</button></div>`, { cls: "tform" });
  const $f = (id) => m.el.querySelector(`#${id}`);
  const err = (t) => { $f("tfErr").textContent = t || ""; };
  const preview = debounce(async () => {
    const when = $f("tfWhen").value.trim(), pv = $f("tfPv");
    if (!when) { pv.className = "pv"; pv.textContent = ""; return; }
    try {
      const r = await T.request("tasks.preview", { when });
      pv.className = `pv ${r.ok ? "ok" : "bad"}`;
      pv.innerHTML = r.ok ? `<b>${esc(r.text)}</b> · next: ${r.next.map((x) => esc(fmtWhen(x))).join(", ")}` : esc(r.error);
    } catch { /* preview is a nicety */ }
  }, 220);
  $f("tfWhen").addEventListener("input", preview);
  const submit = async () => {
    err("");
    const body = { title: $f("tfTitle").value.trim(), prompt: $f("tfPrompt").value.trim(), when: $f("tfWhen").value.trim() };
    if (!body.prompt) { err("Say what Troy should do."); return; }
    try {
      if (editing) {
        const patch = { id: task.id, prompt: body.prompt, title: body.title || task.title };
        if (body.when) patch.when = body.when;
        const r = $f("tfRetries").value, dl = $f("tfDelay").value;
        if (r === "") patch.default_retries = true; else patch.max_retries = +r;
        if (dl !== "") patch.retry_delay = +dl;
        await T.request("tasks.modify", patch);
      } else {
        if (!body.when) { err("Say when."); return; }
        const create = { ...body, approve: $f("tfApprove").value.trim() };
        const created = await T.request("tasks.create", create);
        const r = $f("tfRetries").value, dl = $f("tfDelay").value;
        if (r !== "" || dl !== "") await T.request("tasks.modify", { id: created.task.id, ...(r !== "" ? { max_retries: +r } : {}), ...(dl !== "" ? { retry_delay: +dl } : {}) });
      }
    } catch (e) { err(cleanErr(e)); return; }
    m.close(true); toast(editing ? "Task updated" : "Task created", "ok", 1600); loadTasks();
  };
  m.el.addEventListener("click", (e) => { const a = e.target.closest("[data-a]")?.dataset.a; if (a === "ok") submit(); else if (a) m.close(null); });
  m.el.addEventListener("keydown", (e) => { if (e.key === "Enter" && e.target.tagName === "INPUT") submit(); });
  (editing ? $f("tfPrompt") : $f("tfWhen")).focus();
}

async function taskAction(e) {
  const open = e.target.closest("[data-task-open]");
  const card = e.target.closest(".task"); if (!card) return;
  const id = card.dataset.task, t = S.tasks.find((x) => x.id === id), act = e.target.closest("[data-a]")?.dataset.a;
  if (!t || !act) return;
  void open;
  const run = async (method, params, done) => { try { await T.request(method, { id, ...(params || {}) }); if (done) toast(done, "ok", 1600); } catch (err) { toast(cleanErr(err)); } loadTasks(); };
  if (act === "chat") { if (t.session_id) openSession(t.session_id, { focus: t.message_index ?? null }); }
  else if (act === "run") run("tasks.run_now", {}, "Starting…");
  else if (act === "pause") run("tasks.pause");
  else if (act === "resume") run("tasks.resume");
  else if (act === "stop") { try { await T.request("chat.stop", {}); } catch { /* ignore */ } }
  else if (act === "approve") run("tasks.approve", {}, "Approved. Running it now.");
  else if (act === "edit") taskForm(t);
  else if (act === "cancel") { if (await confirmBox({ title: "Cancel this task?", text: `“${t.title}” won't run again. You can still find it under Finished.`, okText: "Cancel task", danger: true })) run("tasks.cancel", {}, "Cancelled"); }
  else if (act === "delete") run("tasks.delete");
  else if (act === "log") { S.taskOpen[id] = !S.taskOpen[id]; renderTasks(); }
}

/* ------------------------------------------------------------------ logs */
const LOG_RE = /^(\d{4}-\d\d-\d\d \d\d:\d\d:\d\d)\s+\[(\w+)\]\s+(.*)$/;
async function loadLogs() {
  let lines = [];
  if (S.logSrc === "file") { try { lines = (await T.request("logs.tail", { lines: 500 })).lines || []; } catch { return; } }
  else lines = S.consoleLines;
  const lvl = S.logLvl, q = S.logQ.trim().toLowerCase();
  const out = els.logOut, stick = out.scrollHeight - out.scrollTop - out.clientHeight < 40;
  const html = [];
  for (const line of lines) {
    const m = LOG_RE.exec(line), level = m ? m[2].toUpperCase() : "";
    if (lvl && level !== lvl) continue;
    if (q && !line.toLowerCase().includes(q)) continue;
    html.push(m ? `<span class="ll ${level}"><span class="lv">${level}</span>${esc(m[1].slice(11))} ${esc(m[3])}</span>` : `<span class="ll">${esc(line)}</span>`);
  }
  out.innerHTML = html.join("") || `<span class="ll">No log lines${q || lvl ? " match the filter" : " yet"}.</span>`;
  if (stick) out.scrollTop = out.scrollHeight;
  out._count = html.length;
}

/* ============================================================== settings */
const PROV = {
  groq: { secret: "GROQ_API_KEY", url: "https://console.groq.com/keys", c1: "#f55036", c2: "#ff8a5c", blurb: "Very fast open models with a generous free tier." },
  openrouter: { secret: "OPENROUTER_API_KEY", url: "https://openrouter.ai/keys", c1: "#6d8bff", c2: "#9d7bff", blurb: "One key for hundreds of models, including free ones." },
  gemini: { secret: "GEMINI_API_KEY", url: "https://aistudio.google.com/apikey", c1: "#4285f4", c2: "#34a853", blurb: "Google's multimodal models. Also used for escalation." },
  nvidia: { secret: "NVIDIA_API_KEY", url: "https://build.nvidia.com", c1: "#76b900", c2: "#a6e22e", blurb: "NVIDIA's catalog: GLM, Nemotron, Kimi, Gemma and more." },
  lmstudio: { secret: null, url: "https://lmstudio.ai", c1: "#6c63ff", c2: "#36c5f0", blurb: "Runs models on your own PC. Private, free, works offline." },
};
const sv = (k) => S.settings?.values?.[k];
const row = (label, hint, ctl) => `<div class="row"><div class="lab">${label}${hint ? `<small>${hint}</small>` : ""}</div><div class="ctl">${ctl}</div></div>`;
const sw = (attrs, on) => `<span class="switch"><input type="checkbox" ${attrs} ${on ? "checked" : ""}><i></i></span>`;

async function saveSetting(key, value, quiet) {
  S.muteSettingsEvent = Date.now() + 1200;
  try {
    const r = await T.request("settings.update", { changes: { [key]: value } });
    if (S.settings?.values && key in S.settings.values) S.settings.values[key] = value;
    if (r.restart_required?.length) showBanner(`Restart the backend for ${r.restart_required.join(", ")} to take effect.`, "Restart backend", restartBackend);
    updateQuick();
    return true;
  } catch (e) { if (!quiet) toast(cleanErr(e)); return false; }
}
async function restartBackend() {
  hideBanner(); setAgentState("starting"); setBusy(false);
  els.confs.innerHTML = "";
  await shell("restartBackend");
}

function provCard(p) {
  const m = PROV[p.id] || {};
  const f = S.fetched[p.id];
  const key = m.secret
    ? row("API key", `<a href="#" data-href="${esc(m.url)}">Get a key ${ic("external", "sm")}</a>`,
      `<div class="keybox"><input type="password" data-key="${m.secret}" placeholder="${S.settings?.secrets_configured?.[m.secret] ? "•••••••• saved — paste a new key to replace" : "Paste your API key"}" autocomplete="off" spellcheck="false"><button class="icon-btn" data-act="eye" title="Show / hide">${ic("eye")}</button></div>
       <button class="btn sm" data-act="savekey">Save</button>${S.settings?.secrets_configured?.[m.secret] ? `<button class="btn sm bad" data-act="rmkey">Remove</button>` : ""}`)
    : row("Use LM Studio", "Start LM Studio's local server (Developer tab) first.", sw(`data-set="LMSTUDIO_ENABLED" data-t="bool"`, sv("LMSTUDIO_ENABLED")));
  return `<div class="card prov" data-p="${p.id}">
    <div class="prov-head"><div class="prov-logo" style="--c1:${m.c1};--c2:${m.c2}">${esc(p.label[0])}</div>
      <div><b>${esc(p.label)}</b><div style="color:var(--dim);font-size:12.5px">${esc(m.blurb || "")}</div></div><span class="sp"></span>
      <span class="badge ${p.configured ? "ok" : ""}">${p.configured ? "ready" : "not set up"}</span>${p.primary ? '<span class="badge pri">primary</span>' : ""}</div>
    ${key}
    ${p.configured ? row(`${p.models.text.length} text · ${p.models.vision.length} vision models in rotation`, "Troy tries them top to bottom until one answers.",
      `${p.primary ? "" : `<button class="btn sm" data-act="prim">Make primary</button>`}<button class="btn sm" data-act="fetch">${ic("refresh", "sm")}${p.id === "lmstudio" ? "Refresh from LM Studio" : "Fetch live model list"}</button>`)
      : p.id === "lmstudio" ? row("Check the connection", "Lists the models LM Studio has, including which can see images.", `<button class="btn sm" data-act="fetch">${ic("refresh", "sm")}Check LM Studio</button>`) : ""}
    ${f ? `<div class="fetched"><div style="display:flex;align-items:center;gap:10px"><b style="font-size:13px">${f.error ? "Couldn't fetch models" : `${f.models.length} models available`}</b><span class="sp"></span>${f.error ? "" : `<label class="search" style="width:220px">${ic("search")}<input type="text" data-fmq placeholder="Filter" autocomplete="off"></label>`}</div>
      ${f.error ? `<p style="color:var(--bad);margin-top:6px;font-size:12.5px">${esc(f.error)}</p>` : `<div class="fm-list">${f.models.slice(0, 400).map((x) => `<button class="fm" data-fm="${esc(x)}">${esc(x)}${f.details?.[x]?.vision ? '<span class="tag">vision</span>' : ""}${f.details?.[x]?.loaded ? '<span class="tag">loaded</span>' : ""}${f.details?.[x]?.context ? `<span class="tag">${Math.round(f.details[x].context / 1024)}k ctx</span>` : ""}</button>`).join("")}</div>`}</div>` : ""}
  </div>`;
}

const optionGroups = (kind, current) => {
  const [op, om] = String(current || "").split(/:(.+)/);
  return S.provs.filter((p) => p.configured).map((p) => `<optgroup label="${esc(p.label)}">${p.models[kind].map((m) => `<option value="${esc(`${p.id}:${m}`)}"${op === p.id && om === m ? " selected" : ""}>${esc(m)}</option>`).join("")}</optgroup>`).join("");
};

function lmBlock() {
  const lm = S.provs.find((p) => p.id === "lmstudio");
  if (!lm) return "";
  if (!lm.configured) return `<h2>Local models (LM Studio)</h2><div class="card">${row("LM Studio is off", "Enable it to run models on your own PC — including vision models that can see your screen.", `<button class="btn sm pri" data-act="enable-lm">Enable LM Studio</button>`)}</div>`;
  const d = lm.details || {};
  const label = (m) => { const x = d[m] || {}; return `${m}${x.vision ? " · vision" : ""}${x.loaded ? " · loaded" : ""}${x.context ? ` · ${Math.round(x.context / 1024)}k ctx` : ""}`; };
  const opts = (list, cur) => `<option value="">Automatic (loaded model)</option>${list.map((m) => `<option value="${esc(m)}"${m === cur ? " selected" : ""}>${esc(label(m))}</option>`).join("")}`;
  const v = S.settings?.values || {};
  const noVision = !lm.models.vision.length;
  return `<h2>Local models (LM Studio)</h2><p>Troy reads the model list straight from LM Studio. Vision models (Qwen-VL, Gemma 3, Llama 3.2 Vision, …) let Troy look at your screen without sending it to the cloud.</p>
    <div class="card">
      ${row("Text model", "Which loaded model answers.", `<select data-set="LMSTUDIO_TEXT_MODEL" data-t="text">${opts(lm.models.text, v.LMSTUDIO_TEXT_MODEL)}</select>`)}
      ${row("Vision model", noVision ? "No vision model found. Load one in LM Studio (look for the “vision” badge in its model search), then refresh." : "Used when Troy looks at the screen.", `<select data-set="LMSTUDIO_VISION_MODEL" data-t="text" ${noVision ? "disabled" : ""}>${opts(lm.models.vision, v.LMSTUDIO_VISION_MODEL)}</select>`)}
      ${row("Context length", "Troy sizes its prompt to this. It's read from LM Studio when the model is loaded; set it if that fails.", `<input type="number" min="1024" max="262144" step="512" data-set="LMSTUDIO_CONTEXT_TOKENS" data-t="int" value="${esc(v.LMSTUDIO_CONTEXT_TOKENS)}"><span class="val">tokens</span>`)}
      ${row("Refresh", "After loading or unloading models.", `<button class="btn sm" data-act="lm-refresh">${ic("refresh", "sm")}Refresh from LM Studio</button>`)}
    </div>`;
}

const PANES = {
  async providers() {
    await Promise.all([loadProviders().catch((e) => console.error(e)), loadSettingsValues().catch((e) => console.error(e))]);
    if (!S.provs.length) throw new Error("Couldn't read the provider list from the backend.");
    const ready = S.provs.some((p) => p.configured);
    return `<h2>AI providers</h2><p>Troy needs at least one. Keys are stored on this PC only and are never shown again after saving.</p>
      ${ready ? "" : `<div class="card" style="border-color:rgba(var(--acc-rgb),.5)">${ic("sparkles")} <b>Start here:</b> paste a key for any provider below — Groq and NVIDIA both have free tiers.</div>`}
      <div id="provs" style="display:flex;flex-direction:column;gap:14px">${S.provs.map(provCard).join("")}</div>`;
  },

  async models() {
    await Promise.all([loadProviders().catch((e) => console.error(e)), loadSettingsValues().catch((e) => console.error(e))]);
    if (!S.provs.length) throw new Error("Couldn't read the provider list from the backend.");
    const v = S.settings?.values || {};
    const ready = S.provs.filter((p) => p.configured);
    const order = S.provs.slice().sort((a, b) => (b.primary - a.primary));
    if (!ready.length) return `<h2>Models</h2><div class="card placeholder">Add an API key first (Providers).</div>`;
    return `<h2>Model selection</h2><p>Picking a text model also makes its provider the primary one. If a model fails, Troy falls through the rest automatically.</p>
      <div class="card">
        ${row("Text model", "Used for thinking and replies.", `<select data-model="text"><option value="">Automatic (provider order)</option>${optionGroups("text", S.overrides.text)}</select>`)}
        ${row("Vision model", "Used when Troy looks at your screen.", `<select data-model="vision"><option value="">Automatic (provider order)</option>${optionGroups("vision", S.overrides.vision)}</select>`)}
        ${row("Primary provider", "Tried first.", `<select data-primary>${ready.map((p) => `<option value="${p.id}"${p.primary ? " selected" : ""}>${esc(p.label)}</option>`).join("")}</select>`)}
        ${row("Let Troy switch its own model", "Mid-chat, Troy can switch to “fast” for quick lookups and back to “strong” for hard thinking (the set_model tool). Switching from a local model to a paid one still asks you first.", sw(`data-set="ALLOW_MODEL_SWITCH" data-t="bool"`, v.ALLOW_MODEL_SWITCH))}
      </div>
      ${lmBlock()}
      <h2>Fallback order</h2><p>Providers are tried top to bottom, models left to right.</p>
      <div class="card">${order.filter((p) => p.configured).map((p) => row(`${esc(p.label)}${p.primary ? ' <span class="badge pri">primary</span>' : ""}`, "", `<div class="chain">${p.models.text.slice(0, 12).map((m) => `<span class="fm">${esc(m)}</span>`).join("")}${p.models.text.length > 12 ? `<span class="fm">+${p.models.text.length - 12}</span>` : ""}</div>`)).join("")}</div>`;
  },

  async general() {
    await loadSettingsValues().catch(() => {});
    if (!S.settings) throw new Error("Couldn't read settings from the backend.");
    const v = S.settings.values;
    return `<h2>General</h2>
      <div class="card">
        ${row("Your name", "How Troy addresses you.", `<input type="text" data-set="USER_NAME" data-t="text" value="${esc(v.USER_NAME)}" placeholder="Your name">`)}
        ${row("Max steps per request", "How many actions Troy may chain before it has to stop.", `<input type="range" min="3" max="40" step="1" data-set="MAX_STEPS_PER_TURN" data-t="int" value="${esc(v.MAX_STEPS_PER_TURN)}"><span class="val">${esc(v.MAX_STEPS_PER_TURN)}</span>`)}
        ${row("Scheduled tasks", "Lets Troy do things later or on a repeat (“sleep the PC at 10 PM”). They run with nobody watching, and only the commands you pre-approved can run.", sw(`data-set="TASKS_ENABLED" data-t="bool"`, v.TASKS_ENABLED))}
        ${row("Retries for a failed task", "How many more times a failed run is tried. Each task can override it.", `<input type="range" min="0" max="10" step="1" data-set="TASK_MAX_RETRIES" data-t="int" value="${esc(v.TASK_MAX_RETRIES ?? 2)}"><span class="val">${esc(v.TASK_MAX_RETRIES ?? 2)}</span>`)}
        ${row("Wait between retries", "Seconds between one attempt and the next.", `<input type="number" min="5" max="3600" data-set="TASK_RETRY_DELAY_SECONDS" data-t="int" value="${esc(v.TASK_RETRY_DELAY_SECONDS ?? 30)}">`)}
        ${row("Still run if it's late", "If the PC or Troy was off at the due time, the task runs anyway when it's back within this many minutes; later than that it is marked missed.", `<input type="number" min="1" max="1440" data-set="TASK_MISSED_GRACE_MINUTES" data-t="int" value="${esc(v.TASK_MISSED_GRACE_MINUTES ?? 10)}">`)}
        ${row("Second opinions", "Let Troy ask Gemini in your browser when it's truly stuck.", sw(`data-set="ESCALATION_ENABLED" data-t="bool"`, v.ESCALATION_ENABLED))}
        ${row("Hide the research browser", "Troy's own web_* browser runs in the background. Needs a restart.", sw(`data-set="BROWSER_HEADLESS" data-t="bool"`, v.BROWSER_HEADLESS))}
        ${row("Launching apps", "How “open an app” works. Troy's instructions don't change — it always just says open_app.", `<select data-set="APP_LAUNCH_MODE" data-t="text">${[["auto", "Direct, then Start menu (recommended)"], ["direct", "Direct only"], ["start_menu", "Start menu (presses the Windows key)"]].map(([k, l]) => `<option value="${k}"${v.APP_LAUNCH_MODE === k ? " selected" : ""}>${l}</option>`).join("")}</select>`)}
        ${row("Try launching an app", "Starts it directly — handy for checking that your apps are found.", `<input type="text" id="appTest" placeholder="e.g. spotify, calculator, notepad"><button class="btn sm" data-act="app-test">${ic("bolt", "sm")}Launch</button>`)}
      </div>`;
  },

  async widget() {
    const w = await syncWidget();
    return `<h2>Widget</h2>
      <p>The widget is Troy's small, always-visible glass pill at the top-centre of your screen, right under the webcam on a laptop. You can talk to it, type to it and approve actions from there. <b>Only one of the widget and this window is ever shown</b>: opening the full app hides the widget, and closing the app brings the widget back.</p>
      <div class="card widget-hero">
        <div class="mini-pill" aria-hidden="true"><i class="mp-orb"></i><span class="mp-id"><b>Troy</b><small>Ready.</small></span><span class="mp-field"><i></i><i></i><i></i><i></i><i></i> Ask me anything…</span><i class="mp-dot"></i></div>
        <div class="hero-actions"><button class="btn pri" data-act="to-widget">${ic("window", "sm")}Switch to the widget now</button></div>
      </div>
      <div class="card">
        ${row("Show / hide shortcut", "Works from any app: opens the widget and focuses its input, and closes it again. Use modifiers + a key, like Ctrl+Alt+T.", `<input type="text" id="wHotkey" data-widget-hotkey value="${esc(fmtHotkey(w.hotkey))}" placeholder="Ctrl+Alt+T" spellcheck="false">${w.hotkeyActive === false ? '<span class="badge bad" title="Another app may be using it">not active</span>' : '<span class="badge ok">active</span>'}`)}
        ${row("Stay above all windows", "Keeps the widget on top of everything, even full-screen apps.", sw(`data-widget="onTop"`, w.onTop !== false))}
        ${row("Fold away after replies", "The panel under the widget collapses by itself a few seconds after Troy has answered.", sw(`data-widget="autoCollapse"`, w.autoCollapse !== false))}
      </div>
      <div class="card" style="color:var(--dim);font-size:13px">Troy can do this himself too: ask him to “switch to the widget”, “open the full app”, or “turn off auto-collapse”.</div>`;
  },

  async power() {
    await loadSettingsValues().catch(() => {});
    await refreshPower();
    const p = S.power, mode = p.mode;
    const battery = p.on_battery === null ? "unknown" : p.on_battery ? "on battery" : "plugged in";
    return `<h2>Power saving</h2>
      <p>Cuts what Troy does in the background so a laptop lasts longer and a busy PC stays cool. Troy keeps working exactly the same: it only looks calmer.</p>
      <div class="card">
        ${row("Mode", "Auto turns power saving on whenever the laptop runs on battery.", `<div class="seg" data-power-seg>${[["off", "Off"], ["auto", "Auto"], ["on", "On"]].map(([k, l]) => `<button data-v="${k}" class="${mode === k ? "on" : ""}">${l}</button>`).join("")}</div>`)}
        ${row("Right now", `This computer is ${battery}.`, `<span class="badge ${p.active ? "ok" : ""}">${p.active ? "Power saving is active" : "Full performance"}</span>`)}
      </div>
      <h2>What it changes</h2>
      <div class="card"><ul class="steps-list">
        <li>The avatar draws at 20 frames a second (8 while asleep) with no glow, sparkles or sound rings, and falls asleep sooner.</li>
        <li>The drifting background, glass blur and decorative animations in this window and in the widget are switched off.</li>
        <li>Live voice-level updates and the phone's screen-sharing frame rate are throttled.</li>
        <li>Replies, tools, wake word and voice mode are unchanged.</li>
      </ul></div>`;
  },

  async performance() {
    await loadSettingsValues().catch(() => {});
    if (!S.settings) throw new Error("Couldn't read settings from the backend.");
    const v = S.settings.values;
    let info = null;
    try { info = await T.request("prompt.info", {}); } catch { /* optional */ }
    const modeLabel = { compact: "Compact", tiny: "Tiny", detailed: "Detailed" };
    return `<h2>Speed &amp; context size</h2><p>Every request carries Troy's instructions plus the conversation. Smaller means faster replies, fewer rate-limit errors (Groq's free tier allows ~8,000 tokens a minute) and it lets small local models run at all.</p>
      <div class="card">
        ${row("Prompt size", info ? `Using <b>${esc(modeLabel[info.mode] || info.mode)}</b> now (about ${info.prompt_tokens.toLocaleString()} tokens). Auto picks Tiny for a small local model, Compact otherwise. Detailed is the original ~9,000-token prompt.` : "", `<select data-set="PROMPT_MODE" data-t="text">${[["auto", "Auto"], ["compact", "Compact (recommended)"], ["tiny", "Tiny (small local models)"], ["detailed", "Detailed (slow)"]].map(([k, l]) => `<option value="${k}"${v.PROMPT_MODE === k ? " selected" : ""}>${l}</option>`).join("")}</select>`)}
        ${row("Tool calling", "How Troy uses its tools. Native uses the model's own function calling: structured arguments instead of parsed text, so fewer mistakes, and the tool list travels outside the prompt. Text is the original command-line protocol. Auto uses Native and falls back to Text for any model that doesn't support it.", `<select data-set="TOOL_CALLING" data-t="text">${[["auto", "Auto (recommended)"], ["native", "Native only"], ["text", "Text protocol"]].map(([k, l]) => `<option value="${k}"${(v.TOOL_CALLING || "auto") === k ? " selected" : ""}>${l}</option>`).join("")}</select>`)}
        ${row("Load extra tools on demand", "The prompt lists only the core tools; Troy calls list_extra_tools to find the rest when a request needs them, and forgets the list afterwards. Smaller, faster prompts. Turn off to list every tool up front.", sw(`data-set="EXTRA_TOOLS_ENABLED" data-t="bool"`, v.EXTRA_TOOLS_ENABLED))}
        ${row("Fast replies", "Asks reasoning models (gpt-oss, Qwen3, Gemini 2.5…) to think less. Troy's answers are short command lines, so long hidden reasoning is wasted time.", sw(`data-set="LLM_FAST" data-t="bool"`, v.LLM_FAST))}
        ${row("Conversation budget", "Most tokens of prompt + history sent per request. Older messages are dropped first, and long tool output is trimmed.", `<input type="range" min="1500" max="24000" step="500" data-set="CONTEXT_BUDGET_TOKENS" data-t="int" value="${esc(v.CONTEXT_BUDGET_TOKENS)}"><span class="val">${esc(v.CONTEXT_BUDGET_TOKENS)}</span>`)}
        ${row("Longest reply", "Cap on the reply length (providers count it against rate limits).", `<input type="range" min="256" max="4000" step="100" data-set="LLM_MAX_OUTPUT_TOKENS" data-t="int" value="${esc(v.LLM_MAX_OUTPUT_TOKENS)}"><span class="val">${esc(v.LLM_MAX_OUTPUT_TOKENS)}</span>`)}
        ${row("Local model context", info?.lmstudio_context ? `LM Studio reports ${info.lmstudio_context.toLocaleString()} tokens for the model Troy will use.` : "Used when LM Studio doesn't report one.", `<input type="number" min="1024" max="262144" step="512" data-set="LMSTUDIO_CONTEXT_TOKENS" data-t="int" value="${esc(v.LMSTUDIO_CONTEXT_TOKENS)}"><span class="val">tokens</span>`)}
      </div>
      <div class="card" style="color:var(--dim);font-size:13px">Models that fail (rate-limited, too small for the request, retired) are skipped for a while instead of being retried on every message, so one bad model no longer slows every reply.</div>`;
  },

  async integrations() {
    await loadSettingsValues().catch(() => {});
    if (!S.settings) throw new Error("Couldn't read settings from the backend.");
    const v = S.settings.values, sec = S.settings.secrets_configured;
    let yt = { configured: false, connected: false, channel: null, error: "" };
    try { yt = await T.request("youtube.status", {}); } catch (e) { yt.error = cleanErr(e); }
    S.yt = yt;
    const badge = yt.connected ? `<span class="badge ok">connected</span>` : yt.configured ? `<span class="badge warn">ready to connect</span>` : `<span class="badge">not set up</span>`;
    return `<h2>YouTube</h2><p>Lets Troy use <i>your</i> YouTube account: “open the last video I liked”, your playlists, subscriptions, search. Sign-in is Google's standard OAuth 2.0 and is read-only.</p>
      <div class="card" data-yt>
        <div class="prov-head"><div class="prov-logo" style="--c1:#ff2d2d;--c2:#ff7a59">▶</div><div><b>YouTube Data API</b>
          <div style="color:var(--dim);font-size:12.5px">${yt.channel ? `<span class="yt-user">${yt.channel.thumbnail ? `<img src="${esc(yt.channel.thumbnail)}" alt="">` : ""}Signed in as ${esc(yt.channel.title)}</span>` : esc(yt.error || "Not signed in")}</div></div><span class="sp"></span>${badge}</div>
        <details class="help"${yt.configured ? "" : " open"}><summary>How to get a client id and secret (one time, ~3 minutes)</summary><div><ol class="steps-list">
          <li>Open the <a href="#" data-href="https://console.cloud.google.com/apis/library/youtube.googleapis.com">Google Cloud Console</a>, create or pick a project, and press <b>Enable</b> on “YouTube Data API v3”.</li>
          <li>Go to <a href="#" data-href="https://console.cloud.google.com/auth/overview">Google Auth Platform</a> (OAuth consent screen): choose <b>External</b>, fill in the app name, and add <b>your own Google account as a test user</b>.</li>
          <li>Go to <a href="#" data-href="https://console.cloud.google.com/apis/credentials">Credentials</a> › <b>Create credentials</b> › <b>OAuth client ID</b> › application type <b>Desktop app</b>.</li>
          <li>Copy the <b>Client ID</b> and <b>Client secret</b> into the boxes below, press Save, then <b>Connect YouTube</b>.</li></ol></div></details>
        ${row("Client ID", "", `<input type="text" data-set="YOUTUBE_CLIENT_ID" data-t="text" value="${esc(v.YOUTUBE_CLIENT_ID)}" placeholder="123456-abc.apps.googleusercontent.com" spellcheck="false">`)}
        ${row("Client secret", "", `<div class="keybox"><input type="password" data-key="YOUTUBE_CLIENT_SECRET" placeholder="${sec.YOUTUBE_CLIENT_SECRET ? "•••••••• saved — paste a new one to replace" : "GOCSPX-…"}" autocomplete="off" spellcheck="false"><button class="icon-btn" data-act="eye" title="Show / hide">${ic("eye")}</button></div><button class="btn sm" data-act="savekey">Save</button>`)}
        ${row("Open videos in", "Videos Troy opens for you appear in a new tab of this browser.", `<select data-set="YOUTUBE_BROWSER" data-t="text">${[["firefox", "Firefox"], ["chrome", "Chrome"], ["edge", "Edge"], ["brave", "Brave"], ["default", "System default"]].map(([k, l]) => `<option value="${k}"${v.YOUTUBE_BROWSER === k ? " selected" : ""}>${l}</option>`).join("")}</select>`)}
        ${S.ytWaiting ? `<div class="row"><div class="lab"><b>Waiting for you to approve in the browser…</b><small>If the page says it can't connect, copy the whole address from the browser's address bar and paste it here.</small></div><div class="ctl"><input type="text" id="ytPaste" placeholder="http://127.0.0.1:…/callback?code=…" spellcheck="false"><button class="btn sm" data-act="yt-paste">Use this</button><button class="btn sm bad" data-act="yt-cancel">Cancel</button></div></div>`
          : row(yt.connected ? "Account" : "Sign in", yt.connected ? "Troy can read your liked videos, playlists and subscriptions." : "Opens Google's sign-in page in your browser.",
            yt.connected ? `<button class="btn sm" data-act="yt-test">${ic("refresh", "sm")}Show my latest liked video</button><button class="btn sm bad" data-act="yt-disconnect">Disconnect</button>` : `<button class="btn pri" data-act="yt-connect" ${yt.configured ? "" : "disabled"}>${ic("link", "sm")}Connect YouTube</button>`)}
        <div id="ytTest"></div>
      </div>
      <h2>NewsAPI</h2>
      <div class="card">${row("API key", `<a href="#" data-href="https://newsapi.org/register">Get a free key ${ic("external", "sm")}</a>`, `<div class="keybox"><input type="password" data-key="NEWSAPI_KEY" placeholder="${sec.NEWSAPI_KEY ? "•••••••• saved — paste a new key to replace" : "For the news_* tools"}" autocomplete="off" spellcheck="false"><button class="icon-btn" data-act="eye" title="Show / hide">${ic("eye")}</button></div><button class="btn sm" data-act="savekey">Save</button>`)}</div>
      <p style="color:var(--dim);font-size:12.5px">Open-Meteo (weather), Frankfurter (currency) and Wikipedia need no key.</p>`;
  },

  async voice() {
    await loadSettingsValues().catch(() => {});
    if (!S.settings) throw new Error("Couldn't read settings from the backend.");
    const v = S.settings.values;
    let status = { active: false, state: "off", muted: false, engines: [], stt: {} };
    try { status = S.voiceStatus = await T.request("voice.mode_status", {}); } catch { /* optional */ }
    try { S.wake = await T.request("wake_listener.status", {}); } catch { /* optional */ }
    if (!S.voiceDevices) { try { S.voiceDevices = (await T.request("voice.devices", {})).devices || []; } catch { S.voiceDevices = []; } }
    let voices = [];
    try { voices = (await T.request("voice.list_voices", { engine: "sapi" })).voices || []; } catch { /* optional */ }
    const eng = (id) => (status.engines || []).find((x) => x.id === id) || {};
    const engBadge = (id) => {
      const e = eng(id);
      if (e.available === undefined) return "";
      return ` <span class="badge ${e.available ? "ok" : ""}" title="${esc(e.reason || "")}">${e.available ? "ready" : "not installed"}</span>`;
    };
    const stt = status.stt || {};
    const edgeVoices = S.edgeVoices || [];
    const edgeCtl = edgeVoices.length
      ? `<select data-set="EDGE_VOICE" data-t="text">${edgeVoices.map((x) => `<option value="${esc(x.id)}"${x.id === v.EDGE_VOICE ? " selected" : ""}>${esc(x.name)}</option>`).join("")}</select>`
      : `<input type="text" data-set="EDGE_VOICE" data-t="text" value="${esc(v.EDGE_VOICE)}" placeholder="en-US-AriaNeural" spellcheck="false"> <button class="btn sm" data-act="edge-voices">${ic("refresh", "sm")}Load voice list</button>`;
    const micOpts = [`<option value=""${!v.VOICE_INPUT_DEVICE ? " selected" : ""}>System default</option>`]
      .concat(S.voiceDevices.map((d) => `<option value="${esc(d.name)}"${d.name === v.VOICE_INPUT_DEVICE ? " selected" : ""}>${esc(d.name)}${d.default ? " (default)" : ""}</option>`)).join("");
    return `<h2>Voice</h2><p>Talk to Troy without touching anything, and hear the answers. The engine picks whatever is installed — natural voices first, the built-in system voice as the safety net.</p>
      <div class="card">
        ${row("Hands-free voice mode", "No wake word, back-and-forth conversation on this PC's mic. Ctrl+Shift+V. Say “stop” to interrupt, “goodbye” to leave.", `<span class="badge ${status.active ? "ok" : ""}">${status.active ? `on · ${esc(status.state)}` : "off"}</span><button class="btn sm ${status.active ? "bad" : "pri"}" data-act="vmode">${status.active ? "Leave" : "Start"}</button>`)}
        ${row("Speak replies aloud", "Also applies outside voice mode: every reply is read out.", sw(`data-set="VOICE_OUTPUT_ENABLED" data-t="bool"`, v.VOICE_OUTPUT_ENABLED))}
      </div>
      <h2>Speech output</h2>
      <div class="card">
        ${row("Text-to-speech engine", "auto = Piper when a voice file is set, else the built-in voice. Edge needs internet; Piper and the built-in voice are offline.",
          `<select data-set="TTS_ENGINE" data-t="text">${[["auto", "Automatic"], ["piper", `Piper (offline, natural)`], ["edge", `Edge (online, neural)`], ["sapi", `Built-in system voice`]].map(([k, l]) => `<option value="${k}"${v.TTS_ENGINE === k ? " selected" : ""}>${l}</option>`).join("")}</select>`)}
        ${row("Engine availability", "What can run on this PC right now.", `<div class="chain">${["piper", "edge", "sapi"].map((id) => `<span class="fm">${id === "sapi" ? "built-in" : id}${engBadge(id)}</span>`).join("")}</div>`)}
        ${row("Voice", voices.length ? "The built-in engine's voices (offline)." : "No built-in voices found — install 'pyttsx3' or pick another engine.", `<select data-set="TTS_VOICE_ID" data-t="text"><option value="">System default</option>${voices.map((x) => `<option value="${esc(x.id)}"${x.id === v.TTS_VOICE_ID ? " selected" : ""}>${esc(x.name)}</option>`).join("")}</select>`)}
        ${row("Edge voice", "Only used when the Edge engine is selected. e.g. en-US-AriaNeural, en-GB-SoniaNeural.", edgeCtl)}
        ${row("Piper voice model", "Path to a .onnx voice from huggingface.co/rhasspy/piper-voices (fully offline).", `<input type="text" data-set="PIPER_MODEL" data-t="text" value="${esc(v.PIPER_MODEL)}" placeholder="C:\\voices\\en_US-amy-medium.onnx" spellcheck="false">`)}
        ${row("Speaking speed", "Words per minute, roughly.", `<input type="range" min="80" max="300" step="5" data-set="TTS_RATE" data-t="int" value="${esc(v.TTS_RATE)}"><span class="val">${esc(v.TTS_RATE)}</span><button class="btn sm" data-act="say">${ic("volume", "sm")}Test</button>`)}
      </div>
      <h2>Listening</h2>
      <div class="card">
        ${row("Wake-word listening", "Say the wake word, then your request. Needs a microphone.", `<span class="badge ${S.wake.running ? "ok" : ""}">${S.wake.running ? `listening · ${esc(S.wake.state)}` : "off"}</span><button class="btn sm ${S.wake.running ? "bad" : "pri"}" data-act="wake">${S.wake.running ? "Stop" : "Start"}</button>`)}
        ${row("Wake word", "Said (case-insensitively) to wake Troy up.", `<input type="text" data-set="WAKE_WORD" data-t="text" value="${esc(v.WAKE_WORD)}" placeholder="troy">`)}
        ${row("Speech recognition", stt.available ? "Installed and ready." : `Not installed yet: ${esc(stt.reason || "pip install SpeechRecognition")}.`, `<select data-set="STT_ENGINE" data-t="text">${["google", "whisper"].map((x) => `<option value="${x}"${x === v.STT_ENGINE ? " selected" : ""}>${x === "google" ? "Google (online)" : "Whisper (offline)"}</option>`).join("")}</select> <span class="badge ${stt.available ? "ok" : ""}">${stt.available ? "ready" : "missing"}</span>`)}
        ${row("Recognition language", "BCP-47 code like en-US or tr-TR. Blank = auto.", `<input type="text" data-set="STT_LANGUAGE" data-t="text" value="${esc(v.STT_LANGUAGE)}" placeholder="auto" spellcheck="false">`)}
        ${row("Microphone", S.voiceDevices.length ? "The one Troy listens on." : "No microphones found — is one plugged in?", `<select data-set="VOICE_INPUT_DEVICE" data-t="text">${micOpts}</select>`)}
        ${row("Test the microphone", "Records a few seconds and shows the peak level plus what was understood.", `<button class="btn sm" data-act="test-mic">${ic("mic", "sm")}Record 4 s</button><div id="micTestBar" class="v-level" style="position:static;width:130px"><i></i></div>`)}
        ${row("", "", `<span id="micTestOut" class="dim" style="font-size:12.5px"></span>`)}
        ${row("Start listening at launch", "For the wake-word listener; voice mode starts from its button.", sw(`data-set="VOICE_INPUT_ENABLED" data-t="bool"`, v.VOICE_INPUT_ENABLED))}
      </div>
      <h2>Conversation feel</h2>
      <div class="card">
        ${row("Follow-up window", "How long Troy keeps waiting for the next thing you say, with no wake word.", `<input type="number" min="5" max="300" step="1" data-set="VOICE_CONVERSATION_IDLE_SECONDS" data-t="int" value="${esc(v.VOICE_CONVERSATION_IDLE_SECONDS)}"><span class="val">seconds</span>`)}
        ${row("Interrupt by talking", "Speaking clearly over Troy stops it mid-sentence (barge-in).", sw(`data-set="VOICE_BARGE_IN" data-t="bool"`, v.VOICE_BARGE_IN))}
        ${row("Spoken-style answers", "While voice is on, ask the model for short speakable replies: no lists, links or markdown.", sw(`data-set="VOICE_SPOKEN_STYLE" data-t="bool"`, v.VOICE_SPOKEN_STYLE))}
      </div>`;
  },

  async appearance() {
    const a = UI.avatar;
    return `<h2>Theme</h2>
      <div class="card">
        ${row("Mode", "", `<div class="seg" data-seg="theme">${["dark", "light", "auto"].map((t) => `<button data-v="${t}" class="${UI.theme === t ? "on" : ""}">${t[0].toUpperCase() + t.slice(1)}</button>`).join("")}</div>`)}
        ${row("Accent colour", "", `<div class="swatches">${ACCENTS.map((x) => `<button class="sw${UI.accent === x.id ? " on" : ""}" data-accent="${x.id}" title="${x.name}" style="--c:linear-gradient(135deg,${x.a},${x.b});background:var(--c)"></button>`).join("")}</div>`)}
        ${row("Glass blur", "How frosted the panels look. Lower it if your GPU struggles.", `<input type="range" min="0" max="44" step="2" data-ui="blur" value="${UI.blur}"><span class="val">${UI.blur}px</span>`)}
        ${row("Reduce motion", "Stops the drifting background and most animations.", sw(`data-ui="reduceMotion"`, UI.reduceMotion))}
        ${row("Default layout", "", `<div class="seg" data-seg="mode">${[["split", "Avatar + chat"], ["focus", "Avatar focus"], ["chat", "Chat only"]].map(([k, l]) => `<button data-v="${k}" class="${UI.mode === k ? "on" : ""}">${l}</button>`).join("")}</div>`)}
      </div>
      <h2>Avatar</h2>
      <div class="card">
        ${row("Size", "", `<input type="range" min="0.6" max="1.5" step="0.05" data-ui="avatar.scale" value="${a.scale}"><span class="val">${Number(a.scale).toFixed(2)}×</span>`)}
        ${row("Eye spacing", "", `<input type="range" min="80" max="200" step="2" data-ui="avatar.gap" value="${a.gap}"><span class="val">${a.gap}</span>`)}
        ${row("Follow the cursor", "Eyes track your mouse while you move it.", sw(`data-ui="avatar.tracking"`, a.tracking))}
        ${row("Fall asleep when idle", "After 8 quiet seconds. Move the mouse to wake it.", sw(`data-ui="avatar.sleep"`, a.sleep))}
        ${row("Sound effects", "Soft chirps when moods change.", sw(`data-ui="avatar.sound"`, a.sound))}
        ${row("Preview moods", "", `<div class="chain">${["idle", "listening", "thinking", "executing", "speaking", "done", "error", "sleeping", "surprised", "wink", "curious", "proud"].map((s) => `<button class="btn sm" data-prev="${s}">${s}</button>`).join("")}</div>`)}
      </div>`;
  },

  async remote() {
    await loadSettingsValues().catch(() => {});
    try { S.mobile = await T.request("mobile_ui.status", {}); } catch { /* optional */ }
    const m = S.mobile, v = S.settings?.values || {}, ts = m.tailscale || {};
    const tsBadge = !ts.installed ? '<span class="badge">not installed</span>' : ts.running ? '<span class="badge ok">connected</span>' : `<span class="badge warn">${esc(ts.state === "NeedsLogin" ? "signed out" : ts.state === "Stopped" ? "turned off" : ts.state || "unknown")}</span>`;
    const peers = (ts.peers || []).slice(0, 8).map((p) => `<span class="peer${p.online ? " on" : ""}" title="${esc(p.os)} ${esc(p.ip)}"><i></i>${esc(p.name)}</span>`).join("");
    const https = (m.urls || []).some((u) => u.kind === "tailscale-https");
    return `<h2>Phone</h2><p>A page for your phone with Troy's face, the chat, approvals and a live view of this PC's screen. It runs on this PC — nothing goes through a cloud server.</p>
      <div class="card">
        ${row("Phone page", m.running ? "Open one of the links below on your phone." : "Turn it on to get a link.", `<span class="badge ${m.running ? "ok" : ""}">${m.running ? "on" : "off"}</span><button class="btn sm ${m.running ? "bad" : "pri"}" data-act="mobile">${m.running ? "Turn off" : "Turn on"}</button>`)}
        ${row("Voice from the phone", "The phone's mic and speaker become Troy's headset on that page. Needs an HTTPS link (below) or Tailscale HTTPS — browsers only hand out the microphone on secure pages.", sw(`data-set="MOBILE_VOICE_ENABLED" data-t="bool"`, v.MOBILE_VOICE_ENABLED))}
        ${row("Replies sound like", "The phone's own voice is instant; Troy's synthesized voice (the TTS engine from Settings › Voice) is richer and sounds the same everywhere.", `<select data-set="VOICE_PHONE_SPEAKER" data-t="text">${[["phone", "The phone's voice (instant)"], ["troy", "Troy's voice, streamed from the PC"]].map(([k, l]) => `<option value="${k}"${v.VOICE_PHONE_SPEAKER === k ? " selected" : ""}>${l}</option>`).join("")}</select>`)}
        ${m.running ? (m.urls || []).map((u) => `<div class="urlrow${u.recommended ? " rec" : ""}"><div class="u"><b>${esc(u.label)} ${u.recommended ? '<span class="badge pri">best</span>' : ""}</b><code>${esc(u.url)}</code><small>${esc(u.detail)}</small></div><button class="icon-btn" data-act="copyurl" data-url="${esc(u.url)}" title="Copy">${ic("copy")}</button><button class="icon-btn" data-act="openurl" data-url="${esc(u.url)}" title="Open">${ic("external")}</button></div>`).join("") : ""}
        ${m.running ? row("Access link", "Anyone with the link can use Troy and see your screen. Make a new one if it leaks.", `<button class="btn sm" data-act="regen">${ic("refresh", "sm")}Make a new link</button>`) : ""}
      </div>
      <h2>Watch this PC's screen</h2>
      <div class="card">
        ${row("Live screen on the phone", "View only — the phone can't click or type. Troy shows “Phone watching” here while someone is looking.", sw(`data-set="MOBILE_SCREEN_ENABLED" data-t="bool"`, v.MOBILE_SCREEN_ENABLED))}
        ${row("Highest frame rate", "Lower saves bandwidth and CPU.", `<input type="range" min="1" max="15" step="1" data-set="MOBILE_SCREEN_MAX_FPS" data-t="int" value="${esc(v.MOBILE_SCREEN_MAX_FPS)}"><span class="val">${esc(v.MOBILE_SCREEN_MAX_FPS)} fps</span>`)}
        ${m.running ? row("Watching now", "", `<span class="badge ${m.viewers ? "warn" : ""}">${m.viewers ? `${m.viewers} phone${m.viewers > 1 ? "s" : ""}` : "nobody"}</span>`) : ""}
      </div>
      <h2>Reach it from anywhere (Tailscale)</h2>
      <p>Tailscale is a free private network between your own devices: install it on this PC and your phone and the page works on mobile data, at work, anywhere — encrypted, with nothing opened on your router.</p>
      <div class="card">
        ${row("Tailscale on this PC", ts.error ? esc(ts.error) : ts.running ? `Signed in${ts.tailnet ? ` as ${esc(ts.tailnet)}` : ""} · ${esc(ts.dns_name || ts.ip)}` : "", `${tsBadge}${ts.installed ? `<button class="btn sm" data-act="ts-refresh">${ic("refresh", "sm")}Recheck</button>` : `<button class="btn sm pri" data-act="ts-get">${ic("external", "sm")}Get Tailscale</button>`}`)}
        ${ts.running && m.running ? row("HTTPS link", https ? "On: https://" + esc(ts.dns_name) + " — also enables voice input and “add to home screen” on the phone." : "Gives the phone a secure https link (needs HTTPS enabled once for your tailnet in Tailscale's admin console).", `<button class="btn sm ${https ? "bad" : "pri"}" data-act="ts-serve" data-enable="${https ? "0" : "1"}">${https ? "Turn off" : "Turn on HTTPS"}</button>`) : ""}
        ${peers ? row("Your devices", "", `<div class="chain">${peers}</div>`) : ""}
      </div>`;
  },

  async about() {
    const t0 = performance.now();
    let ping = null;
    try { ping = await T.request("app.ping", {}); } catch { /* offline */ }
    const ms = Math.round(performance.now() - t0);
    const sh = (await shell("getPrefs")) || S.shell || {};
    return `<h2>About</h2>
      <div class="card"><dl class="kv">
        <dt>Troy</dt><dd>${ping ? `${esc(ping.version_label)} ${esc(ping.version)}` : "backend offline"}</dd>
        <dt>Backend latency</dt><dd>${ping ? `${ms} ms (stdio IPC — no network)` : "—"}</dd>
        <dt>Interface</dt><dd>Electron ${esc(sh.electron || "—")} on ${esc(sh.platform || T.platform || "—")}${sh.packaged === false ? " (development)" : ""}</dd>
        <dt>Python</dt><dd>${esc(sh.python || "—")}</dd>
      </dl></div>
      <div class="card">
        ${row("Restart the backend", "Reloads the Python side. Chats are saved.", `<button class="btn sm" data-act="restart">${ic("power", "sm")}Restart</button>`)}
        ${row("Reload the interface", "", `<button class="btn sm" data-act="reload">${ic("refresh", "sm")}Reload</button>`)}
        ${row("Quit Troy completely", "Stops listening and closes the tray icon.", `<button class="btn sm bad" data-act="quit">${ic("power", "sm")}Quit</button>`)}
      </div>
      <h2>Shortcuts</h2>
      <div class="card"><dl class="kv">
        <dt>Voice mode</dt><dd><kbd>Ctrl</kbd> <kbd>Shift</kbd> <kbd>V</kbd></dd>
        <dt>Command palette</dt><dd><kbd>Ctrl</kbd> <kbd>K</kbd></dd><dt>New chat</dt><dd><kbd>Ctrl</kbd> <kbd>N</kbd></dd>
        <dt>Stop the current task</dt><dd><kbd>Ctrl</kbd> <kbd>.</kbd></dd><dt>Sidebar</dt><dd><kbd>Ctrl</kbd> <kbd>B</kbd></dd>
        <dt>Settings</dt><dd><kbd>Ctrl</kbd> <kbd>,</kbd></dd><dt>Switch view</dt><dd><kbd>Ctrl</kbd> <kbd>1</kbd>–<kbd>5</kbd></dd>
        <dt>Slash commands</dt><dd>type <kbd>/</kbd> in the message box</dd>
      </dl></div>`;
  },
};

let paneToken = 0;
const SKELETON = '<div class="skeleton"><i></i><i></i><i></i></div>';
async function renderPane() {
  $$("#setNav button").forEach((b) => b.classList.toggle("on", b.dataset.pane === S.pane));
  const token = ++paneToken, scroller = els.setPane.closest(".page"), y = scroller ? scroller.scrollTop : 0;
  // Show something immediately: a pane can wait on the backend, and a blank panel looked like a hang.
  if (els.setPane.dataset.pane !== S.pane) els.setPane.innerHTML = SKELETON;
  els.setPane.dataset.pane = S.pane;
  try {
    const html = await PANES[S.pane]();
    if (token !== paneToken) return;
    els.setPane.innerHTML = html;
    if (scroller) scroller.scrollTop = y;
  } catch (e) {
    if (token !== paneToken) return;
    console.error(`Settings pane '${S.pane}' failed:`, e);
    els.setPane.innerHTML = `<div class="card placeholder"><b>This page couldn't load.</b><br>${esc(cleanErr(e))}<br><br><button class="btn" data-act="retrypane">${ic("refresh", "sm")}Try again</button></div>`;
  }
}
async function loadSettingsValues() {
  S.settings = await T.request("settings.get", {});
  updateQuick();
  return S.settings;
}

/* settings interactions (one delegated listener each) */
async function paneChange(e) {
  const t = e.target;
  if (t.matches("[data-fmq]")) return;
  if (t.dataset.set) {
    const kind = t.dataset.t;
    const value = kind === "bool" ? t.checked : kind === "int" ? parseInt(t.value, 10) : t.value.trim();
    if (kind === "int" && Number.isNaN(value)) return;
    const ok = await saveSetting(t.dataset.set, value);
    if (!ok) { renderPane(); return; }
    if (["LMSTUDIO_ENABLED", "LMSTUDIO_TEXT_MODEL", "LMSTUDIO_VISION_MODEL", "LMSTUDIO_CONTEXT_TOKENS"].includes(t.dataset.set)) { await loadProviders().catch(() => {}); renderPane(); }
    if (["YOUTUBE_CLIENT_ID", "PROMPT_MODE", "LLM_FAST", "MOBILE_SCREEN_ENABLED", "EXTRA_TOOLS_ENABLED"].includes(t.dataset.set)) renderPane();
    if (t.dataset.set === "VOICE_INPUT_ENABLED") { try { if (value) { const r = await T.request("wake_listener.start", {}); S.wake.running = !!r.started; } else { await T.request("wake_listener.stop", {}); S.wake.running = false; } } catch { /* ignore */ } updateQuick(); }
    toast("Saved", "ok", 1200);
  } else if (t.dataset.ui) {
    const path = t.dataset.ui.split("."), val = t.type === "checkbox" ? t.checked : parseFloat(t.value);
    let o = UI; for (let i = 0; i < path.length - 1; i++) o = o[path[i]];
    o[path[path.length - 1]] = val;
    saveUI(); applyUI();
  } else if (t.dataset.widget) {
    await setWidgetOption(t.dataset.widget, t.checked);
  } else if (t.dataset.widgetHotkey !== undefined) {
    const r = await setWidgetOption("hotkey", t.value.trim());
    if (!r?.ok) { toast(r?.error || "That shortcut can't be used.", "bad", 4200); renderPane(); }
    else toast(`Shortcut: ${fmtHotkey(r.hotkey)}`, "ok", 1600);
  } else if (t.dataset.model) {
    const kind = t.dataset.model;
    if (!t.value) { await call("model.set", { kind }).catch(() => {}); }
    else {
      const i = t.value.indexOf(":"), pid = t.value.slice(0, i), model = t.value.slice(i + 1);
      if (kind === "text") await selectModel(pid, model);
      else await call("model.set", { kind, provider: pid, model }).catch(() => {});
    }
    await loadProviders(); toast("Saved", "ok", 1200); renderPane();
  } else if (t.dataset.primary !== undefined) {
    await call("provider.set_primary", { provider: t.value }).catch(() => {});
    await loadProviders(); renderPane();
  }
}
function paneInput(e) {
  const t = e.target;
  if (t.matches("[data-fmq]")) {
    const q = t.value.trim().toLowerCase();
    $$(".fm", t.closest(".fetched")).forEach((b) => { b.style.display = !q || b.dataset.fm.toLowerCase().includes(q) ? "" : "none"; });
    return;
  }
  if (t.type === "range") {
    const val = t.nextElementSibling;
    if (val?.classList.contains("val")) val.textContent = t.dataset.ui === "blur" ? `${t.value}px` : t.dataset.ui === "avatar.scale" ? `${Number(t.value).toFixed(2)}×` : t.dataset.set === "MOBILE_SCREEN_MAX_FPS" ? `${t.value} fps` : t.value;
    if (t.dataset.ui) paneChange(e);                       // appearance sliders apply live
  }
}
async function paneClick(e) {
  const a = e.target.closest("a[data-href]");
  if (a) { e.preventDefault(); T.openExternal(a.dataset.href); return; }
  const pw = e.target.closest("[data-power-seg] button");
  if (pw) { await saveSetting("POWER_SAVING", pw.dataset.v); await refreshPower(); renderPane(); return; }
  if (e.target.closest("[data-act='to-widget']")) { showWidgetMode(); return; }
  const seg = e.target.closest("[data-seg] button");
  if (seg) {
    const k = seg.parentElement.dataset.seg; UI[k] = seg.dataset.v; saveUI(); applyUI();
    $$("button", seg.parentElement).forEach((b) => b.classList.toggle("on", b === seg)); return;
  }
  const sw_ = e.target.closest("[data-accent]");
  if (sw_) { UI.accent = sw_.dataset.accent; saveUI(); applyUI(); $$("[data-accent]").forEach((b) => b.classList.toggle("on", b === sw_)); return; }
  const prev = e.target.closest("[data-prev]");
  if (prev && ["wink", "curious", "proud"].includes(prev.dataset.prev)) { if (face) { face.locked = false; face.play(prev.dataset.prev, 2400); } return; }
  if (prev) { flash(prev.dataset.prev, 2600); if (prev.dataset.prev === "speaking") S.speechUntil = Date.now() + 2600; return; }
  const fm = e.target.closest("[data-fm]");
  if (fm) {
    const pid = fm.closest("[data-p]").dataset.p, model = fm.dataset.fm;
    menuPop(fm, [
      { label: "Use for text", icon: "chat", onPick: () => selectModel(pid, model).then(renderPane) },
      { label: "Use for vision", icon: "eye", onPick: () => call("model.set", { kind: "vision", provider: pid, model }).then(() => { loadProviders(); toast(`Vision model: ${model}`, "ok"); renderPane(); }).catch(() => {}) },
      { label: "Copy name", icon: "copy", onPick: () => copyText(model) },
    ]);
    return;
  }
  const b = e.target.closest("[data-act]"); if (!b) return;
  const card = b.closest("[data-p]"), pid = card?.dataset.p, act = b.dataset.act;
  if (act === "retrypane") { renderPane(); return; }
  if (act === "eye") { const i = $("input", b.parentElement); const show = i.type === "password"; i.type = show ? "text" : "password"; b.innerHTML = ic(show ? "eye-off" : "eye"); }
  else if (act === "savekey") {
    const i = $("input[data-key]", b.closest(".row")), val = i.value.trim();
    if (!val) { toast("Paste a key first.", "info"); return; }
    if (await saveSetting(i.dataset.key, val)) { toast("Key saved", "ok"); if (pid) S.fetched[pid] = null; await Promise.all([loadProviders().catch(() => {}), loadSettingsValues().catch(() => {})]); renderPane(); }
  } else if (act === "rmkey") {
    const i = $("input[data-key]", b.closest(".row"));
    if (await confirmBox({ title: "Remove this key?", text: "Troy will stop using this provider until you add a key again.", okText: "Remove", danger: true }) && await saveSetting(i.dataset.key, "")) {
      S.fetched[pid] = null; await Promise.all([loadProviders(), loadSettingsValues()]); renderPane();
    }
  } else if (act === "prim") { await call("provider.set_primary", { provider: pid }).catch(() => {}); await loadProviders(); renderPane(); }
  else if (act === "fetch") {
    b.disabled = true;
    try { const r = await T.request("provider.fetch_models", { provider: pid }); S.fetched[pid] = { models: r.models, details: r.details || {} }; }
    catch (err) { S.fetched[pid] = { error: cleanErr(err) }; }
    const p = S.provs.find((x) => x.id === pid); card.outerHTML = provCard(p);
  } else if (act === "say") call("voice.speak", { text: "Hello, this is Troy. How do I sound?" }).catch(() => {});
  else if (act === "wake") { await toggleListening(); }
  else if (act === "vmode") {
    if (S.voiceStatus?.active || VM.active) await endVoiceMode();
    else await startVoiceMode();
    renderPane();
  }
  else if (act === "test-mic") {
    const out = $("#micTestOut");
    b.disabled = true; if (out) out.textContent = "Recording for 4 seconds — say something…";
    try {
      const r = await T.request("voice.test_mic", { seconds: 4 });
      if (r && r.ok) {
        const pct = Math.round((r.peak || 0) * 100);
        if (out) out.textContent = `Peak ${pct}%${r.silent ? " — very quiet: check the microphone" : ""}${r.heard ? ` · heard “${r.heard}”` : " · nothing understood"}`;
        if (r.silent) toast("That was almost silent — check the microphone selection above.", "bad", 6000);
      } else { if (out) out.textContent = r?.error || "Test failed"; toast(r?.error || "Test failed", "bad", 7000); }
    } catch (err) { if (out) out.textContent = cleanErr(err); toast(cleanErr(err), "bad", 7000); }
    b.disabled = false;
  }
  else if (act === "edge-voices") {
    b.disabled = true;
    try { const r = await T.request("voice.list_voices", { engine: "edge" }); S.edgeVoices = r.voices || []; }
    catch (err) { toast(`Couldn't load Edge voices: ${cleanErr(err)}`, "bad", 7000); }
    renderPane();
  }
  else if (act === "mobile") {
    try { await call(S.mobile.running ? "mobile_ui.stop" : "mobile_ui.start"); } catch { return; }
    renderPane();
  } else if (act === "copyurl") copyText(b.dataset.url || S.mobile.url);
  else if (act === "openurl") T.openExternal(b.dataset.url || S.mobile.url);
  else if (act === "regen") {
    if (await confirmBox({ title: "Make a new link?", text: "Phones using the old link will be signed out and need the new one.", okText: "Make new link" })) { await call("mobile_ui.regenerate_token").catch(() => {}); renderPane(); }
  }
  else if (act === "ts-refresh") { await call("remote.tailscale", { force: true }).catch(() => {}); renderPane(); }
  else if (act === "ts-get") T.openExternal("https://tailscale.com/download");
  else if (act === "ts-serve") {
    b.disabled = true;
    try { const r = await T.request("remote.tailscale_serve", { enable: b.dataset.enable === "1" }); toast(r.success ? r.message : r.message, r.success ? "ok" : "bad", r.success ? 3000 : 9000); }
    catch (err) { toast(cleanErr(err)); }
    renderPane();
  }
  else if (act === "enable-lm") { await saveSetting("LMSTUDIO_ENABLED", true); await loadProviders().catch(() => {}); renderPane(); }
  else if (act === "lm-refresh") { b.disabled = true; try { await T.request("provider.fetch_models", { provider: "lmstudio" }); } catch (err) { toast(cleanErr(err)); } await loadProviders().catch(() => {}); renderPane(); }
  else if (act === "app-test") {
    const name = $("#appTest").value.trim(); if (!name) { toast("Type an app name first.", "info"); return; }
    b.disabled = true;
    try { const r = await T.request("apps.test", { name }); toast(r.message, r.success ? "ok" : "bad", r.success ? 3500 : 7000); } catch (err) { toast(cleanErr(err)); }
    b.disabled = false;
  }
  else if (act === "yt-connect") {
    try { await T.request("youtube.connect", {}); S.ytWaiting = true; toast("Approve the sign-in in your browser…", "info", 5000); } catch (err) { toast(cleanErr(err), "bad", 8000); }
    renderPane();
  }
  else if (act === "yt-cancel") { await T.request("youtube.cancel", {}).catch(() => {}); S.ytWaiting = false; renderPane(); }
  else if (act === "yt-paste") {
    const url = $("#ytPaste").value.trim(); if (!url) return;
    try { await T.request("youtube.complete", { url }); S.ytWaiting = false; S.yt = { ...S.yt, connected: true }; } catch (err) { toast(cleanErr(err), "bad", 8000); }
    renderPane();
  }
  else if (act === "yt-disconnect") {
    if (await confirmBox({ title: "Disconnect YouTube?", text: "Troy will forget the sign-in. You can connect again any time.", okText: "Disconnect", danger: true })) { await call("youtube.disconnect").catch(() => {}); renderPane(); }
  }
  else if (act === "yt-test") {
    const box = $("#ytTest"); box.innerHTML = '<div class="skeleton"><i style="height:54px"></i></div>';
    try {
      const r = await T.request("youtube.test", {}), v = r.video;
      box.innerHTML = `<div class="urlrow rec" style="margin-top:10px"><div class="u"><b>${esc(v.title)}</b><small>${esc(v.channel)} · most recently added to ${esc(v.playlist)} (${esc(String(v.added_at).slice(0, 10))})</small><code>${esc(v.url)}</code></div><button class="btn sm pri" data-act="yt-open" data-url="${esc(v.url)}">Open in browser</button></div>`;
    } catch (err) { box.innerHTML = `<p style="color:var(--bad);margin-top:8px;font-size:13px">${esc(cleanErr(err))}</p>`; }
  }
  else if (act === "yt-open") { const r = await call("browser.open", { url: b.dataset.url }).catch(() => null); if (r) toast(r.message, r.success ? "ok" : "bad"); }
  else if (act === "restart") restartBackend();
  else if (act === "reload") shell("reload");
  else if (act === "quit") shell("quit");
}

/* ============================================================== palette */
function paletteItems(q) {
  const v = S.settings?.values || {};
  const th = resolvedTheme();
  const base = [
    { label: "New chat", hint: "Ctrl N", icon: "plus", run: newChat },
    { label: "Go to Chat", hint: "Ctrl 1", icon: "chat", run: () => setView("chat") },
    { label: "Go to Memory", hint: "Ctrl 2", icon: "memory", run: () => setView("memory") },
    { label: "Go to Tools", hint: "Ctrl 3", icon: "tools", run: () => setView("tools") },
    { label: "Go to Logs", hint: "Ctrl 4", icon: "logs", run: () => setView("logs") },
    { label: "Go to Tasks (scheduled)", hint: "Ctrl 6", icon: "tasks", run: () => setView("tasks") },
    { label: "New scheduled task…", icon: "tasks", run: () => { setView("tasks"); taskForm(); } },
    { label: "Open Settings", hint: "Ctrl ,", icon: "settings", run: () => openSettings() },
    { label: "Settings: Providers & API keys", icon: "key", run: () => openSettings("providers") },
    { label: "Settings: Models", icon: "cpu", run: () => openSettings("models") },
    { label: "Settings: Voice", icon: "volume", run: () => openSettings("voice") },
    { label: "Settings: Appearance & avatar", icon: "sparkles", run: () => openSettings("appearance") },
    { label: "Settings: Phone web page", icon: "phone", run: () => openSettings("remote") },
    { label: "Settings: Widget", icon: "window", run: () => openSettings("widget") },
    { label: "Settings: Power saving", icon: "battery", run: () => openSettings("power") },
    { label: S.power.mode === "on" ? "Power saving: turn off" : "Power saving: turn on", icon: "battery", run: () => saveSetting("POWER_SAVING", S.power.mode === "on" ? "off" : "on").then(refreshPower) },
    { label: "Choose model…", icon: "cpu", run: () => setTimeout(openModelPicker, 30) },
    { label: "Layout: Avatar + chat", icon: "layout", run: () => setMode("split") },
    { label: "Layout: Avatar focus", icon: "focus", run: () => setMode("focus") },
    { label: "Layout: Chat only", icon: "chat", run: () => setMode("chat") },
    { label: "Toggle sidebar", hint: "Ctrl B", icon: "panel", run: toggleSidebar },
    { label: th === "light" ? "Switch to dark theme" : "Switch to light theme", icon: th === "light" ? "moon" : "sun", run: toggleTheme },
    { label: "Stop current task", hint: "Ctrl .", icon: "stop", run: stopTurn },
    { label: "Refresh what Troy can see", icon: "refresh", run: () => refreshCtx(true) },
    { label: "Export chat as Markdown", icon: "download", run: exportChat },
    { label: "Find in this chat", hint: "Ctrl F", icon: "search", run: () => { setView("chat"); openFind(null); } },
    { label: "Search all chats", hint: "Ctrl Shift F", icon: "search", run: () => { if (!UI.sidebar) toggleSidebar(); els.sessQ.focus(); } },
    { label: "Settings: Speed & context size", icon: "bolt", run: () => openSettings("performance") },
    { label: "Settings: Integrations (YouTube)", icon: "link", run: () => openSettings("integrations") },
    { label: v.VOICE_OUTPUT_ENABLED ? "Mute voice replies" : "Speak replies aloud", icon: v.VOICE_OUTPUT_ENABLED ? "volume-off" : "volume", run: toggleSpeak },
    { label: VM.active ? "End voice mode" : "Start voice mode (hands-free)", hint: "Ctrl Shift V", icon: "mic", run: () => (VM.active ? endVoiceMode() : startVoiceMode()) },
    { label: VM.muted ? "Unmute the microphone" : "Mute the microphone", icon: VM.muted ? "volume" : "volume-off", run: () => setVoiceMuted(!VM.muted) },
    { label: S.wake.running ? "Stop listening" : "Start listening (wake word)", icon: "mic", run: toggleListening },
    { label: "Restart backend", icon: "power", run: restartBackend },
    { label: "Switch to the widget", hint: fmtHotkey(S.widget.hotkey), icon: "window", run: showWidgetMode },
  ];
  const words = q.toLowerCase().split(/\s+/).filter(Boolean);
  const match = (it) => words.every((w) => `${it.label} ${it.hint || ""}`.toLowerCase().includes(w));
  let out;
  if (!words.length) out = base.slice(0, 14);
  else {
    const models = [];
    for (const p of S.provs.filter((x) => x.configured)) for (const m of p.models.text) models.push({ label: `Use ${m}`, hint: p.label, icon: "cpu", run: () => selectModel(p.id, m) });
    out = base.concat(models).filter(match).slice(0, 30);
    out.unshift({ label: `Search chats for “${q}”`, icon: "search", run: () => { if (!UI.sidebar) toggleSidebar(); els.sessQ.value = q; S.sessQ = q; renderSessions(); searchDebounced(); els.sessQ.focus(); } });
    out.push({ label: `Ask Troy: ${q}`, icon: "send", run: () => { setView("chat"); sendMessage(q); } });
  }
  return out;
}

function toggleSidebar() { UI.sidebar = !UI.sidebar; saveUI(); applyUI(); }
function toggleTheme() { UI.theme = resolvedTheme() === "light" ? "dark" : "light"; saveUI(); applyUI(); if (S.view === "settings" && S.pane === "appearance") renderPane(); }
const fmtHotkey = (h) => String(h || "Ctrl+Alt+T").replace(/CommandOrControl|CmdOrCtrl/g, T.platform === "darwin" ? "Cmd" : "Ctrl").replace(/\bControl\b/g, "Ctrl");
async function syncWidget() {
  try { S.widget = (await T.widget("getInfo")) || S.widget; S.mode = S.widget.mode || S.mode; } catch { /* old shell */ }
  return S.widget;
}
async function setWidgetOption(key, value) {
  try { const r = await T.widget("setOption", { key, value }); S.widget = { ...S.widget, ...r }; return r; }
  catch (e) { toast(cleanErr(e)); return null; }
}
const showWidgetMode = () => T.widget("show").catch(() => {});      // the shell hides this window and shows the widget
async function refreshPower() {
  try { S.power = await T.request("power.status", {}); } catch { /* optional */ }
  applyUI();
  return S.power;
}
function applyCommand(cmd) {                                          // Troy's own tools (troy/tools_app.py)
  if (!cmd) return;
  if (cmd.action === "new_chat") { S.sid = null; S.title = "New chat"; S.log = []; renderEmpty(); updateTitle(); loadSessions(); setCaption(""); }
  else if (cmd.action === "view") { if (cmd.view === "settings") openSettings(cmd.pane || undefined); else setView(cmd.view); }
  else if (cmd.action === "appearance") {
    if (cmd.key === "theme") UI.theme = cmd.value;
    else if (cmd.key === "accent") UI.accent = cmd.value;
    else if (cmd.key === "layout") UI.mode = cmd.value;
    saveUI(); applyUI();
    if (S.view === "settings" && S.pane === "appearance") renderPane();
  }
}

/* ============================================================== banners */
function showBanner(text, btn, handler) {
  S.banner = handler; els.bannerText.textContent = text;
  els.bannerBtn.textContent = btn || "";
  els.bannerBtn.classList.toggle("hidden", !btn);
  els.banner.classList.remove("hidden");
}
function hideBanner() { S.banner = null; els.banner.classList.add("hidden"); }

function setBackend(up, info) {
  S.backendUp = up;
  els.beDot.dataset.s = up ? "idle" : "offline";
  els.beText.textContent = up ? `Backend ready${info?.version ? ` · ${info.version}` : ""}` : "Backend offline";
}

/* ================================================================ events */
function wireEvents() {
  T.on("app.ready", (d) => { setBackend(true, d); });
  T.on("agent.state", (d) => setAgentState(d.state, d.detail || ""));
  T.on("chat.user_message", (d) => {
    if (d.source === "typed") return;                        // already drawn by sendMessage()
    addMsg("user", d.text, { src: d.source });
    S.log.push({ role: "user", text: d.text });
    if (!S.sid) loadSessions();
  });
  T.on("chat.turn_started", () => { if (!S.busy) { setBusy(true); } });
  T.on("agent.speak", (d) => {
    const err = looksLikeError(d.text) || /^\(Troy couldn't/.test(d.text);
    addMsg("assistant", d.text, { error: err });
    S.log.push({ role: "assistant", text: d.text });
    setCaption(d.text, UI.mode === "focus");
    S.speechUntil = Date.now() + clamp(String(d.text).length * 60, 1400, 14000);
    applyAvatar();
  });
  T.on("agent.tool_result", (d) => { addStep(d); S.log.push({ role: "tool", ...d }); });
  T.on("agent.error", (d) => { addMsg("assistant", `\u26A0 ${d.message}`, { error: true }); flash("error", 2800); setCaption(d.message, true); });
  T.on("chat.turn_complete", (d) => {
    if (d && d.pending > 0) return;
    setBusy(false);
    if (S.state !== "error") flash("done", 1400);
    loadSessions(); refreshCtx();
    setTimeout(() => { if (!S.busy && (S.state === "error" || S.state === "stopped")) setAgentState("idle"); }, 3500);
  });
  T.on("confirmation.request", confCard);
  T.on("task.changed", (d) => d.task && upsertTask(d.task));
  T.on("task.deleted", (d) => { S.tasks = S.tasks.filter((t) => t.id !== d.id); renderTasks(); });
  T.on("task.step", (d) => { S.taskStep[d.id] = `${d.name}${d.arg ? `: ${String(d.arg).slice(0, 60)}` : ""} ${d.success ? "✓" : "✗"}`; if (S.view === "tasks") renderTasks(); });
  T.on("task.started", (d) => { if (d.task) { S.taskStep[d.task.id] = "starting…"; upsertTask(d.task); } toast(`Running task: ${d.task?.title || ""}`, "info", 2600); });
  T.on("task.retrying", (d) => toast(`Task “${d.task?.title}” failed (${d.error || "error"}), trying again soon.`, "info", 5200));
  T.on("task.finished", (d) => {
    toast(d.text, d.ok ? "ok" : "bad", 9000);
    if (d.in_current_chat && d.entry) { addTaskNote(d.entry); S.log.push(d.entry); }
    if (d.task) { upsertTask(d.task); }
    loadSessions();
  });
  T.on("confirmation.resolved", (d) => document.getElementById(`conf-${d.id}`)?.remove());
  /* ---- full voice mode (troy/voice_mode.py) ---- */
  T.on("voice.state", (d) => {
    VM.active = !!d.active;
    VM.state = d.state || "off";
    VM.muted = !!d.muted;
    if (VM.state === "off" && VM.open) hideVoiceOverlay();
    setVoiceUI();
    if (S.view === "settings" && S.pane === "voice" && !els.setPane.contains(document.activeElement) && !VM.active) renderPane();
  });
  T.on("voice.level", (d) => {
    if (!VM.open && d.state !== "test") return;
    const pct = Math.min(1, Math.sqrt(Math.max(0, Number(d.level) || 0) / 240000));
    const bar = $("i", els.vLevel);
    if (bar) bar.style.width = `${Math.round(pct * 100)}%`;
    const testBar = $("#micTestBar i");
    if (testBar) testBar.style.width = `${Math.round(pct * 100)}%`;
  });
  T.on("voice.transcript", (d) => { if (VM.open) addVTranscript("you", d.text, { pc: d.source !== "phone" }); });
  T.on("voice.ended", (d) => {
    VM.active = false; VM.state = "off";
    hideVoiceOverlay(); setVoiceUI();
    if (d?.reason === "goodbye") toast("Voice mode ended — you said “goodbye”", "info", 2600);
  });
  T.on("voice.phone", (d) => {
    if (d?.active) toast("A phone just joined as Troy's headset.", "info", 3000);
    if (S.view === "settings" && S.pane === "remote") renderPane();
  });
  T.on("model.changed", (d) => {
    loadProviders().catch(() => {});
    updateModelLabel();
    if (d?.by === "troy") {
      const [pid, model] = String(d.text || "").split(/:(.+)/);
      toast(`Troy switched its own brain: ${model ? `${providerLabel(pid)} · ${model}` : "automatic model choice"}`, "info", 5200);
    }
  });
  T.on("wake_listener.state", (d) => {
    S.wake.state = d.state; S.wake.running = true; updateQuick(); applyAvatar();
    if (S.view === "settings" && S.pane === "voice" && !els.setPane.contains(document.activeElement)) renderPane();
  });
  let settingsTimer = null;
  T.on("settings.changed", () => {
    clearTimeout(settingsTimer);
    settingsTimer = setTimeout(() => {
      loadProviders().catch(() => {});
      if (Date.now() < S.muteSettingsEvent) return;         // our own change: the pane is already up to date
      if (S.view === "settings" && !els.setPane.contains(document.activeElement)) renderPane();
    }, 250);
  });
  T.on("mobile_ui.started", (d) => { S.mobile = { ...S.mobile, running: true, url: d.url }; });
  T.on("mobile_ui.viewers", (d) => {
    els.viewerChip.classList.toggle("hidden", !d.count);
    $("span", els.viewerChip).textContent = d.count > 1 ? `${d.count} phones watching` : "Phone watching";
    if (d.count && !S.viewerToasted) { S.viewerToasted = true; toast("A phone is watching your screen.", "info", 3500); }
    if (!d.count) S.viewerToasted = false;
    if (S.view === "settings" && S.pane === "remote" && !els.setPane.contains(document.activeElement)) renderPane();
  });
  T.on("youtube.connected", (d) => {
    const already = S.yt?.connected && !S.ytWaiting;               // the pane already shows it: don't redraw over the user
    S.ytWaiting = false; toast(`YouTube connected${d?.channel?.title ? ` as ${d.channel.title}` : ""}`, "ok");
    if (!already && S.view === "settings" && S.pane === "integrations") renderPane();
  });
  T.on("youtube.error", (d) => { S.ytWaiting = false; toast(d.message, "bad", 9000); if (S.view === "settings" && S.pane === "integrations") renderPane(); });
  T.on("youtube.disconnected", () => { if (S.view === "settings" && S.pane === "integrations") renderPane(); });
  T.on("backend.stderr", (d) => {
    for (const l of String(d.text).split("\n")) if (l.trim()) S.consoleLines.push(l);
    if (S.consoleLines.length > 600) S.consoleLines.splice(0, S.consoleLines.length - 600);
    if (S.view === "logs" && S.logSrc === "console") loadLogs();
  });
  T.on("backend.exited", (d) => {
    setBackend(false); setAgentState("offline"); setBusy(false); hideTyping();
    showBanner(`The Python backend stopped${d?.code != null ? ` (exit code ${d.code})` : ""}. Check Logs, then restart it.`, "Restart backend", restartBackend);
  });
  T.on("backend.error", (d) => { setBackend(false); setAgentState("offline"); showBanner(d.message, "Retry", restartBackend); });
  T.on("backend.restarted", () => { hydrate(); });
  T.on("window.shown", () => refreshCtx());
  T.on("ui.command", applyCommand);
  T.on("face.event", (d) => { if (d && d.origin !== FACE_ID && face) face.applyRemote(d); });
  /* the phone opened / renamed / deleted a chat, or started a new one: follow it */
  T.on("session.changed", (d) => {
    if (!d) return;
    if (d.by === "phone" && d.action === "loaded" && d.id && d.id !== S.sid && !S.busy) openSession(d.id);
    else if (d.by === "phone" && d.action === "reset" && !S.busy) applyCommand({ action: "new_chat" });
    else if (d.action === "deleted" && d.was_current && d.by === "phone") applyCommand({ action: "new_chat" });
    else loadSessions();
  });
  T.on("ui.mode", (d) => { S.mode = d.mode; if (d.mode === "app" && S.view === "chat") setTimeout(() => els.inp.focus(), 120); });
  T.on("widget.options", (d) => { S.widget = d; if (S.view === "settings" && S.pane === "widget" && !els.setPane.contains(document.activeElement)) renderPane(); });
  T.on("power.state", (d) => { S.power = d; applyUI(); if (S.view === "settings" && S.pane === "power") renderPane(); });
}

/* ================================================================= boot */
async function waitForBackend() {
  for (let i = 0; i < 160; i++) {
    try { return await T.request("app.ping", {}); }
    catch { if (i === 12) els.beText.textContent = "Still starting…"; await sleep(500); }
  }
  throw new Error("The backend didn't start in time.");
}

async function hydrate() {
  try {
    const ping = await waitForBackend();
    setBackend(true, ping); hideBanner(); setAgentState("idle");
    const [status] = await Promise.all([
      T.request("agent.status", {}).catch(() => ({})),
      loadProviders().catch(() => {}), loadSettingsValues().catch(() => {}), loadSessions(), loadMemory(),
    ]);
    try { S.wake = await T.request("wake_listener.status", {}); } catch { /* optional */ }
    await Promise.all([refreshPower(), syncWidget()]);
    try {
      const vs = await T.request("voice.mode_status", {});
      VM.active = !!vs.active; VM.state = vs.state || "off"; VM.muted = !!vs.muted;
      setVoiceUI();
      if (VM.active) showVoiceOverlay();          // a reload mid-conversation keeps the panel up
    } catch { /* optional */ }
    updateQuick();
    loadTasks();
    if (status.session_id && !status.busy) {
      try { const r = await T.request("session.load", { id: status.session_id }); S.sid = status.session_id; renderLog(r.display_log || []); S.log = (r.display_log || []).slice(); }
      catch { renderEmpty(); }
    } else renderEmpty();
    if (status.busy) { setBusy(true); }
    updateTitle();
    try { (await T.request("confirmation.list", {})).pending.forEach(confCard); } catch { /* optional */ }
    refreshCtx();
    if (!S.providersChecked) {
      S.providersChecked = true;
      if (!S.provs.some((p) => p.configured)) {
        showBanner("Add an API key to give Troy a brain.", "Open settings", () => { hideBanner(); openSettings("providers"); });
      }
    }
  } catch (e) {
    setBackend(false); setAgentState("offline");
    showBanner(cleanErr(e), "Retry", restartBackend);
  }
}

function bindUI() {
  els.sbToggle.onclick = toggleSidebar;
  els.themeBtn.onclick = toggleTheme;
  els.cmdBtn.onclick = () => openPalette(paletteItems);
  els.widgetBtn.onclick = showWidgetMode;
  els.modelBtn.onclick = openModelPicker;
  els.sessionTitle.onclick = renameCurrent;
  els.bannerBtn.onclick = () => S.banner && S.banner();
  $$("#nav button").forEach((b) => { b.onclick = () => setView(b.dataset.view); });
  $$("#modeSeg button").forEach((b) => { b.onclick = () => setMode(b.dataset.mode); });
  els.focusBtn.onclick = () => setMode(UI.mode === "focus" ? "split" : "focus");
  els.newChat.onclick = newChat;
  els.sessQ.oninput = (e) => { S.sessQ = e.target.value; renderSessions(); searchDebounced(); };
  els.sessions.onclick = sessionClick;
  els.sessQ.onkeydown = (e) => { if (e.key === "Escape") { els.sessQ.value = ""; S.sessQ = ""; S.search = null; renderSessions(); els.inp.focus(); } };
  els.micBtn.onclick = toggleListening;
  els.speakBtn.onclick = toggleSpeak;
  els.ctxBtn.onclick = () => refreshCtx(true);
  els.stopBtn.onclick = stopTurn;
  els.sendBtn.onclick = () => sendMessage();
  els.jump.onclick = () => scrollBottom(true);
  els.voiceModeBtn.onclick = toggleVoiceMode;
  els.vEndBtn.onclick = () => endVoiceMode();
  els.vMuteBtn.onclick = () => setVoiceMuted(!VM.muted);
  els.vStopBtn.onclick = async () => { try { await T.request("voice.interrupt", {}); toast("Stopped", "info", 1400); } catch (e) { toast(cleanErr(e)); } };
  els.messages.addEventListener("scroll", () => { if (nearBottom()) S.unseen = 0; updateJump(); });

  els.inp.addEventListener("input", () => { autosize(); slashSel = 0; updateSlash(); });
  els.inp.addEventListener("keydown", (e) => {
    const open = !els.slash.classList.contains("hidden");
    if (open && (e.key === "ArrowDown" || e.key === "ArrowUp")) {
      e.preventDefault();
      slashSel = (slashSel + (e.key === "ArrowDown" ? 1 : -1) + slashShown.length) % slashShown.length; updateSlash(); return;
    }
    if (open && (e.key === "Tab" || (e.key === "Enter" && !e.shiftKey))) { e.preventDefault(); runSlash(slashShown[slashSel]); return; }
    if (open && e.key === "Escape") { els.slash.classList.add("hidden"); return; }
    if (e.key === "Enter" && !e.shiftKey && !e.isComposing) { e.preventDefault(); sendMessage(); return; }
    if (e.key === "ArrowUp" && !els.inp.value && S.lastUser) { e.preventDefault(); els.inp.value = S.lastUser; autosize(); }
  });
  els.slash.addEventListener("click", (e) => { const r = e.target.closest(".it"); if (r) runSlash(slashShown[+r.dataset.i]); });

  // delegated clicks inside the transcript
  els.messages.addEventListener("click", (e) => {
    const a = e.target.closest("a[data-href]");
    if (a) { e.preventDefault(); T.openExternal(a.dataset.href); return; }
    const cm = e.target.closest("[data-copy-msg]");
    if (cm) { copyText(cm.closest(".msg")._raw); return; }
    const cp = e.target.closest("[data-copy]");
    if (cp) { copyText($("code", cp.closest("pre")).textContent); return; }
    const sg = e.target.closest("[data-sugg]");
    if (sg) sendMessage(SUGGESTIONS[+sg.dataset.sugg].p);
  });

  // memory
  els.memAdd.onclick = async () => { const v = els.memIn.value.trim(); if (!v) return; els.memIn.value = ""; await remember(v); };
  els.memIn.onkeydown = (e) => { if (e.key === "Enter") els.memAdd.click(); };
  els.memQ.oninput = (e) => { S.memQ = e.target.value; loadMemory(); };
  els.memList.onclick = async (e) => {
    const b = e.target.closest("[data-del]"); if (!b) return;
    await call("memory.delete", { index: +b.dataset.del }).catch(() => {}); loadMemory();
  };
  els.memClear.onclick = async () => {
    if (!S.memories.length) { toast("Memory is already empty.", "info"); return; }
    if (await confirmBox({ title: "Forget everything?", text: `Troy will lose all ${S.memories.length} remembered facts. This can't be undone.`, okText: "Forget all", danger: true })) {
      await call("memory.clear").catch(() => {}); loadMemory();
    }
  };

  // tasks
  els.taskNew.onclick = () => taskForm();
  els.taskQ.oninput = (e) => { S.taskQ = e.target.value; renderTasks(); };
  els.taskFilter.onclick = (e) => { const b = e.target.closest("[data-v]"); if (b) { S.taskFilter = b.dataset.v; renderTasks(); } };
  els.taskClear.onclick = async () => {
    if (await confirmBox({ title: "Clear finished tasks?", text: "Done, failed, missed and cancelled tasks are removed from the list.", okText: "Clear", danger: true })) { await call("tasks.clear_finished").catch(() => {}); loadTasks(); }
  };
  els.taskOn.onclick = async () => { await saveSetting("TASKS_ENABLED", true); loadTasks(); };
  els.taskList.onclick = taskAction;
  els.messages.addEventListener("click", (e) => { const b = e.target.closest("[data-task-open]"); if (b) { setView("tasks"); setTimeout(() => flashTask(b.dataset.taskOpen), 60); } });

  // tools
  els.toolQ.oninput = (e) => { S.toolQ = e.target.value; loadTools(); };
  els.toolCats.onclick = (e) => { const c = e.target.closest("[data-cat]"); if (c) { S.toolCat = c.dataset.cat; loadTools(); } };
  els.toolList.onclick = (e) => {
    const b = e.target.closest("[data-try]"); if (!b) return;
    setView("chat"); els.inp.value = `Use the ${b.dataset.try} tool to `; autosize(); els.inp.focus();
  };

  // logs
  $$("#logSrc button").forEach((b) => { b.onclick = () => { S.logSrc = b.dataset.v; $$("#logSrc button").forEach((x) => x.classList.toggle("on", x === b)); loadLogs(); }; });
  $$("#logLvl button").forEach((b) => { b.onclick = () => { S.logLvl = b.dataset.v; $$("#logLvl button").forEach((x) => x.classList.toggle("on", x === b)); loadLogs(); }; });
  els.logQ.oninput = (e) => { S.logQ = e.target.value; loadLogs(); };
  els.logRef.onclick = loadLogs;
  els.logCopy.onclick = () => copyText(els.logOut.innerText);

  // settings
  els.setNav.onclick = (e) => { const b = e.target.closest("[data-pane]"); if (b) { S.pane = b.dataset.pane; renderPane(); } };
  els.setPane.addEventListener("change", paneChange);
  els.setPane.addEventListener("input", paneInput);
  els.setPane.addEventListener("click", paneClick);

  // global links
  document.addEventListener("click", (e) => {
    const a = e.target.closest("a[data-href]");
    if (a && !els.messages.contains(a) && !els.setPane.contains(a)) { e.preventDefault(); T.openExternal(a.dataset.href); }
    const cp = e.target.closest(".pre-copy"); void cp;
  });
  // let a link/file dropped on the window do nothing instead of navigating away
  addEventListener("dragover", (e) => e.preventDefault());
  addEventListener("drop", (e) => e.preventDefault());

  // find in chat
  $("#findIn").addEventListener("input", (e) => markAll(e.target.value));
  $("#findIn").addEventListener("keydown", (e) => { if (e.key === "Enter") { e.preventDefault(); stepFind(e.shiftKey ? -1 : 1); } if (e.key === "Escape") closeFind(); });
  $("#findNext").onclick = () => stepFind(1); $("#findPrev").onclick = () => stepFind(-1); $("#findClose").onclick = closeFind;
  els.viewerChip.onclick = () => openSettings("remote");

  // keyboard shortcuts
  addEventListener("keydown", (e) => {
    const mod = e.ctrlKey || e.metaKey;
    if (e.key === "Escape" && VM.open && !document.querySelector(".palette, .modal, .pop")) { hideVoiceOverlay(); return; }
    if (!mod) return;
    const k = e.key.toLowerCase();
    if (k === "v" && e.shiftKey) { e.preventDefault(); toggleVoiceMode(); return; }
    if (k === "f" && e.shiftKey) { e.preventDefault(); if (!UI.sidebar) toggleSidebar(); els.sessQ.focus(); els.sessQ.select(); return; }
    if (k === "f") { e.preventDefault(); if (S.view !== "chat") setView("chat"); openFind(null); return; }
    if (k === "k") { e.preventDefault(); openPalette(paletteItems); }
    else if (k === "n") { e.preventDefault(); newChat(); }
    else if (k === ",") { e.preventDefault(); openSettings(); }
    else if (k === "b") { e.preventDefault(); toggleSidebar(); }
    else if (k === ".") { e.preventDefault(); stopTurn(); }
    else if (k === "l") { e.preventDefault(); setView("chat"); els.inp.focus(); }
    else if (/^[1-6]$/.test(k)) { e.preventDefault(); setView(SHORTCUT_VIEWS[+k - 1]); }
  });

  // slow background refresh of "what Troy can see"
  ctxTimer = setInterval(() => { if (S.view === "chat" && !S.busy && S.backendUp && !document.hidden) refreshCtx(); }, 45000);
  setInterval(applyAvatar, 250);                         // expires flash / speaking timers
}

async function main() {
  platformClass();
  applyUI();
  mountFace();
  bindUI();
  wireEvents();
  syncWidget();
  renderEmpty();
  setAgentState("starting");
  await hydrate();
  applyAvatar();
  window.__troyReady = true;
}
main();
})();
