/* Nova -- Troy's animated face.
 *
 * A canvas-drawn face driven by a handful of springs. Slightly underdamped
 * springs are what make it feel soft and alive: eyes overshoot a little, the
 * body squashes when it hops, blinks snap shut and ease open.
 *
 *   const face = NovaFace.mount(canvas, { onTint: (r, g, b) => {} });
 *   face.setState("thinking");
 *   face.setOptions({ scale: 1.1, gap: 130, tracking: true, sound: false, sleep: true, saver: false });
 *   face.setLevel(0.6);     // 0..1 live voice level: rings, mouth and glow follow it
 *   face.play("wink");      // a short expression on top of the current state
 *   face.poke();            // happy hop; click again for a wink
 *   face.locked = true;     // set by the app while Troy is working
 *   face.setSync({ now: () => serverMs, send: (evt) => {}, id: "phone-1" });
 *                           // keep several faces (PC app, widget, phone) in step: blinks, glances and idle
 *                           // expressions follow a shared clock instead of random numbers, and pokes / wake-ups
 *                           // are passed on with send() and replayed elsewhere with face.applyRemote(evt)
 *
 * States (what Troy is doing): idle, listening, thinking, executing, speaking,
 *   done, error, surprised, sleeping.
 * Expressions (play() them, or let idle do it): wink, curious, proud.
 *
 * What's new in this version
 *  - eyebrows that carry the mood (raised, worried, focused, one-sided)
 *  - eyes with depth: a soft gradient and a glint instead of a flat pill
 *  - sparkle bursts, thinking dots, sound rings that
 *    follow the voice level, an "executing" scanner with HUD brackets
 *  - head tilt, a smirk and a mouth that changes width
 *  - idle personality: every now and then it winks, tilts its head, or gets curious
 *  - power saving: options.saver caps the frame rate, drops the glow and the particles
 */
(function () {
  "use strict";

  /* ---------- spring helper ---------- */
  const spring = (x, k = 170, d = 15) => ({ x, v: 0, t: x, k, d });
  const step = (s, dt) => { s.v += (s.k * (s.t - s.x) - s.d * s.v) * dt; s.x += s.v * dt; };
  const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
  const hex = (h) => [1, 3, 5].map((i) => parseInt(h.substr(i, 2), 16));
  const mixWhite = (rgb, k) => rgb.map((v) => Math.round(v + (255 - v) * k));

  /* ---------- state presets: targets for the springs ---------- */
  const BASE = {
    ew: 56, ehL: 80, ehR: 80, lidL: 0, lidR: 0, tiltL: 0, tiltR: 0,
    happyL: 0, happyR: 0,
    smile: 0.55, open: 0, blush: 0.35, mouthW: 13, skew: 0,
    brow: 0, browY: 0, browTilt: 0, browAsym: 0,
    roll: 0,
  };
  const HAPPY = { happyL: 1, happyR: 1 };
  const STATES = {
    idle:      { ...BASE, col: "#e6f3ff", hint: "Relaxed. Breathes, blinks and glances around." },
    listening: { ...BASE, ew: 60, ehL: 92, ehR: 92, tiltL: -0.05, tiltR: 0.05, smile: 0.25, open: 0.12, blush: 0.2, brow: 0.55, browY: -6, col: "#bff6ff", hint: "Listening." },
    thinking:  { ...BASE, ew: 52, ehL: 66, ehR: 86, tiltL: 0.12, tiltR: -0.05, smile: -0.05, blush: 0.1, brow: 1, browY: -3, browAsym: 9, browTilt: 0.12, skew: -0.7, mouthW: 10, roll: -0.045, col: "#ffe3a3", hint: "Working it out." },
    speaking:  { ...BASE, smile: 0.4, blush: 0.45, col: "#c9e8ff", hint: "Talking." },
    executing: { ...BASE, ew: 64, ehL: 54, ehR: 54, lidL: 0.2, lidR: 0.2, smile: 0, blush: 0, brow: 1, browY: 9, browTilt: 0.2, mouthW: 9, col: "#d9ccff", hint: "Busy doing something." },
    done:      { ...BASE, ...HAPPY, smile: 1, blush: 0.85, brow: 0.6, browY: -8, mouthW: 16, col: "#ffcfe3", hint: "Finished." },
    error:     { ...BASE, ew: 54, ehL: 64, ehR: 64, lidL: 0.3, lidR: 0.3, tiltL: -0.2, tiltR: 0.2, smile: -0.9, blush: 0, brow: 1, browY: -3, browTilt: -0.32, mouthW: 12, col: "#ffb4b4", hint: "Something went wrong." },
    sleeping:  { ...BASE, ew: 54, ehL: 7, ehR: 7, tiltL: 0.05, tiltR: -0.05, smile: 0.2, blush: 0.25, roll: 0.04, col: "#aab6ff", hint: "Asleep. Move the mouse to wake." },
    surprised: { ...BASE, ew: 62, ehL: 100, ehR: 100, smile: 0, open: 0.9, blush: 0.2, brow: 1, browY: -15, mouthW: 8, col: "#ffffff", hint: "Oh!" },
    // expressions (shown for a moment by play(), or by idle's own personality)
    wink:      { ...BASE, happyR: 1, ehL: 86, smile: 0.95, blush: 0.7, roll: 0.05, mouthW: 16, skew: 0.5, col: "#fff1c9", hint: "Wink." },
    curious:   { ...BASE, ew: 58, ehL: 98, ehR: 68, tiltL: -0.04, tiltR: 0.08, smile: 0.1, open: 0.26, blush: 0.2, brow: 1, browY: -7, browAsym: -12, mouthW: 7, roll: 0.13, col: "#c8f0ff", hint: "Hmm?" },
    proud:     { ...BASE, ...HAPPY, smile: 1, blush: 0.9, brow: 0.7, browY: -9, mouthW: 17, roll: -0.04, col: "#ffe9a3", hint: "Nailed it." },
  };
  const EXPRESSIONS = { wink: 950, curious: 1700, proud: 1600 };

  /* ---------- a shared, deterministic "randomness" so every face does the same thing at the same time ---------- */
  function hash32(n) {
    n = Math.imul((n | 0) ^ ((n | 0) >>> 16), 0x45d9f3b);
    n = Math.imul(n ^ (n >>> 16), 0x45d9f3b);
    return ((n ^ (n >>> 16)) >>> 0);
  }
  const unit = (n) => (hash32(n) % 10000) / 10000;          // 0..1

  /* ---------- optional, very soft sound effects ---------- */
  function makeAudio() {
    let ctx = null;
    return {
      on: false,
      blip(f1, f2, dur = 0.12, vol = 0.03, type = "sine", delay = 0) {
        if (!this.on) return;
        try {
          ctx = ctx || new (window.AudioContext || window.webkitAudioContext)();
          if (ctx.state === "suspended") ctx.resume();
          const t = ctx.currentTime + delay, o = ctx.createOscillator(), g = ctx.createGain();
          o.type = type; o.connect(g); g.connect(ctx.destination);
          o.frequency.setValueAtTime(f1, t); o.frequency.exponentialRampToValueAtTime(f2, t + dur);
          g.gain.setValueAtTime(vol, t); g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
          o.start(t); o.stop(t + dur);
        } catch { /* audio is a nicety; never let it break the face */ }
      },
      state(s) {
        if (s === "thinking") this.blip(440, 580, 0.12);
        if (s === "done" || s === "proud") { this.blip(660, 660, 0.3, 0.035); this.blip(880, 880, 0.35, 0.035, "sine", 0.09); }
        if (s === "surprised") this.blip(280, 860, 0.2, 0.05, "triangle");
        if (s === "error") this.blip(300, 190, 0.3, 0.04, "triangle");
        if (s === "sleeping") this.blip(200, 120, 0.45, 0.02);
        if (s === "wink") this.blip(900, 1300, 0.08, 0.025);
      },
    };
  }

  /* ---------- the face ---------- */
  class Face {
    constructor(canvas, opts = {}) {
      this.cv = canvas;
      this.ctx = canvas.getContext("2d");
      this.noDraw = !this.ctx;            // headless/test environments have no canvas
      this.options = { scale: 1, gap: 130, tracking: true, sound: false, sleep: true, light: false, saver: false, fps: 0 };
      this.onTint = opts.onTint || null;
      this.onStateChange = null;
      this.audio = makeAudio();
      this.locked = false;               // true while the assistant is busy: poke/sleep/flourishes are suppressed
      this.requested = "idle";           // what the app asked for (internal sleep / expressions never change it)
      this.state = "idle";               // what is shown right now
      this.fx = null;                    // active expression {name, until}
      this.time = 0;
      this.lastActive = performance.now();
      this.pointer = { x: 0, y: 0, seen: 0 };
      this.nextBlink = 2; this.nextGlance = 2; this.scanAt = 0;
      this.nextFlourish = 9 + Math.random() * 8;
      this.glance = null; this.gTarget = { x: 0, y: 0 };
      this.wakeTimer = null; this.tintAt = 0;
      this.pokes = []; this.parts = [];
      this.sync = null; this._blinkSlot = -1; this._flourishSlot = -1e9; this._glanceSlot = -1; this._scanSlot = -1;
      this.level = 0; this.levelAt = 0; this.lv = 0;      // raw / smoothed voice level
      this.shake = 0;
      this.W = 0; this.H = 0;
      this.running = true;

      const soft = [170, 15], snappy = [420, 26], gaze = [120, 17], blinkK = [1100, 52];
      this.p = {};
      for (const k in BASE) this.p[k] = spring(BASE[k], ...soft);
      this.p.gx = spring(0, ...gaze); this.p.gy = spring(0, ...gaze);
      this.p.bob = spring(0, 150, 9);        // hop: bouncy
      this.p.sq = spring(1, 220, 12);        // squash and stretch
      this.p.blink = spring(0, ...blinkK);
      this.p.open.k = 260; this.p.open.d = 22;
      for (const k of ["happyL", "happyR"]) { this.p[k].k = snappy[0]; this.p[k].d = snappy[1]; }
      this.p.roll.k = 110; this.p.roll.d = 13;
      this.col = hex(STATES.idle.col); this.colT = this.col.slice();

      this._ro = new ResizeObserver(() => this.resize());
      this._ro.observe(canvas.parentElement);
      this.resize();

      this._onPointer = (e) => this.touch(e.clientX, e.clientY);
      this._onKey = () => this.touch();
      addEventListener("pointermove", this._onPointer, { passive: true });
      addEventListener("keydown", this._onKey, { passive: true });
      canvas.addEventListener("click", () => this.poke());

      this._last = performance.now(); this._acc = 0;
      const loop = (now) => {
        if (!this.running) return;
        this._raf = requestAnimationFrame(loop);
        this._acc += now - this._last; this._last = now;
        if (!Number.isFinite(this._acc)) this._acc = 0;     // _last is unset on the very first frame: NaN here would poison every spring for good
        // frame-rate cap: power saving (20 fps, 8 asleep) or an explicit options.fps
        const cap = this.options.saver ? (this.state === "sleeping" ? 8 : 20) : this.options.fps;
        if (cap && this._acc < 1000 / cap - 2) return;
        const dt = Math.min(this._acc / 1000, this.options.saver ? 0.1 : 1 / 30);
        this._acc = 0;
        if (this.W > 20 && this.H > 20) { this.update(dt); if (!this.noDraw) this.draw(); }
      };
      this._raf = requestAnimationFrame(loop);
    }

    destroy() {
      this.running = false;
      cancelAnimationFrame(this._raf);
      this._ro.disconnect();
      removeEventListener("pointermove", this._onPointer);
      removeEventListener("keydown", this._onKey);
    }

    setOptions(o) {
      Object.assign(this.options, o);
      this.audio.on = !!this.options.sound;
    }

    /** Joins the shared clock (see the header). Pass null to go back to local randomness. */
    setSync(cfg) { this.sync = cfg && typeof cfg.now === "function" ? cfg : null; }

    /** Another face (PC app / widget / phone) was poked or woken: do the same, without echoing it back. */
    applyRemote(evt) {
      if (!evt) return;
      if (evt.kind === "poke") this.poke(true);
      else if (evt.kind === "wake" && this.state === "sleeping") this.wake(true);
    }

    _send(evt) { if (this.sync && this.sync.send) { try { this.sync.send({ ...evt, origin: this.sync.id }); } catch { /* offline */ } } }

    setLevel(v) { this.level = clamp(+v || 0, 0, 1); this.levelAt = performance.now(); }

    resize() {
      const r = this.cv.parentElement.getBoundingClientRect();
      const dpr = Math.min(devicePixelRatio || 1, 2);
      this.cv.width = Math.max(1, Math.round(r.width * dpr));
      this.cv.height = Math.max(1, Math.round(r.height * dpr));
      if (this.ctx) this.ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      this.W = r.width; this.H = r.height;
    }

    touch(x, y) {
      this.lastActive = performance.now();
      if (x !== undefined) this.pointer = { x, y, seen: this.lastActive };
      if (this.state === "sleeping") this.wake();
    }

    /** The app tells the face what Troy is doing. Repeating the same state is a no-op. */
    setState(s) {
      if (!STATES[s] || EXPRESSIONS[s] || s === this.requested) return;
      this.requested = s;
      this.fx = null;
      this._enter(s);
    }

    /** Applies a preset: all the spring targets, the colour, the entry "kick". */
    _enter(s) {
      if (s === this.state && !this.fx) return;
      this.state = s;
      const P = STATES[s];
      for (const k in BASE) this.p[k].t = P[k];
      this.colT = hex(P.col);
      this.lastActive = performance.now();
      if (s === "done")      { this.p.bob.v = -520; this.p.sq.v = 2.5; this.burst("spark", 9); }
      if (s === "proud")     { this.p.bob.v = -430; this.p.sq.v = 2; this.burst("spark", 12); }
      if (s === "surprised") { this.p.bob.v = -700; this.p.sq.v = 3; }
      if (s === "listening") { this.p.bob.v = -160; }
      if (s === "thinking")  { this.p.sq.v = -1; }
      if (s === "error")     { this.p.sq.v = -2; this.shake = 1; }
      if (s === "sleeping")  { this.p.sq.v = -1.2; }
      if (s === "wink")      { this.p.bob.v = -180; }
      if (s === "curious")   { this.p.sq.v = 1; this.p.bob.v = -120; }
      if (s === "executing") this.scanAt = 0;
      this.audio.state(s);
      this.cv.title = P.hint;
      if (this.onStateChange) this.onStateChange(s);
    }

    /** Shows an expression for a moment on top of the current state, then returns to it. */
    play(name, ms) {
      if (!EXPRESSIONS[name] || this.locked || this.state === "sleeping") return false;
      const until = performance.now() + (ms || EXPRESSIONS[name]);
      this.fx = { name, until };
      this._enter(name);
      clearTimeout(this._fxTimer);
      this._fxTimer = setTimeout(() => this._endFx(until), (ms || EXPRESSIONS[name]) + 30);
      return true;
    }

    _endFx(until) {
      if (!this.fx || this.fx.until !== until) return;
      this.fx = null;
      this._enter(this.requested);
    }

    wake(remote) {
      if (!remote) this._send({ kind: "wake" });
      this.fx = null;
      this._enter("surprised");
      clearTimeout(this.wakeTimer);
      this.wakeTimer = setTimeout(() => { if (this.state === "surprised") this._enter(this.requested === "sleeping" ? "idle" : this.requested); }, 1000);
    }

    /** Click / tap: a happy hop; poke again quickly for a wink. */
    poke(remote) {
      if (this.state === "sleeping") return this.wake(remote);
      if (this.locked) return;
      if (!remote) this._send({ kind: "poke" });
      const now = performance.now();
      this.pokes = this.pokes.filter((t) => now - t < 1700); this.pokes.push(now);
      this.lastActive = now;
      const n = this.pokes.length;
      if (n >= 2) { this.pokes = []; this.play("wink"); return; }
      this.fx = { name: "done", until: now + 1100 };
      this._enter("done");
      clearTimeout(this.wakeTimer);
      const until = this.fx.until;
      this.wakeTimer = setTimeout(() => this._endFx(until), 1130);
    }

    blink(double) {
      this.p.blink.t = 1;
      setTimeout(() => { this.p.blink.t = 0; }, 90);
      if (double) setTimeout(() => { this.p.blink.t = 1; setTimeout(() => { this.p.blink.t = 0; }, 90); }, 260);
    }

    burst(kind, n) {
      if (this.options.saver || this.parts.length > 60) return;
      for (let i = 0; i < n; i++) {
        const a = Math.random() * Math.PI * 2, sp = 60 + Math.random() * 140;
        this.parts.push({
          kind, x: (Math.random() - 0.5) * 120, y: -10 + (Math.random() - 0.5) * 40,
          vx: Math.cos(a) * sp, vy: Math.sin(a) * sp - 40, life: 0, max: 0.9 + Math.random() * 0.7,
          size: 5 + Math.random() * 6, rot: Math.random() * 6,
        });
      }
    }

    update(dt) {
      this.time += dt;
      const t = this.time, now = performance.now(), p = this.p, s = this.state, saver = this.options.saver;

      // Gaze: follow the pointer if it moved recently, otherwise glance around on its own
      const r = this.cv.getBoundingClientRect();
      // a hidden canvas (e.g. behind the Settings view) has a 0x0 rect: following the cursor would divide by zero and poison the gaze springs with NaN
      const follow = this.options.tracking && !saver && now - this.pointer.seen < 2500 && r.width > 1 && r.height > 1;
      let gx = 0, gy = 0;
      if (follow) {
        gx = clamp((this.pointer.x - (r.left + r.width / 2)) / (r.width / 2), -1, 1) * 16;
        gy = clamp((this.pointer.y - (r.top + r.height / 2)) / (r.height / 2), -1, 1) * 11;
      } else {
        if (this.sync) {                                           // same glance, same moment, on every face
          const slot = Math.floor(this.sync.now() / 2200);
          if (slot !== this._glanceSlot) { this._glanceSlot = slot; this.glance = { x: (unit(slot * 7 + 1) - 0.5) * 18, y: (unit(slot * 7 + 2) - 0.5) * 8 }; }
        } else if (t > this.nextGlance) {
          this.glance = { x: (Math.random() - 0.5) * 18, y: (Math.random() - 0.5) * 8 };
          this.nextGlance = t + (saver ? 3.5 : 1.5) + Math.random() * 2.5;
        }
        if (this.glance) { gx = this.glance.x; gy = this.glance.y; }
      }

      if (s === "thinking") { gx = 12 + Math.sin(t * 0.9) * 7; gy = -10 + Math.sin(t * 1.4) * 2; }
      if (s === "executing") {
        if (this.sync) {
          const slot = Math.floor(this.sync.now() / 450);
          if (slot !== this._scanSlot) { this._scanSlot = slot; this.gTarget = { x: (unit(slot * 5 + 3) - 0.5) * 30, y: (unit(slot * 5 + 4) - 0.5) * 12 }; }
        } else if (t > this.scanAt) { this.gTarget = { x: (Math.random() - 0.5) * 30, y: (Math.random() - 0.5) * 12 }; this.scanAt = t + 0.45; }
        gx = this.gTarget.x; gy = this.gTarget.y;
      }
      if (s === "listening") { gx *= 0.3; gy = -2; }
      if (s === "sleeping") { gx = 0; gy = 5; }
      if (s === "error") { gx = 0; gy = 6; }
      if (s === "curious") { gx = 14; gy = -8; }
      if (s === "done" || s === "surprised" || s === "proud" || s === "wink") { gx *= 0.4; gy *= 0.4; }
      p.gx.t = gx; p.gy.t = gy;

      // Voice level: smoothed, and only trusted while fresh
      const fresh = now - this.levelAt < 350;
      this.lv += ((fresh ? this.level : 0) - this.lv) * Math.min(1, dt * (fresh && this.level > this.lv ? 16 : 7));

      // Speaking: the mouth follows the real voice level when we have one, otherwise loose syllables
      if (s === "speaking") {
        const synth = Math.max(0, Math.sin(t * 11) * 0.5 + Math.sin(t * 17.3) * 0.3 + 0.2);
        const env = fresh ? clamp(this.lv * 1.5, 0, 1) : synth;
        p.open.t = Math.min(0.8, env);
        p.sq.t = 1 + env * 0.035;
      } else p.sq.t = 1;

      // Natural blinking, sometimes twice
      if (["idle", "speaking", "thinking", "listening", "curious"].includes(s)) {
        if (this.sync) {                                           // a blink roughly every 3 s, decided by the shared clock
          const slot = Math.floor(this.sync.now() / 450);
          if (slot !== this._blinkSlot) { this._blinkSlot = slot; if (hash32(slot) % 7 === 0) this.blink(hash32(slot * 31 + 7) % 5 === 0); }
        } else if (t > this.nextBlink) {
          this.blink(Math.random() < 0.2);
          this.nextBlink = t + 2.2 + Math.random() * 3.6;
        }
      }

      // Idle personality: now and then it does something on its own
      if (s === "idle" && !this.fx && !this.locked && !saver && this.requested === "idle") {
        if (this.sync) {                                           // one expression every ~15 s, the same one everywhere
          const slot = Math.floor(this.sync.now() / 1000);
          if (slot !== this._flourishSlot && slot - this._flourishSlot >= 9 && hash32(slot * 977 + 13) % 15 === 0) {
            this._flourishSlot = slot; this.play(hash32(slot * 13 + 5) % 2 ? "curious" : "wink");
          }
        } else if (t > this.nextFlourish) {
          const pick = Math.random();
          this.play(pick < 0.5 ? "curious" : "wink");
          this.nextFlourish = t + 11 + Math.random() * 12;
        }
      }

      // Fall asleep after a while of nothing (sooner when saving power)
      if (s === "idle" && this.options.sleep && !this.locked && now - this.lastActive > (saver ? 5000 : 8000)) {
        this._enter("sleeping");
      }

      // Error shake decays
      this.shake = Math.max(0, this.shake - dt * 2.2);

      // Particles
      if (!saver) {
        for (const q of this.parts) { q.life += dt; q.x += q.vx * dt; q.y += q.vy * dt; if (q.kind === "spark") { q.vy += 160 * dt; q.vx *= 0.99; } q.rot += dt * 2; }
        this.parts = this.parts.filter((q) => q.life < q.max);
      } else this.parts.length = 0;

      // Integrate in small fixed sub-steps: the stiff blink spring (k=1100) goes
      // unstable with one big step on a slow frame, which made the eyes explode.
      const n = Math.max(1, Math.ceil(dt / (1 / 120))), h = dt / n;
      for (let i = 0; i < n; i++) for (const k in p) step(p[k], h);
      for (let i = 0; i < 3; i++) this.col[i] += (this.colT[i] - this.col[i]) * Math.min(1, dt * 6);

      if (this.onTint && now - this.tintAt > 120) {
        this.tintAt = now;
        this.onTint(Math.round(this.col[0]), Math.round(this.col[1]), Math.round(this.col[2]));
      }
    }

    /* ----------------------------------------------------------- drawing */
    _star(c, x, y, r, rot) {
      c.beginPath();
      for (let i = 0; i < 8; i++) {
        const a = rot + (i * Math.PI) / 4, rr = i % 2 ? r * 0.32 : r;
        c[i ? "lineTo" : "moveTo"](x + Math.cos(a) * rr, y + Math.sin(a) * rr);
      }
      c.closePath();
    }

    draw() {
      const c = this.ctx, p = this.p, W = this.W, H = this.H, s = this.state, saver = this.options.saver;
      // Unit scale: fit the face to whatever room there is (small banner or full-screen focus mode)
      const u = this.options.scale * clamp(Math.min(W / 440, H / 250), 0.3, 2.4);
      // On a light theme the pale glowing face would vanish, so mix the mood colour
      // toward a deep indigo (still tinted by the mood) and soften the glow.
      const ink = this.options.light ? this.col.map((v, i) => Math.round(v * 0.38 + [34, 48, 120][i] * 0.62)) : this.col.map(Math.round);
      const rgb = `rgb(${ink})`, rgba = (a) => `rgba(${ink[0]},${ink[1]},${ink[2]},${a})`;
      const glow = saver ? 0 : this.options.light ? 12 : 26;
      c.clearRect(0, 0, W, H);

      // breathing: slow, with slightly different speeds for float and scale
      const sleepy = s === "sleeping";
      const breath = Math.sin(this.time * (sleepy ? 0.9 : 1.6));
      const jitter = this.shake > 0 ? Math.sin(this.time * 70) * 5 * this.shake * u : 0;
      const cx = W / 2 + p.gx.x * 0.35 * u + jitter;
      const cy = H / 2 - 14 * u + p.bob.x * u + breath * (sleepy ? 3 : 4) * u;
      const sq = p.sq.x * (1 + breath * 0.012);
      const lv = this.lv;
      const half = this.options.gap * u / 2, mouthY = cy + 74 * u + p.gy.x * 0.3 * u;

      // ---- behind the face: sound rings (listening / speaking) ----
      if (!saver && (s === "listening" || (s === "speaking" && lv > 0.03))) {
        c.save(); c.lineWidth = 2 * u;
        for (let i = 0; i < 3; i++) {
          const k = (this.time * (s === "listening" ? 0.55 : 0.8) + i / 3) % 1;
          c.globalAlpha = (1 - k) * (0.1 + lv * 0.45) * (s === "listening" ? 1 : 0.8);
          c.strokeStyle = rgb; c.beginPath();
          c.ellipse(cx, cy + 22 * u, (96 + k * 150) * u, (62 + k * 96) * u, 0, 0, 7); c.stroke();
        }
        c.restore();
      }

      c.save();
      c.translate(cx, cy); c.rotate(p.roll.x); c.scale(sq, 2 - sq); c.translate(-cx, -cy);   // head tilt + squash & stretch around the face centre

      // cheeks
      if (p.blush.x > 0.02) for (const sd of [-1, 1]) {
        const bx = cx + sd * (half + 38 * u), by = mouthY - 8 * u;
        const g = c.createRadialGradient(bx, by, 0, bx, by, 30 * u);
        g.addColorStop(0, `rgba(255,140,175,${p.blush.x * 0.5})`); g.addColorStop(1, "rgba(255,140,175,0)");
        c.fillStyle = g; c.beginPath(); c.arc(bx, by, 30 * u, 0, 7); c.fill();
      }

      // eyes
      c.shadowColor = rgb; c.shadowBlur = glow * u * (1 + lv * 0.5); c.strokeStyle = rgb; c.lineCap = "round"; c.lineJoin = "round";
      const bl = p.blink.x;
      [[-1, p.ehL.x, p.lidL.x, p.tiltL.x, p.happyL.x], [1, p.ehR.x, p.lidR.x, p.tiltR.x, p.happyR.x]].forEach(([sd, eh, lid, tilt, hp]) => {
        const w = p.ew.x * u * (1 + 0.1 * bl), h = Math.max(7 * u, eh * u * (1 - 0.93 * bl));
        c.save();
        c.translate(cx + sd * half + p.gx.x * u * (sd < 0 ? 1 : 0.9), cy + p.gy.x * u);
        c.rotate(tilt);
        const solid = 1 - clamp(hp, 0, 1);
        if (solid > 0.02) {
          c.save(); c.globalAlpha = solid;
          if (lid > 0.01) { c.beginPath(); c.rect(-w, -h / 2 + lid * h, w * 2, h * 2); c.clip(); }
          // depth: lighter at the top, the mood colour at the bottom, a glint, a soft lower reflection
          const g = c.createLinearGradient(0, -h / 2, 0, h / 2);
          g.addColorStop(0, `rgb(${mixWhite(ink, 0.62)})`); g.addColorStop(0.55, rgb); g.addColorStop(1, `rgb(${ink.map((v) => Math.round(v * 0.82))})`);
          c.fillStyle = g;
          c.beginPath(); c.roundRect(-w / 2, -h / 2, w, h, Math.max(0, Math.min(w, h) / 2)); c.fill();
          c.shadowBlur = 0;
          if (h > 16 * u) {
            c.globalAlpha = solid * 0.85 * (1 - bl);
            c.fillStyle = "rgba(255,255,255,.92)";
            c.beginPath(); c.ellipse(-w * 0.17 - p.gx.x * 0.1 * u, -h * 0.27, w * 0.11, Math.min(h * 0.11, w * 0.16), -0.5, 0, 7); c.fill();
            c.globalAlpha = solid * 0.22; c.fillStyle = "#fff";
            c.beginPath(); c.ellipse(0, h * 0.34, w * 0.26, h * 0.06, 0, 0, 7); c.fill();
          }
          c.restore();
          c.shadowBlur = glow * u * (1 + lv * 0.5);
        }
        if (hp > 0.02) {                       // happy "^" eye
          c.save(); c.globalAlpha = clamp(hp, 0, 1); c.lineWidth = 13 * u;
          c.beginPath(); c.moveTo(-w * 0.38, 10 * u); c.quadraticCurveTo(0, -34 * u, w * 0.38, 10 * u); c.stroke();
          c.restore();
        }
        c.restore();
      });

      // eyebrows: they carry most of the mood
      if (p.brow.x > 0.03) {
        c.save(); c.globalAlpha = clamp(p.brow.x, 0, 1) * 0.9; c.lineWidth = 5.5 * u; c.shadowBlur = glow * 0.5 * u;
        for (const sd of [-1, 1]) {
          const eh = sd < 0 ? p.ehL.x : p.ehR.x, asym = sd < 0 ? -p.browAsym.x : p.browAsym.x;   // + asym lowers the right brow / raises the left
          const bx = cx + sd * half + p.gx.x * u * 0.6, by = cy + p.gy.x * u - eh * u / 2 - 22 * u + (p.browY.x + asym) * u;
          c.save(); c.translate(bx, by); c.rotate(sd * p.browTilt.x);
          c.beginPath(); c.moveTo(-p.ew.x * u * 0.42, 3 * u); c.quadraticCurveTo(0, -5 * u, p.ew.x * u * 0.42, 3 * u); c.stroke();
          c.restore();
        }
        c.restore();
      }

      // mouth: a smile curve (with a smirk and a variable width) that opens into an oval when talking
      c.shadowBlur = glow * 0.4 * u;
      const mx = cx + p.gx.x * 0.45 * u, o = p.open.x, mw = p.mouthW.x * u, sk = p.skew.x * 6 * u;
      c.globalAlpha = 1 - Math.min(1, o * 1.6);
      c.lineWidth = 6 * u; c.beginPath();
      c.moveTo(mx - mw, mouthY + sk); c.quadraticCurveTo(mx, mouthY + p.smile.x * 20 * u, mx + mw, mouthY - sk); c.stroke();
      c.globalAlpha = Math.min(1, o * 1.6);
      c.fillStyle = rgb;
      c.beginPath(); c.ellipse(mx, mouthY + 4 * u, (mw * 0.7 + o * 5 * u), (2 + o * 15) * u, 0, 0, 7); c.fill();
      c.globalAlpha = 1;
      c.restore();

      // ---- on top of the face ----
      c.save(); c.shadowColor = rgb; c.shadowBlur = glow * 0.5 * u;
      if (s === "thinking") {                                        // three dots, rippling
        for (let i = 0; i < 3; i++) {
          const ph = this.time * 4.2 - i * 0.8, a = 0.35 + 0.65 * Math.max(0, Math.sin(ph));
          c.globalAlpha = a; c.fillStyle = rgb;
          c.beginPath(); c.arc(cx + half + (44 + i * 17) * u, cy - (46 + 6 * Math.sin(ph)) * u - i * 4 * u, (3.4 + i * 0.9) * u, 0, 7); c.fill();
        }
      }
      if (s === "executing" && !saver) {                             // HUD brackets + a scanner line
        c.globalAlpha = 0.45; c.lineWidth = 3 * u; c.strokeStyle = rgb;
        const bx = half + 62 * u, by = 56 * u, L = 14 * u;
        for (const sx of [-1, 1]) for (const sy of [-1, 1]) {
          c.beginPath(); c.moveTo(cx + sx * bx, cy + sy * by - sy * L); c.lineTo(cx + sx * bx, cy + sy * by); c.lineTo(cx + sx * bx - sx * L, cy + sy * by); c.stroke();
        }
        const sy = cy + Math.sin(this.time * 3.1) * 40 * u;
        const g = c.createLinearGradient(cx - bx, 0, cx + bx, 0);
        g.addColorStop(0, rgba(0)); g.addColorStop(0.5, rgba(0.55)); g.addColorStop(1, rgba(0));
        c.globalAlpha = 1; c.fillStyle = g; c.fillRect(cx - bx, sy - 1 * u, bx * 2, 2 * u);
      }
      for (const q of this.parts) {                                  // sparkles
        const k = q.life / q.max, a = Math.sin(clamp(k, 0, 1) * Math.PI);
        c.globalAlpha = a * 0.9;
        const px = cx + q.x * u, py = cy + q.y * u;
        c.fillStyle = rgb; this._star(c, px, py, q.size * u, q.rot); c.fill();
      }
      c.restore();

      // floating z's
      if (sleepy) {
        c.save(); c.fillStyle = rgb; c.shadowBlur = 0;
        for (let i = 0; i < 3; i++) {
          const k = (this.time * 0.5 + i / 3) % 1;
          c.globalAlpha = Math.sin(k * Math.PI) * 0.7;
          c.font = `700 ${(14 + i * 5) * u}px ui-rounded, system-ui, sans-serif`;
          c.fillText("z", cx + half + (36 + k * 34) * u + Math.sin(k * 6) * 4, cy - (10 + k * 60) * u);
        }
        c.restore();
      }
    }
  }

  window.NovaFace = {
    STATES: Object.keys(STATES).filter((k) => !EXPRESSIONS[k]),
    EXPRESSIONS: Object.keys(EXPRESSIONS),
    mount: (canvas, opts) => new Face(canvas, opts),
  };
})();
