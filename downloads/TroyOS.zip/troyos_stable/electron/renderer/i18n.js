/* Troy interface translation.
 *
 * One small engine shared by the app window, the widget and the phone page (the file is copied to troy/web/phone/ and a
 * test keeps the copies identical, like avatar.js).
 *
 * How it works: English is the source language and the fallback. A dictionary (i18n-tr.js) maps an English phrase to its
 * translation. The engine translates every text node and the title / placeholder / aria-label / alt attributes whose
 * whole text matches an entry, once when the page loads and again whenever the app inserts or changes something (a
 * MutationObserver). Entries may contain {0} {1} ... placeholders for numbers and names ("{0} phones watching"), which
 * is how composed sentences are covered. Anything without an entry simply stays English, so a missing translation can
 * never break the interface.
 *
 * Never translated: user and model content (chat messages, memory, logs, task text, code) -- see SKIP -- because a message
 * that happens to equal a menu label must stay as the user wrote it.
 *
 * Switching language reloads the window (the app restores its chat on reload), so no text is ever "half" translated and
 * nothing has to remember its original wording.
 *
 *   I18N.lang              "en" | "tr"   (what is active; "auto" in the setting resolves to this)
 *   I18N.t("{0} left", 3)  explicit translation for strings built in code
 *   I18N.locale()          "tr-TR" | undefined, for toLocaleString / toLocaleDateString
 *   I18N.setPreference(p)  remembers "en" | "tr" | "auto" for the next start; returns true if the active language changes
 *   I18N.misses()          untranslated visible phrases seen so far (for the coverage test)
 */
"use strict";

(function (global) {
  const KEY = "troy.lang";
  const SUPPORTED = ["en", "tr"];
  const dicts = {};
  const compiled = {};
  const ATTRS = ["title", "placeholder", "aria-label", "alt"];
  // Containers whose text is the user's or the model's, not the interface's.
  const SKIP = [
    '[translate="no"]', ".notranslate", "script", "style", "pre", "code", "textarea", "kbd",
    ".msg .src", ".steps .slist", ".steps .sum .nm", "#caption", ".sess .t", ".sres", ".item .tx", "#logOut", ".log-line",
    ".vt-text", ".tool-card .ds", ".tool-card .nm", ".tool-card .ar", ".task-title", ".task-instr", ".task-log", ".conf .desc",
  ].join(",");
  const misses = new Set();
  const produced = new Set();                          // phrases t() already translated (so they aren't reported as misses)

  function preference() {
    try { const v = localStorage.getItem(KEY); if (v === "en" || v === "tr" || v === "auto") return v; } catch { /* storage unavailable */ }
    return "en";
  }
  function resolve(pref) {
    if (pref === "auto") {
      const sys = String((typeof navigator !== "undefined" && (navigator.languages?.[0] || navigator.language)) || "en").toLowerCase();
      return SUPPORTED.includes(sys.slice(0, 2)) ? sys.slice(0, 2) : "en";
    }
    return SUPPORTED.includes(pref) ? pref : "en";
  }

  const api = {
    lang: resolve(preference()),
    register(lang, entries) { dicts[lang] = Object.assign(dicts[lang] || {}, entries); compiled[lang] = null; },
    locale() { return api.lang === "tr" ? "tr-TR" : undefined; },
    misses() { return [...misses]; },
    preference,
    setPreference(pref) {
      if (!(pref === "en" || pref === "tr" || pref === "auto")) pref = "en";
      try { localStorage.setItem(KEY, pref); } catch { /* ignore */ }
      return resolve(pref) !== api.lang;
    },
  };

  const norm = (s) => s.replace(/\s+/g, " ").trim();

  function patternsFor(lang) {
    if (compiled[lang]) return compiled[lang];
    const list = [];
    for (const [src, out] of Object.entries(dicts[lang] || {})) {
      if (!/\{#?\d\}/.test(src)) continue;
      try {                                            // one bad entry must never take the whole interface down
        const re = new RegExp("^" + src.replace(/[.*+?^$()|[\]\\]/g, "\\$&")
          .replace(/\{#(\d)\}/g, "(?<g$1>\\d[\\d.,:]*)").replace(/\{(\d)\}/g, "(?<g$1>.+?)") + "$");
        list.push({ re, out, weight: src.replace(/\{#?\d\}/g, "").length });
      } catch (err) { if (typeof console !== "undefined") console.warn("i18n: skipped invalid entry:", src); }
    }
    list.sort((a, b) => b.weight - a.weight);          // the most specific phrase wins
    return (compiled[lang] = list);
  }

  function fill(out, groups) { return out.replace(/\{#?(\d)\}/g, (_, i) => groups[`g${i}`] ?? ""); }

  /* "English text" (any whitespace) -> translation, or null when there is none. */
  function lookup(text) {
    const d = dicts[api.lang];
    if (!d) return null;
    const key = norm(text);
    if (!key) return null;
    if (Object.prototype.hasOwnProperty.call(d, key)) return d[key];
    for (const p of patternsFor(api.lang)) {
      const m = p.re.exec(key);
      if (m) {
        // The captured pieces may themselves be translatable ("2 of Mon" ...): translate them first.
        const groups = {};
        for (const [g, v] of Object.entries(m.groups)) groups[g] = lookup(v) ?? v;
        return fill(p.out, groups);
      }
    }
    return null;
  }

  api.t = function (text, ...args) {
    let out = api.lang === "en" ? null : lookup(text);
    if (out == null) out = text; else produced.add(norm(out.replace(/\{#?\d\}/g, "")));
    return out.replace(/\{#?(\d)\}/g, (_, i) => (args[+i] !== undefined ? args[+i] : ""));
  };

  /* Adopt the backend's UI_LANGUAGE setting (the source of truth, shared with the widget and the phone) and reload once if
   * that changes the language in use. `request(method, params)` is the page's backend call. Returns the preference. */
  api.sync = async function (request) {
    try {
      const pref = (await request("settings.get", {}))?.values?.UI_LANGUAGE || "en";
      if (api.setPreference(pref) && typeof location !== "undefined") location.reload();
      return pref;
    } catch { return api.preference(); }
  };

  if (typeof document === "undefined") { global.I18N = api; return; }

  /* ------------------------------------------------------------------ DOM */
  const made = new WeakMap();                           // Text node / Element -> what we last wrote (so we don't redo it)
  const skipped = (el) => !!(el && el.closest && el.closest(SKIP));

  function translateText(node) {
    const raw = node.data;
    if (made.get(node) === raw) return;
    if (!/[A-Za-z]{2}/.test(raw)) return;
    if (skipped(node.parentElement)) return;
    const out = lookup(raw);
    if (out == null) { if (!produced.has(norm(raw))) misses.add(norm(raw)); return; }
    const lead = raw.match(/^\s*/)[0], trail = raw.match(/\s*$/)[0];
    const next = lead + out + trail;
    made.set(node, next);
    if (next !== raw) node.data = next;
  }

  function translateAttrs(el) {
    if (!el.getAttribute || skipped(el)) return;
    let rec = made.get(el);
    for (const a of ATTRS) {
      const raw = el.getAttribute(a);
      if (!raw || !/[A-Za-z]{2}/.test(raw)) continue;
      if (rec && rec[a] === raw) continue;
      const out = lookup(raw);
      if (out == null) { misses.add(norm(raw)); continue; }
      (rec = rec || {}, made.set(el, rec));
      rec[a] = out;
      if (out !== raw) el.setAttribute(a, out);
    }
  }

  function translateTree(root) {
    if (!root || api.lang === "en") return;
    if (root.nodeType === 3) { translateText(root); return; }
    if (root.nodeType !== 1) return;
    translateAttrs(root);
    const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT | NodeFilter.SHOW_ELEMENT);
    for (let n = walker.nextNode(); n; n = walker.nextNode()) {
      if (n.nodeType === 3) translateText(n); else translateAttrs(n);
    }
  }
  api.translate = translateTree;

  function start() {
    document.documentElement.lang = api.lang;
    if (api.lang === "en") return;
    translateTree(document.body);
    if (document.title) { const t = lookup(document.title); if (t) document.title = t; }
    new MutationObserver((records) => {
      for (const r of records) {
        if (r.type === "characterData") translateText(r.target);
        else if (r.type === "attributes") translateAttrs(r.target);
        else r.addedNodes.forEach(translateTree);
      }
    }).observe(document.body, { childList: true, subtree: true, characterData: true, attributes: true, attributeFilter: ATTRS });
  }

  document.documentElement.lang = api.lang;
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", start); else start();
  global.I18N = api;
})(typeof window !== "undefined" ? window : globalThis);
