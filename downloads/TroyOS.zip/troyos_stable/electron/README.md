# Troy — Electron frontend

This is Troy's desktop UI. It is a normal Electron app that owns exactly
one extra responsibility beyond the usual window/menu/tray plumbing:
spawning the Python backend as a child process and talking to it over
**stdio IPC** (`main.py --ipc`) instead of any kind of HTTP server. There
is deliberately no `127.0.0.1:8000`-style local web server anywhere in
this stack — that was tried and didn't work reliably (port conflicts,
firewall prompts, the server not being up yet when the window opened).
Everything below is real inter-process communication over pipes.

## Running it

```
cd electron
npm install
npm start
```

`npm start` runs `electron .`, which spawns `python -u ../main.py --ipc`
automatically (see `main.js`) — you do not need to start the Python
backend yourself, and you do not need it running before `npm start`.

If your Python interpreter isn't on `PATH` as `python` (Windows default)
or `python3` (macOS/Linux default), set `TROY_PYTHON` to the exact
interpreter first, e.g.:

```
set TROY_PYTHON=C:\path\to\venv\Scripts\python.exe   (Windows, cmd)
$env:TROY_PYTHON="C:\path\to\venv\Scripts\python.exe" (Windows, PowerShell)
export TROY_PYTHON=/path/to/venv/bin/python3          (macOS/Linux)
```

Make sure the Python backend's own dependencies are installed first (see
the project root `README.md` / `requirements.txt`).

## Architecture, in one picture

```
renderer (index.html, plain JS/HTML/CSS)
    |  window.troy.request(method, params) -> Promise
    |  window.troy.on(eventName, callback)
    v
preload.js  --contextBridge-->  main.js  (Electron's OWN internal IPC --
                                           ipcMain.handle / ipcRenderer.invoke,
                                           NOT the stdio protocol below)
    |
    |  child_process.spawn("python", ["-u", "main.py", "--ipc"])
    |  newline-delimited JSON over stdin/stdout (REAL OS-level IPC, no network)
    v
troy/ipc_host.py  (Python backend: the actual agent, tools, memory, sessions, ...)
```

Two separate IPC layers are stacked on top of each other, and neither of
them is HTTP:
1. **Electron's own internal IPC** (`ipcMain`/`ipcRenderer`/`contextBridge`)
   between the renderer (untrusted, sandboxed, `contextIsolation: true`,
   `nodeIntegration: false`) and the main process.
2. **Stdio IPC** between `main.js` (the main process) and the Python
   backend child process — plain stdin/stdout, one JSON object per line.

`main.js` is the only file that knows both protocols exist; it just
relays between them. `preload.js` exposes a small, safe surface
(`window.troy.request`, `.on`, `.off`) to the renderer — that's the
*entire* API available to whatever HTML/CSS/JS is designing the actual
UI. Nothing else Electron/Node-related is reachable from the renderer.

## The renderer's whole API surface

```js
window.troy.request(method, params) -> Promise<result>
```
Calls one of the methods below. Resolves with `result`. Rejects (throws
inside an `await`, or a `.catch()`) if the backend returned an error or
the call timed out (60s default, see `REQUEST_TIMEOUT_MS` in `main.js`).

```js
const unsubscribe = window.troy.on(eventName, (data) => { ... });
// later, if needed:
unsubscribe();  // or: window.troy.off(eventName, thatSameCallback)
```
Subscribes to one of the push events below. Multiple listeners for the
same event are fine.

The renderer in `electron/renderer/` is a complete glassmorphism UI, not a template:

| file | what it is |
|---|---|
| `widget/` | the always-on-top widget (see below): `widget.html`, `widget.css`, `widget.js` |
| `index.html` | markup + icon sprite |
| `styles.css` | all styling; theme, accent and blur are CSS variables on `<body>` |
| `ui-kit.js` | helpers: safe markdown, toasts, modals, popovers, command palette |
| `avatar.js` | "Nova", the animated canvas face (`NovaFace.mount(canvas)`) |
| `app.js` | state, every backend call/event, all views |
| `mock-backend.js` | demo backend used **only** when `window.troy` doesn't exist |

Features: avatar + chat (split / focus / chat-only layouts), tool-call steps,
approval cards, sessions (search, rename, delete, auto-titles), memory, tool
browser, log viewer, provider/API-key manager with live model fetch, model
pickers, **full voice mode overlay (Ctrl+Shift+V)**, voice + wake word with
engine/microphone settings, phone page (incl. phone-voice options),
themes/accents/blur, command palette
(Ctrl+K), slash commands, keyboard shortcuts, widget mode (see below), tray, power saving.
The avatar's mood follows the agent (thinking, executing, speaking, listening,
done, error, asleep) and tints the background.

**Restyling without Python:** `npm run demo` opens the UI against
`mock-backend.js`, which implements every method/event below with fake data.
`npm run test:ui` drives the real UI against that demo backend (87 checks;
on Linux use `xvfb-run -a npm run test:ui`).

## The widget (always-visible glass pill)

A second, tiny window docked at the **top centre of the primary display** (right
under a laptop webcam). It is always on top (above full-screen apps too), never
steals focus when it appears, and talks to the same backend as the main window:
every backend event is broadcast to both windows, so they never disagree.

```
[ orb · Troy / status ] [ ||| Ask me anything…  ] [ >_ ] [ ⚙ ] [ ● ]
```

| piece | what it does |
|---|---|
| avatar orb | the same `NovaFace` as the main app, in a glass sphere. It **grows and shrinks**: calm when idle, bigger while Troy is busy/listening, and it pulses with the live mic level (`voice.level`) or a synthetic rhythm while speaking. The glow and the whole pill take the face's mood colour |
| status | `Ready.` · `Thinking…` · `Working…` · `Speaking…` · `Listening…` · `Hearing you…` · `Mic muted` · `Needs your OK` · `Backend offline` |
| wave button | starts / ends full voice mode (`voice.mode_start` / `voice.mode_stop`); the 5 bars dance with the mic level |
| input | Enter sends (`chat.send` with `source: "widget"`); ↑/↓ recall earlier messages; a send or stop button appears as needed |
| `>_` | activity log: state changes, tool calls and results, replies |
| ⚙ | menu: open the full app, new chat, auto-collapse, stay-above-all-windows, hide, quit |
| dot | green = connected, amber = busy, cyan = listening, red = backend offline |

The pill **melts open into a panel** when something happens (you send a message,
Troy replies, a tool runs, voice mode starts) and folds back after a few quiet
seconds (hover, a pending approval, an active voice session, typed text or the
**Pin** button keep it open; *Auto-collapse* can be switched off). Risky actions
show the same approve / deny card as the main window, so you can answer them
right there. `Esc` closes the panel (or clears the input first).

**Modes.** Troy is the widget, the full app, or hidden, never the widget and the app at
once. Opening the app (widget menu, tray, Settings, or Troy's `open_full_app`) hides the widget;
the app's close button (and the title-bar *Widget* button) hands the screen back to the widget.
**Global hotkey** `Ctrl+Alt+T` (`Cmd+Alt+T` on macOS; change it in Settings > Widget) opens the
widget and focuses its input, and closes it again. The tray menu has *Ask Troy*, *Open full app*
and *Hide Troy*. Choices are remembered in the window-state file (`widgetHotkey`, `widgetOnTop`,
`widgetAutoCollapse`).

Files: `renderer/widget/widget.html | widget.css | widget.js` (self-contained; it only
shares `avatar.js`, and `mock-backend.js` for demos). `main.js` creates the window
(`createWidget`) and handles `window.troy.widget(action, value)`:
`fit({w,h}) | passthrough(bool) | focus | blur | openMain | show | hide | toggle | setMode(m) |
setOption({key, value}) | setOnTop(bool) | quit | getInfo` (all resolve with `{mode, onTop,
autoCollapse, hotkey, hotkeyActive, visible, platform, size}`; `setOption` for `hotkey` also returns
`{ok, error}`). Options: `onTop`, `autoCollapse`, `hotkey`.
`fit` is used by `widget.js` to size the transparent OS window to the pill: it grows the
window *before* the glass expands and shrinks it *after* the glass has folded away, so
nothing is clipped and the empty margin never blocks clicks (on Windows/macOS the
margin is additionally click-through).

Design notes: all visuals are in `widget.css`, driven by `--tint`, `--w`, `--r`, `--lvl`
and `--os`. A transparent Electron window cannot blur the desktop behind it, so the
liquid-glass look is layered instead: smoky translucent base, drifting colour blobs,
specular rim, moving sheen, film grain, and a frosted input capsule that blurs those
blobs. On Linux the widget needs a compositing window manager for transparency.

Try it without Python: `npm run demo:widget`. Tests: `npm run test:widget` (33 checks), `npm run test:shell` (real `main.js` against a fake backend: modes,
hotkey, prefs, power report; Linux/macOS), `npm run test:ui` (107 checks). On Linux prefix with `xvfb-run -a`.

## Window API (`window.troy.window`, `window.troy.openExternal`)

Handled by `main.js`, not Python:
`minimize | toggleMaximize | hide | show | quit | setTheme(symbolColor) | restartBackend |
reload | devtools | getPrefs` (`hide` = back to the widget, `show` = open the app) — every call
resolves with `{mode, maximized, visible, platform, version, electron, packaged, python, ...}`.
`openExternal(url)` opens http(s) links in the real browser. `window.troy.platform`
is `win32 | darwin | linux`. Closing the app window never quits: it hands the screen back to the widget (so the wake
word keeps working). The retired `alwaysOnTop` / `closeToTray` options no longer exist.

## Methods (`window.troy.request`)

| method | params | result | notes |
|---|---|---|---|
| `app.ping` | `{}` | `{pong, version, version_label}` | health check |
| `chat.send` | `{text, source?}` | `{accepted: true, session_id}` | **async** — the actual reply arrives via `agent.speak`/`agent.tool_result`/`chat.turn_complete` events, not this call's result. `source` defaults to `"typed"`; pass `"voice"` for anything coming from `wake_listener.state`/mic input. |
| `chat.stop` | `{}` | `{stopped: true}` | force-stops the current turn |
| `session.reset` | `{}` | `{id: null}` | **what "New chat" should call.** Detaches from the current session without creating a file; the next `chat.send` creates one lazily and titles it from the first message. Rejects while a turn is running |
| `session.new` | `{title?}` | `{id}` | creates an (empty) session file immediately — prefer `session.reset` |
| `session.list` | `{}` | `{sessions: [{id, title, updated_at, has_tasks, task_count}, ...]}` | `has_tasks`: the chat created scheduled tasks (mark it with a task icon). Its `display_log` can hold `{role: "task", text, task_id, ok}` notes |
| `session.load` | `{id}` | `{id, title, display_log}` | `display_log` is an array of `{role, text}` / `{role: "tool", name, arg, success, message}` entries, ready to render |
| `session.save` | `{title?}` | `{id, title}` | explicit save; autosave also happens after every `agent.speak` and at turn end |
| `session.rename` | `{id, title}` | `{ok}` | |
| `session.delete` | `{id}` | `{ok, was_current}` | deleting the open chat also resets the agent |
| `memory.list` | `{}` | `{memories: [{timestamp, fact}, ...]}` | long-term facts remembered about the user |
| `memory.add` | `{fact}` | `{message}` | |
| `memory.delete` | `{index}` | `{ok}` | |
| `memory.clear` | `{}` | `{cleared: <count>}` | |
| `context.get` | `{}` | `{success, message}` | the exact same live situational snapshot (time/active window/CPU-RAM/web-browser state) the model itself is handed every turn |
| `confirmation.list` | `{}` | `{pending: [{id, name, arg, risk_level, description}, ...]}` | any risky actions already awaiting approval (e.g. after a reload) |
| `confirmation.resolve` | `{id, approved}` | `{result: {success, message, name, arg}}` | approve or cancel one pending risky action; Troy is resumed afterward and reacts to the outcome (watch for more `agent.speak`/`chat.turn_complete` events after this) |
| `settings.get` | `{}` | `{values: {KEY: value, ...}, secrets_configured: {GROQ_API_KEY: bool, ...}, assistant_name, version, version_label, restart_required_keys}` | current values of every editable setting. **API keys are never returned**, only whether each is set |
| `settings.update` | `{changes: {KEY: value, ...}}` | `{applied: [...], restart_required: [...]}` | applies immediately **and** saves to `troy_settings.json` (survives restarts, no `.env` editing). All-or-nothing: an unknown key rejects the whole call. Editable keys: `USER_NAME, PRIMARY_PROVIDER, TEXT_MODEL_OVERRIDE, VISION_MODEL_OVERRIDE, ESCALATION_ENABLED, LMSTUDIO_ENABLED, ALLOW_MODEL_SWITCH, VOICE_INPUT_ENABLED, VOICE_OUTPUT_ENABLED, HOTKEY_COMBO, WAKE_WORD, STT_ENGINE, STT_LANGUAGE, TTS_ENGINE, TTS_VOICE_ID, TTS_RATE, EDGE_VOICE, PIPER_MODEL, VOICE_CONVERSATION_IDLE_SECONDS, VOICE_BARGE_IN, VOICE_INPUT_DEVICE, VOICE_SPOKEN_STYLE, MOBILE_VOICE_ENABLED, VOICE_PHONE_SPEAKER, MOBILE_HTTPS_ENABLED, MAX_STEPS_PER_TURN, BROWSER_HEADLESS, ...`; write-only secrets: `GROQ_API_KEY, OPENROUTER_API_KEY, GEMINI_API_KEY, NVIDIA_API_KEY, NEWSAPI_KEY` |
| `settings.set` | `{key, value}` | same as `settings.update` | single-key convenience wrapper |
| `provider.list` | `{}` | `{providers: [{id, label, configured, primary, models: {text: [...], vision: [...]}}], overrides: {text, vision}}` | every provider with its ready state and model lists; drives provider/model pickers |
| `provider.set_primary` | `{provider}` | `{applied, restart_required}` | `groq`/`openrouter`/`gemini`/`nvidia`/`lmstudio` |
| `provider.fetch_models` | `{provider}` | `{models: [<id>, ...], details: {id: {vision, loaded, context}}}` (details for LM Studio) | asks the provider's own `/models` endpoint what it serves right now (needs a configured key) |
| `model.set` | `{kind: "text"\|"vision", provider?, model?}` | `{applied, restart_required}` | forces a model; omit provider/model to go back to automatic |
| `tools.list` | `{}` | `{tools: [{name, description, category, risk_level, requires_confirmation, arg_hint}, ...]}` | the extended tool library, for a tools browser |
| `agent.status` | `{}` | `{state, session_id, busy, pending_confirmations, wake_listener}` | use at startup to restore UI state after a reload |
| `voice.list_voices` | `{engine?}` | `{voices: [{id, name}, ...]}` | `sapi` (default): installed system voices; `edge`: the online neural voices list (needs `edge-tts`) |
| `voice.speak` | `{text}` | `{queued: true}` | speaks arbitrary text immediately through the full engine chain (not tied to a turn) |
| `voice.mode_start` | `{greet?}` | `{started, already?}` or throws | **full hands-free voice mode** (no wake word, conversation state machine in `troy/voice_mode.py`). Watch `voice.state`/`voice.transcript`/`voice.level`/`voice.ended` |
| `voice.mode_stop` | `{reason?}` | `{stopped: true}` | end it (same as saying "goodbye") |
| `voice.mode_status` | `{}` | `{active, state, source, muted, phone, engines, stt}` | one call for the overlay + Settings > Voice: mode info, which TTS engines can run here, and whether STT is installed |
| `voice.mute` | `{muted}` | `{...info}` | pauses the microphone while staying in voice mode |
| `voice.interrupt` | `{}` | `{ok}` | the overlay's Stop button: silence Troy, cancel the turn, keep listening |
| `voice.devices` | `{}` | `{devices: [{index, name, default}]}` | input devices for the microphone picker |
| `voice.test_mic` | `{seconds?}` | `{ok, peak, heard, silent}` or `{ok: false, error}` | records a few seconds; live level arrives as `voice.level` with `state: "test"` |
| `wake_listener.start` | `{}` | `{started}` | begins always-on wake-word listening; recognized commands come back as normal `chat.send` turns (`source: "voice"`) — shares the voice-mode hooks, so mic level/transcripts/barge-in events flow either way |
| `wake_listener.stop` | `{}` | `{stopped: true}` | |
| `wake_listener.status` | `{}` | `{running, state}` | `state` is one of `idle`/`hearing`/`thinking`/`awake` |
| `session.search` | `{query, limit?}` | `{results: [{id, title, updated_at, title_match, hit_count, hits: [{index, role, snippet, start, length}]}], total_chats}` | titles + messages, accent/case-insensitive, every word must match; `index` is the message position in that chat's `display_log` |
| `prompt.info` | `{}` | `{mode, setting, prompt_tokens, budget_tokens, lmstudio_context}` | which prompt size is in use and how big it is |
| `youtube.status` | `{}` | `{configured, connected, signing_in, channel: {id, title, thumbnail}, error}` | |
| `youtube.connect` | `{}` | `{auth_url, port}` | opens Google's consent page in the browser; finish arrives as the `youtube.connected` / `youtube.error` events |
| `youtube.complete` | `{url}` | `{message}` | fallback: paste the redirect address if the loopback page couldn't load |
| `youtube.cancel` / `youtube.disconnect` | `{}` | `{cancelled}` / `{ok}` | |
| `youtube.test` | `{}` | `{video: {title, channel, added_at, url, playlist}}` | what "open my last liked video" would open |
| `browser.open` | `{url, browser?}` | `{success, message}` | opens http(s) in a new tab of firefox/chrome/edge/brave |
| `apps.test` | `{name}` | `{success, message}` | launches an app with the direct method |
| `remote.tailscale` | `{force?}` | `{installed, running, state, ip, dns_name, tailnet, serving, peers, error}` | |
| `remote.tailscale_serve` | `{enable}` | `{success, message, url?}` | HTTPS for the phone page via `tailscale serve` |
| `mobile_ui.regenerate_token` | `{}` | same as `mobile_ui.status` | invalidates saved phone links |
| `tasks.list` | `{}` | `{tasks: [{id, title, prompt, schedule, schedule_text, status, next_run, last_run, last_outcome, last_summary, last_error, run_count, session_id, message_index, chat_exists, chat_title, grants, needs_approval, run, ...}], enabled, scheduler_running, defaults}` | all scheduled tasks, active first |
| `tasks.get` / `tasks.logs` | `{id}` / `{id, limit?}` | `{task}` / `{entries: [{ts, event, level, message}]}` | |
| `tasks.preview` | `{when}` | `{ok: true, spec, text, next: [iso x3]}` or `{ok: false, error}` | what a wording means; never throws, for live form feedback |
| `tasks.create` | `{when, prompt, title?, approve?}` | `{task}` | `approve` = `;`-separated exact commands allowed to run unattended (typing them is the approval) |
| `tasks.modify` | `{id, title?, prompt?, when?, max_retries?, retry_delay?, default_retries?}` | `{task}` | changing `prompt` clears approvals |
| `tasks.cancel` / `tasks.pause` / `tasks.resume` / `tasks.run_now` | `{id}` | `{task}` | |
| `tasks.approve` | `{id, commands?}` | `{task}` | grants the commands that were refused (default: all of them) and runs the task again |
| `tasks.delete` / `tasks.clear_finished` | `{id}` / `{}` | `{ok}` / `{cleared}` | |
| `logs.tail` | `{lines?}` | `{lines: [<string>, ...]}` | last N lines of `troy_logs/troy.log` (default 200) |
| `mobile_ui.start` | `{port?}` | `{url}` | starts the optional phone-remote-control web server (independent of this Electron app — see `troy/mobile_server.py`); auto-starts already if `TROY_MOBILE_UI_ENABLED=true` |
| `mobile_ui.stop` | `{}` | `{stopped: true}` | |
| `mobile_ui.status` | `{}` | `{running, url, urls: [{kind, label, url, detail, recommended}], viewers, screen_enabled, port, tailscale}` | |

## Events (`window.troy.on`)

| event | data | fires when |
|---|---|---|
| `chat.user_message` | `{text, source}` | any surface sent a message (`typed`, `widget`, `voice`, `mobile`, `confirmation`). Render it unless `source` is `typed` and you already drew it |
| `chat.turn_started` | `{source}` | a turn was queued/started — set your busy state here (also fires for voice/phone/approval-resumed turns) |
| `window.shown` / `window.hidden` / `window.focused` | `{}` | window visibility, from `main.js` |
| `backend.error` | `{message}` | Python couldn't be started at all (usually: not installed) |
| `backend.restarted` | `{}` | `restartBackend` finished — re-hydrate |
| `mobile_ui.viewers` | `{count}` | phones currently watching the screen |
| `youtube.connected` / `youtube.error` / `youtube.disconnected` | `{channel}` / `{message}` / `{}` | OAuth sign-in outcome |
| `settings.changed` | `{keys}` | any setting was updated (by any caller) — refresh pickers |
| `app.ready` | `{version, version_label}` | backend finished starting (before this, requests may queue/fail) |
| `agent.state` | `{state, detail}` | `state` is `thinking`/`executing`/`speaking`/`idle`/`error`/`stopped` — drives a status indicator |
| `agent.speak` | `{text}` | Troy said something (append to the log) |
| `agent.tool_result` | `{name, arg, success, message}` | one non-`speak`/non-`done` command finished (append to the log, e.g. dimmed/monospace) |
| `agent.error` | `{message}` | the whole turn crashed unexpectedly |
| `chat.turn_complete` | `{pending}` | one turn ended; busy is over only when `pending` is 0 (turns queue and run one at a time) |
| `voice.state` | `{active, state, source, muted, ...}` | the voice-mode state machine moved: `listening / hearing / transcribing / thinking / executing / speaking / muted / off` — drives the overlay's chip + avatar |
| `voice.level` | `{level, state}` | live mic level (0-32768-ish RMS, throttled to 10/s; `state: "test"` while the Settings mic-test records) |
| `voice.transcript` | `{text, source}` | something was recognized (`pc` or `phone`) — show it in the live transcript |
| `voice.ended` | `{reason}` | voice mode ended (`user`, `goodbye`, `idle`) — close the overlay |
| `voice.phone` | `{active, speaking?}` | a phone joined/left as Troy's headset, or its playback started/finished |
| `model.changed` | `{text, by}` | the text/vision model changed (by `model.set` from here, or `by: "troy"` when Troy switched its own model mid-chat) — refresh pickers; toast when `by === "troy"` |
| `confirmation.request` | `{id, name, arg, risk_level, description}` | a risky action needs a real approve/cancel click — render a prompt, then call `confirmation.resolve` |
| `confirmation.resolved` | `{id, approved, result}` | that prompt was just resolved (by this window or another) — dismiss the prompt if still shown |
| `wake_listener.state` | `{state}` | mic status changed — drive a colored indicator |
| `ui.command` | `{action, ...}` | Troy's own tools driving the UI: `mode` (`widget`/`app`/`hidden`/`toggle`), `view` (`view`, `pane`), `appearance` (`key`: theme/accent/layout, `value`), `widget_option`, `new_chat`. `main.js` carries out the window-level ones; the renderers do the rest |
| `ui.mode` | `{mode}` | which surface is showing: `widget`, `app` or `hidden` (from `main.js`) |
| `widget.options` | `{onTop, autoCollapse, hotkey, ...}` | a widget option changed (here, in Settings, or by Troy) |
| `power.state` | `{mode, on_battery, active}` | power saving became active/inactive (renderers toggle `body.saver`, set `face.setOptions({saver})`) |
| `task.changed` / `task.deleted` | `{task}` / `{id}` | any task was created, edited or changed state / removed |
| `task.started` / `task.retrying` | `{task}` / `{task, error, attempt}` | a run began / failed and will be retried |
| `task.step` | `{id, name, arg, success, message}` | a tool ran during a scheduled run |
| `task.finished` | `{task, ok, text, kind, session_id, in_current_chat, entry}` | a run ended for good (`kind` `finished` or `missed`); `entry` is the `role: "task"` note already saved in the chat that created it — render it live only when `in_current_chat` |
| `backend.stderr` | `{text}` | raw stderr line from the Python process (debugging aid; the backend's own file logger at `troy_logs/troy.log` is the durable record) |
| `backend.exited` | `{code, signal}` | the Python process died — nothing else will work until the app is restarted |

## Design notes for whoever builds the real UI on top of this

- Everything above already works against the real backend — this is not
  a mock/stub to later "wire up for real."
- `chat.send` is fire-and-forget on purpose: a turn can run many steps
  and take a while, so the UI should show a "Troy is thinking/typing"
  state (`agent.state`) and stream in `agent.speak`/`agent.tool_result`
  events as they arrive, not block waiting for `chat.send`'s own result.
- A `confirmation.request` can arrive **in the middle of a turn**, at any
  time chat is otherwise idle-looking — always keep a listener mounted
  for it, not just while a turn is visibly running.
- `session.load`'s `display_log` is the friendly, human-facing transcript
  (separate from what's actually replayed to the model) — safe to render
  directly.
