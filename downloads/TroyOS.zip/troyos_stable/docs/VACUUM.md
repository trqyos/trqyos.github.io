# Xiaomi Robot Vacuum S20+ with Troy

Troy can start, pause, stop and dock your **Xiaomi Robot Vacuum S20+** (`xiaomi.vacuum.b108gl`), clean named rooms,
change suction / mop water / mode, find the robot, and tell you its status, battery and brush life — by voice, chat,
the widget, the phone page, or a scheduled task ("every weekday at 10:00 start the vacuum").

It talks to the robot **directly over your home Wi-Fi** (local MIoT protocol, UDP port 54321). No cloud account is used
while running; you only need the cloud **once** to read the robot's device token.

> **Honest status.** This was built from the published S20+ protocol spec and the experience of other S20+ owners
> (sources at the bottom), and tested against a faithful fake robot plus a byte-level cross-check with `python-miio`.
> It has **not** been run against a physical S20+ by its author. Most commands are well documented; **room cleaning** is
> the one S20+ feature that different projects report differently, so Troy verifies it actually worked (see
> [Room cleaning](#room-cleaning)). If something misbehaves, section [Troubleshooting](#troubleshooting) says what to send me.

---

## 1. What you need

| Thing | Notes |
|---|---|
| Robot set up in the **Xiaomi Home** app | Same Wi-Fi network (2.4 GHz) as the PC. Not a guest network. |
| The robot's **IP address** | Troy can find it for you (step 3), or read it in your router's device list. |
| The robot's **device token** | 32 hex characters. One-time, step 2. |
| Troy | No new Python packages: the protocol client only uses `cryptography`, already in `requirements.txt`. |

Tip: give the robot a **fixed IP** (DHCP reservation in your router) so the address never changes.

## 2. Getting the token (one time)

The token is a secret that lets anyone on your network control the robot. Troy stores it on this PC only (in
`troy_settings.json`, like your API keys) and never shows it again after you save it.

Use the community-maintained **Xiaomi Cloud Tokens Extractor** (`github.com/PiotrMachowski/Xiaomi-cloud-tokens-extractor`):

1. Download `token_extractor.exe` from its Releases page (Windows), or run `python token_extractor.py` after
   `pip install -r requirements.txt`.
2. Log in with your **Xiaomi Home** account (the one the robot is in; *not* a Roborock account). It supports password
   login with 2FA/captcha handling and a **QR-code login** — use the QR option if the password login is refused.
3. Choose your region server (or leave it empty to check all). Find the entry named like your robot
   (model `xiaomi.vacuum.b108gl`) and copy its **TOKEN** (32 characters) and its **IP**.

If the token is 96 characters long it is the Bluetooth key, not the Wi-Fi token; Troy will tell you.

**Resetting the robot's Wi-Fi in the app generates a new token** — if Troy suddenly says "wrong token", extract it again.

## 3. Set it up in Troy

**Settings › Integrations › Robot vacuum** (Ayarlar › Entegrasyonlar › Robot süpürge):

1. Press **Find on network** → pick your robot's address (or type the IP).
2. Paste the **device token** → **Save**.
3. Turn on **Use the robot vacuum**.
4. Press **Test connection**. You should see something like
   `Connected to xiaomi.vacuum.b108gl (firmware 4.5.x); it is charging on the dock, battery 87%.`

Prefer a file? Put this in `.env` instead (the Settings screen overrides it):

```
TROY_VACUUM_ENABLED=true
TROY_VACUUM_HOST=192.168.1.50
TROY_VACUUM_TOKEN=00112233445566778899aabbccddeeff
```

### Test from the command line (no need to start Troy)

```
python -m troy.vacuum_cli discover          # find robots on the LAN
python -m troy.vacuum_cli test --host 192.168.1.50 --token <32 hex chars>
python -m troy.vacuum_cli status
python -m troy.vacuum_cli rooms
python -m troy.vacuum_cli start | pause | resume | stop | dock | locate
python -m troy.vacuum_cli clean "kitchen, hall"
python -m troy.vacuum_cli set suction strong
python -m troy.vacuum_cli get 2 1 3 1       # raw property read (siid piid ...), for diagnosis
```

## 4. Using it

Just ask Troy, in English or Turkish:

| Say | Troy does |
|---|---|
| "Start the vacuum" / "Süpürgeyi çalıştır" | whole-home clean (resumes if it was paused) |
| "Clean the kitchen and the hallway" / "Mutfağı ve salonu temizle" | room clean |
| "Mop the whole house" | `vacuum_start` with mode `mop` (needs the mop pad attached) |
| "Pause it" / "Stop" / "Send it home" | pause / stop / back to the dock |
| "Where is the robot?" | makes it announce itself |
| "Set suction to max", "Mop water low", "Sweep then mop" | settings |
| "What's the vacuum doing?", "Are the brushes worn?" | status / consumables |
| "Start the vacuum every weekday at 10:00" | a scheduled task (works unattended: no approval card is needed) |

### The tools (11)

| Tool | Purpose |
|---|---|
| `vacuum_status` | state, battery, area/time, current settings, faults |
| `vacuum_rooms` | rooms on the map (names, ids, each room's saved settings) |
| `vacuum_consumables` | brush / filter / mop-pad life |
| `vacuum_start [mode]` | whole-home clean; mode: `sweep`, `mop`, `sweep_mop`, `sweep_then_mop` |
| `vacuum_clean_rooms <rooms>` | clean the named rooms (comma-separated) |
| `vacuum_pause` / `vacuum_resume` / `vacuum_stop` | pause, continue, stop |
| `vacuum_dock` | return to the dock |
| `vacuum_locate` | make the robot announce itself |
| `vacuum_set <setting>\|<value>` | `suction` silent/standard/strong/max · `mop_water` off/low/medium/high · `mode` · `passes` 1/2 · `volume` 0-100 |

Design decisions worth knowing:

* **Commands report what actually happened.** The S20+ answers "OK" even to commands it ignores, so Troy re-reads the
  robot's state afterwards and tells you the truth ("sent start, but the robot is still charging — it reports fault
  210009").
* **No approval cards** for these tools: starting a vacuum is harmless and reversible, and cards would block scheduled
  runs. Changing the *robot's address or on/off switch* via Troy **does** need your approval, and the token can only be
  entered by you in Settings.
* **No "reset consumable" tool** on purpose: the S20+'s three "brush" services share a name in its spec; the labels Troy
  shows (main brush / side brush / filter / mop pad) follow the spec's service order but are unconfirmed. Resetting the
  wrong counter would be silent, so do that in the Xiaomi Home app.

## Room cleaning

Rooms are cleaned with the settings you saved for each room in the Xiaomi Home app (Troy lists them in `vacuum_rooms`).
Room names match flexibly and Turkish-aware (`mutfak`, `Mutfak`, `MUTFAK`, `cocuk` → `Çocuk Odası`).

The S20+'s room command has been reported working in **three different payload encodings** by different projects. Troy
knows four (`json_tagged`, `json`, `csv`, `csv_tagged`). In **Automatic** mode it tries them in order, and accepts one only
when the robot really enters *selected-room* cleaning (two consecutive status reads). If the robot instead starts a
whole-home clean by mistake, Troy stops it and sends it home. The encoding that worked is saved
(`VACUUM_ROOM_ENCODING`, Settings › Integrations › Robot vacuum › Advanced), so later requests are instant.

If none works, Troy says so and you can still start the room from the app. Please open an issue with the output of
`python -m troy.vacuum_cli get 2 1 2 4` right after starting a room clean in the app.

## Troubleshooting

| Message | Meaning / fix |
|---|---|
| "The robot at … didn't answer" | Wrong IP, robot offline/asleep, different network, or UDP 54321 blocked. Run `vacuum_cli discover`. |
| "reachable but ignored the request… wrong token" | A real S20+ silently drops packets with a bad token. Re-extract the token (it changes if you re-pair the robot). |
| "isn't set up yet" / "turned off" | Fill the IP + token and flip the switch (step 3). |
| "didn't answer in time" on a command | Busy robots sometimes don't acknowledge; Troy checks the state anyway. Retry once. |
| Start says "robot is charging, not cleaning" + fault code | Stuck, bin/tank missing, or battery too low — check the robot. |
| Mop mode refused | The robot reports no mop pad attached (it silently reverts mop modes otherwise). |

Logs: **Logs** screen (look for `Vacuum:`). Never share your token when asking for help.

## Language

Settings › General › **Language** switches the whole interface (app, widget, phone page, tray menu) between English and
Türkçe (or "Automatic" to follow the system). Troy's replies already follow the language you write or speak in.
Switching reloads the window; your chat is restored. See `electron/renderer/i18n-tr.js` to improve or add translations
(`i18n.js` explains the format; phone copies live in `troy/web/phone/` and a test keeps them in sync).

## How it works (for developers)

```
tools_vacuum.py   11 thin tools (registry + schemas)
vacuum.py         S20+ property/action table, state-verified commands, room matching, encoding fallback
miot_client.py    encrypted miIO UDP client (AES-128-CBC, MD5 key/iv/checksum): ~200 lines, no third-party protocol lib
vacuum_cli.py     setup/diagnostic CLI
```

* S20+ addresses (siid/piid/aiid): status `2/1`, fault `2/2`, mode `2/3`, sweep-type `2/4`, area `2/5` (hundredths of m²),
  time `2/6`, passes `2/7`, suction `2/8`, mop water `2/9`, battery `3/1`, volume `4/2`, mop-attached `6/1`, room-info
  `6/10`; actions start `2/1`, stop `2/2`, pause `2/6`, room-sweep `2/13`, resume `6/1`, locate `6/6`, dock `3/1`.
  These differ from the X20 Max table in the Home Assistant integration; nothing was borrowed from that table.
* Why not `python-miio`? Heavy, fragile on new Python versions. The wire format is verified byte-for-byte against it in
  `tests/test_miot_client.py`.
* Tests: `tests/test_miot_client.py` (real UDP fake robot), `tests/test_vacuum.py` (stateful fake S20+),
  `tests/test_tools_vacuum.py`, `tests/test_i18n.py`; UI: `electron/test/i18n-smoke.js`.

### Sources

* roquerodrigo/ha-xiaomi-vacuum and its API notes (local MIoT + QR/cloud design; S20+ room-clean via cloud note)
* openHAB community thread "Xiaomi Robot Vacuum S20+ (xiaomi.vacuum.b108gl)" (spec, verified room action `2/13`)
* callemand/gladys-xiaomi-home PR #10 (verified on a real S20+: commands, dock `3/1`, area units, handshake timeouts)
* merdok/homebridge-miot issue #762 (S20+ locate `6/6`, modes, suction levels)
* PiotrMachowski/Xiaomi-cloud-tokens-extractor (token retrieval)

## Ideas not done yet

Live map picture (needs the cloud map download), per-room setting changes, DND schedule, consumable reset (once the
service mapping is confirmed on hardware), and a cloud fallback for room cleaning.
