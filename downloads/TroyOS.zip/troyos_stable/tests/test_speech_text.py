import pytest

from troy.speech_text import clean_for_speech as clean, is_end_phrase, is_stop_phrase, looks_like_noise, split_sentences


def test_markdown_becomes_plain_speech():
    out = clean("Here's the outlook for **London**:\n\n- **Mon** \u2014 partly cloudy, 9-17\u00B0C\n- Tue \u2014 rain\n\nTake an *umbrella* \U0001F327\uFE0F")
    assert "**" not in out and "- " not in out and "\U0001F327" not in out
    assert "9 to 17 degrees Celsius" in out and "London" in out and "umbrella" in out and "\n" not in out


def test_links_paths_and_code_are_not_read_out_character_by_character():
    assert clean("Open https://www.youtube.com/watch?v=dQw4w9WgXcQ now") == "Open youtube.com now"
    assert clean("See [the docs](https://example.com/very/long/path) please") == "See the docs please"
    assert clean(r"Saved to C:\Users\alex\Documents\report.docx") == "Saved to report.docx"
    assert clean("Run `pip install x` first") == "Run pip install x first"
    assert "put the code on screen" in clean("Here:\n```python\nprint(1)\n```\nDone")


def test_numbers_and_symbols():
    assert clean("CPU 12% & RAM 41%") == "CPU 12 percent and RAM 41 percent"
    assert clean("1. First\n2. Second") == "First. Second"
    assert clean("") == "" and clean(None) == ""


def test_sentence_splitting_respects_abbreviations_and_decimals():
    assert split_sentences("Dr. Smith paid 3.5 dollars. It was fine! Really?") == ["Dr. Smith paid 3.5 dollars.", "It was fine!", "Really?"]
    assert split_sentences("e.g. this one. And that.") == ["e.g. this one.", "And that."]
    long = ("word " * 120).strip() + "."
    parts = split_sentences(long, max_chars=100)
    assert len(parts) > 3 and all(len(p) <= 101 for p in parts) and " ".join(parts).replace(" ", "") == long.replace(" ", "")
    assert split_sentences("  ") == []


@pytest.mark.parametrize("text", ["goodbye", "That's all.", "Okay, stop listening", "thanks troy that's all", "end voice mode", "Go to sleep!"])
def test_end_phrases(text):
    assert is_end_phrase(text)


@pytest.mark.parametrize("text", ["open firefox", "what's the weather like in goodbye street", "stop the music and play jazz please now"])
def test_not_end_phrases(text):
    assert not is_end_phrase(text)


@pytest.mark.parametrize("text", ["stop", "Troy, stop!", "never mind", "cancel that", "be quiet", "stop talking please", "okay stop"])
def test_stop_phrases(text):
    assert is_stop_phrase(text)


def test_stop_phrase_is_only_for_short_interruptions():
    assert not is_stop_phrase("stop the download and open settings") and not is_stop_phrase("open firefox")


def test_noise_filter():
    assert looks_like_noise("you") and looks_like_noise(" . ") and looks_like_noise("Thank you for watching")
    assert not looks_like_noise("open firefox")
