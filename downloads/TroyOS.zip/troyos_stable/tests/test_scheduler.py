"""The scheduler: persistence, retries, missed runs, restart recovery, cancellation, logs -- with a fake clock and executor."""
import json
import threading
import time
from datetime import datetime, timedelta

import pytest

from troy import config, scheduler as sch
from troy.schedule_spec import ScheduleError
from troy.scheduler import Outcome


class Clock:
    def __init__(self, now): self.now = now
    def __call__(self): return self.now
    def advance(self, **kw): self.now += timedelta(**kw)


T0 = datetime(2026, 10, 19, 21, 59, 0)


@pytest.fixture
def env(tmp_path):
    class E: pass
    e = E()
    e.clock, e.events, e.runs = Clock(T0), [], []
    e.script = []                                    # outcomes the fake executor hands out, in order

    def executor(task, run):
        e.runs.append({"id": task["id"], "attempt": run.attempt, "done": list(run.done_actions), "last_error": run.last_error})
        out = e.script.pop(0) if e.script else Outcome("done", summary="ok")
        return out

    def make():
        return sch.Scheduler(executor=executor, on_event=lambda n, p: e.events.append(n), clock=e.clock,
                             tasks_file=str(tmp_path / "t.json"), log_file=str(tmp_path / "t.jsonl"))
    e.make, e.s = make, make()
    e.names = lambda: e.events
    return e


# ---------------------------------------------------------------- creating
def test_add_computes_the_next_run_and_persists(env):
    t = env.s.add("Put the computer to sleep.", "every day at 22:00", title="Sleep PC")
    assert t["status"] == "scheduled" and t["next_run"] == "2026-10-19T22:00:00" and t["schedule_text"] == "Every day at 22:00"
    again = env.make()                               # a "restart": a new instance reads the same file
    assert again.get(t["id"])["prompt"] == "Put the computer to sleep."


def test_add_rejects_empty_past_and_unparseable(env):
    with pytest.raises(ValueError):
        env.s.add("  ", "in 5 minutes")
    with pytest.raises(ScheduleError):
        env.s.add("x", "2026-10-18 09:00")
    with pytest.raises(ScheduleError):
        env.s.add("x", "whenever")
    assert env.s.list() == []


def test_title_defaults_to_the_instruction(env):
    t = env.s.add("Open the quarterly report and print it " * 3, "in 5 minutes")
    assert t["title"].endswith("\u2026") and len(t["title"]) <= 61


def test_chat_link_comes_from_the_context_provider(env):
    env.s.context_provider = lambda: {"session_id": "abc", "message_index": 7}
    t = env.s.add("x", "in 5 minutes")
    assert t["session_id"] == "abc" and t["message_index"] == 7


# ---------------------------------------------------------------- running
def test_a_one_time_task_runs_once_then_completes(env):
    t = env.s.add("Say hi", "in 1 minutes")
    assert env.s.tick() is None                      # not due yet
    env.clock.advance(minutes=1)
    assert env.s.tick() == t["id"]
    got = env.s.get(t["id"])
    assert got["status"] == "completed" and got["last_outcome"] == "success" and got["next_run"] is None and got["run_count"] == 1
    assert env.s.tick() is None and len(env.runs) == 1
    assert "started" in env.events and "finished" in env.events


def test_a_recurring_task_goes_back_to_scheduled(env):
    t = env.s.add("Back up", "every day at 22:00")
    env.clock.now = datetime(2026, 10, 19, 22, 0, 5)
    env.s.tick()
    got = env.s.get(t["id"])
    assert got["status"] == "scheduled" and got["next_run"] == "2026-10-20T22:00:00" and got["run_count"] == 1


def test_nothing_runs_without_an_executor_call_until_due(env):
    env.s.add("x", "in 10 minutes")
    for _ in range(3):
        assert env.s.tick() is None
    assert env.runs == []


def test_tasks_run_one_at_a_time_in_due_order(env):
    a = env.s.add("first", "in 1 minutes")
    b = env.s.add("second", "in 2 minutes")
    env.clock.advance(minutes=5)
    assert env.s.tick() == a["id"] and env.s.tick() == b["id"] and env.s.tick() is None


# ---------------------------------------------------------------- retries
def test_a_failed_attempt_is_retried_after_the_delay_then_succeeds(env, monkeypatch):
    monkeypatch.setattr(config, "TASK_MAX_RETRIES", 2)
    monkeypatch.setattr(config, "TASK_RETRY_DELAY_SECONDS", 30)
    t = env.s.add("flaky", "in 1 minutes")
    env.clock.advance(minutes=1)
    env.script = [Outcome("retry", error="network down"), Outcome("done", summary="worked")]
    env.s.tick()
    mid = env.s.get(t["id"])
    assert mid["status"] == "retrying" and mid["next_run"] == (env.clock.now + timedelta(seconds=30)).replace(microsecond=0).isoformat()
    assert env.s.tick() is None                      # the delay hasn't elapsed
    env.clock.advance(seconds=31)
    env.s.tick()
    done = env.s.get(t["id"])
    assert done["status"] == "completed" and done["last_summary"] == "worked"
    assert [r["attempt"] for r in env.runs] == [1, 2] and env.runs[1]["last_error"] == "network down"
    assert "retrying" in env.events


def test_retries_are_limited_and_the_final_failure_is_reported(env, monkeypatch):
    monkeypatch.setattr(config, "TASK_MAX_RETRIES", 1)
    monkeypatch.setattr(config, "TASK_RETRY_DELAY_SECONDS", 5)
    t = env.s.add("never works", "in 1 minutes")
    env.clock.advance(minutes=1)
    env.script = [Outcome("retry", error="e1"), Outcome("retry", error="e2")]
    env.s.tick()
    env.clock.advance(seconds=6)
    env.s.tick()
    got = env.s.get(t["id"])
    assert got["status"] == "failed" and got["fail_count"] == 1 and "e2" in got["last_error"] and "gave up after 2 attempts" in got["last_error"]
    assert len(env.runs) == 2
    assert [e for e in env.events if e == "finished"] == ["finished"]


@pytest.mark.parametrize("status", ["blocked", "stopped"])
def test_blocked_and_stopped_runs_are_not_retried(env, status):
    t = env.s.add("x", "in 1 minutes")
    env.clock.advance(minutes=1)
    env.script = [Outcome(status, error="nope")]
    env.s.tick()
    assert env.s.get(t["id"])["status"] == "failed" and len(env.runs) == 1


def test_a_failing_recurring_task_keeps_its_schedule(env):
    t = env.s.add("x", "every day at 22:00")
    env.clock.now = datetime(2026, 10, 19, 22, 0, 1)
    env.script = [Outcome("blocked", error="no")]
    env.s.tick()
    got = env.s.get(t["id"])
    assert got["status"] == "scheduled" and got["last_outcome"] == "failed" and got["next_run"] == "2026-10-20T22:00:00"


def test_per_task_retry_settings_override_the_defaults(env, monkeypatch):
    monkeypatch.setattr(config, "TASK_MAX_RETRIES", 5)
    t = env.s.add("x", "in 1 minutes", max_retries=0)
    env.clock.advance(minutes=1)
    env.script = [Outcome("retry", error="e")]
    env.s.tick()
    assert env.s.get(t["id"])["status"] == "failed" and len(env.runs) == 1


def test_actions_that_already_succeeded_are_handed_to_the_next_attempt(env, monkeypatch):
    monkeypatch.setattr(config, "TASK_RETRY_DELAY_SECONDS", 5)
    recorded = []

    def executor(task, run):
        recorded.append([a["name"] for a in run.done_actions])
        if run.attempt == 1:
            run.record_action("copy_file", "a|b", "copied")
            return Outcome("retry", error="second step failed")
        return Outcome("done", summary="finished")
    s = sch.Scheduler(executor=executor, clock=env.clock, tasks_file=str(env.s._tasks_file), log_file=str(env.s._log_file))
    t = s.add("two steps", "in 1 minutes")
    env.clock.advance(minutes=1)
    s.tick()
    env.clock.advance(seconds=6)
    s.tick()
    assert recorded == [[], ["copy_file"]]
    assert s.get(t["id"])["status"] == "completed"


def test_a_crashing_executor_counts_as_a_failed_attempt(env):
    def boom(task, run): raise RuntimeError("kaboom")
    env.s.executor = boom
    t = env.s.add("x", "in 1 minutes")
    env.clock.advance(minutes=1)
    env.s.tick()
    got = env.s.get(t["id"])
    assert got["status"] == "retrying" and "kaboom" in got["last_error"]


# ---------------------------------------------------------------- missed runs and restarts
def test_a_task_due_while_off_runs_if_within_the_grace_period(env, monkeypatch):
    monkeypatch.setattr(config, "TASK_MISSED_GRACE_MINUTES", 10)
    t = env.s.add("x", "in 1 minutes")
    env.clock.advance(minutes=8)
    assert env.s.tick() == t["id"]


def test_a_one_time_task_long_overdue_is_marked_missed_not_run(env, monkeypatch):
    monkeypatch.setattr(config, "TASK_MISSED_GRACE_MINUTES", 10)
    t = env.s.add("sleep", "in 1 minutes")
    env.clock.advance(hours=7)                       # the PC was asleep all night
    assert env.s.tick() is None and env.runs == []
    got = env.s.get(t["id"])
    assert got["status"] == "missed" and got["last_outcome"] == "missed" and "off" in got["last_summary"]
    assert "missed" in env.events


def test_a_recurring_task_skips_the_missed_occurrence_and_waits_for_the_next(env):
    t = env.s.add("x", "every day at 22:00")
    env.clock.now = datetime(2026, 10, 20, 7, 0, 0)
    assert env.s.tick() is None
    got = env.s.get(t["id"])
    assert got["status"] == "scheduled" and got["next_run"] == "2026-10-20T22:00:00" and got["last_outcome"] == "missed"


def _recover_without_thread(sched):
    """What start() does on a restart, minus the background loop: that loop can pick the retried task up
    (and run it) before the test looks, which made these tests flaky."""
    sched._ensure_loaded()
    with sched._cond:
        sched._recover_locked()


def test_a_run_interrupted_by_a_shutdown_continues_as_a_retry_with_its_progress(env):
    t = env.s.add("x", "in 1 minutes")
    env.clock.advance(minutes=1)
    with env.s._cond:
        env.s._start_locked(env.s._tasks[t["id"]], env.clock.now)        # it started...
    env.s.executor = None
    env.s._record_action(t["id"], "copy_file", "a|b", "copied")           # ...did one thing...
    restarted = env.make()                                                 # ...and Troy was closed
    _recover_without_thread(restarted)
    got = restarted.get(t["id"])
    assert got["status"] == "retrying" and got["run"]["attempt"] == 2 and got["run"]["done_actions"][0]["name"] == "copy_file"
    assert any(e["event"] == "interrupted" for e in restarted.logs(t["id"]))


def test_an_interrupted_run_with_no_retries_left_fails(env, monkeypatch):
    monkeypatch.setattr(config, "TASK_MAX_RETRIES", 0)
    t = env.s.add("x", "in 1 minutes")
    env.clock.advance(minutes=1)
    with env.s._cond:
        env.s._start_locked(env.s._tasks[t["id"]], env.clock.now)
    restarted = env.make()
    _recover_without_thread(restarted)
    assert restarted.get(t["id"])["status"] == "failed"


def test_a_corrupt_task_file_is_set_aside_not_fatal(env):
    env.s.add("x", "in 5 minutes")
    open(env.s._tasks_file, "w").write("{not json")
    fresh = env.make()
    assert fresh.list() == []
    assert any("corrupt" in p.name for p in __import__("pathlib").Path(env.s._tasks_file).parent.iterdir())


# ---------------------------------------------------------------- user control
def test_cancel_modify_pause_resume_and_delete(env):
    t = env.s.add("x", "every day at 22:00")
    paused = env.s.pause(t["id"])
    assert paused["status"] == "paused" and paused["next_run"] is None
    env.clock.advance(days=2)
    assert env.s.tick() is None                      # a paused task never fires
    resumed = env.s.resume(t["id"])
    assert resumed["status"] == "scheduled" and resumed["next_run"] == "2026-10-21T22:00:00"   # no catch-up
    changed = env.s.modify(t["id"], when="every monday at 9am", title="Weekly", prompt="Do the weekly thing")
    assert changed["schedule_text"] == "Every Monday at 09:00" and changed["title"] == "Weekly" and changed["prompt"] == "Do the weekly thing"
    assert env.s.cancel(t["id"])["status"] == "cancelled"
    with pytest.raises(ValueError):
        env.s.cancel(t["id"])
    assert env.s.delete(t["id"]) is True and env.s.get(t["id"]) is None


def test_modifying_the_instruction_clears_approvals(env):
    t = env.s.add("sleep", "in 5 minutes", grants=["sleep_computer"])
    assert env.s.get(t["id"])["grants"] == ["sleep_computer"]
    assert env.s.modify(t["id"], title="renamed")["grants"] == ["sleep_computer"]
    assert env.s.modify(t["id"], prompt="shut down instead")["grants"] == []


def test_a_finished_task_comes_back_when_given_a_new_time(env):
    t = env.s.add("x", "in 1 minutes")
    env.clock.advance(minutes=1)
    env.s.tick()
    assert env.s.get(t["id"])["status"] == "completed"
    assert env.s.modify(t["id"], when="in 10 minutes")["status"] == "scheduled"


def test_run_now_runs_a_task_immediately_and_keeps_the_recurring_schedule(env):
    t = env.s.add("x", "every day at 22:00")
    env.s.run_now(t["id"])
    assert env.s.tick() == t["id"]
    got = env.s.get(t["id"])
    assert got["status"] == "scheduled" and got["next_run"] == "2026-10-19T22:00:00" and got["run_count"] == 1


def test_cancelling_a_running_task_stops_it_and_it_stays_cancelled(env):
    stopped = []
    env.s.stop_current = lambda: stopped.append(1)
    gate = threading.Event()

    def executor(task, run):
        env.s.cancel(task["id"])                     # the user cancels while it is running
        return Outcome("retry", error="stopped")
    env.s.executor = executor
    t = env.s.add("x", "in 1 minutes")
    env.clock.advance(minutes=1)
    env.s.tick()
    assert env.s.get(t["id"])["status"] == "cancelled" and stopped == [1]


def test_a_running_task_cannot_be_deleted_or_edited(env):
    t = env.s.add("x", "in 1 minutes")
    env.clock.advance(minutes=1)
    seen = {}

    def executor(task, run):
        for fn in (lambda: env.s.delete(task["id"]), lambda: env.s.modify(task["id"], title="no")):
            with pytest.raises(ValueError):
                fn()
        seen["ok"] = True
        return Outcome("done")
    env.s.executor = executor
    env.s.tick()
    assert seen["ok"]


def test_resolve_by_id_prefix_and_title(env):
    a = env.s.add("x", "in 5 minutes", title="Backup photos")
    env.s.add("y", "in 6 minutes", title="Backup music")
    assert env.s.resolve(a["id"])["id"] == a["id"]
    assert env.s.resolve("photos")["id"] == a["id"]
    with pytest.raises(LookupError, match="matches 2"):
        env.s.resolve("backup")
    with pytest.raises(LookupError):
        env.s.resolve("nothing")


def test_grant_records_the_approval_and_clears_the_pending_request(env):
    t = env.s.add("x", "in 5 minutes")
    env.s._tasks[t["id"]]["needs_approval"] = ["sleep_computer"]
    got = env.s.grant(t["id"], ["sleep_computer"])
    assert got["grants"] == ["sleep_computer"] and got["needs_approval"] == []


# ---------------------------------------------------------------- logs and the background thread
def test_every_step_is_logged(env):
    t = env.s.add("x", "in 1 minutes")
    env.clock.advance(minutes=1)
    env.s.tick()
    events = [e["event"] for e in env.s.logs(t["id"])]
    assert events == ["created", "started", "success"]
    assert env.s.logs("other") == []
    line = open(env.s._log_file).readline()
    assert json.loads(line)["task_id"] == t["id"]


def test_the_background_thread_runs_a_due_task_without_polling_the_model(tmp_path):
    done = threading.Event()
    calls = []

    def executor(task, run):
        calls.append(task["id"])
        done.set()
        return Outcome("done", summary="ok")
    s = sch.Scheduler(executor=executor, tasks_file=str(tmp_path / "t.json"), log_file=str(tmp_path / "l.jsonl"))
    # +2s, because the due time is truncated to whole seconds: +1s could really be only ~0.1s away
    t = s.add("x", {"kind": "once", "at": (datetime.now() + timedelta(seconds=2)).isoformat()})
    s.start()
    assert not done.wait(0.3) and calls == []        # idle until it is due
    assert done.wait(5) and calls == [t["id"]]
    end = time.time() + 2
    while s.get(t["id"])["status"] != "completed" and time.time() < end:
        time.sleep(0.02)
    assert s.get(t["id"])["status"] == "completed"
    s.stop()


def test_adding_a_task_wakes_the_sleeping_thread(tmp_path):
    done = threading.Event()
    s = sch.Scheduler(executor=lambda t, r: (done.set(), Outcome("done"))[1], tasks_file=str(tmp_path / "t.json"), log_file=str(tmp_path / "l.jsonl"))
    s.start()
    time.sleep(0.1)                                   # nothing scheduled: it is waiting
    s.add("x", {"kind": "once", "at": (datetime.now() + timedelta(seconds=1)).isoformat()})
    assert done.wait(4)
    s.stop()
