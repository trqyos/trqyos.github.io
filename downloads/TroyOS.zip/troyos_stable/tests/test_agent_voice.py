"""Streaming early speech and the spoken reply style."""
import pytest

from troy import agent as agent_mod, config, dispatcher, llm_client


class Script:
    """A fake llm_client.chat that streams its reply in small chunks."""
    def __init__(self, *replies): self.replies, self.calls, self.prompts = list(replies), 0, []
    def __call__(self, messages, stop_check=None, on_text=None):
        self.prompts.append(messages[2]["content"])
        text = self.replies[self.calls]; self.calls += 1
        if on_text:
            on_text("")
            for i in range(1, len(text) + 1, 3):
                on_text(text[:i])
            on_text(text)
        return text


@pytest.fixture
def troy(monkeypatch):
    spoken, events = [], []
    a = agent_mod.TroyAgent(on_speak=spoken.append, on_state=lambda s, d="": events.append((s, d)), on_tool_result=lambda *x: None)
    monkeypatch.setattr(config, "VOICE_SPOKEN_STYLE", True)
    monkeypatch.setattr(dispatcher, "execute", lambda name, arg: {"is_speech": True, "message": arg} if name == "speak" else {"is_done": True} if name == "done" else {"success": True, "message": "ok"})
    a.spoken, a.events = spoken, events
    return a


def test_the_opening_speak_line_is_said_before_the_reply_finishes(troy, monkeypatch):
    when = {}
    original = troy.on_speak
    def on_speak(t): when.setdefault("at", troy._streamed_chars); original(t)
    troy.on_speak = on_speak
    script = Script("speak:On it.\nopen_app:firefox\nspeak:Firefox is open.\ndone\n")
    def chat(messages, stop_check=None, on_text=None):
        def tap(text):
            troy._streamed_chars = len(text); on_text(text)
        return script(messages, stop_check, tap)
    monkeypatch.setattr(llm_client, "chat", chat)
    troy.handle_user_input("open firefox")
    assert troy.spoken == ["On it.", "Firefox is open."]            # each exactly once
    assert when["at"] < len("speak:On it.\nopen_app:firefox\nspeak:Firefox is open.\ndone\n") - 20     # spoken mid-stream


def test_nothing_is_spoken_early_after_an_action_command(troy, monkeypatch):
    monkeypatch.setattr(llm_client, "chat", Script("get_system_stats\nspeak:Busy.\ndone\n", "speak:Done.\ndone\n"))
    seen_early = []
    orig = troy._early_speak
    troy._early_speak = lambda early, text: (orig(early, text), seen_early.append(list(early["spoken"])))
    troy.handle_user_input("cpu?")
    assert all(s == [] for s in seen_early[:len(seen_early) // 2 + 1]) and troy.spoken[-1] == "Done."


def test_a_restarted_stream_does_not_repeat_itself(troy, monkeypatch):
    early = {"pos": 0, "spoken": [], "blocked": False}
    troy._early_speak(early, "speak:Hello there.\nopen")
    troy._early_speak(early, "")                                  # the first model failed; another one starts over
    troy._early_speak(early, "speak:Hello there.\ndone\n")
    assert troy.spoken == ["Hello there."]


def test_reasoning_blocks_are_never_spoken(troy):
    early = {"pos": 0, "spoken": [], "blocked": False}
    troy._early_speak(early, "<think>speak:no\n")
    troy._early_speak(early, "<think>speak:no\n</think>\nspeak:Hi.\n")
    assert troy.spoken == []


def test_voice_turns_ask_for_short_spoken_replies(troy, monkeypatch):
    script = Script("speak:Hi.\ndone\n", "speak:Hi.\ndone\n")
    monkeypatch.setattr(llm_client, "chat", script)
    troy.handle_user_input("hello", source="typed")
    troy.handle_user_input("hello", source="voice")
    assert "VOICE:" not in script.prompts[0] and "VOICE:" in script.prompts[1]
    troy.voice_forced = True
    monkeypatch.setattr(llm_client, "chat", Script("speak:Hi.\ndone\n"))
    troy.handle_user_input("typed during voice mode", source="typed")
    assert troy.voice_style is True
    monkeypatch.setattr(config, "VOICE_SPOKEN_STYLE", False)
    assert "VOICE:" not in troy._build_context_message("x")["content"]
