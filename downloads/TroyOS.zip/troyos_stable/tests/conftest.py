"""
Shared pytest fixtures.

Two jobs:
1. Install a minimal pyautogui stub when there's no real display (this CI/
   dev-container environment) so the whole `troy` package can still import
   -- on a real Windows machine with a real pyautogui installed, this is a
   no-op and the real thing is used untouched.
2. Redirect every persistent-storage path (sessions, memory, logs) to a
   fresh temp directory per test, so the test suite never reads or writes
   the actual project's troy_sessions/troy_memory.json and tests can't
   bleed state into each other.
"""

import os
import sys
import types

import pytest


def _install_pyautogui_stub_if_needed():
    try:
        import pyautogui  # noqa: F401
        return
    except Exception:
        pass

    stub = types.ModuleType("pyautogui")
    stub.FAILSAFE = True

    class _FakeImage:
        size = (1920, 1080)
        def save(self, *a, **k): pass
        def convert(self, *a, **k): return self
        def resize(self, *a, **k): return self
        def getdata(self): return [(0, 0, 0)] * 100

    stub.screenshot = lambda *a, **k: _FakeImage()
    stub.size = lambda: (1920, 1080)
    stub.position = lambda: (0, 0)
    stub.pixel = lambda *a, **k: (0, 0, 0)
    for name in ("click", "moveTo", "scroll", "typewrite", "press", "hotkey",
                 "doubleClick", "rightClick", "dragTo", "mouseDown", "mouseUp",
                 "keyDown", "keyUp"):
        setattr(stub, name, lambda *a, **k: None)
    sys.modules["pyautogui"] = stub


_install_pyautogui_stub_if_needed()

# Project root must be importable as `troy` regardless of where pytest is
# invoked from.
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))


@pytest.fixture
def isolated_storage(tmp_path, monkeypatch):
    """Points every persistent-storage path at a fresh temp directory for
    the duration of one test."""
    from troy import config

    sessions_dir = tmp_path / "troy_sessions"
    memory_file = tmp_path / "troy_memory.json"

    monkeypatch.setattr(config, "SESSIONS_DIR", str(sessions_dir))
    monkeypatch.setattr(config, "MEMORY_FILE", str(memory_file))

    return {"sessions_dir": str(sessions_dir), "memory_file": str(memory_file)}


@pytest.fixture(autouse=True)
def _text_tool_calling_by_default(monkeypatch):
    """Most tests fake llm_client.chat() with text-protocol replies, so they run the text protocol; the native
    function-calling tests (test_native_*.py) switch this on explicitly."""
    from troy import config
    monkeypatch.setattr(config, "TOOL_CALLING", "text")


@pytest.fixture(autouse=True)
def _isolated_task_files(tmp_path, monkeypatch):
    """Scheduled tasks persist to files under the project root; no test may touch the real ones."""
    from troy import config
    monkeypatch.setattr(config, "TASKS_FILE", str(tmp_path / "troy_tasks.json"))
    monkeypatch.setattr(config, "TASK_LOG_FILE", str(tmp_path / "troy_task_runs.jsonl"))
