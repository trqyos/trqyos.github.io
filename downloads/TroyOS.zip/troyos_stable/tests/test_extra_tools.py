"""On-demand extra tools: the list, the honesty rules, the usage gate, and forgetting the list afterwards."""
import re

import pytest

from troy import agent as agent_mod, config, context_budget, dispatcher, extra_tools, llm_client, system_prompt, tools_all
from troy.extra_tools import KEPT_OPEN, LIST_CLOSE, LIST_OPEN


class Script:
    def __init__(self, *replies): self.replies, self.sent = list(replies), []
    def __call__(self, messages, stop_check=None, on_text=None):
        self.sent.append([dict(m) for m in messages])
        return self.replies.pop(0)


@pytest.fixture
def demo_tools(monkeypatch):
    """Two harmless extra tools, so the tests can see which one ran."""
    calls = []
    for name, hint in (("zz_alpha", "<x>"), ("zz_beta", "<y>|<z>")):
        monkeypatch.setitem(tools_all._REGISTRY, name, tools_all.ToolDefinition(
            name=name, func=(lambda arg, n=name: (calls.append((n, arg)), {"success": True, "message": f"{n} ok"})[1]),
            description=f"Demo tool {name}.", category="zzdemo", arg_hint=hint))
    return calls


@pytest.fixture
def agent(monkeypatch):
    shown, spoken = [], []
    a = agent_mod.TroyAgent(on_speak=spoken.append, on_state=lambda *x: None, on_tool_result=lambda n, ar, ok, msg: shown.append((n, msg)))
    a.shown, a.spoken = shown, spoken
    return a


def user_text(sent_messages):
    return "\n".join(m["content"] for m in sent_messages if m["role"] == "user")


# ---------------------------------------------------------------- the prompt states only the core
def test_the_default_compact_prompt_names_core_tools_only_and_points_at_the_list():
    prompt = system_prompt.build_system_prompt("compact")
    assert "list_extra_tools" in prompt and "schedule_task" in prompt and "set_model" in prompt
    assert "convert_currency" not in prompt and "delete_file" not in prompt and "find_duplicate_files" not in prompt
    assert "never invent a command" in prompt
    assert context_budget.estimate_tokens(prompt) < 1800          # was ~2600 with every tool listed


def test_the_count_in_the_prompt_matches_what_the_list_reports():
    for mode in ("compact", "tiny"):
        prompt = system_prompt.build_system_prompt(mode)
        n = int(re.search(r"(\d+) more tools", prompt).group(1))
        listed = extra_tools.list_extra_tools("")["message"]
        if mode == "compact":
            assert f"({n} of {n} extra tools" in listed


def test_the_tiny_prompt_has_the_same_rules_in_fewer_words():
    prompt = system_prompt.build_system_prompt("tiny")
    assert "list_extra_tools" in prompt and "never invent" in prompt and context_budget.estimate_tokens(prompt) < 700


def test_the_detailed_prompt_lists_everything_so_nothing_is_extra(monkeypatch):
    monkeypatch.setattr(system_prompt, "build_system_prompt", lambda mode="compact": system_prompt.TROY_SYSTEM_PROMPT)
    r = extra_tools.list_extra_tools("")
    assert r["success"] and "no extra tools" in r["message"] and "tell them plainly that you can't" in r["message"]


def test_the_old_behaviour_is_one_setting_away(monkeypatch):
    monkeypatch.setattr(config, "EXTRA_TOOLS_ENABLED", False)
    prompt = system_prompt.build_system_prompt("compact")
    assert all(n in prompt for n in tools_all.all_tools())
    assert "no extra tools" in extra_tools.list_extra_tools("")["message"]
    assert extra_tools.gate("web_open", "x") is None


def test_builtin_command_set_matches_the_dispatcher():
    src = open(dispatcher.__file__, encoding="utf-8").read()
    found = set(re.findall(r'name == "([a-z_]+)"', src))
    for group in re.findall(r"name in \(([^)]*)\)", src):
        found |= set(re.findall(r'"([a-z_]+)"', group))
    assert found == set(extra_tools.BUILTIN_COMMANDS)


# ---------------------------------------------------------------- the list itself
def test_the_list_holds_every_extra_tool_with_exact_usage_and_the_honesty_rule():
    r = extra_tools.list_extra_tools("")
    text = r["message"]
    assert text.startswith(LIST_OPEN) and text.endswith(LIST_CLOSE) and r["full"] is True
    stated = extra_tools.stated_names(system_prompt.build_system_prompt("compact"))
    expected = set(extra_tools.catalog()) - stated
    assert all(re.search(rf"(?<![A-Za-z0-9_]){n}(?![A-Za-z0-9_])", text) for n in expected)     # none silently left out
    assert "convert_currency(amount|from|to)*" in text and "delete_file(path)!" in text         # usage, approval and info marks
    assert "never invent a command" in text and "say so plainly" in text


def test_the_list_never_includes_what_the_prompt_already_states():
    text = extra_tools.list_extra_tools("")["message"]
    for name in ("set_model", "schedule_task", "list_tasks"):
        assert not re.search(rf"(?<![A-Za-z0-9_]){name}(?![A-Za-z0-9_])", text.split("\n", 2)[2]), name


def test_filtering_by_category_and_by_words():
    cat = extra_tools.list_extra_tools("api")["message"]
    assert "category 'api'" in cat and "convert_currency:amount|from|to" in cat and "delete_file" not in cat
    assert "Frankfurter" in cat or "exchange" in cat.lower()                                     # filtered lists carry descriptions
    words = extra_tools.list_extra_tools("currency")["message"]
    assert "convert_currency" in words and "web_open" not in words


def test_asking_for_something_that_does_not_exist_gets_an_honest_no(monkeypatch):
    r = extra_tools.list_extra_tools("teleport the user to mars")
    assert r["success"] and "No extra tool matches" in r["message"] and "tell the user you can't" in r["message"]
    assert LIST_OPEN not in r["message"]                          # nothing to forget afterwards, nothing invented


def test_a_list_too_big_for_the_budget_drops_to_names_only_and_says_so(monkeypatch):
    monkeypatch.setattr(extra_tools, "_limit_chars", lambda: 4700)            # usage lines don't fit, bare names do
    r = extra_tools.list_extra_tools("")
    text = r["message"]
    assert "Names only" in text and "names only" in r["ui_message"]
    assert len(text) <= 4700
    stated = extra_tools.stated_names(system_prompt.build_system_prompt("compact"))
    assert all(re.search(rf"(?<![A-Za-z0-9_]){n}(?![A-Za-z0-9_])", text) for n in set(extra_tools.catalog()) - stated)   # still every name
    assert "convert_currency" in text and "convert_currency(" not in text
    req = extra_tools.RequestTools(lambda: [])
    with extra_tools.activate(req):
        extra_tools.list_extra_tools("")
    assert req.revealed == set()                                  # names alone don't license a call: usage comes first


def test_when_not_even_the_names_fit_only_categories_are_shown_and_it_says_so(monkeypatch):
    monkeypatch.setattr(extra_tools, "_limit_chars", lambda: 1500)
    r = extra_tools.list_extra_tools("")
    assert "Categories only" in r["message"] and "categories only" in r["ui_message"] and "[api] 10 tools" in r["message"]
    assert "convert_currency" not in r["message"] and len(r["message"]) <= 1500


def test_listing_marks_tools_as_revealed_for_the_request():
    req = extra_tools.RequestTools(lambda: [{"role": "system", "content": system_prompt.build_system_prompt("compact")}])
    with extra_tools.activate(req):
        extra_tools.list_extra_tools("")
    assert {"convert_currency", "delete_file", "find_duplicate_files"} <= req.revealed and "set_model" not in req.revealed


def test_the_list_reaches_the_model_whole_but_ordinary_long_messages_are_still_cut():
    listing = extra_tools.list_extra_tools("")["message"]
    msgs = [{"role": "system", "content": "s"}, {"role": "system", "content": "m"}, {"role": "system", "content": "c"},
            {"role": "user", "content": listing}, {"role": "user", "content": "x" * 6000}]
    out = context_budget.fit_messages(msgs, 20000)
    assert out[3]["content"] == listing and "trimmed" in out[4]["content"]


# ---------------------------------------------------------------- the usage gate
def test_a_never_shown_extra_tool_returns_its_usage_instead_of_running(demo_tools):
    req = extra_tools.RequestTools(lambda: [{"role": "system", "content": system_prompt.build_system_prompt("compact")}])
    with extra_tools.activate(req):
        first = dispatcher.execute("zz_beta", "a|b")
        assert not first["success"] and first["needs_followup"] and "did NOT run" in first["message"] and "zz_beta:y|z" in first["message"]
        assert demo_tools == []
        second = dispatcher.execute("zz_beta", "a|b")                   # now that its usage was shown, it runs
        assert second["success"] and demo_tools == [("zz_beta", "a|b")]
        assert req.used == {"zz_beta": "zz_beta:y|z -- Demo tool zz_beta."}


def test_listed_tools_run_straight_away_and_unlisted_ones_still_wait(demo_tools):
    req = extra_tools.RequestTools(lambda: [{"role": "system", "content": system_prompt.build_system_prompt("compact")}])
    with extra_tools.activate(req):
        extra_tools.list_extra_tools("zzdemo")
        assert dispatcher.execute("zz_alpha", "1")["success"]
        assert dispatcher.execute("get_battery_info", "")["needs_followup"]


def test_core_tools_builtins_and_discovery_are_never_gated(demo_tools):
    req = extra_tools.RequestTools(lambda: [{"role": "system", "content": system_prompt.build_system_prompt("compact")}])
    with extra_tools.activate(req):
        for name in ("list_extra_tools", "tool_help", "list_tasks", "list_models", "task_result"):
            assert extra_tools.gate(name, "") is None, name
        assert dispatcher.execute("get_time", "")["success"]


def test_without_an_active_request_nothing_is_gated(demo_tools):
    assert extra_tools.gate("zz_alpha", "x") is None


def test_an_unknown_command_fails_with_the_nearest_real_names_and_no_pretending():
    r = dispatcher.execute("get_batery_info", "")
    assert not r["success"] and r["needs_followup"] and "doesn't exist" in r["message"] and "get_battery_info" in r["message"]
    assert "never invent a command" in r["message"] and "list_extra_tools" in r["message"]


# ---------------------------------------------------------------- a whole request, through the real agent
def test_the_list_is_forgotten_after_the_request_and_only_used_tools_are_kept(agent, demo_tools, monkeypatch):
    script = Script("list_extra_tools:zzdemo\ndone\n", "zz_alpha:hello\nspeak:Done.\ndone\n")
    monkeypatch.setattr(llm_client, "chat", script)
    agent.handle_user_input("please run the thing")

    # during the request the model really saw the list (a bundled `done` did not cut the turn short)
    assert len(script.sent) == 2 and LIST_OPEN in user_text(script.sent[1]) and "zz_beta" in user_text(script.sent[1])
    assert demo_tools == [("zz_alpha", "hello")] and agent.spoken == ["Done."]

    # afterwards: the list is gone, a stub keeps what was used, nothing else
    history = user_text(agent.messages)
    assert LIST_OPEN not in history and "zz_beta" not in history.replace("zz_alpha", "") and "Extra tool list removed" in history
    assert f"{KEPT_OPEN} zz_alpha:x -- Demo tool zz_alpha." in history
    assert agent.messages[0]["content"] == system_prompt.build_system_prompt(agent._prompt_mode_in_use)   # back to the original prompt
    assert "zz_beta" not in agent.messages[0]["content"]
    assert agent.extra_tools_used() == {"zz_alpha": "zz_alpha:x -- Demo tool zz_alpha."}
    assert agent._extra.revealed == set() and agent._extra.used == {}


def test_a_request_that_used_nothing_keeps_nothing(agent, demo_tools, monkeypatch):
    monkeypatch.setattr(llm_client, "chat", Script("list_extra_tools:zzdemo\ndone\n", "speak:Nothing there fits, sorry.\ndone\n"))
    agent.handle_user_input("do something impossible")
    history = user_text(agent.messages)
    assert LIST_OPEN not in history and KEPT_OPEN not in history and "none of its tools were used" in history
    assert agent.spoken == ["Nothing there fits, sorry."]


def test_the_next_request_can_reuse_a_kept_tool_but_must_ask_again_for_forgotten_ones(agent, demo_tools, monkeypatch):
    monkeypatch.setattr(llm_client, "chat", Script("list_extra_tools:zzdemo\ndone\n", "zz_alpha:1\ndone\n", "zz_alpha:2\nzz_beta:b|c\ndone\n", "done\n"))
    agent.handle_user_input("first")
    agent.handle_user_input("second")
    assert demo_tools[:2] == [("zz_alpha", "1"), ("zz_alpha", "2")]       # kept: ran at once in the later request
    assert ("zz_beta", "b|c") not in demo_tools                             # forgotten: asked for its usage first
    assert any("zz_beta" in m for n, m in agent.shown if "did NOT run" in m)


def test_the_ui_gets_a_one_line_summary_not_the_whole_list(agent, demo_tools, monkeypatch):
    monkeypatch.setattr(llm_client, "chat", Script("list_extra_tools:zzdemo\ndone\n", "done\n"))
    agent.handle_user_input("what else can you do")
    (line,) = [m for n, m in agent.shown if n == "list_extra_tools"]
    assert line == "Listed 2 extra tools (category 'zzdemo')." and LIST_OPEN not in line


def test_a_stopped_request_still_forgets_the_list(agent, demo_tools, monkeypatch):
    from troy import stop_control
    def chat(messages, stop_check=None, on_text=None):
        if len(chat.n) == 0:
            chat.n.append(1)
            return "list_extra_tools:zzdemo\ndone\n"
        stop_control.stop_controller.request_stop()
        raise llm_client.StoppedByUser()
    chat.n = []
    monkeypatch.setattr(llm_client, "chat", chat)
    agent.handle_user_input("start something")
    assert LIST_OPEN not in user_text(agent.messages)


def test_kept_tools_survive_a_reload_of_the_chat(agent, demo_tools, monkeypatch):
    monkeypatch.setattr(llm_client, "chat", Script("list_extra_tools:zzdemo\ndone\n", "zz_alpha:1\ndone\n"))
    agent.handle_user_input("go")
    saved = agent.export_history()
    fresh = agent_mod.TroyAgent(on_speak=lambda t: None)
    fresh.load_history(saved)
    assert fresh._extra.kept_names() == {"zz_alpha"}
