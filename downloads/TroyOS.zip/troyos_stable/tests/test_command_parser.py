from troy.command_parser import parse_commands, split_args


def test_basic_command_no_arg():
    assert parse_commands("done") == [("done", "")]


def test_basic_command_with_arg():
    assert parse_commands("speak:Hello there") == [("speak", "Hello there")]


def test_multiple_lines_in_order():
    text = "speak:Hi\nopen_app:firefox\ndone"
    assert parse_commands(text) == [
        ("speak", "Hi"), ("open_app", "firefox"), ("done", ""),
    ]


def test_blank_lines_are_skipped():
    text = "speak:Hi\n\n\nopen_app:firefox\n\ndone"
    assert parse_commands(text) == [
        ("speak", "Hi"), ("open_app", "firefox"), ("done", ""),
    ]


def test_markdown_bullets_and_fences_stripped():
    text = "```\n- speak:Hi\n* open_app:firefox\n```\ndone"
    assert parse_commands(text) == [
        ("speak", "Hi"), ("open_app", "firefox"), ("done", ""),
    ]


def test_lines_that_dont_look_like_commands_are_skipped():
    text = "Sure, here's what I'll do:\nspeak:Hi\ndone"
    assert parse_commands(text) == [("speak", "Hi"), ("done", "")]


def test_uppercase_or_numeric_command_names_are_rejected():
    # command names are lowercase-and-underscore only
    text = "Speak:Hi\nOPEN_APP:firefox\ndone"
    assert parse_commands(text) == [("done", "")]


def test_think_block_is_stripped_entirely():
    text = "<think>\nspeak:this should never appear\nmore reasoning\n</think>\nspeak:Hi\ndone"
    result = parse_commands(text)
    assert result == [("speak", "Hi"), ("done", "")]


def test_think_block_case_insensitive_and_multiline():
    text = "<THINK>reasoning across\nmultiple lines</THINK>\ndone"
    assert parse_commands(text) == [("done", "")]


def test_empty_input_returns_empty_list():
    assert parse_commands("") == []
    assert parse_commands(None) == []


def test_whitespace_only_arg_becomes_empty_string():
    assert parse_commands("wait:   ") == [("wait", "")]


def test_glued_trailing_done_is_split_out():
    # small/free models routinely forget the newline before `done`
    text = "speak:Hey there. done"
    assert parse_commands(text) == [("speak", "Hey there."), ("done", "")]


def test_glued_trailing_done_with_punctuation_variants():
    for suffix in ["done", "done.", "done!", "done?"]:
        text = f"speak:All set {suffix}"
        result = parse_commands(text)
        assert result[-1] == ("done", ""), f"failed for suffix={suffix!r}: {result}"
        assert result[0][0] == "speak"
        assert not result[0][1].rstrip().endswith("done")


def test_standalone_done_is_not_mangled():
    # a real, standalone `done` line must still work normally
    assert parse_commands("speak:Hi\ndone") == [("speak", "Hi"), ("done", "")]


def test_done_itself_is_never_treated_as_having_a_glued_done():
    # a done command with its own arg-looking text shouldn't recurse/duplicate
    assert parse_commands("done") == [("done", "")]


def test_word_containing_done_is_not_falsely_split():
    # "abandoned" contains "done" as a substring but isn't the word "done"
    text = "speak:The mission was abandoned"
    assert parse_commands(text) == [("speak", "The mission was abandoned")]


class TestSplitArgs:
    def test_basic(self):
        assert split_args("a|b|c") == ["a", "b", "c"]

    def test_strips_whitespace_around_each_part(self):
        assert split_args(" a | b |c ") == ["a", "b", "c"]

    def test_empty_string_returns_empty_list(self):
        assert split_args("") == []

    def test_single_value_no_pipe(self):
        assert split_args("just one") == ["just one"]

    def test_empty_segments_are_preserved(self):
        assert split_args("a||c") == ["a", "", "c"]
