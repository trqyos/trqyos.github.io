import pytest

from troy import confirmation


@pytest.fixture(autouse=True)
def _clean_state():
    confirmation.cancel_all()
    confirmation.set_listener(None)
    yield
    confirmation.cancel_all()
    confirmation.set_listener(None)


class TestRequest:
    def test_request_creates_a_pending_confirmation_with_a_unique_id(self):
        pc1 = confirmation.request("delete_file", "a.txt", "high", lambda a: {"success": True, "message": "ok"}, "delete a.txt")
        pc2 = confirmation.request("delete_file", "b.txt", "high", lambda a: {"success": True, "message": "ok"}, "delete b.txt")
        assert pc1.id != pc2.id

    def test_request_appears_in_list_pending(self):
        confirmation.request("shutdown_computer", "", "high", lambda a: {}, "shut down")
        pending = confirmation.list_pending()
        assert len(pending) == 1
        assert pending[0].name == "shutdown_computer"


class TestResolve:
    def test_approving_runs_the_function_and_returns_its_result(self):
        pc = confirmation.request("do_thing", "x", "medium", lambda a: {"success": True, "message": f"did {a}"}, "do x")
        result = confirmation.resolve(pc.id, approved=True)
        assert result["success"] is True
        assert result["message"] == "did x"
        assert result["name"] == "do_thing"
        assert result["arg"] == "x"

    def test_cancelling_never_calls_the_function(self):
        called = []
        pc = confirmation.request("do_thing", "x", "medium", lambda a: called.append(a) or {}, "do x")
        result = confirmation.resolve(pc.id, approved=False)
        assert called == []
        assert result["success"] is True  # cancelling itself is not a failure
        assert "Cancelled" in result["message"]

    def test_resolving_removes_it_from_pending(self):
        pc = confirmation.request("do_thing", "x", "low", lambda a: {}, "do x")
        confirmation.resolve(pc.id, approved=True)
        assert confirmation.list_pending() == []

    def test_resolving_twice_the_second_time_fails_cleanly(self):
        pc = confirmation.request("do_thing", "x", "low", lambda a: {}, "do x")
        confirmation.resolve(pc.id, approved=True)
        second = confirmation.resolve(pc.id, approved=True)
        assert second["success"] is False

    def test_resolving_unknown_id_fails_cleanly_without_raising(self):
        result = confirmation.resolve(123456789, approved=True)
        assert result["success"] is False

    def test_function_raising_becomes_a_failed_result_not_a_crash(self):
        def _boom(arg):
            raise RuntimeError("boom")
        pc = confirmation.request("do_thing", "x", "high", _boom, "do x")
        result = confirmation.resolve(pc.id, approved=True)
        assert result["success"] is False
        assert "boom" in result["message"]

    def test_function_returning_non_dict_is_handled_gracefully(self):
        pc = confirmation.request("do_thing", "x", "low", lambda a: "not a dict", "do x")
        result = confirmation.resolve(pc.id, approved=True)
        assert result["success"] is True
        assert result["message"] == "not a dict"


class TestListener:
    def test_listener_fires_synchronously_on_request(self):
        received = []
        confirmation.set_listener(lambda pc: received.append(pc.name))
        confirmation.request("shutdown_computer", "", "high", lambda a: {}, "shut down")
        assert received == ["shutdown_computer"]

    def test_no_listener_set_does_not_raise(self):
        confirmation.set_listener(None)
        confirmation.request("do_thing", "x", "low", lambda a: {}, "do x")  # must not raise


class TestCancelAll:
    def test_cancel_all_clears_the_queue_without_running_anything(self):
        called = []
        confirmation.request("a", "1", "low", lambda a: called.append(a), "a")
        confirmation.request("b", "2", "low", lambda a: called.append(a), "b")
        confirmation.cancel_all()
        assert confirmation.list_pending() == []
        assert called == []
