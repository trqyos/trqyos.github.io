import time

import numpy as np
import pytest

from troy import wake_listener


@pytest.fixture(autouse=True)
def _reset_listener_state():
    """_state/_awake_until are module-level globals -- reset around every
    test so they can't leak between tests."""
    wake_listener._state = "idle"
    wake_listener._awake_until = 0.0
    wake_listener._on_command = None
    wake_listener._on_state_change = None
    yield
    wake_listener._state = "idle"
    wake_listener._awake_until = 0.0
    wake_listener._on_command = None
    wake_listener._on_state_change = None


class TestSplitWakeWord:
    def test_wake_word_with_command_in_same_breath(self):
        triggered, remainder = wake_listener._split_wake_word("troy open chrome", "troy")
        assert triggered is True
        assert remainder == "open chrome"

    def test_wake_word_only_opens_followup_with_empty_remainder(self):
        triggered, remainder = wake_listener._split_wake_word("troy", "troy")
        assert triggered is True
        assert remainder == ""

    def test_wake_word_is_case_insensitive(self):
        triggered, remainder = wake_listener._split_wake_word("TROY OPEN FIREFOX", "troy")
        assert triggered is True
        assert remainder == "OPEN FIREFOX"

    def test_wake_word_mid_sentence(self):
        triggered, remainder = wake_listener._split_wake_word("hey troy what time is it", "troy")
        assert triggered is True
        assert remainder == "what time is it"

    def test_no_wake_word_present_does_not_trigger(self):
        triggered, remainder = wake_listener._split_wake_word("just some background chatter", "troy")
        assert triggered is False
        assert remainder == ""

    def test_substring_match_inside_another_word_does_not_trigger(self):
        # "trojan" contains "troy" as a substring but is a different word
        triggered, remainder = wake_listener._split_wake_word("the trojan horse story", "troy")
        assert triggered is False

    def test_trailing_punctuation_is_stripped_from_remainder(self):
        triggered, remainder = wake_listener._split_wake_word("Troy, open Chrome please", "troy")
        assert remainder == "open Chrome please"

    def test_empty_wake_word_treats_everything_as_a_command(self):
        triggered, remainder = wake_listener._split_wake_word("anything at all", "")
        assert triggered is True
        assert remainder == "anything at all"

    def test_custom_wake_word(self):
        triggered, remainder = wake_listener._split_wake_word("computer open chrome", "computer")
        assert triggered is True
        assert remainder == "open chrome"


class TestRms:
    def test_silence_has_near_zero_rms(self):
        silence = np.zeros(480, dtype=np.int16)
        assert wake_listener._rms(silence) < 1.0

    def test_loud_signal_has_higher_rms_than_quiet_signal(self):
        quiet = np.full(480, 100, dtype=np.int16)
        loud = np.full(480, 10000, dtype=np.int16)
        assert wake_listener._rms(loud) > wake_listener._rms(quiet)

    def test_constant_signal_rms_equals_its_absolute_value(self):
        signal = np.full(480, 500, dtype=np.int16)
        assert abs(wake_listener._rms(signal) - 500) < 1.0


class TestSetCallbacks:
    def test_set_callbacks_stores_both(self):
        cmd_calls = []
        state_calls = []
        wake_listener.set_callbacks(lambda t: cmd_calls.append(t), lambda s: state_calls.append(s))
        wake_listener._on_command("hello")
        wake_listener._on_state_change("hearing")
        assert cmd_calls == ["hello"]
        assert state_calls == ["hearing"]

    def test_state_change_callback_is_optional(self):
        wake_listener.set_callbacks(lambda t: None)
        wake_listener._set_state("hearing")  # must not raise with no listener


class TestFinishUtteranceStateMachine:
    """Exercises the real decision logic (_finish_utterance/_dispatch)
    directly, with voice.transcribe faked out -- this is the part that
    decides whether something heard becomes a sent command."""

    def _make_frames(self, seconds=0.5, samplerate=16000):
        return [np.zeros(int(samplerate * seconds), dtype=np.int16)]

    def test_utterance_with_wake_word_and_command_dispatches_immediately(self, monkeypatch):
        monkeypatch.setattr("troy.voice.transcribe", lambda audio, sr: "troy open chrome")
        received = []
        wake_listener.set_callbacks(on_command=lambda t: received.append(t))
        wake_listener._finish_utterance(self._make_frames(), 16000)
        assert received == ["open chrome"]
        assert wake_listener._state == "awake"

    def test_wake_word_only_opens_followup_without_dispatching(self, monkeypatch):
        monkeypatch.setattr("troy.voice.transcribe", lambda audio, sr: "troy")
        received = []
        wake_listener.set_callbacks(on_command=lambda t: received.append(t))
        wake_listener._finish_utterance(self._make_frames(), 16000)
        assert received == []
        assert wake_listener._state == "awake"
        assert wake_listener._awake_until > time.monotonic()

    def test_utterance_without_wake_word_is_ignored_when_idle(self, monkeypatch):
        monkeypatch.setattr("troy.voice.transcribe", lambda audio, sr: "the weather is nice today")
        received = []
        wake_listener.set_callbacks(on_command=lambda t: received.append(t))
        wake_listener._finish_utterance(self._make_frames(), 16000)
        assert received == []
        assert wake_listener._state == "idle"

    def test_utterance_inside_followup_window_dispatches_without_wake_word(self, monkeypatch):
        monkeypatch.setattr("troy.voice.transcribe", lambda audio, sr: "open firefox")
        wake_listener._awake_until = time.monotonic() + 10  # already in a follow-up window
        received = []
        wake_listener.set_callbacks(on_command=lambda t: received.append(t))
        wake_listener._finish_utterance(self._make_frames(), 16000)
        assert received == ["open firefox"]

    def test_expired_followup_window_requires_wake_word_again(self, monkeypatch):
        monkeypatch.setattr("troy.voice.transcribe", lambda audio, sr: "open firefox")
        wake_listener._awake_until = time.monotonic() - 1  # already expired
        received = []
        wake_listener.set_callbacks(on_command=lambda t: received.append(t))
        wake_listener._finish_utterance(self._make_frames(), 16000)
        assert received == []  # no wake word in "open firefox" -> ignored

    def test_empty_transcription_does_not_dispatch(self, monkeypatch):
        monkeypatch.setattr("troy.voice.transcribe", lambda audio, sr: "")
        received = []
        wake_listener.set_callbacks(on_command=lambda t: received.append(t))
        wake_listener._finish_utterance(self._make_frames(), 16000)
        assert received == []
        assert wake_listener._state == "idle"

    def test_empty_transcription_while_awake_stays_awake(self, monkeypatch):
        monkeypatch.setattr("troy.voice.transcribe", lambda audio, sr: "")
        wake_listener._awake_until = time.monotonic() + 10
        wake_listener._finish_utterance(self._make_frames(), 16000)
        assert wake_listener._state == "awake"

    def test_dispatch_extends_the_followup_window(self, monkeypatch):
        monkeypatch.setattr("troy.voice.transcribe", lambda audio, sr: "troy open chrome")
        from troy import config
        wake_listener.set_callbacks(on_command=lambda t: None)
        before = time.monotonic()
        wake_listener._finish_utterance(self._make_frames(), 16000)
        assert wake_listener._awake_until >= before + config.WAKE_WORD_FOLLOWUP_SECONDS

    def test_a_broken_command_callback_does_not_crash_the_listener(self, monkeypatch):
        monkeypatch.setattr("troy.voice.transcribe", lambda audio, sr: "troy do something")
        wake_listener.set_callbacks(on_command=lambda t: 1 / 0)
        wake_listener._finish_utterance(self._make_frames(), 16000)  # must not raise
        assert wake_listener._state == "awake"


class TestStartStop:
    def test_start_returns_false_when_sounddevice_missing(self, monkeypatch):
        import builtins
        real_import = builtins.__import__

        def _fake_import(name, *a, **k):
            if name == "sounddevice":
                raise ImportError("no module")
            return real_import(name, *a, **k)

        monkeypatch.setattr(builtins, "__import__", _fake_import)
        wake_listener._thread = None
        assert wake_listener.start() is False

    def test_start_returns_false_when_sounddevice_native_library_is_broken(self, monkeypatch):
        # this is the exact real-world failure this fixes: sounddevice
        # raises OSError (not ImportError) when its native PortAudio
        # library is missing/broken -- start() must not let this crash
        # the whole app at startup, same as the ImportError case above.
        import builtins
        real_import = builtins.__import__

        def _fake_import(name, *a, **k):
            if name == "sounddevice":
                raise OSError("PortAudio library not found")
            return real_import(name, *a, **k)

        monkeypatch.setattr(builtins, "__import__", _fake_import)
        wake_listener._thread = None
        assert wake_listener.start() is False

    def test_is_running_false_before_start(self):
        wake_listener._thread = None
        assert wake_listener.is_running() is False

    def test_stop_without_start_does_not_raise(self):
        wake_listener._thread = None
        wake_listener.stop()  # must not raise
