"""What schedules mean: natural language -> spec, next-run maths, and the wording shown back to the user."""
from datetime import datetime, timedelta

import pytest

from troy import schedule_spec as S

NOW = datetime(2026, 10, 19, 15, 0, 0)          # a Monday


def parse(text, now=NOW):
    return S.parse_when(text, now)


def runs(spec, n=3, after=NOW):
    return [r.strftime("%a %m-%d %H:%M") for r in S.occurrences(spec, after, n)]


# ---------------------------------------------------------------- the forms the task asks for
def test_every_day_at_a_clock_time():
    spec = parse("every day at 22:00")
    assert spec["kind"] == "daily" and spec["time"] == "22:00"
    assert runs(spec) == ["Mon 10-19 22:00", "Tue 10-20 22:00", "Wed 10-21 22:00"]
    assert S.describe(spec) == "Every day at 22:00"


def test_specific_weekdays():
    spec = parse("every monday, wednesday and friday at 22:00")
    assert spec["days"] == [0, 2, 4]
    assert runs(spec, 4) == ["Mon 10-19 22:00", "Wed 10-21 22:00", "Fri 10-23 22:00", "Mon 10-26 22:00"]
    assert S.describe(spec) == "Every Monday, Wednesday and Friday at 22:00"


def test_exact_date_and_time_in_several_spellings():
    for text in ("October 25, 2026 at 14:30", "2026-10-25 14:30", "25 October 2026 at 2:30 pm", "oct 25 at 14:30"):
        assert S.parse_when(text, NOW) == {"kind": "once", "at": "2026-10-25T14:30:00"}, text


@pytest.mark.parametrize("text, expected", [
    ("every week", ["Mon 10-26 09:00"]),
    ("weekly on friday at 5pm", ["Fri 10-23 17:00", "Fri 10-30 17:00"]),
    ("every 2 weeks on monday at 9am", ["Mon 11-02 09:00", "Mon 11-16 09:00"]),
    ("every month on the 15th at 09:00", ["Sun 11-15 09:00", "Tue 12-15 09:00"]),
    ("on the last day of every month at 23:00", ["Sat 10-31 23:00", "Mon 11-30 23:00"]),
    ("every year on March 3 at 9am", ["Wed 03-03 09:00"]),
    ("every 2 days at 9am", ["Wed 10-21 09:00", "Fri 10-23 09:00"]),
    ("every 90 minutes", ["Mon 10-19 16:30", "Mon 10-19 18:00"]),
    ("every 3 hours", ["Mon 10-19 18:00", "Mon 10-19 21:00"]),
    ("every weekday at 8:30", ["Tue 10-20 08:30", "Wed 10-21 08:30"]),
    ("every weekend at 10am", ["Sat 10-24 10:00", "Sun 10-25 10:00"]),
])
def test_recurring_calendar_and_interval_schedules(text, expected):
    got = runs(parse(text), len(expected))
    assert got == expected


@pytest.mark.parametrize("text, at", [
    ("in 30 minutes", "2026-10-19T15:30:00"), ("in 2 hours", "2026-10-19T17:00:00"), ("in an hour and a half", "2026-10-19T16:30:00"),
    ("in 1 hour 30 minutes", "2026-10-19T16:30:00"), ("tomorrow at 9 AM", "2026-10-20T09:00:00"), ("today at 18:30", "2026-10-19T18:30:00"),
    ("friday at 8pm", "2026-10-23T20:00:00"), ("monday at 9am", "2026-10-26T09:00:00"),      # Monday 9am has passed -> next Monday
    ("at 22:00", "2026-10-19T22:00:00"), ("at 10am", "2026-10-20T10:00:00"),                # a bare clock time: the next time it shows
    ("tonight", "2026-10-19T21:00:00"),
])
def test_relative_and_one_time_phrases(text, at):
    assert parse(text) == {"kind": "once", "at": at}


def test_every_two_days_without_a_time_keeps_the_current_time_of_day():
    spec = parse("every 2 days")
    assert spec["kind"] == "daily" and spec["every"] == 2 and spec["time"] == "15:00"


# ---------------------------------------------------------------- refusing to guess
@pytest.mark.parametrize("text", ["", "whenever", "yesterday at 5pm", "at 25:00", "feb 30", "in 0 minutes", "every second",
                                  "at 5pm sometime next quarter", "every 5 seconds", "2026-10-25", "every month"])
def test_things_that_cannot_be_understood_raise_a_helpful_error(text):
    with pytest.raises(S.ScheduleError):
        parse(text)


def test_a_time_already_past_is_rejected():
    with pytest.raises(S.ScheduleError, match="past"):
        parse("2026-10-18 09:00")


def test_json_specs_are_accepted_and_validated():
    spec = S.parse_when('{"kind":"weekdays","days":[1,3],"time":"07:15"}', NOW)
    assert spec["days"] == [1, 3] and spec["time"] == "07:15"
    for bad in ('{"kind":"weekdays","days":[9],"time":"07:15"}', '{"kind":"nope"}', '{"kind":"daily","time":"25:00"}', '{"kind":', '{"kind":"monthly","day":40}'):
        with pytest.raises(S.ScheduleError):
            S.parse_when(bad, NOW)


# ---------------------------------------------------------------- next_run edge cases
def test_one_time_schedule_has_no_run_once_past():
    spec = {"kind": "once", "at": "2026-10-19T16:00:00"}
    assert S.next_run(spec, NOW) == datetime(2026, 10, 19, 16, 0)
    assert S.next_run(spec, datetime(2026, 10, 19, 16, 0)) is None


def test_the_31st_runs_on_the_last_day_of_shorter_months():
    spec = S.validate({"kind": "monthly", "day": 31, "time": "08:00"}, NOW)
    assert runs(spec, 3) == ["Sat 10-31 08:00", "Mon 11-30 08:00", "Thu 12-31 08:00"]


def test_leap_day_falls_back_to_the_28th_in_other_years():
    spec = S.validate({"kind": "yearly", "month": 2, "day": 29, "time": "08:00"}, datetime(2027, 1, 1))
    assert [r.strftime("%Y-%m-%d") for r in S.occurrences(spec, datetime(2027, 1, 1), 3)] == ["2027-02-28", "2028-02-29", "2029-02-28"]


def test_a_run_exactly_at_the_reference_time_is_not_returned_again():
    spec = parse("every day at 22:00")
    first = S.next_run(spec, NOW)
    assert S.next_run(spec, first) == first + timedelta(days=1)


def test_every_n_days_counts_from_its_start_date():
    spec = S.validate({"kind": "daily", "time": "09:00", "every": 3, "start": "2026-10-19"}, NOW)
    assert runs(spec, 3) == ["Thu 10-22 09:00", "Sun 10-25 09:00", "Wed 10-28 09:00"]


def test_interval_before_its_anchor_starts_one_step_after_it():
    spec = {"kind": "interval", "seconds": 600, "start": "2026-10-19T16:00:00"}
    assert S.next_run(spec, NOW) == datetime(2026, 10, 19, 16, 10)


def test_validate_fills_defaults_and_rejects_nonsense():
    assert S.validate({"kind": "daily"}, NOW)["time"] == "09:00"
    with pytest.raises(S.ScheduleError):
        S.validate({"kind": "interval", "seconds": 3}, NOW)
    with pytest.raises(S.ScheduleError):
        S.validate({"kind": "daily", "every": 0}, NOW)
    with pytest.raises(S.ScheduleError):
        S.validate("daily", NOW)


def test_descriptions_read_naturally():
    assert S.describe(parse("every weekday at 8:30")) == "Every weekday (Mon-Fri) at 08:30"
    assert S.describe(parse("every 2 weeks on monday at 9am")) == "Every 2 weeks on Monday at 09:00"
    assert S.describe(parse("on the last day of every month at 23:00")) == "On the last day of every month at 23:00"
    assert S.describe(parse("every 90 minutes")) == "Every 90 minutes"
    assert S.describe(parse("every 2 days at 9am")) == "Every 2 days at 09:00"
    assert S.describe(parse("October 25, 2026 at 14:30")) == "Once, Sun Oct 25 2026 at 14:30"
    assert S.is_recurring(parse("every day at 9")) and not S.is_recurring(parse("in 5 minutes"))
