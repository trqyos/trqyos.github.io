"""The vacuum tools as Troy's model sees them: registry, schemas, argument handling, safety model, IPC, CLI."""
import pytest

from tests.test_vacuum import FakeS20, setup  # noqa: F401  (fixtures)
from troy import config, confirmation, settings_store, tool_schema, tools_all, tools_vacuum, vacuum, vacuum_cli
from troy.ipc_host import IPCHost

NAMES = ["vacuum_status", "vacuum_rooms", "vacuum_consumables", "vacuum_start", "vacuum_clean_rooms", "vacuum_pause", "vacuum_resume",
         "vacuum_stop", "vacuum_dock", "vacuum_locate", "vacuum_set"]


def test_all_tools_are_registered_in_one_category():
    for n in NAMES:
        t = tools_all.get(n)
        assert t and t.category == "vacuum", n
    assert not [n for n in tools_all.all_tools() if n.startswith("vacuum") and n not in NAMES]


def test_read_only_tools_are_info_and_nothing_needs_approval():
    for n in ("vacuum_status", "vacuum_rooms", "vacuum_consumables"):
        assert tools_all.get(n).info
    # No Approve card: it would block scheduled runs ("start the vacuum at 10") and starting a vacuum is harmless.
    assert not [n for n in NAMES if tools_all.get(n).requires_confirmation]


def test_there_is_deliberately_no_reset_or_raw_tool():
    assert not [n for n in tools_all.all_tools() if n.startswith("vacuum") and ("reset" in n or "raw" in n or "call" in n)]


def test_schemas_are_valid_and_enumerated():
    for n in NAMES:
        s = tool_schema.schema_for(n)
        assert s and s["function"]["name"] == n
    props = tool_schema.schema_for("vacuum_set")["function"]["parameters"]["properties"]
    assert props["setting"]["enum"] == ["suction", "mop_water", "mode", "passes", "volume"]
    assert tool_schema.call_to_command("vacuum_set", {"setting": "suction", "value": "strong"}) == ("vacuum_set", "suction|strong")
    assert tool_schema.call_to_command("vacuum_clean_rooms", {"rooms": "mutfak, salon"}) == ("vacuum_clean_rooms", "mutfak, salon")
    assert tool_schema.call_to_command("vacuum_start", {}) == ("vacuum_start", "")
    with pytest.raises(tool_schema.ToolArgError):
        tool_schema.call_to_command("vacuum_set", {"setting": "colour", "value": "red"})


def test_requests_in_english_and_turkish_find_the_vacuum_tools():
    for text in ("clean the kitchen with the robot vacuum", "süpürgeyi çalıştır", "mutfağı paspasla", "send the hoover home", "robotu şarja gönder"):
        assert any(n.startswith("vacuum") for n in tool_schema.relevant_names(text, 6)), text


def test_tools_run_through_the_registry(setup):  # noqa: F811
    robot = setup(FakeS20())
    assert tools_all.run("vacuum_start", "")["success"] and robot.p[vacuum.STATUS] == 4
    assert tools_all.run("vacuum_set", "suction|max")["success"] and robot.p[vacuum.SUCTION] == 4
    assert "Use vacuum_set" in tools_all.run("vacuum_set", "suction")["message"]
    assert tools_all.run("vacuum_pause", "")["success"]


def test_clean_rooms_tool_end_to_end(setup):  # noqa: F811
    setup(FakeS20(accepts=("json_tagged",)))
    out = tools_all.run("vacuum_clean_rooms", "mutfak")
    assert out["success"] and "Mutfak" in out["message"]


def test_scheduled_unattended_runs_may_use_the_vacuum(setup):  # noqa: F811
    """A scheduled task has no Approve button to click: vacuum tools must run without one and leave no 'denied' trace."""
    from troy import task_context
    robot = setup(FakeS20())
    ctx = task_context.RunContext("t1", grants=())
    with task_context.activate(ctx):
        assert tools_all.run("vacuum_start", "")["success"]
    assert robot.p[vacuum.STATUS] == 4 and ctx.denied == []


def test_troy_cannot_repoint_enable_or_set_the_token_without_the_user(monkeypatch, tmp_path):
    from troy import tools_app
    monkeypatch.setattr(settings_store, "SETTINGS_FILE", str(tmp_path / "s.json"))
    for arg in ("VACUUM_HOST|192.168.1.99", "VACUUM_ENABLED|on"):
        r = tools_app.change_setting(arg)
        assert r.get("pending"), arg                                      # an Approve card, not applied
    assert config.VACUUM_HOST != "192.168.1.99" and config.VACUUM_ENABLED is False
    r = tools_app.change_setting("VACUUM_TOKEN|" + "ab" * 16)
    assert not r["success"] and "API keys" in r["message"] and config.VACUUM_TOKEN == ""
    for p in list(confirmation.list_pending()):
        confirmation.resolve(p.id, False)


def test_token_is_a_write_only_secret():
    assert "VACUUM_TOKEN" in settings_store.SECRETS and "VACUUM_TOKEN" not in settings_store.SETTINGS


def test_settings_validation(monkeypatch, tmp_path):
    monkeypatch.setattr(settings_store, "SETTINGS_FILE", str(tmp_path / "s.json"))
    with pytest.raises(ValueError):
        settings_store.apply_settings({"VACUUM_HOST": "http://evil/;rm -rf"})
    with pytest.raises(ValueError):
        settings_store.apply_settings({"VACUUM_ROOM_ENCODING": "xml"})
    with pytest.raises(ValueError):
        settings_store.apply_settings({"UI_LANGUAGE": "klingon"})
    assert settings_store.apply_settings({"VACUUM_HOST": "192.168.1.50", "UI_LANGUAGE": "tr", "VACUUM_TOKEN": "ab" * 16}) 
    assert config.VACUUM_HOST == "192.168.1.50" and config.UI_LANGUAGE == "tr" and config.VACUUM_TOKEN == "ab" * 16
    for k, val in (("VACUUM_HOST", ""), ("UI_LANGUAGE", "en"), ("VACUUM_TOKEN", "")):
        setattr(config, k, val)


def test_ipc_test_method_reports_success_and_failure(setup, monkeypatch):  # noqa: F811
    setup(FakeS20())
    host = IPCHost.__new__(IPCHost)
    assert host._m_vacuum_test({})["success"]
    monkeypatch.setattr(config, "VACUUM_ENABLED", False)
    assert not host._m_vacuum_test({})["success"]


def test_ipc_discover_lists_devices(monkeypatch):
    monkeypatch.setattr(vacuum_cli, "discover", lambda seconds=3: [("192.168.1.20", 123456)])
    assert IPCHost.__new__(IPCHost)._m_vacuum_discover({}) == {"devices": [{"ip": "192.168.1.20", "did": 123456}]}


def test_cli_commands(setup, capsys):  # noqa: F811
    robot = setup(FakeS20())
    assert vacuum_cli.main(["status", "--host", "10.0.0.5", "--token", "00" * 16]) == 0
    assert "charging on the dock" in capsys.readouterr().out
    assert vacuum_cli.main(["start"]) == 0 and robot.p[vacuum.STATUS] == 4
    assert vacuum_cli.main(["get", "3", "1", "9", "9"]) == 0
    out = capsys.readouterr().out
    assert "3.1 = 87" in out and "9.9 = (not available)" in out
    assert vacuum_cli.main(["call", "6", "6"]) == 0 and robot.calls[-1][0] == (6, 6)
    assert vacuum_cli.main(["set", "suction", "strong"]) == 0
    assert vacuum_cli.main(["bogus"]) == 2
