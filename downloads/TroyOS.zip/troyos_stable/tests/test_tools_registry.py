import pytest

import troy.tools_all as tools_all
from troy import confirmation


@pytest.fixture(autouse=True)
def _clean_confirmation_queue():
    """Every test starts and ends with an empty confirmation queue, since
    it's module-level global state shared across the whole test run."""
    confirmation.cancel_all()
    confirmation.set_listener(None)
    yield
    confirmation.cancel_all()
    confirmation.set_listener(None)


@pytest.fixture
def clean_registry(monkeypatch):
    """Tests that register throwaway tools shouldn't pollute the real,
    shared _REGISTRY dict for other tests -- swap in a fresh copy."""
    original = dict(tools_all._REGISTRY)
    monkeypatch.setattr(tools_all, "_REGISTRY", dict(original))
    yield
    # monkeypatch restores the attribute automatically after the test


class TestRegistryIntegrity:
    """Every tool actually registered in the shipping product must be
    real and callable -- this is the same invariant that was checked by
    hand with an AST walk during development; codifying it as a test
    means a future edit that typos a function name fails CI instead of
    failing silently at runtime."""

    def test_every_registered_tool_has_a_callable_func(self):
        for name, tool in tools_all.all_tools().items():
            assert callable(tool.func), f"'{name}' is not callable"

    def test_no_duplicate_tool_names(self):
        names = list(tools_all.all_tools().keys())
        assert len(names) == len(set(names))

    def test_at_least_the_expected_tool_categories_exist(self):
        categories = set(tools_all.by_category().keys())
        expected = {"filesystem", "system", "network", "process", "web", "desktop", "vision", "windows"}
        assert expected.issubset(categories)

    def test_get_returns_none_for_unknown_tool(self):
        assert tools_all.get("this_tool_does_not_exist") is None

    def test_get_returns_the_registered_tool(self):
        tool = tools_all.get("get_cpu_info")
        assert tool is not None
        assert tool.name == "get_cpu_info"

    def test_info_command_names_only_includes_info_tools(self):
        info_names = tools_all.info_command_names()
        for name in info_names:
            assert tools_all.get(name).info is True

    def test_by_category_groups_are_alphabetically_sorted_within_category(self):
        for category, tools in tools_all.by_category().items():
            names = [t.name for t in tools]
            assert names == sorted(names), f"category '{category}' isn't sorted"


class TestRun:
    """tools_all.run() is the single execution path dispatcher.py falls
    back to for the ~150-tool extended library -- these are the contract
    guarantees every one of those tools depends on."""

    def test_unknown_tool_returns_failure_without_raising(self):
        result = tools_all.run("definitely_not_a_real_tool", "")
        assert result == {"success": False, "message": "Unknown command: definitely_not_a_real_tool"}

    def test_normal_tool_executes_and_returns_its_result(self, clean_registry):
        tools_all.register("_test_echo", lambda arg: {"success": True, "message": f"echo:{arg}"}, "test", category="test")
        result = tools_all.run("_test_echo", "hello")
        assert result == {"success": True, "message": "echo:hello"}

    def test_exception_inside_a_tool_is_caught_not_raised(self, clean_registry):
        def _boom(arg):
            raise ValueError("kaboom")
        tools_all.register("_test_boom", _boom, "test", category="test")
        result = tools_all.run("_test_boom", "")
        assert result["success"] is False
        assert "kaboom" in result["message"]

    def test_tool_returning_a_bare_string_is_normalized_to_a_dict(self, clean_registry):
        tools_all.register("_test_bare", lambda arg: "just a string", "test", category="test")
        result = tools_all.run("_test_bare", "")
        assert result == {"success": True, "message": "just a string"}

    def test_missing_arg_defaults_to_empty_string(self, clean_registry):
        captured = {}
        def _capture(arg):
            captured["arg"] = arg
            return {"success": True, "message": "ok"}
        tools_all.register("_test_capture", _capture, "test", category="test")
        tools_all.run("_test_capture", None)
        assert captured["arg"] == ""


class TestConfirmationGating:
    """The whole point of troy/confirmation.py: a risky tool must NEVER
    execute directly from tools_all.run() -- it must always be diverted
    into a pending confirmation instead, regardless of who's calling it
    (the main dispatcher)."""

    def test_confirmation_required_tool_does_not_execute_immediately(self, clean_registry):
        executed = []
        def _dangerous(arg):
            executed.append(arg)
            return {"success": True, "message": "deleted"}
        tools_all.register("_test_dangerous", _dangerous, "test", category="test",
                            risk_level="high", requires_confirmation=True)

        result = tools_all.run("_test_dangerous", "important.txt")

        assert executed == [], "a confirmation-gated tool ran without approval"
        assert result["success"] is False
        assert result["pending_confirmation"] is True
        assert "confirmation_id" in result

    def test_approving_the_pending_confirmation_runs_the_real_tool(self, clean_registry):
        executed = []
        def _dangerous(arg):
            executed.append(arg)
            return {"success": True, "message": f"deleted {arg}"}
        tools_all.register("_test_dangerous", _dangerous, "test", category="test",
                            risk_level="high", requires_confirmation=True)

        result = tools_all.run("_test_dangerous", "important.txt")
        confirm_result = confirmation.resolve(result["confirmation_id"], approved=True)

        assert executed == ["important.txt"]
        assert confirm_result["success"] is True
        assert "deleted important.txt" in confirm_result["message"]

    def test_cancelling_the_pending_confirmation_never_runs_it(self, clean_registry):
        executed = []
        tools_all.register("_test_dangerous", lambda arg: executed.append(arg) or {"success": True, "message": "ran"},
                            "test", category="test", requires_confirmation=True)

        result = tools_all.run("_test_dangerous", "x")
        confirmation.resolve(result["confirmation_id"], approved=False)

        assert executed == []

    def test_resolving_an_unknown_confirmation_id_fails_cleanly(self):
        result = confirmation.resolve(999999, approved=True)
        assert result["success"] is False

    def test_listener_is_notified_when_a_confirmation_is_requested(self, clean_registry):
        received = []
        confirmation.set_listener(lambda pc: received.append(pc))
        tools_all.register("_test_dangerous", lambda arg: {"success": True, "message": "ran"},
                            "test", category="test", requires_confirmation=True)

        tools_all.run("_test_dangerous", "x")

        assert len(received) == 1
        assert received[0].name == "_test_dangerous"

    def test_a_broken_listener_does_not_prevent_the_confirmation_from_being_created(self, clean_registry):
        confirmation.set_listener(lambda pc: 1 / 0)  # deliberately broken
        tools_all.register("_test_dangerous", lambda arg: {"success": True, "message": "ran"},
                            "test", category="test", requires_confirmation=True)

        result = tools_all.run("_test_dangerous", "x")

        assert result["pending_confirmation"] is True
        assert confirmation.list_pending()  # still queued despite the listener blowing up
