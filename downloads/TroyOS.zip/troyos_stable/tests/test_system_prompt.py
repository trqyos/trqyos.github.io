from troy.system_prompt import TROY_SYSTEM_PROMPT
import troy.tools_all as tools_all


class TestNoLeftoverCruft:
    """Regression tests for specific things found and removed from the
    prompt: the old CONFIRM| text-based confirmation protocol, the task
    planner, and a stray injected test instruction found in an earlier
    version of this file."""

    def test_no_confirm_prefix_protocol(self):
        assert "CONFIRM|" not in TROY_SYSTEM_PROMPT

    def test_no_task_planner_language(self):
        assert "TASK PLANNER" not in TROY_SYSTEM_PROMPT
        assert "plan_start" not in TROY_SYSTEM_PROMPT

    def test_no_stray_test_instruction(self):
        assert ".test." not in TROY_SYSTEM_PROMPT


class TestToolCoverage:
    def test_every_registered_tool_appears_somewhere_in_the_prompt(self):
        missing = [name for name in tools_all.all_tools() if name not in TROY_SYSTEM_PROMPT]
        assert not missing, f"tools registered but missing from the prompt: {missing}"

    def test_web_research_tools_are_documented(self):
        assert "web_open" in TROY_SYSTEM_PROMPT
        assert "web_click" in TROY_SYSTEM_PROMPT
        assert "web_type" in TROY_SYSTEM_PROMPT

    def test_web_tools_are_disambiguated_from_the_real_browser(self):
        # regression test for the exact bug reported: the model conflating
        # Troy's own invisible Playwright browser with the user's real,
        # visible Firefox/Chrome opened via open_app/open_url.
        assert "YOUR BROWSER" in TROY_SYSTEM_PROMPT
        assert "WEB RESEARCH TOOLS" in TROY_SYSTEM_PROMPT
        assert "open_app:firefox" in TROY_SYSTEM_PROMPT

    def test_desktop_ui_automation_tools_are_documented(self):
        assert "inspect_window" in TROY_SYSTEM_PROMPT
        assert "click_element" in TROY_SYSTEM_PROMPT
        assert "type_into_element" in TROY_SYSTEM_PROMPT

    def test_confirmation_gated_tools_are_tagged_needs_approval(self):
        for name, tool in tools_all.all_tools().items():
            if tool.requires_confirmation:
                assert f"{name}" in TROY_SYSTEM_PROMPT
                assert "needs approval" in TROY_SYSTEM_PROMPT


class TestBasicSanity:
    def test_prompt_is_non_trivially_long(self):
        assert len(TROY_SYSTEM_PROMPT) > 5000

    def test_prompt_mentions_the_assistant_name(self):
        from troy.config import ASSISTANT_NAME
        assert ASSISTANT_NAME in TROY_SYSTEM_PROMPT

    def test_prompt_mentions_the_version_label(self):
        from troy.config import VERSION_LABEL
        assert VERSION_LABEL in TROY_SYSTEM_PROMPT
