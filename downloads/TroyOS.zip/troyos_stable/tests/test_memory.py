from troy import memory


class TestRemember:
    def test_remember_and_all_memories(self, isolated_storage):
        memory.remember("The user's dog is named Biscuit")
        entries = memory.all_memories()
        assert len(entries) == 1
        assert entries[0]["fact"] == "The user's dog is named Biscuit"
        assert "timestamp" in entries[0]

    def test_remember_empty_fact_is_a_no_op(self, isolated_storage):
        result = memory.remember("   ")
        assert "Nothing to remember" in result
        assert memory.all_memories() == []

    def test_remember_strips_whitespace(self, isolated_storage):
        memory.remember("  has extra whitespace  ")
        assert memory.all_memories()[0]["fact"] == "has extra whitespace"

    def test_multiple_facts_accumulate_in_order(self, isolated_storage):
        memory.remember("fact one")
        memory.remember("fact two")
        memory.remember("fact three")
        facts = [e["fact"] for e in memory.all_memories()]
        assert facts == ["fact one", "fact two", "fact three"]


class TestRecall:
    def test_recall_on_empty_memory(self, isolated_storage):
        assert "empty" in memory.recall("anything").lower()

    def test_recall_empty_query_returns_most_recent(self, isolated_storage):
        for i in range(10):
            memory.remember(f"fact number {i}")
        result = memory.recall("", limit=3)
        assert "fact number 7" in result
        assert "fact number 8" in result
        assert "fact number 9" in result
        assert "fact number 0" not in result

    def test_recall_matches_by_keyword(self, isolated_storage):
        memory.remember("The user's favorite editor is VS Code")
        memory.remember("The user's favorite browser is Firefox")
        result = memory.recall("browser")
        assert "Firefox" in result
        assert "VS Code" not in result

    def test_recall_with_no_matches(self, isolated_storage):
        memory.remember("something about cats")
        result = memory.recall("quantum physics blockchain")
        assert "No matching memories" in result

    def test_recall_ranks_better_matches_first(self, isolated_storage):
        memory.remember("likes pizza")
        memory.remember("likes pizza and also loves pizza toppings")
        result = memory.recall("pizza toppings", limit=1)
        assert "toppings" in result

    def test_recall_substring_credit_for_longer_words(self, isolated_storage):
        # 'firefox' (>=4 chars) should match "Firefox," via substring even
        # though the punctuation makes it a different exact word
        memory.remember("Opened Firefox, then closed it")
        result = memory.recall("firefox")
        assert "Firefox" in result


class TestDeleteAndClear:
    def test_delete_memory_by_index(self, isolated_storage):
        memory.remember("keep me")
        memory.remember("delete me")
        ok = memory.delete_memory(1)
        assert ok is True
        facts = [e["fact"] for e in memory.all_memories()]
        assert facts == ["keep me"]

    def test_delete_out_of_range_index_returns_false(self, isolated_storage):
        memory.remember("only one")
        assert memory.delete_memory(5) is False
        assert memory.delete_memory(-1) is False
        assert len(memory.all_memories()) == 1

    def test_clear_all_removes_everything_and_returns_count(self, isolated_storage):
        memory.remember("one")
        memory.remember("two")
        memory.remember("three")
        count = memory.clear_all()
        assert count == 3
        assert memory.all_memories() == []


class TestRecentMemories:
    def test_recent_memories_respects_limit(self, isolated_storage):
        for i in range(5):
            memory.remember(f"fact {i}")
        recent = memory.recent_memories(limit=2)
        assert len(recent) == 2
        assert recent[-1]["fact"] == "fact 4"

    def test_recent_memories_defaults_to_config_max(self, isolated_storage):
        from troy import config
        for i in range(3):
            memory.remember(f"fact {i}")
        recent = memory.recent_memories()
        assert len(recent) <= config.MAX_MEMORIES_IN_CONTEXT
