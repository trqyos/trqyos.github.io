"""The speed / context-size work: token budgeting, compact prompts, failure
cooldowns, 413 recovery, speed-up parameters and LM Studio discovery."""
import json

import pytest

from troy import config, context_budget, llm_client, system_prompt, tools_all
from troy.context_budget import estimate_tokens, fit_messages, total_tokens


# ------------------------------------------------------------ token budget
def _convo(turns=30, obs_chars=3000):
    msgs = [{"role": "system", "content": "prompt " * 50}, {"role": "system", "content": "memory"}, {"role": "system", "content": "context"}]
    for i in range(turns):
        msgs.append({"role": "user", "content": f"[OBSERVATION] step {i} " + "x" * obs_chars})
        msgs.append({"role": "assistant", "content": "speak:ok\ndone"})
    msgs.append({"role": "user", "content": "latest request"})
    return msgs


def test_fit_messages_respects_budget_and_keeps_head_and_latest():
    msgs = _convo()
    out = fit_messages(msgs, 3000)
    assert total_tokens(out) <= 3200
    assert out[:3] == msgs[:3]
    assert out[-1]["content"] == "latest request"
    assert any("omitted" in m["content"] for m in out)


def test_fit_messages_never_mutates_the_original():
    msgs = _convo(turns=5)
    snapshot = json.dumps(msgs)
    fit_messages(msgs, 800)
    assert json.dumps(msgs) == snapshot


def test_fit_messages_shrinks_an_oversized_memory_message():
    msgs = _convo(turns=1)
    msgs[1]["content"] = "fact " * 5000
    out = fit_messages(msgs, 2500)
    assert total_tokens(out) <= 2700


def test_small_conversations_pass_through_unchanged():
    msgs = _convo(turns=2, obs_chars=50)
    assert fit_messages(msgs, 5500) == msgs


# ------------------------------------------------------------------ prompts
def test_prompt_sizes():
    assert estimate_tokens(system_prompt.build_system_prompt("compact")) < 2700
    assert estimate_tokens(system_prompt.build_system_prompt("tiny")) < 700
    assert estimate_tokens(system_prompt.build_system_prompt("detailed")) > 6000


def test_compact_prompt_names_every_tool_and_keeps_the_browser_rules(monkeypatch):
    # legacy mode (EXTRA_TOOLS_ENABLED=false): every tool is named in the prompt. The default mode,
    # where only the core tools are named and the rest come from list_extra_tools, is in test_extra_tools.py.
    monkeypatch.setattr(config, "EXTRA_TOOLS_ENABLED", False)
    prompt = system_prompt.build_system_prompt("compact")
    missing = [n for n in tools_all.all_tools() if n not in prompt]
    assert not missing, missing
    assert "open_app:firefox" in prompt and "WEB RESEARCH TOOLS" in prompt and "YOUR BROWSER" in prompt
    assert "list_tools" in prompt and "tool_help" in prompt


def test_tiny_prompt_points_at_discovery_and_separates_the_browsers(monkeypatch):
    monkeypatch.setattr(config, "EXTRA_TOOLS_ENABLED", False)
    prompt = system_prompt.build_system_prompt("tiny")
    assert "list_tools" in prompt and "web_*" in prompt and "visible browser" in prompt
    assert "api" in prompt     # category names are listed


def test_prompt_uses_the_live_user_name(monkeypatch):
    monkeypatch.setattr(config, "USER_NAME", "Zephyr")
    assert "Zephyr" in system_prompt.build_system_prompt("compact")


def test_relevant_tools_hint_finds_the_right_tools():
    hint = system_prompt.relevant_tools_hint("how much is 250 usd in euros")
    assert "convert_currency" in hint
    assert system_prompt.relevant_tools_hint("hello there") == ""


def test_list_tools_and_tool_help():
    assert "api (" in tools_all.list_tools("")["message"]
    assert "convert_currency" in tools_all.list_tools("api")["message"]
    assert not tools_all.list_tools("nope")["success"]
    assert "Frankfurter" in tools_all.tool_help("convert_currency")["message"]
    assert tools_all.tool_help("speak")["success"]
    assert not tools_all.tool_help("convert_curency")["success"]


# --------------------------------------------------------- failure cooldowns
@pytest.fixture(autouse=False)
def fresh():
    llm_client.clear_cooldowns()
    llm_client._NO_EXTRAS.clear()
    yield
    llm_client.clear_cooldowns()


def test_failing_model_is_skipped_on_the_next_request(fresh, monkeypatch):
    calls = []

    def fake(base_url, api_key, model, messages, **kw):
        calls.append(model)
        if model == "big":
            raise llm_client.LLMError("413 Payload Too Large: nope")
        return "ok"
    monkeypatch.setattr(llm_client, "_call_openai_compatible", fake)
    chain = [("groq", "u", "k", ["big", "small"])]
    msgs = [{"role": "system", "content": "s"}, {"role": "user", "content": "hi"}]
    assert llm_client._try_provider_chain(chain, msgs) == "ok"
    assert calls == ["big", "small"]
    calls.clear()
    assert llm_client._try_provider_chain(chain, msgs) == "ok"
    assert calls == ["small"]                      # "big" is cooling down


def test_cooled_down_models_are_still_tried_if_nothing_else_works(fresh, monkeypatch):
    llm_client._penalize("groq", "only", "429 Too Many Requests")
    monkeypatch.setattr(llm_client, "_call_openai_compatible", lambda *a, **k: "worked")
    assert llm_client._try_provider_chain([("groq", "u", "k", ["only"])], [{"role": "user", "content": "x"}]) == "worked"


def test_413_with_a_stated_limit_is_retried_trimmed(fresh, monkeypatch):
    seen = []

    def fake(base_url, api_key, model, messages, **kw):
        seen.append(total_tokens(messages))
        if len(seen) == 1:
            raise llm_client.LLMError('413 Payload Too Large: {"error":{"message":"Limit 8000, Requested 9591"}}')
        return "fit"
    monkeypatch.setattr(config, "CONTEXT_BUDGET_TOKENS", 20000)   # so only the retry trims
    monkeypatch.setattr(llm_client, "_call_openai_compatible", fake)
    msgs = _convo(turns=40, obs_chars=1500)
    assert llm_client._try_provider_chain([("groq", "u", "k", ["m"])], msgs) == "fit"
    assert seen[1] < 8000 - 300 and seen[1] < seen[0]


@pytest.mark.parametrize("error,expected", [
    ("429 Too Many Requests: Please try again in 7.5s", (9, 17)),
    ("413 Payload Too Large", (600, 600)),
    ("404 Not Found: model decommissioned", (6 * 3600, 6 * 3600)),
    ("503 Service Unavailable", (45, 45)),
])
def test_cooldown_lengths(error, expected):
    seconds, _ = llm_client._cooldown_for(error)
    assert expected[0] <= seconds <= expected[1]


def test_invalid_key_cools_the_whole_provider(fresh):
    llm_client._penalize("groq", "m1", "401 Unauthorized: invalid api key")
    assert llm_client._cooling("groq", "any-other-model") > 0


# ------------------------------------------------ speed-up request parameters
class FakeStream:
    def __init__(self, status=200, text="", lines=None):
        self.status_code, self.ok, self.reason, self.text = status, status < 400, "X", text
        self._lines, self.encoding = lines or [], None
    def iter_lines(self, decode_unicode=True): return iter(self._lines)
    def close(self): pass


def _ok_stream():
    return FakeStream(lines=['data: {"choices":[{"delta":{"content":"hi"}}]}', "data: [DONE]"])


def test_groq_reasoning_models_get_low_effort_and_a_token_cap(fresh, monkeypatch):
    bodies = []
    monkeypatch.setattr(llm_client.requests, "post", lambda url, json=None, **k: bodies.append(json) or _ok_stream())
    llm_client._call_openai_compatible("u", "k", "openai/gpt-oss-120b", [{"role": "user", "content": "x"}], label="groq")
    assert bodies[0]["reasoning_effort"] == "low" and bodies[0]["max_tokens"] == config.LLM_MAX_OUTPUT_TOKENS


def test_models_that_reject_the_extra_parameter_are_retried_plain(fresh, monkeypatch):
    bodies = []

    def post(url, json=None, **k):
        bodies.append(json)
        return FakeStream(400, "unknown parameter reasoning_effort") if "reasoning_effort" in json else _ok_stream()
    monkeypatch.setattr(llm_client.requests, "post", post)
    out = llm_client._call_openai_compatible("u", "k", "openai/gpt-oss-20b", [{"role": "user", "content": "x"}], label="groq")
    assert out == "hi" and len(bodies) == 2 and "reasoning_effort" not in bodies[1]
    assert ("groq", "openai/gpt-oss-20b") in llm_client._NO_EXTRAS


def test_fast_mode_can_be_turned_off(fresh, monkeypatch):
    monkeypatch.setattr(config, "LLM_FAST", False)
    assert llm_client._extra_params("groq", "openai/gpt-oss-120b") == {}


# ------------------------------------------------------------ LM Studio
class Resp:
    def __init__(self, payload, ok=True): self._p, self.ok, self.status_code = payload, ok, 200 if ok else 500
    def json(self): return self._p


LM_API = {"data": [
    {"id": "qwen2.5-vl-7b-instruct", "type": "vlm", "state": "loaded", "loaded_context_length": 8192, "max_context_length": 32768},
    {"id": "llama-3.2-3b-instruct", "type": "llm", "state": "not-loaded", "max_context_length": 131072},
    {"id": "text-embedding-nomic", "type": "embeddings", "state": "not-loaded"},
]}


@pytest.fixture
def lm(monkeypatch):
    monkeypatch.setattr(config, "LMSTUDIO_ENABLED", True)
    monkeypatch.setattr(config, "LMSTUDIO_TEXT_MODEL", "")
    monkeypatch.setattr(config, "LMSTUDIO_VISION_MODEL", "")
    llm_client._LM.update(at=0.0, models=[], error="")
    hits = []
    def get(url, timeout=None, **k):
        hits.append(url)
        if "/api/v0/models" in url:
            return Resp(LM_API)
        return Resp({"data": [{"id": "gemma-3-12b-it"}, {"id": "mistral-7b"}]})
    monkeypatch.setattr(llm_client.requests, "get", get)
    return hits


def test_lmstudio_reports_vision_models_context_and_skips_embeddings(lm):
    info = llm_client.lmstudio_models_info()
    assert [m["id"] for m in info] == ["qwen2.5-vl-7b-instruct", "llama-3.2-3b-instruct"]
    assert llm_client._models_for("lmstudio", "vision") == ["qwen2.5-vl-7b-instruct"]
    assert llm_client._models_for("lmstudio", "text")[0] == "qwen2.5-vl-7b-instruct"     # loaded first
    assert llm_client.lmstudio_context() == 8192


def test_lmstudio_lookups_are_cached(lm):
    llm_client.lmstudio_models_info(); llm_client.lmstudio_models_info(); llm_client._models_for("lmstudio", "text")
    assert len(lm) == 1


def test_lmstudio_not_asked_when_disabled(lm, monkeypatch):
    monkeypatch.setattr(config, "LMSTUDIO_ENABLED", False)
    assert llm_client.lmstudio_models_info() == [] and lm == []


def test_lmstudio_falls_back_to_the_openai_list_with_a_name_heuristic(monkeypatch):
    monkeypatch.setattr(config, "LMSTUDIO_ENABLED", True)
    monkeypatch.setattr(config, "LMSTUDIO_VISION_MODEL", "")
    llm_client._LM.update(at=0.0, models=[], error="")
    def get(url, timeout=None, **k):
        if "/api/v0/" in url:
            raise ConnectionError("old LM Studio")
        return Resp({"data": [{"id": "gemma-3-12b-it"}, {"id": "mistral-7b"}]})
    monkeypatch.setattr(llm_client.requests, "get", get)
    assert llm_client._models_for("lmstudio", "vision") == ["gemma-3-12b-it"]


def test_unreachable_lmstudio_does_not_stall_repeated_calls(monkeypatch):
    monkeypatch.setattr(config, "LMSTUDIO_ENABLED", True)
    llm_client._LM.update(at=0.0, models=[], error="")
    n = []
    monkeypatch.setattr(llm_client.requests, "get", lambda *a, **k: n.append(1) or (_ for _ in ()).throw(ConnectionError("down")))
    for _ in range(5):
        llm_client._models_for("lmstudio", "text")
    assert len(n) == 2         # one attempt (two endpoints), then cached for a few seconds


def test_small_local_context_gets_a_small_budget(lm):
    budget, cap = llm_client._budget_for("lmstudio")
    assert budget < 8192 and cap == 700


def test_vision_screenshots_are_shrunk_for_local_models_and_scaled_back(monkeypatch):
    PIL = pytest.importorskip("PIL.Image")
    import base64, io
    img = PIL.new("RGB", (2000, 1000), "white")
    buf = io.BytesIO(); img.save(buf, "PNG")
    b64 = base64.b64encode(buf.getvalue()).decode()
    sent = []
    monkeypatch.setattr(config, "LMSTUDIO_ENABLED", True)
    monkeypatch.setattr(config, "LMSTUDIO_VISION_MODEL", "vlm")
    monkeypatch.setattr(config, "PRIMARY_PROVIDER", "lmstudio")
    monkeypatch.setattr(config, "VISION_MODEL_OVERRIDE", "")
    monkeypatch.setattr(llm_client, "_call_openai_compatible", lambda base, key, model, msgs, **k: sent.append(msgs) or "500,250")
    text, seen = llm_client.describe_image_ex(b64, "Screenshot is {size} px. Where?", size=(2000, 1000))
    assert text == "500,250" and seen == (1024, 512)
    assert "1024x512" in sent[0][0]["content"][0]["text"]
