import pytest

from troy import dispatcher
from troy.dispatcher import _parse_int_pair, execute, INFO_COMMANDS


class TestParseIntPair:
    def test_comma_separated(self):
        assert _parse_int_pair("100,200") == (100, 200)

    def test_pipe_separated(self):
        assert _parse_int_pair("100|200") == (100, 200)

    def test_handles_whitespace(self):
        assert _parse_int_pair(" 100 , 200 ") == (100, 200)

    def test_handles_float_like_input(self):
        assert _parse_int_pair("100.0,200.0") == (100, 200)


class TestGetContextRouting:
    """get_context is a special-cased, always-available command (like
    get_time) rather than a registry entry -- it must route straight to
    tools_all.get_context_snapshot() and always return a usable snapshot
    for the model to re-orient itself with, even if some sub-checks
    inside it silently fail on this machine."""

    def test_get_context_returns_a_successful_snapshot(self):
        result = execute("get_context", "")
        assert result["success"] is True
        assert "Time:" in result["message"]


class TestExecuteRouting:
    def test_speak_returns_the_text_as_speech(self):
        result = execute("speak", "hello there")
        assert result == {"success": True, "message": "hello there", "is_speech": True}

    def test_done_marks_is_done(self):
        result = execute("done", "")
        assert result.get("is_done") is True

    def test_unknown_command_falls_through_to_tools_all_and_fails_cleanly(self):
        result = execute("not_a_real_command_at_all", "")
        assert result["success"] is False

    def test_a_raising_command_is_caught_and_reported(self, monkeypatch):
        import troy.tools_all as tools_all
        def _boom(arg):
            raise RuntimeError("simulated failure")
        monkeypatch.setattr(tools_all, "open_app", _boom)
        result = execute("open_app", "whatever")
        assert result["success"] is False
        assert "simulated failure" in result["message"]

    def test_wait_command_actually_waits_approximately_the_right_duration(self):
        import time
        start = time.monotonic()
        execute("wait", "0.2")
        elapsed = time.monotonic() - start
        assert 0.15 <= elapsed <= 1.0

    def test_wait_is_interruptible_by_stop_control(self):
        import time
        from troy import stop_control
        stop_control.stop_controller.request_stop()
        try:
            start = time.monotonic()
            execute("wait", "5")
            elapsed = time.monotonic() - start
            assert elapsed < 1.0, "wait: should have returned almost immediately once stopped"
        finally:
            stop_control.stop_controller.clear()

    def test_commands_are_refused_once_stopped(self):
        from troy import stop_control
        stop_control.stop_controller.request_stop()
        try:
            result = execute("speak", "should not run")
            assert result["success"] is False
        finally:
            stop_control.stop_controller.clear()


class TestInfoCommands:
    def test_info_commands_includes_hardcoded_and_registry_names(self):
        # a hand-picked hardcoded one, plus one that comes from the
        # registry's info=True tools
        assert "screenshot" in INFO_COMMANDS
        assert "get_cpu_info" in INFO_COMMANDS

    def test_action_commands_are_not_in_info_commands(self):
        assert "open_app" not in INFO_COMMANDS
        assert "click" not in INFO_COMMANDS
