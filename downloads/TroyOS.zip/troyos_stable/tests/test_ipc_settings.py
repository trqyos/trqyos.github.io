import pytest

from troy import config, ipc_host, settings_store


@pytest.fixture
def host(tmp_path, monkeypatch):
    monkeypatch.setattr(settings_store, "SETTINGS_FILE", str(tmp_path / "troy_settings.json"))
    monkeypatch.setattr(ipc_host, "_emit", lambda *a, **k: None)
    for key in ("PRIMARY_PROVIDER", "TEXT_MODEL_OVERRIDE", "VISION_MODEL_OVERRIDE", "NVIDIA_API_KEY", "TTS_RATE", "ESCALATION_ENABLED"):
        monkeypatch.setattr(config, key, getattr(config, key))
    return ipc_host.IPCHost.__new__(ipc_host.IPCHost)  # no agent/mobile side effects needed


def test_update_applies_and_persists(host, tmp_path):
    r = host._m_settings_update({"changes": {"TTS_RATE": "190", "ESCALATION_ENABLED": "false"}})
    assert config.TTS_RATE == 190 and config.ESCALATION_ENABLED is False
    assert sorted(r["applied"]) == ["ESCALATION_ENABLED", "TTS_RATE"]
    assert "190" in (tmp_path / "troy_settings.json").read_text()


def test_unknown_key_rejected_atomically(host):
    before = config.TTS_RATE
    with pytest.raises(ValueError):
        host._m_settings_update({"changes": {"TTS_RATE": 250, "NOPE": 1}})
    assert config.TTS_RATE == before


def test_secrets_are_write_only(host):
    host._m_settings_update({"changes": {"NVIDIA_API_KEY": "secret-value"}})
    dumped = str(host._m_settings_get({}))
    assert "secret-value" not in dumped
    assert host._m_settings_get({})["secrets_configured"]["NVIDIA_API_KEY"] is True


def test_model_set_and_clear(host):
    host._m_model_set({"kind": "text", "provider": "nvidia", "model": "z-ai/glm-5.3"})
    assert config.TEXT_MODEL_OVERRIDE == "nvidia:z-ai/glm-5.3"
    host._m_model_set({"kind": "text"})
    assert config.TEXT_MODEL_OVERRIDE == ""
    with pytest.raises(ValueError):
        host._m_model_set({"kind": "audio"})


def test_provider_list_and_primary(host):
    host._m_settings_update({"changes": {"NVIDIA_API_KEY": "k"}})
    host._m_provider_set_primary({"provider": "nvidia"})
    providers = {p["id"]: p for p in host._m_provider_list({})["providers"]}
    assert providers["nvidia"]["primary"] and providers["nvidia"]["configured"]
    assert "moonshotai/kimi-k3" in providers["nvidia"]["models"]["vision"]
    with pytest.raises(ValueError):
        host._m_provider_set_primary({"provider": "bogus"})


def test_tools_list_includes_new_api_tools(host):
    names = {t["name"] for t in host._m_tools_list({})["tools"]}
    assert {"convert_currency", "wikipedia_summary", "news_search"} <= names
