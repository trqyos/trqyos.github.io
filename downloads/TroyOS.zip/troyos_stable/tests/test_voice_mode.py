"""troy/voice_mode.py -- the full hands-free voice mode orchestrator.

Everything runs against a fake host, two fake speakers, and a recorded
stand-in for the wake_listener surface, with voice.transcribe stubbed out
-- so no microphone, no TTS engine and no network is ever touched. What's
under test is the state machine: listening -> hearing -> transcribing ->
thinking -> speaking -> listening, who hears what and who speaks back.
"""

import sys
import types

import numpy as np
import pytest

from troy import audio_in, config, voice, voice_mode, wake_listener


# ----------------------------------------------------------------- fakes
class FakeSpeaker:
    """Just enough of tts.Speaker for the orchestrator: say/stop/speaking.

    `speaking_after_say` mimics a live engine that really starts playing
    (so callbacks about finished playback make sense); the default False
    makes say() behave like an instantly-done engine.
    """

    def __init__(self):
        self.said = []
        self.stopped = 0
        self._speaking = False
        self.speaking_after_say = False
        self.on_speaking = lambda speaking: None
        self.sink = None

    @property
    def speaking(self):
        return self._speaking

    def say(self, text, interrupt=True, clean=True):
        self.said.append(text)
        self._speaking = self.speaking_after_say

    def stop(self):
        self.stopped += 1
        self._speaking = False

    def finish(self):
        """Pretend playback of everything just ended (fires the real hook)."""
        self._speaking = False


class FakeAgent:
    voice_forced = False


class FakeHost:
    """What voice_mode needs from ipc_host: turn control + event/broadcast."""

    def __init__(self):
        self.start_turns = []
        self.stop_turns = 0
        self.events = []
        self.broadcasts = []
        self.agent = FakeAgent()

    def start_turn(self, text, source):
        self.start_turns.append((text, source))

    def stop_turn(self):
        self.stop_turns += 1

    def emit(self, event, data=None):
        self.events.append((event, data or {}))

    def broadcast(self, data):
        self.broadcasts.append(dict(data))


# -------------------------------------------------------------- fixtures
@pytest.fixture
def wl(monkeypatch):
    """A recording stand-in for wake_listener's module-level surface."""
    calls = []
    state = {"running": False, "conversation": False}

    def record(name, side=None):
        def wrapper(*args, **kwargs):
            calls.append((name, args))
            if side:
                side(*args, **kwargs)
            return True
        monkeypatch.setattr(wake_listener, name, wrapper)

    record("set_hooks")
    record("set_callbacks")
    record("set_conversation", lambda enabled: state.__setitem__("conversation", bool(enabled)))
    record("set_paused")
    record("extend_conversation")
    monkeypatch.setattr(wake_listener, "start", lambda: state.__setitem__("running", True) or True)
    monkeypatch.setattr(wake_listener, "stop", lambda: state.__setitem__("running", False))
    monkeypatch.setattr(wake_listener, "is_running", lambda: state["running"])
    monkeypatch.setattr(wake_listener, "in_conversation", lambda: state["conversation"])
    return {"calls": calls, "state": state}


@pytest.fixture
def stt_ok(monkeypatch):
    monkeypatch.setattr(voice, "stt_status", lambda: {"engine": "stub", "available": True, "reason": ""})


@pytest.fixture
def vm(wl, stt_ok, isolated_storage, monkeypatch):
    """A VoiceMode wired to fakes (voice output off, phone voice on by
    default like the shipped settings)."""
    monkeypatch.setattr(config, "MOBILE_VOICE_ENABLED", True)
    host, pc, phone = FakeHost(), FakeSpeaker(), FakeSpeaker()
    mode = voice_mode.VoiceMode(host, pc_speaker=pc, phone_speaker=phone)
    mode.pc_speaker.on_speaking = mode._on_pc_speaking   # so pc.finish() paths are realistic
    mode.test = {"host": host, "pc": pc, "phone": phone}
    return mode


def events(vm, name):
    return [d for e, d in vm.test["host"].events if e == name]


def utterance(mode, text, monkeypatch, has_speech=True):
    """One phone utterance that `transcribes` to `text`."""
    monkeypatch.setattr(voice, "transcribe", lambda pcm, rate: text)
    monkeypatch.setattr(audio_in, "has_speech", lambda pcm, rate=audio_in.RATE: has_speech)
    return mode.handle_phone_audio(np.zeros(16000, dtype=np.int16), 16000)


# ------------------------------------------------------ start / stop
class TestStartStop:
    def test_start_refused_when_stt_unavailable(self, monkeypatch):
        monkeypatch.setattr(voice, "stt_status", lambda: {"engine": "x", "available": False, "reason": "pip install thing"})
        mode = voice_mode.VoiceMode(FakeHost(), pc_speaker=FakeSpeaker(), phone_speaker=FakeSpeaker())
        r = mode.start()
        assert r["started"] is False and "pip install thing" in r["error"]

    def test_start_refused_when_microphone_cannot_open(self, vm, monkeypatch):
        monkeypatch.setattr(wake_listener, "start", lambda: False)
        r = vm.start()
        assert r["started"] is False and "microphone" in r["error"].lower()
        assert vm.active is False

    def test_start_installs_conversation_mode(self, vm, wl):
        r = vm.start()
        assert r["started"] is True
        assert vm.active and vm.source == "pc" and vm.state == "listening"
        assert vm.test["host"].agent.voice_forced is True
        assert ("set_conversation", (True,)) in wl["calls"]
        assert ("set_paused", (False,)) in wl["calls"]
        assert ("set_hooks", ()) in wl["calls"] and ("set_callbacks", ()) in wl["calls"]
        assert events(vm, "voice.state")[-1]["state"] == "listening"

    def test_start_greets_aloud(self, vm):
        vm.start()
        assert vm.test["pc"].said == ["Voice mode on. I'm listening."]

    def test_start_twice_is_idempotent(self, vm):
        assert vm.start()["started"] is True
        assert vm.start() == {"started": True, "already": True}
        assert len(vm.test["pc"].said) == 1          # no second greeting

    def test_stop_turns_everything_off(self, vm, wl):
        vm.start()
        vm.stop(reason="user", say="Voice mode off.")
        assert vm.active is False and vm.muted is False
        assert vm.state == "off"
        assert ("set_conversation", (False,)) in wl["calls"]
        assert "Voice mode off." in vm.test["pc"].said
        assert events(vm, "voice.ended")[-1] == {"reason": "user"}
        assert vm.test["host"].agent.voice_forced is False

    def test_stop_stops_listener_it_started(self, vm, wl):
        vm.start()                                    # listener wasn't running -> voice mode starts it
        vm.stop()
        assert wl["state"]["running"] is False

    def test_stop_leaves_a_listener_it_did_not_start(self, vm, wl):
        wl["state"]["running"] = True                 # the plain wake-word listener was already on
        vm.start()
        vm.stop()
        assert wl["state"]["running"] is True

    def test_stop_keeps_listener_when_always_listening_setting_on(self, vm, wl, monkeypatch):
        monkeypatch.setattr(config, "VOICE_INPUT_ENABLED", True)
        vm.start()
        vm.stop()
        assert wl["state"]["running"] is True


# ------------------------------------------------------------ mute / cut
class TestMuteAndInterrupt:
    def test_mute_pauses_the_microphone(self, vm, wl):
        vm.start()
        vm.set_muted(True)
        assert vm.muted and vm.state == "muted"
        assert ("set_paused", (True,)) in wl["calls"]
        vm.set_muted(False)
        assert vm.state == "listening" and ("set_paused", (False,)) in wl["calls"]

    def test_mute_while_off_only_records_the_flag(self, vm):
        vm.set_muted(True)
        assert vm.muted is True and vm.state == "off"

    def test_interrupt_silences_and_cancels_the_turn(self, vm):
        vm.start()
        vm.interrupt()
        host, pc, phone = vm.test["host"], vm.test["pc"], vm.test["phone"]
        assert pc.stopped == 1 and phone.stopped == 1 and host.stop_turns == 1
        assert vm.state == "listening"

    def test_barge_in_quiets_the_pc_without_ending_mode(self, vm):
        vm.start()
        vm._on_barge_in()
        assert vm.test["pc"].stopped == 1 and vm.test["host"].stop_turns == 1
        assert vm.active is True


# ----------------------------------------------------- the PC microphone
class TestPCUtterances:
    def test_a_heard_command_starts_a_voice_turn(self, vm):
        vm.start()
        vm._on_pc_command("what's the weather tomorrow")
        assert vm.test["host"].start_turns == [("what's the weather tomorrow", "voice")]
        assert vm.state == "thinking"
        assert vm._last_input == "pc"

    def test_listener_state_maps_to_voice_state(self, vm):
        vm.start()
        vm._on_listener_state("hearing")
        assert vm.state == "hearing"
        vm._on_listener_state("thinking")
        assert vm.state == "transcribing"
        vm._on_listener_state("whatever")
        assert vm.state == "listening"

    def test_listener_state_suppressed_while_troy_speaks(self, vm):
        vm.start()
        vm.test["pc"]._speaking = True                 # the real Speaker is mid-playback when it fires this
        vm._on_pc_speaking(True)
        assert vm.state == "speaking"
        vm._on_listener_state("hearing")
        assert vm.state == "speaking"                 # don't thrash the UI mid-sentence

    def test_when_troy_stops_speaking_it_listens_again(self, vm, wl):
        vm.start()
        vm._on_pc_speaking(True)
        vm._on_pc_speaking(False)
        assert vm.state == "listening"
        assert ("extend_conversation", ()) in wl["calls"]   # follow-up window re-opened

    def test_transcripts_reach_both_frontends(self, vm):
        vm._on_transcript("hello world")
        assert events(vm, "voice.transcript") == [{"text": "hello world", "source": "pc"}]
        assert vm.test["host"].broadcasts[-1] == {"type": "voice", "action": "transcript", "text": "hello world", "source": "pc"}

    def test_mic_level_is_throttled(self, vm):
        vm._on_level(0.5)
        vm._on_level(0.6)                              # within 0.1 s -> swallowed
        assert len(events(vm, "voice.level")) == 1
        assert events(vm, "voice.level")[0]["level"] == 0.5


# ------------------------------------------------------ agent progress
class TestAgentState:
    def test_thinking_is_shown_while_a_turn_runs(self, vm):
        vm.start()
        vm.agent_state("thinking", "opening Firefox")
        assert vm.state == "thinking"
        assert events(vm, "voice.state")[-1]["detail"] == "opening Firefox"

    def test_idle_returns_to_listening(self, vm):
        vm.start()
        vm.agent_state("thinking")
        vm.agent_state("idle")
        assert vm.state == "listening"

    def test_agent_state_ignored_when_mode_is_off(self, vm):
        vm.agent_state("thinking")
        assert vm.state == "off"

    def test_agent_state_suppressed_while_speaking(self, vm):
        vm.start()
        vm.test["pc"]._speaking = True                 # mid-playback, like the real Speaker
        vm._on_pc_speaking(True)
        vm.agent_state("thinking")
        assert vm.state == "speaking"


# ------------------------------------------------------------ reply output
class TestSpeakRouting:
    def test_speak_out_loud_in_voice_mode(self, vm):
        vm.start()
        vm.speak("It's noon.")
        assert vm.test["pc"].said[-1] == "It's noon."

    def test_speak_out_loud_when_setting_enabled(self, vm, monkeypatch):
        monkeypatch.setattr(config, "VOICE_OUTPUT_ENABLED", True)
        vm.speak("always talking")
        assert vm.test["pc"].said[-1] == "always talking"

    def test_silent_when_voice_is_off(self, vm):
        vm.speak("crickets")
        assert vm.test["pc"].said == []

    def test_replies_go_to_the_phone_after_a_phone_utterance(self, vm, monkeypatch):
        vm.start()
        vm.phone_start()
        utterance(vm, "hi troy", monkeypatch)          # phone-voice turn -> last input = phone
        vm.speak("hello from the phone side")
        assert vm.test["phone"].said[-1] == "hello from the phone side"
        assert vm.test["pc"].said == ["Voice mode on. I'm listening."]

    def test_say_on_pc_is_for_system_messages(self, vm):
        vm.say_on_pc("Heads up.")
        assert vm.test["pc"].said == ["Heads up."]


# ------------------------------------------------------------- the phone
class TestPhoneVoice:
    def test_phone_start_blocked_when_disabled(self, vm, monkeypatch):
        monkeypatch.setattr(config, "MOBILE_VOICE_ENABLED", False)
        with pytest.raises(ValueError, match="turned off"):
            vm.phone_start()

    def test_phone_start_needs_stt_on_the_pc(self, vm, monkeypatch):
        monkeypatch.setattr(voice, "stt_status", lambda: {"engine": "x", "available": False, "reason": "pip install thing"})
        with pytest.raises(ValueError, match="pip install thing"):
            vm.phone_start()

    def test_phone_start_reports_speaker_and_engine(self, vm):
        r = vm.phone_start()
        assert r == {"ok": True, "speaker": config.VOICE_PHONE_SPEAKER, "engine": "stub"}
        assert vm._phone_voice is True
        assert events(vm, "voice.phone")[-1] == {"active": True}

    def test_phone_stop(self, vm):
        vm.phone_start()
        vm.phone_stop()
        assert vm._phone_voice is False
        assert events(vm, "voice.phone")[-1] == {"active": False}

    def test_phone_event_reports_speaking_state(self, vm):
        vm.phone_start()
        vm.phone_event({"speaking": True})
        assert events(vm, "voice.phone")[-1] == {"active": True, "speaking": True}

    def test_audio_before_voice_started_is_rejected(self, vm, monkeypatch):
        monkeypatch.setattr(voice, "transcribe", lambda pcm, rate: "hello")
        with pytest.raises(ValueError, match="isn't on"):
            vm.handle_phone_audio(np.zeros(16000, dtype=np.int16), 16000)

    def test_silent_utterance_is_ignored(self, vm, monkeypatch):
        vm.phone_start()
        r = utterance(vm, "whatever", monkeypatch, has_speech=False)
        assert r == {"action": "ignored", "reason": "silence"}
        assert vm.test["host"].start_turns == []

    def test_noise_utterance_is_ignored(self, vm, monkeypatch):
        vm.phone_start()
        r = utterance(vm, "uh", monkeypatch)
        assert r == {"action": "ignored", "reason": "nothing understood"}
        assert events(vm, "voice.transcript") == []

    def test_a_phone_utterance_starts_a_turn(self, vm, monkeypatch):
        vm.phone_start()
        r = utterance(vm, "what time is it in tokyo", monkeypatch)
        assert r == {"action": "turn", "text": "what time is it in tokyo"}
        assert vm.test["host"].start_turns == [("what time is it in tokyo", "phone-voice")]
        assert vm._last_input == "phone"
        assert events(vm, "voice.transcript") == [{"text": "what time is it in tokyo", "source": "phone"}]

    def test_wake_word_is_stripped_from_phone_utterances(self, vm, monkeypatch):
        monkeypatch.setattr(config, "WAKE_WORD", "troy")
        vm.phone_start()
        r = utterance(vm, "hey troy, open notepad", monkeypatch)
        assert r == {"action": "turn", "text": "open notepad"}

    def test_end_phrase_leaves_phone_voice(self, vm, monkeypatch):
        vm.phone_start()
        r = utterance(vm, "goodbye", monkeypatch)
        assert r == {"action": "end", "text": "goodbye"}
        assert vm._phone_voice is False
        assert vm.test["host"].start_turns == []

    def test_stop_phrase_interrupts_without_a_turn(self, vm, monkeypatch):
        vm.phone_start()
        r = utterance(vm, "stop", monkeypatch)
        assert r == {"action": "stop", "text": "stop"}
        assert vm.test["host"].stop_turns == 1 and vm.test["phone"].stopped == 1
        assert vm.test["host"].start_turns == []

    def test_stale_phone_speech_is_dropped_before_a_new_turn(self, vm, monkeypatch):
        vm.phone_start()
        vm.test["phone"]._speaking = True              # still saying the previous answer
        utterance(vm, "next question", monkeypatch)
        assert vm.test["phone"].stopped == 1


class TestPhoneAudioDelivery:
    def test_sentences_with_audio_are_broadcast_and_cached(self, vm):
        vm.phone_start()
        sink = vm.phone_speaker.sink
        sink.wants_audio = True
        sink("Hello there.", b"fakewav", "wav")
        b = vm.test["host"].broadcasts[-1]
        assert b == {"type": "voice", "action": "speak", "id": 1, "text": "Hello there.",
                     "audio": "/api/voice/audio/1", "fmt": "wav"}
        assert vm.audio(1) == (b"fakewav", "wav")

    def test_text_only_sentences_carry_no_audio_url(self, vm):
        vm.phone_start()
        sink = vm.phone_speaker.sink
        sink.wants_audio = False
        sink("Hi.", None, "none")
        b = vm.test["host"].broadcasts[-1]
        assert b["audio"] is None and vm.audio(b["id"]) is None

    def test_audio_cache_keeps_only_the_last_24(self, vm):
        for i in range(26):
            vm._phone_sink(f"sentence {i}", b"audio", "wav")
        assert vm.audio(1) is None and vm.audio(2) is None
        assert vm.audio(3) == (b"audio", "wav") and vm.audio(26) == (b"audio", "wav")


# ------------------------------------------------------------- leaving
class TestLeaving:
    def test_goodbye_finishes_once_the_farewell_ends(self, vm):
        vm.test["pc"].speaking_after_say = True         # the engine really plays "bye for now"
        vm.start()
        vm._on_conversation_end("goodbye")
        assert "Okay, bye for now." in vm.test["pc"].said
        assert vm.active is False
        assert events(vm, "voice.ended") == []          # still saying goodbye
        vm._on_pc_speaking(False)                       # playback finished
        assert events(vm, "voice.ended")[-1] == {"reason": "goodbye"}
        assert vm.state == "off"

    def test_idle_timeout_ends_immediately(self, vm):
        vm.start()
        vm._on_conversation_end("idle")
        assert vm.active is False and vm.state == "off"
        assert events(vm, "voice.ended")[-1] == {"reason": "idle"}


# ------------------------------------------------------------- devices
class TestDevices:
    def test_devices_lists_inputs_only(self, monkeypatch):
        fake_sd = types.SimpleNamespace(
            default=types.SimpleNamespace(device=(0, 0)),
            query_devices=lambda: [
                {"name": "Built-in Mic", "max_input_channels": 1},
                {"name": "Speakers", "max_input_channels": 0},
                {"name": "USB Mic", "max_input_channels": 2},
            ])
        monkeypatch.setitem(sys.modules, "sounddevice", fake_sd)
        devs = voice_mode.VoiceMode(FakeHost(), pc_speaker=FakeSpeaker(), phone_speaker=FakeSpeaker()).devices()
        assert [d["name"] for d in devs] == ["Built-in Mic", "USB Mic"]
        assert devs[0]["default"] is True and devs[1]["default"] is False

    def test_devices_survives_a_missing_sounddevice(self, monkeypatch):
        monkeypatch.setitem(sys.modules, "sounddevice", None)   # import fails
        assert voice_mode.VoiceMode(FakeHost()).devices() == []

    def test_microphone_check_reports_peak_and_heard(self, vm, monkeypatch):
        fake_sd = types.SimpleNamespace(
            rec=lambda n, **k: np.full((n, 1), 5000, dtype=np.int16),
            wait=lambda: None)
        monkeypatch.setitem(sys.modules, "sounddevice", fake_sd)
        monkeypatch.setattr(wake_listener, "_pick_input_device", lambda sd: None)
        monkeypatch.setattr(audio_in, "has_speech", lambda pcm, rate=audio_in.RATE: True)
        monkeypatch.setattr(voice, "transcribe", lambda pcm, rate: "hello from the test")
        r = vm.test_microphone(seconds=1)
        assert r["ok"] is True
        assert 0.1 < r["peak"] < 0.2 and r["heard"] == "hello from the test" and r["silent"] is False

    def test_microphone_check_survives_a_dead_recorder(self, vm, monkeypatch):
        def boom(n, **k):
            raise OSError("no device")
        monkeypatch.setitem(sys.modules, "sounddevice", types.SimpleNamespace(rec=boom, wait=lambda: None))
        r = vm.test_microphone(seconds=1)
        assert r["ok"] is False and "no device" in r["error"]


# ---------------------------------------------------------------- info
def test_info_shape(vm):
    i = vm.info()
    assert {"active", "state", "source", "muted"} <= set(i)
    assert {"connected", "voice", "speaker"} <= set(i["phone"])
    assert "listener" in i and "conversation" in i


def test_phone_liveness_expires(vm, monkeypatch):
    import troy.voice_mode as vmmod
    vm.phone_ping()
    assert vm._phone_alive() is True
    monkeypatch.setattr(vmmod, "PHONE_ALIVE_SECONDS", -1)   # time travel
    assert vm._phone_alive() is False
