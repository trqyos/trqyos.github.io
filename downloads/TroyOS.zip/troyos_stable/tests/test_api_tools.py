"""Tests for the Open-Meteo / Frankfurter / Wikipedia / NewsAPI tools.
All HTTP is faked -- no network needed."""

from troy import config, tools_all


class FakeResp:
    def __init__(self, payload, status=200):
        self._payload, self.status_code = payload, status
        self.ok = status < 400
        self.reason = "OK" if self.ok else "Not Found"
        self.text = str(payload)
        self.encoding = None

    def json(self):
        return self._payload


def fake_get(routes):
    def _get(url, params=None, headers=None, timeout=None):
        for fragment, payload in routes.items():
            if fragment in url:
                return payload if isinstance(payload, FakeResp) else FakeResp(payload)
        raise AssertionError(f"unexpected URL {url}")
    return _get


def test_all_api_tools_registered_and_info():
    for name in ("geocode_place", "get_weather_forecast", "convert_currency", "get_exchange_rates",
                 "get_historical_rate", "list_currencies", "wikipedia_search", "wikipedia_summary",
                 "news_top_headlines", "news_search"):
        tool = tools_all.get(name)
        assert tool is not None and tool.info and tool.category == "api"


def test_convert_currency(monkeypatch):
    monkeypatch.setattr(tools_all.requests, "get", fake_get({"frankfurter": {"date": "2026-09-25", "rates": {"EUR": 92.1}}}))
    r = tools_all.convert_currency("100|usd|eur")
    assert r["success"] and "92.1 EUR" in r["message"]


def test_convert_currency_bad_args():
    assert not tools_all.convert_currency("abc|USD|EUR")["success"]
    assert not tools_all.convert_currency("100|USD")["success"]


def test_forecast(monkeypatch):
    routes = {
        "geocoding": {"results": [{"name": "Paris", "country": "France", "latitude": 1, "longitude": 2}]},
        "open-meteo.com/v1/forecast": {"daily": {
            "time": ["2026-09-28"], "weather_code": [0], "temperature_2m_max": [20],
            "temperature_2m_min": [10], "precipitation_sum": [0], "precipitation_probability_max": [5],
            "wind_speed_10m_max": [12]}},
    }
    monkeypatch.setattr(tools_all.requests, "get", fake_get(routes))
    r = tools_all.get_weather_forecast("Paris|1")
    assert r["success"] and "2026-09-28" in r["message"] and "10-20" in r["message"]


def test_wikipedia_summary_falls_back_to_search(monkeypatch):
    def _get(url, params=None, headers=None, timeout=None):
        if "rest_v1/page/summary/einstein" in url:
            return FakeResp({"message": "nope"}, status=404)
        if "api.php" in url:
            return FakeResp({"query": {"search": [{"title": "Albert Einstein"}]}})
        return FakeResp({"title": "Albert Einstein", "extract": "German-born physicist \u2011 relativity."})
    monkeypatch.setattr(tools_all.requests, "get", _get)
    r = tools_all.wikipedia_summary("einstein")
    assert r["success"] and "Albert Einstein" in r["message"]
    assert "\u2011" in r["message"]  # non-breaking hyphen survives intact


def test_news_requires_key(monkeypatch):
    monkeypatch.setattr(config, "NEWSAPI_KEY", "")
    r = tools_all.news_search("ai")
    assert not r["success"] and "TROY_NEWSAPI_KEY" in r["message"]


def test_news_search_ok(monkeypatch):
    monkeypatch.setattr(config, "NEWSAPI_KEY", "k")
    monkeypatch.setattr(tools_all.requests, "get", fake_get({"newsapi": {"status": "ok", "articles": [
        {"title": "Headline", "source": {"name": "BBC"}, "publishedAt": "2026-09-27T10:00:00Z", "url": "http://x"}]}}))
    r = tools_all.news_search("ai")
    assert r["success"] and "Headline (BBC, 2026-09-27)" in r["message"]
