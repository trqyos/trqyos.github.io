"""Troy changing its own model mid-chat."""
import pytest

from troy import config, confirmation, llm_client, settings_store, tools_all


@pytest.fixture
def brain(monkeypatch, tmp_path):
    monkeypatch.setattr(settings_store, "SETTINGS_FILE", str(tmp_path / "s.json"))
    for k, v in {"NVIDIA_API_KEY": "n", "GROQ_API_KEY": "g", "PRIMARY_PROVIDER": "groq", "TEXT_MODEL_OVERRIDE": "",
                 "VISION_MODEL_OVERRIDE": "", "ALLOW_MODEL_SWITCH": True, "LMSTUDIO_ENABLED": False}.items():
        monkeypatch.setattr(config, k, v)
    events = []
    settings_store.on_change(lambda keys, src: events.append((keys, src)))
    yield events
    settings_store._listeners.clear()
    confirmation.cancel_all()


def test_list_models_tags_speed_and_vision(brain):
    r = tools_all.list_models("")["message"]
    assert "groq" in r and "nvidia" in r and "[fast]" in r and "[strong]" in r and "vision" in r and "*current provider*" in r


def test_switch_by_name_changes_provider_and_model_and_persists(brain, tmp_path):
    r = tools_all.set_model("glm-5.3-flash")
    assert r["success"] and "nvidia / z-ai/glm-5.3-flash" in r["message"]
    assert config.PRIMARY_PROVIDER == "nvidia" and config.TEXT_MODEL_OVERRIDE == "nvidia:z-ai/glm-5.3-flash"
    assert "glm-5.3-flash" in (tmp_path / "s.json").read_text()
    assert brain and brain[-1][1] == "troy" and "TEXT_MODEL_OVERRIDE" in brain[-1][0]
    assert llm_client._apply_override([("nvidia", "u", "k", ["a", "z-ai/glm-5.3-flash"])], config.TEXT_MODEL_OVERRIDE)[0][3][0] == "z-ai/glm-5.3-flash"


def test_switch_by_provider_and_goal(brain):
    assert tools_all.set_model("groq|gpt-oss-120b")["success"] and config.TEXT_MODEL_OVERRIDE == "groq:openai/gpt-oss-120b"
    assert tools_all.set_model("fast")["success"] and tools_all._speed_class(config.TEXT_MODEL_OVERRIDE.split(":", 1)[1]) == "fast"
    assert tools_all.set_model("strong")["success"] and tools_all._speed_class(config.TEXT_MODEL_OVERRIDE.split(":", 1)[1]) == "strong"
    assert tools_all.set_model("glm-5.3-flsh")["success"] and "flash" in config.TEXT_MODEL_OVERRIDE      # typo tolerated


def test_speed_classes():
    sc = tools_all._speed_class
    assert sc("openai/gpt-oss-120b") == "strong" and sc("openai/gpt-oss-20b") == "fast" and sc("llama-3.3-70b-versatile") == "strong"
    assert sc("z-ai/glm-5.3-flash") == "fast" and sc("gemini-2.5-flash") == "fast" and sc("nvidia/nemotron-3-super-120b-a12b") == "strong"


def test_unknown_models_and_providers_fail_helpfully(brain):
    r = tools_all.set_model("totally-made-up-xyz")
    assert not r["success"] and "list_models" in r["message"]
    r = tools_all.set_model("openrouter|llama")
    assert not r["success"] and "isn't a provider that's set up" in r["message"]
    assert tools_all.set_model("local")["success"] is False


def test_it_can_be_switched_off(brain, monkeypatch):
    monkeypatch.setattr(config, "ALLOW_MODEL_SWITCH", False)
    for call in (lambda: tools_all.set_model("fast"), tools_all.reset_model, lambda: tools_all.set_vision_model("kimi")):
        r = call()
        assert not r["success"] and "turned off" in r["message"]
    assert config.TEXT_MODEL_OVERRIDE == ""


def test_going_from_local_to_cloud_needs_approval(brain, monkeypatch):
    monkeypatch.setattr(config, "LMSTUDIO_ENABLED", True)
    monkeypatch.setattr(config, "PRIMARY_PROVIDER", "lmstudio")
    monkeypatch.setattr(llm_client, "_models_for", lambda label, kind: {"lmstudio": ["qwen-local"], "groq": ["llama-3.3-70b-versatile"], "nvidia": ["z-ai/glm-5.3"]}.get(label, []) if kind == "text" else [])
    r = tools_all.set_model("groq|llama")
    assert r["success"] and r["pending"] and config.PRIMARY_PROVIDER == "lmstudio"          # nothing changed yet
    pending = confirmation.list_pending()
    assert len(pending) == 1 and "sent to groq" in pending[0].description
    confirmation.resolve(pending[0].id, True)
    assert config.PRIMARY_PROVIDER == "groq" and "llama-3.3-70b" in config.TEXT_MODEL_OVERRIDE
    # staying local needs no approval
    monkeypatch.setattr(config, "PRIMARY_PROVIDER", "lmstudio")
    assert tools_all.set_model("qwen")["success"] and not confirmation.list_pending()


def test_reset_and_current(brain):
    tools_all.set_model("glm-5.3-flash")
    assert "Pinned to nvidia:z-ai/glm-5.3-flash" in tools_all.current_model("")["message"]
    assert tools_all.reset_model("")["success"] and config.TEXT_MODEL_OVERRIDE == ""
    assert "Automatic" in tools_all.current_model("")["message"]


def test_vision_model_must_support_images(brain):
    assert not tools_all.set_vision_model("glm-5.3-flash")["success"]
    assert tools_all.set_vision_model("kimi")["success"] and config.VISION_MODEL_OVERRIDE == "nvidia:moonshotai/kimi-k3"


def test_the_prompt_and_registry_know_about_the_tools():
    from troy import system_prompt
    for name in ("set_model", "list_models", "reset_model", "current_model"):
        assert name in system_prompt.build_system_prompt("compact") and tools_all.get(name)
    assert "set_model" in system_prompt.build_system_prompt("tiny")
