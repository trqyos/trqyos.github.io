"""
browser_worker.py exists to solve one specific problem: Playwright's sync
API objects are tied to whichever thread created them, but tool calls can
arrive on any QThreadPool worker thread. These tests fake out the
`playwright` package entirely (real Chromium isn't guaranteed to be
available wherever this test suite runs) and verify the actual mechanism
that matters: one dedicated thread, a blocking job queue, and correct
exception propagation back to the calling thread.
"""

import sys
import types

import pytest


class _FakePage:
    def __init__(self, url="about:blank"):
        self.url = url
        self._title = "Fake Page"

    def goto(self, url, **kw):
        self.url = url
        self._title = f"Title of {url}"

    def title(self):
        return self._title

    def close(self):
        pass


class _FakeContext:
    def __init__(self):
        self.pages_created = 0

    def new_page(self):
        self.pages_created += 1
        return _FakePage()

    def close(self):
        pass


class _FakeChromium:
    def launch_persistent_context(self, profile_dir, **kw):
        return _FakeContext()


class _FakePlaywright:
    chromium = _FakeChromium()

    def stop(self):
        pass


class _FakeSyncPlaywrightCM:
    def start(self):
        return _FakePlaywright()


@pytest.fixture
def fake_playwright(monkeypatch, tmp_path):
    """Installs a fake `playwright.sync_api` module and resets
    browser_worker's module-level state before and after the test, since
    it's a real singleton background thread shared across the process."""
    fake_module = types.ModuleType("playwright.sync_api")
    fake_module.sync_playwright = lambda: _FakeSyncPlaywrightCM()
    fake_pkg = types.ModuleType("playwright")
    monkeypatch.setitem(sys.modules, "playwright", fake_pkg)
    monkeypatch.setitem(sys.modules, "playwright.sync_api", fake_module)

    from troy import config
    monkeypatch.setattr(config, "BROWSER_PROFILE_DIR", str(tmp_path / "profile"))
    monkeypatch.setattr(config, "BROWSER_HEADLESS", True)

    from troy import browser_worker
    yield browser_worker
    _reset_browser_worker(browser_worker)


def _reset_browser_worker(browser_worker):
    """shutdown() assumes a live worker thread will consume the None
    sentinel it enqueues -- but a thread that already exited on its own
    (e.g. the "playwright isn't installed" case, which returns right
    after setting _start_error, before ever reaching its job loop) will
    never consume it, leaving a stale None sitting in the shared,
    module-level _job_queue that would otherwise poison the NEXT test:
    a fresh worker thread would read that leftover None as its first
    "job" and exit immediately, before ever touching the real work
    that test submits. Draining the queue after shutdown() makes each
    test's browser_worker state fully independent of the last."""
    browser_worker.shutdown()
    import time
    time.sleep(0.1)  # give a live thread a moment to actually consume the sentinel
    while not browser_worker._job_queue.empty():
        try:
            browser_worker._job_queue.get_nowait()
        except Exception:  # noqa: BLE001
            break
    browser_worker._thread = None
    browser_worker._playwright = None
    browser_worker._context = None
    browser_worker._pages = []
    browser_worker._active_index = 0
    browser_worker._started.clear()
    browser_worker._start_error = ""


class TestEnsureStarted:
    def test_starts_successfully_with_a_working_playwright(self, fake_playwright):
        err = fake_playwright.ensure_started(timeout=5)
        assert err == ""
        assert fake_playwright.is_running()

    def test_missing_playwright_package_gives_a_clear_error(self, monkeypatch, tmp_path):
        # simulate playwright genuinely not being installed
        monkeypatch.setitem(sys.modules, "playwright.sync_api", None)
        monkeypatch.delitem(sys.modules, "playwright.sync_api", raising=False)
        import builtins
        real_import = builtins.__import__

        def _fake_import(name, *a, **k):
            if name == "playwright.sync_api" or name.startswith("playwright"):
                raise ImportError("No module named 'playwright'")
            return real_import(name, *a, **k)

        monkeypatch.setattr(builtins, "__import__", _fake_import)

        from troy import config
        monkeypatch.setattr(config, "BROWSER_PROFILE_DIR", str(tmp_path / "profile2"))

        from troy import browser_worker
        try:
            err = browser_worker.ensure_started(timeout=5)
            assert "playwright" in err.lower()
        finally:
            _reset_browser_worker(browser_worker)

    def test_calling_ensure_started_twice_is_idempotent(self, fake_playwright):
        fake_playwright.ensure_started(timeout=5)
        thread_1 = fake_playwright._thread
        fake_playwright.ensure_started(timeout=5)
        assert fake_playwright._thread is thread_1


class TestRun:
    def test_run_executes_on_the_worker_thread_and_returns_the_result(self, fake_playwright):
        import threading
        seen_thread_name = {}

        def _do():
            seen_thread_name["name"] = threading.current_thread().name
            return "result-value"

        result = fake_playwright.run(_do)
        assert result == "result-value"
        assert seen_thread_name["name"] == "troy-browser"

    def test_run_propagates_exceptions_to_the_calling_thread(self, fake_playwright):
        def _boom():
            raise RuntimeError("deliberate failure")

        with pytest.raises(RuntimeError, match="deliberate failure"):
            fake_playwright.run(_boom)

    def test_run_times_out_cleanly_for_a_hanging_job(self, fake_playwright):
        import time

        def _hang():
            time.sleep(5)

        with pytest.raises(RuntimeError, match="timed out"):
            fake_playwright.run(_hang, timeout=0.3)

    def test_sequential_jobs_do_not_interfere_with_each_other(self, fake_playwright):
        results = [fake_playwright.run(lambda i=i: i * 2) for i in range(10)]
        assert results == [i * 2 for i in range(10)]


class TestPageAndTabState:
    def test_active_page_exists_after_start(self, fake_playwright):
        fake_playwright.ensure_started(timeout=5)
        page = fake_playwright.get_active_page()
        assert page is not None

    def test_add_page_and_switch_active_index(self, fake_playwright):
        fake_playwright.ensure_started(timeout=5)
        context = fake_playwright.get_context()

        def _new_tab():
            page = context.new_page()
            fake_playwright.add_page(page)
            fake_playwright.set_active_index(len(fake_playwright.list_pages()) - 1)
            return page

        new_page = fake_playwright.run(_new_tab)
        assert len(fake_playwright.list_pages()) == 2
        assert fake_playwright.get_active_index() == 1
        assert fake_playwright.get_active_page() is new_page

    def test_goto_actually_mutates_the_fake_page_state(self, fake_playwright):
        def _do():
            page = fake_playwright.get_active_page()
            page.goto("https://example.com")
            return page.title()

        title = fake_playwright.run(_do)
        assert title == "Title of https://example.com"
        assert fake_playwright.get_active_page().url == "https://example.com"


class TestShutdown:
    def test_shutdown_stops_the_worker_thread(self, fake_playwright):
        fake_playwright.ensure_started(timeout=5)
        assert fake_playwright.is_running()
        fake_playwright.shutdown()
        import time
        time.sleep(0.3)
        assert fake_playwright._thread is not None
        assert not fake_playwright._thread.is_alive()
