"""The phone page's second life: the voice 'start_turn' regression, the allow-listed /api/rpc door
(chats, tasks, memory, settings), and the events that keep the phone in step with the PC app."""
import socket
import time

import pytest
import requests

from troy import config, ipc_host, mobile_server, settings_store


class FakeAgent:
    def __init__(self, on_speak=None, on_state=None, on_tool_result=None):
        self.history, self.calls, self.voice_forced = [], [], False

    def handle_user_input(self, text, source="typed"): self.calls.append((text, source))
    def resume_with_observation(self, text): pass
    def export_history(self): return list(self.history)
    def load_history(self, h): self.history = list(h)
    def refresh_memory_context(self): pass
    def refresh_situational_context(self): pass


@pytest.fixture
def host(isolated_storage, monkeypatch, tmp_path):
    events, sent = [], []
    monkeypatch.setattr(ipc_host, "TroyAgent", FakeAgent)
    monkeypatch.setattr(ipc_host, "_emit", lambda event, data=None: events.append((event, data or {})))
    monkeypatch.setattr(settings_store, "SETTINGS_FILE", str(tmp_path / "troy_settings.json"))
    monkeypatch.setattr(mobile_server, "broadcast", lambda ev: sent.append(ev))
    monkeypatch.setattr(config, "VOICE_OUTPUT_ENABLED", False)
    h = ipc_host.IPCHost()
    h.events, h.sent = events, sent
    return h


def wait_for(cond, seconds=3.0):
    end = time.time() + seconds
    while time.time() < end:
        if cond():
            return True
        time.sleep(0.02)
    return False


# ---- the reported bug: "'IPCHost' object has no attribute 'start_turn'" -------------------------
def test_host_has_the_start_turn_that_voice_mode_calls(host):
    assert callable(host.start_turn) and callable(host.stop_turn) and callable(host.emit) and callable(host.broadcast)


def test_a_phone_voice_utterance_reaches_the_agent(host, monkeypatch):
    from troy import voice
    monkeypatch.setattr(config, "MOBILE_VOICE_ENABLED", True)
    monkeypatch.setattr(voice, "stt_status", lambda: {"available": True, "engine": "fake", "reason": ""})
    monkeypatch.setattr(voice, "transcribe", lambda pcm, rate: "what time is it")
    from troy import audio_in
    monkeypatch.setattr(audio_in, "has_speech", lambda pcm: True)
    host.voice.phone_start()
    pcm = (b"\x00\x20\xff\x5f" * 4000)                       # loud enough to count as speech
    r = host.voice.handle_phone_audio(pcm, 16000)
    assert r["action"] == "turn" and r["text"] == "what time is it"
    assert wait_for(lambda: host.agent.calls == [("what time is it", "phone-voice")])


def test_a_pc_voice_command_reaches_the_agent(host):
    host.voice._on_pc_command("open spotify")
    assert wait_for(lambda: host.agent.calls == [("open spotify", "voice")])


# ---- /api/rpc allow-list -----------------------------------------------------------------------
def test_rpc_refuses_anything_off_the_list(host):
    for method in ("mobile_ui.stop", "mobile_ui.regenerate_token", "logs.tail", "voice.devices", "youtube.disconnect", "memory.clear"):
        with pytest.raises(ValueError, match="can't call"):
            host.phone_rpc(method, {})


def test_rpc_only_lets_safe_settings_through(host):
    for bad in ({"GROQ_API_KEY": "x"}, {"MOBILE_UI_PORT": 1}, {"POWER_SAVING": "on", "OPENROUTER_API_KEY": "k"}):
        with pytest.raises(ValueError, match="can't change"):
            host.phone_rpc("settings.update", {"changes": bad})
    with pytest.raises(ValueError, match="can't change"):
        host.phone_rpc("settings.set", {"key": "MOBILE_SCREEN_ENABLED", "value": False})
    out = host.phone_rpc("settings.update", {"changes": {"POWER_SAVING": "on"}})
    assert out["applied"] == ["POWER_SAVING"] and config.POWER_SAVING == "on"
    out = host.phone_rpc("settings.set", {"key": "VOICE_BARGE_IN", "value": False})
    assert out["applied"] == ["VOICE_BARGE_IN"]


def test_rpc_never_exposes_secret_values(host, monkeypatch):
    monkeypatch.setattr(config, "GROQ_API_KEY", "gsk_super_secret", raising=False)
    got = host.phone_rpc("settings.get", {})
    assert "gsk_super_secret" not in repr(got) and got["secrets_configured"]["GROQ_API_KEY"] is True


def test_phone_chats_and_new_chat_tell_the_pc(host):
    host._start_turn("hello there", "typed")
    assert wait_for(lambda: host._pending_turns == 0)
    listed = host.phone_rpc("session.list", {})["sessions"]
    assert len(listed) == 1
    sid = listed[0]["id"]
    host.events.clear()
    host.phone_rpc("session.reset", {})
    assert ("session.changed", {"action": "reset", "by": "phone", "id": None}) in host.events
    host.events.clear()
    loaded = host.phone_rpc("session.load", {"id": sid})
    assert loaded["display_log"][0]["text"] == "hello there"
    ev = [d for e, d in host.events if e == "session.changed"][0]
    assert ev["action"] == "loaded" and ev["by"] == "phone" and ev["id"] == sid
    host.phone_rpc("session.rename", {"id": sid, "title": "Renamed"})
    assert host.phone_rpc("session.list", {})["sessions"][0]["title"] == "Renamed"
    host.phone_rpc("session.delete", {"id": sid})
    assert host.phone_rpc("session.list", {})["sessions"] == []


def test_phone_tasks_round_trip(host):
    created = host.phone_rpc("tasks.create", {"prompt": "say hi", "when": "in 2 hours", "title": "Greeter"})["task"]
    assert created["title"] == "Greeter" and created["status"] == "scheduled"
    listed = host.phone_rpc("tasks.list", {})
    assert [t["id"] for t in listed["tasks"]] == [created["id"]] and "enabled" in listed
    assert host.phone_rpc("tasks.preview", {"when": "every monday at 9"})["ok"]
    assert host.phone_rpc("tasks.pause", {"id": created["id"]})["task"]["status"] == "paused"
    assert host.phone_rpc("tasks.resume", {"id": created["id"]})["task"]["status"] == "scheduled"
    assert host.phone_rpc("tasks.cancel", {"id": created["id"]})["task"]["status"] == "cancelled"
    assert host.phone_rpc("tasks.delete", {"id": created["id"]})["ok"]
    host.tasks.stop() if hasattr(host.tasks, "stop") else None


def test_phone_memory(host):
    host.phone_rpc("memory.add", {"fact": "likes jazz"})
    assert [m["fact"] for m in host.phone_rpc("memory.list", {})["memories"]] == ["likes jazz"]
    assert host.phone_rpc("memory.delete", {"index": 0})["ok"]


def test_face_relay_reaches_pc_and_validates(host):
    host.phone_rpc("face.relay", {"kind": "poke", "origin": "phone-1"})
    assert ("face.event", {"kind": "poke", "origin": "phone-1"}) in host.events
    with pytest.raises(ValueError):
        host.phone_rpc("face.relay", {"kind": "explode"})


def test_selected_events_are_mirrored_to_phones(isolated_storage, monkeypatch, capsys):
    sent = []
    monkeypatch.setattr(mobile_server, "broadcast", lambda ev: sent.append(ev))
    ipc_host._emit("task.changed", {"task": {"id": "a"}})
    ipc_host._emit("session.changed", {"action": "created"})
    ipc_host._emit("agent.speak", {"text": "private-ish"})          # has its own broadcast path: not duplicated here
    assert [e["event"] for e in sent] == ["task.changed", "session.changed"]
    assert all(e["type"] == "event" for e in sent)


# ---- over real HTTP ----------------------------------------------------------------------------
H = {"X-Troy-Token": "T" * 20}


@pytest.fixture
def server(monkeypatch):
    s = socket.socket(); s.bind(("127.0.0.1", 0)); port = s.getsockname()[1]; s.close()
    monkeypatch.setattr(mobile_server, "_session_token", "T" * 20)
    calls = []

    def rpc(method, params):
        calls.append((method, params))
        if method == "tasks.list":
            return {"tasks": [], "enabled": True}
        raise ValueError("boom")
    mobile_server.configure(mobile_server.Bridge(enqueue_turn=lambda t: None, get_display_log=lambda: [],
                                                 get_status=lambda: {}, rpc=rpc))
    mobile_server.start(port)
    yield f"http://127.0.0.1:{port}", calls
    mobile_server.stop()


def test_http_rpc_checks_token_allow_list_and_errors(server):
    base, calls = server
    assert requests.post(base + "/api/rpc", json={"method": "tasks.list"}).status_code == 401
    ok = requests.post(base + "/api/rpc", headers=H, json={"method": "tasks.list", "params": {}})
    assert ok.status_code == 200 and ok.json() == {"ok": True, "result": {"tasks": [], "enabled": True}}
    refused = requests.post(base + "/api/rpc", headers=H, json={"method": "mobile_ui.regenerate_token"})
    assert refused.status_code == 403 and calls == [("tasks.list", {})]
    failed = requests.post(base + "/api/rpc", headers=H, json={"method": "tasks.get", "params": {"id": "x"}})
    assert failed.status_code == 400 and failed.json()["error"] == "boom"


def test_state_carries_the_pcs_clock_and_page_ships_every_asset(server):
    base, _ = server
    st = requests.get(base + "/api/state", headers=H).json()
    assert abs(st["now"] - time.time() * 1000) < 5000
    for name in ("phone.js", "views.js", "phone.css", "avatar.js"):
        assert requests.get(f"{base}/assets/{name}").status_code == 200, name
