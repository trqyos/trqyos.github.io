"""Native function calling: tool schemas, history repair/conversion, SSE tool-call streaming, the provider chain,
and the agent loop driven by a scripted model (no network)."""
import json
import re

import pytest

from troy import agent as agent_mod, config, context_budget, dispatcher, llm_client, memory, stop_control, system_prompt, task_context, tool_history, tool_schema, tools_all
from troy.llm_client import LLMError, NoNativeTools, Reply, StoppedByUser, ToolsUnsupported


# =============================================================================================== helpers
def call(name, args=None, cid=None):
    return {"id": cid or tool_history.new_call_id(), "name": name, "arguments": json.dumps(args if args is not None else {})}


def assert_valid_pairing(msgs):
    """The rule every provider enforces: each tool call answered by tool messages right after it; no stray tool message."""
    pending = set()
    for m in msgs:
        if m["role"] == "tool":
            assert m["tool_call_id"] in pending, f"orphan tool message {m}"
            pending.discard(m["tool_call_id"])
        else:
            assert not pending, f"unanswered tool calls {pending} before {m['role']}"
            pending = {tc["id"] for tc in m.get("tool_calls") or []}
    assert not pending, f"unanswered tool calls at the end: {pending}"


# =============================================================================================== schemas
def test_every_tool_has_a_valid_schema():
    names = tool_schema.all_names()
    assert len(names) > 200
    ident = re.compile(r"^[a-zA-Z][a-zA-Z0-9_]{0,63}$")
    for n in names + [tool_schema.FIND_TOOLS]:
        sc = tool_schema.schema_for(n)
        assert sc and sc["type"] == "function", n
        fn = sc["function"]
        assert ident.match(fn["name"]) and fn["description"].strip(), n
        props, req = fn["parameters"]["properties"], fn["parameters"].get("required", [])
        assert fn["parameters"]["type"] == "object" and set(req) <= set(props), n
        assert all(ident.match(k) and v["type"] in ("string", "integer", "number", "boolean") for k, v in props.items()), n
        json.dumps(sc)


def test_every_tool_can_turn_dummy_arguments_into_a_legacy_arg_string():
    for n in tool_schema.all_names():
        spec = tool_schema.spec_for(n)
        args = {p.name: (p.enum[0] if p.enum else "1" if p.type != "string" else "v") for p in spec.params}
        name, arg = tool_schema.call_to_command(n, args)
        assert name == n and isinstance(arg, str), n


def test_text_only_tools_are_not_offered_natively():
    names = set(tool_schema.all_names())
    assert not names & {"speak", "done", "list_extra_tools", "list_tools", "tool_help"}


@pytest.mark.parametrize("name, args, expected", [
    ("click", {"x": 10.0, "y": "20"}, "10,20"),
    ("open_app", {"name": "firefox"}, "firefox"),
    ("hotkey", {"keys": "ctrl+c"}, "ctrl+c"),
    ("get_time", {}, ""),
    ("drag_mouse", {"x1": 1, "y1": 2, "x2": 3, "y2": 4}, "1,2|3,4"),
    ("create_file", {"path": "a.txt", "content": "hello"}, "a.txt|hello"),
    ("create_file", {"path": "a.txt"}, "a.txt"),
    ("schedule_task", {"when": "in 5 minutes", "instruction": "Open Spotify."}, "in 5 minutes|Open Spotify."),
    ("schedule_task", {"when": "w", "instruction": "i", "approve": "sleep_computer"}, "w|i||sleep_computer"),
    ("set_appearance", {"setting": "Theme", "value": "dark"}, "theme|dark"),
    ("set_power_saving", {"mode": "On"}, "on"),
    ("compress_image", {"source": "a", "destination": "b", "quality": 50}, "a|b|50"),
    ("modify_task", {"id_or_title": "x", "field": "title", "value": "y"}, "x|title|y"),
    ("task_log", {"id_or_title": "x"}, "x"),
    ("mouse_up", {}, ""),
    ("escalate", {"request": "r", "reason": "why"}, "r||||why"),
])
def test_call_to_command(name, args, expected):
    assert tool_schema.call_to_command(name, args) == (name, expected)


@pytest.mark.parametrize("name, args, fragment", [
    ("click", {"x": "abc", "y": 1}, "whole number"),
    ("click", {"x": 1.5, "y": 1}, "whole number"),
    ("click", {"x": 1}, "Missing required parameter 'y'"),
    ("open_app", {}, "Missing required parameter 'name'"),
    ("open_app", {"name": "x", "bogus": 1}, "Unknown parameter"),
    ("open_app", {"name": ["a", "b"]}, "single string value"),
    ("set_power_saving", {"mode": "maybe"}, "one of: off, auto, on"),
    ("create_file", {"path": "a|b", "content": "x"}, "'|'"),
    ("no_such_tool", {}, "no tool named"),
    ("click", "not an object", "JSON object"),
    ("wait", {"seconds": True}, "number"),
])
def test_bad_arguments_are_explained_to_the_model(name, args, fragment):
    with pytest.raises(tool_schema.ToolArgError) as e:
        tool_schema.call_to_command(name, args)
    assert fragment in str(e.value)


def test_a_pipe_is_fine_in_the_last_parameter_and_in_single_parameter_tools():
    assert tool_schema.call_to_command("create_file", {"path": "p", "content": "a|b"})[1] == "p|a|b"
    assert tool_schema.call_to_command("type_text", {"text": "a|b"})[1] == "a|b"


def test_the_token_cost_of_the_default_tools_stays_small():
    full = context_budget.tools_tokens(tool_schema.Toolbox("").schemas())
    tiny = context_budget.tools_tokens(tool_schema.Toolbox("", tiny=True).schemas())
    assert full < 2300 and tiny < 1300, (full, tiny)
    assert context_budget.estimate_tokens(system_prompt.build_native_prompt()) < 800


def test_toolbox_loads_what_the_user_asked_about_and_find_tools_loads_more():
    tb = tool_schema.Toolbox("turn the volume up")
    assert tb.has("volume_up") and tb.has(tool_schema.FIND_TOOLS) and tb.has("open_app")
    assert not tb.has("resize_image")
    out = tool_schema.find_tools(tb, "resize image")
    assert out["success"] and tb.has("resize_image") and "resize_image(source, destination, width, height)" in out["message"]
    assert "No tool matches" in tool_schema.find_tools(tb, "zzzqqq")["message"]
    assert tb.names.count("resize_image") == 1


def test_toolbox_for_a_scheduled_run_includes_task_result():
    assert tool_schema.Toolbox("x", scheduled_run=True).has("task_result")
    assert not tool_schema.Toolbox("x").has("task_result")


# =============================================================================================== history
def _native_exchange():
    c1, c2 = call("get_time"), call("get_system_stats")
    return [
        {"role": "user", "content": "status?"},
        tool_history.assistant_message("On it.", [c1, c2]),
        tool_history.tool_message(c1["id"], "get_time", "10:00", arg=""),
        tool_history.tool_message(c2["id"], "get_system_stats", "FAILED - nope", ok=False),
        tool_history.assistant_message("All good.", []),
    ]


def test_repair_leaves_valid_history_alone_and_fixes_broken_pairing():
    good = _native_exchange()
    assert tool_history.repair(good) == good
    # a stop mid-batch: the second result is missing
    broken = good[:3] + [good[4]]
    fixed = tool_history.repair(broken)
    assert_valid_pairing(fixed)
    assert any("interrupted" in m.get("content", "") for m in fixed if m["role"] == "tool")
    # an orphan result (its call was trimmed away) is dropped
    assert_valid_pairing(tool_history.repair(good[2:]))
    # the history is not mutated
    assert broken == good[:3] + [good[4]]


def test_repair_fixes_duplicate_or_missing_ids_and_bad_arguments():
    m = {"role": "assistant", "content": "", "tool_calls": [
        {"id": "a", "type": "function", "function": {"name": "get_time", "arguments": ""}},
        {"id": "a", "type": "function", "function": {"name": "get_time", "arguments": None}},
        {"id": "", "type": "function", "function": {"name": "get_time", "arguments": "{}"}}]}
    fixed = tool_history.repair([{"role": "user", "content": "x"}, m])
    ids = [tc["id"] for tc in fixed[1]["tool_calls"]]
    assert len(set(ids)) == 3 and all(tc["function"]["arguments"] == "{}" for tc in fixed[1]["tool_calls"])
    assert_valid_pairing(fixed)


def test_to_wire_strips_private_keys():
    wire = tool_history.to_wire(_native_exchange())
    assert all(not ({"fmt", "ok", "arg", "name"} & set(m)) for m in wire)
    assert "content" not in wire[1] or wire[1]["content"]            # fine either way, but never an empty string with tool calls
    empty = tool_history.to_wire([tool_history.assistant_message("", [call("get_time")])])[0]
    assert "content" not in empty and empty["tool_calls"]
    assert tool_history.to_wire(_native_exchange(), keep_tool_name=True)[2]["name"] == "get_time"
    json.dumps(wire)


def test_native_history_flattens_to_the_text_protocol():
    text = tool_history.to_text(_native_exchange())
    assert text[0] == {"role": "user", "content": "status?"}
    assert text[1] == {"role": "assistant", "content": "speak:On it.\nget_time\nget_system_stats"}
    assert text[2]["role"] == "user" and "[OBSERVATION] get_time: -> OK - 10:00" in text[2]["content"]
    assert "[OBSERVATION] get_system_stats: -> FAILED - FAILED - nope" in text[2]["content"] or "FAILED" in text[2]["content"]
    assert text[3] == {"role": "assistant", "content": "speak:All good.\ndone"}
    assert all(not tool_history.is_native(m) for m in text)


def test_flattening_uses_the_real_argument_string():
    c = call("click", {"x": 5, "y": 6})
    text = tool_history.to_text([{"role": "user", "content": "c"}, tool_history.assistant_message("", [c]), tool_history.tool_message(c["id"], "click", "ok", arg="5,6")])
    assert text[1]["content"] == "click:5,6" and "click:5,6 -> OK" in text[2]["content"]


def test_old_text_history_becomes_plain_conversation_for_a_native_model():
    old = [{"role": "user", "content": "open firefox"},
           {"role": "assistant", "content": "speak:On it.\nopen_app:firefox\ndone"},
           {"role": "user", "content": "[OBSERVATION] open_app:firefox -> OK - opened"},
           {"role": "assistant", "content": "speak:Firefox is open.\ndone"},
           {"role": "user", "content": "thanks"}]
    out = tool_history.to_native(old)
    assert out == [{"role": "user", "content": "open firefox"}, {"role": "assistant", "content": "On it.\nFirefox is open."}, {"role": "user", "content": "thanks"}]


def test_a_native_answer_that_looks_like_a_command_is_not_converted():
    msgs = [{"role": "user", "content": "hi"}, tool_history.assistant_message("sure: here you go", [])]
    assert tool_history.to_native(msgs)[1]["content"] == "sure: here you go"
    assert tool_history.to_text(msgs)[1]["content"] == "speak:sure: here you go\ndone"


def test_context_trimming_never_leaves_an_orphan_tool_message():
    msgs = [{"role": "system", "content": "p"}, {"role": "system", "content": "m"}, {"role": "system", "content": "c"}]
    for i in range(30):
        c = call("read_file", {"path": f"f{i}"})
        msgs += [{"role": "user", "content": f"q{i}"}, tool_history.assistant_message("", [c]),
                 tool_history.tool_message(c["id"], "read_file", "x" * 900), tool_history.assistant_message(f"a{i}", [])]
    msgs.append({"role": "user", "content": "latest"})
    out = context_budget.fit_messages(msgs, 1200, message_cap_chars=700)
    assert context_budget.total_tokens(out) <= 1400 and out[-1]["content"] == "latest"
    assert_valid_pairing(tool_history.repair(out[3:]))
    assert context_budget.message_tokens(tool_history.assistant_message("", [call("click", {"x": 1, "y": 2})])) > 8


# =============================================================================================== streaming
class FakeStream:
    def __init__(self, lines, status=200, text=""):
        self.status_code, self.ok, self.reason, self.text = status, status < 400, "X", text
        self._lines, self.encoding = lines, None
    def iter_lines(self, decode_unicode=True): return iter(self._lines)
    def close(self): pass


def sse(*chunks):
    return [f"data: {json.dumps({'choices': [{'delta': c}]})}" for c in chunks] + ["data: [DONE]"]


@pytest.fixture
def fresh():
    llm_client.clear_cooldowns()
    llm_client._NO_TOOLS.clear()
    llm_client._NO_EXTRAS.clear()
    yield
    llm_client._NO_TOOLS.clear()


def stream(monkeypatch, lines, bodies=None, **kw):
    monkeypatch.setattr(llm_client.requests, "post", lambda url, json=None, **k: (bodies.append(json) if bodies is not None else None) or FakeStream(lines, **kw))


def test_tool_call_fragments_are_reassembled(fresh, monkeypatch):
    bodies, started = [], []
    stream(monkeypatch, sse(
        {"content": "On it."},
        {"tool_calls": [{"index": 0, "id": "call_a", "type": "function", "function": {"name": "click", "arguments": ""}}]},
        {"tool_calls": [{"index": 0, "function": {"arguments": '{"x": 1'}}]},
        {"tool_calls": [{"index": 0, "function": {"arguments": ', "y": 2}'}}]},
        {"tool_calls": [{"index": 1, "id": "call_b", "function": {"name": "get_time", "arguments": "{}"}}]},
    ), bodies)
    r = llm_client._call_native("u", "k", "m", [{"role": "user", "content": "x"}], [{"type": "function"}], label="x", on_tool_start=lambda: started.append(1))
    assert r.text == "On it." and [(c["id"], c["name"], c["arguments"]) for c in r.tool_calls] == [("call_a", "click", '{"x": 1, "y": 2}'), ("call_b", "get_time", "{}")]
    assert started == [1, 1] and bodies[0]["tools"] == [{"type": "function"}] and bodies[0]["temperature"] == 0.2
    assert r.provider == "x" and r.model == "m"


def test_servers_that_omit_the_index_or_send_decoded_arguments(fresh, monkeypatch):
    stream(monkeypatch, sse(
        {"tool_calls": [{"id": "a", "function": {"name": "click", "arguments": '{"x":'}}]},
        {"tool_calls": [{"function": {"arguments": ' 1, "y": 2}'}}]},          # no id, no index: continues the last call
        {"tool_calls": [{"id": "b", "function": {"name": "open_app", "arguments": {"name": "firefox"}}}]},   # new id, arguments already decoded
    ))
    r = llm_client._call_native("u", "k", "m", [], [{}], label="x")
    assert [c["name"] for c in r.tool_calls] == ["click", "open_app"]
    assert json.loads(r.tool_calls[0]["arguments"]) == {"x": 1, "y": 2} and json.loads(r.tool_calls[1]["arguments"]) == {"name": "firefox"}


def test_a_call_without_an_id_gets_one_and_a_text_only_reply_has_no_calls(fresh, monkeypatch):
    stream(monkeypatch, sse({"tool_calls": [{"index": 0, "function": {"name": "get_time", "arguments": "{}"}}]}))
    assert llm_client._call_native("u", "k", "m", [], [{}], label="x").tool_calls[0]["id"]
    stream(monkeypatch, sse({"content": "Just words."}))
    r = llm_client._call_native("u", "k", "m", [], [{}], label="x")
    assert r.text == "Just words." and r.tool_calls == []


def test_text_requests_send_no_tools_field(fresh, monkeypatch):
    bodies = []
    stream(monkeypatch, sse({"content": "hi"}), bodies)
    assert llm_client._call_openai_compatible("u", "k", "m", [{"role": "user", "content": "x"}], label="x") == "hi"
    assert "tools" not in bodies[0] and bodies[0]["temperature"] == 0.4


def test_stop_during_a_native_stream_raises(fresh, monkeypatch):
    stream(monkeypatch, sse({"content": "a"}, {"content": "b"}))
    with pytest.raises(StoppedByUser):
        llm_client._call_native("u", "k", "m", [], [{}], label="x", stop_check=lambda: True)


@pytest.mark.parametrize("status, body, unsupported", [
    (400, "tools is not supported for this model", True),
    (404, "No endpoints found that support tool use", True),
    (422, "unknown field: tools", True),
    (400, '{"error":{"code":"tool_use_failed","failed_generation":"<function=x>"}}', False),
    (429, "rate limit: too many tool calls", False),
    (500, "tool server exploded", False),
])
def test_only_a_real_rejection_of_tools_marks_a_model_as_unsupported(fresh, monkeypatch, status, body, unsupported):
    stream(monkeypatch, [], status=status, text=body)
    with pytest.raises(ToolsUnsupported if unsupported else LLMError) as e:
        llm_client._call_native("u", "k", "m", [], [{}], label="x")
    assert isinstance(e.value, ToolsUnsupported) == unsupported


# =============================================================================================== provider chain
def test_a_model_without_tool_support_is_skipped_for_the_next_one_and_remembered(fresh, monkeypatch):
    seen = []

    def fake(base, key, model, msgs, tools, **k):
        seen.append(model)
        if model == "old":
            raise ToolsUnsupported("400 no tools")
        return Reply(text="ok", provider=k.get("label", ""), model=model)
    monkeypatch.setattr(llm_client, "_call_native", fake)
    chain = [("groq", "u", "key", ["old", "new"])]
    r = llm_client._try_provider_chain(chain, None, build_messages=lambda label: [], native={"tools": [{}]})
    assert r.text == "ok" and seen == ["old", "new"] and ("groq", "old") in llm_client._NO_TOOLS
    seen.clear()
    llm_client._try_provider_chain(chain, None, build_messages=lambda label: [], native={"tools": [{}]})
    assert seen == ["new"]                                                      # never asked "old" again
    assert llm_client._cooling("groq", "old") == 0                              # and it was NOT put on cooldown: it works as a text model


def test_when_no_model_supports_tools_the_caller_is_told_to_use_text(fresh, monkeypatch):
    monkeypatch.setattr(llm_client, "_call_native", lambda *a, **k: (_ for _ in ()).throw(ToolsUnsupported("400 no tools")))
    chain = [("groq", "u", "key", ["a", "b"]), ("gemini", "u", "", ["c"])]       # the keyless provider is skipped, not counted
    with pytest.raises(NoNativeTools):
        llm_client._try_provider_chain(chain, None, build_messages=lambda label: [], native={"tools": [{}]})
    with pytest.raises(NoNativeTools):                                           # second time: nothing is even sent
        llm_client._try_provider_chain(chain, None, build_messages=lambda label: [], native={"tools": [{}]})


def test_a_real_failure_is_not_mistaken_for_missing_tool_support(fresh, monkeypatch):
    def fake(base, key, model, msgs, tools, **k):
        raise ToolsUnsupported("400 no tools") if model == "a" else LLMError("500 server error")
    monkeypatch.setattr(llm_client, "_call_native", fake)
    with pytest.raises(LLMError) as e:
        llm_client._try_provider_chain([("groq", "u", "key", ["a", "b"])], None, build_messages=lambda label: [], native={"tools": [{}]})
    assert not isinstance(e.value, NoNativeTools)


# =============================================================================================== the agent loop
class Model:
    """A scripted stand-in for llm_client.chat_tools. Each item is a Reply, an exception, or a function(model, wire, tools, on_text, on_tool_start)."""
    def __init__(self, *script):
        self.script, self.requests = list(script), []

    def __call__(self, build_messages, tools, stop_check=None, on_text=None, on_tool_start=None):
        wire = build_messages("groq")
        self.requests.append({"messages": wire, "tools": [t["function"]["name"] for t in tools], "schemas": tools})
        assert_valid_pairing([m for m in wire if m["role"] != "system"])
        item = self.script.pop(0)
        if callable(item):
            item = item(self, wire, tools, on_text, on_tool_start)
        if isinstance(item, Exception):
            raise item
        return item


def R(text="", *calls):
    return Reply(text=text, tool_calls=list(calls))


@pytest.fixture
def troy(monkeypatch, isolated_storage):
    monkeypatch.setattr(config, "TOOL_CALLING", "auto")
    monkeypatch.setattr(config, "VOICE_SPOKEN_STYLE", True)
    monkeypatch.setattr(config, "MAX_STEPS_PER_TURN", 8)
    stop_control.stop_controller.clear()
    spoken, results, states = [], [], []
    a = agent_mod.TroyAgent(on_speak=spoken.append, on_state=lambda s, d="": states.append((s, d)), on_tool_result=lambda *x: results.append(x))
    a.spoken, a.results, a.states = spoken, results, states
    return a


def use(monkeypatch, *script):
    m = Model(*script)
    monkeypatch.setattr(llm_client, "chat_tools", m)
    return m


def test_a_plain_answer_is_spoken_and_the_request_ends(troy, monkeypatch):
    m = use(monkeypatch, R("Hello there."))
    troy.handle_user_input("hi")
    assert troy.spoken == ["Hello there."] and len(m.requests) == 1
    req = m.requests[0]
    assert tool_schema.FIND_TOOLS in req["tools"] and "open_app" in req["tools"] and "speak" not in req["tools"] and "done" not in req["tools"]
    system = req["messages"][0]["content"]
    assert "calling the tools you were given" in system and "OUTPUT: only commands" not in system
    assert troy.messages[-1]["role"] == "assistant" and troy.messages[-1]["fmt"] == "n"
    assert troy.states[-1] == ("idle", "")


def test_tools_run_and_their_results_go_back_as_tool_messages(troy, monkeypatch):
    seen = []
    monkeypatch.setattr(dispatcher, "execute", lambda name, arg: seen.append((name, arg)) or {"success": True, "message": "10:42"})
    c = call("get_time", {}, "call_1")
    m = use(monkeypatch, R("", c), R("It's 10:42."))
    troy.handle_user_input("what time is it")
    assert seen == [("get_time", "")] and troy.spoken == ["It's 10:42."]
    second = m.requests[1]["messages"]
    assistant = next(x for x in second if x.get("tool_calls"))
    assert assistant["tool_calls"][0]["id"] == "call_1" and "content" not in assistant
    tool = next(x for x in second if x["role"] == "tool")
    assert tool == {"role": "tool", "tool_call_id": "call_1", "content": "10:42"}      # nothing private leaks onto the wire
    assert troy.results == [("get_time", "", True, "10:42")]
    assert ("executing", "get_time") in troy.states


def test_the_arguments_become_the_same_command_a_text_call_would_give(troy, monkeypatch):
    seen = []
    monkeypatch.setattr(dispatcher, "execute", lambda name, arg: seen.append((name, arg)) or {"success": True, "message": "ok"})
    use(monkeypatch, R("", call("click", {"x": 10, "y": 20}), call("create_file", {"path": "a.txt", "content": "hi"}), call("hotkey", {"keys": "ctrl+s"})), R("Done."))
    troy.handle_user_input("do things")
    assert seen == [("click", "10,20"), ("create_file", "a.txt|hi"), ("hotkey", "ctrl+s")]


def test_the_sentence_before_a_tool_call_is_spoken_as_soon_as_the_call_starts(troy, monkeypatch):
    monkeypatch.setattr(dispatcher, "execute", lambda n, a: {"success": True, "message": "ok"})
    order = []
    original = troy.on_speak
    troy.on_speak = lambda t: (order.append(("say", t)), original(t))

    def streaming(model, wire, tools, on_text, on_tool_start):
        on_text("")
        on_text("On it.")
        order.append(("stream", "text done"))
        on_tool_start()                                     # the first tool call begins arriving here
        order.append(("stream", "rest of the reply"))
        return R("On it.", call("get_time"))
    use(monkeypatch, streaming, R("Finished."))
    troy.handle_user_input("go")
    assert order == [("stream", "text done"), ("say", "On it."), ("stream", "rest of the reply"), ("say", "Finished.")]
    assert troy.spoken == ["On it.", "Finished."]                                # the narration is not repeated after the reply


def test_narration_is_spoken_once_even_when_it_was_not_streamed(troy, monkeypatch):
    monkeypatch.setattr(dispatcher, "execute", lambda n, a: {"success": True, "message": "ok"})
    use(monkeypatch, R("Checking.", call("get_time")), R("All fine."))
    troy.handle_user_input("check")
    assert troy.spoken == ["Checking.", "All fine."]


def test_bad_arguments_never_reach_the_tool_and_the_model_can_fix_them(troy, monkeypatch):
    seen = []
    monkeypatch.setattr(dispatcher, "execute", lambda name, arg: seen.append((name, arg)) or {"success": True, "message": "clicked"})
    m = use(monkeypatch, R("", call("click", {"x": "abc", "y": 1}, "c1"), call("click", {"x": 1}, "c2"), call("click", {"x": 3, "y": 4}, "c3")), R("Clicked."))
    troy.handle_user_input("click")
    assert seen == [("click", "3,4")]
    tools = {x["tool_call_id"]: x["content"] for x in m.requests[1]["messages"] if x["role"] == "tool"}
    assert tools["c1"].startswith("FAILED - ") and "whole number" in tools["c1"]
    assert "Missing required parameter 'y'" in tools["c2"] and tools["c3"] == "clicked"


def test_invalid_json_arguments_are_reported_not_crashed_on(troy, monkeypatch):
    monkeypatch.setattr(dispatcher, "execute", lambda *a: pytest.fail("must not run"))
    m = use(monkeypatch, R("", {"id": "c1", "name": "click", "arguments": '{"x": 1,'}), R("Sorry."))
    troy.handle_user_input("click")
    assert "weren't valid JSON" in next(x for x in m.requests[1]["messages"] if x["role"] == "tool")["content"]


def test_an_invented_tool_gets_suggestions_and_runs_nothing(troy, monkeypatch):
    monkeypatch.setattr(dispatcher, "execute", lambda *a: pytest.fail("must not run"))
    m = use(monkeypatch, R("", call("open_aap", {"name": "x"})), R("I can't."))
    troy.handle_user_input("x")
    msg = next(x for x in m.requests[1]["messages"] if x["role"] == "tool")["content"]
    assert "no tool named 'open_aap'" in msg and "open_app" in msg and "find_tools" in msg


def test_a_real_tool_that_was_not_loaded_is_loaded_instead_of_guessed_at(troy, monkeypatch):
    monkeypatch.setattr(dispatcher, "execute", lambda *a: pytest.fail("must not run before its schema was shown"))
    m = use(monkeypatch, R("", call("resize_image", {"source": "a.png"})), R("Let me retry."))
    troy.handle_user_input("hello")
    assert "resize_image" not in m.requests[0]["tools"] and "resize_image" in m.requests[1]["tools"]
    assert "did NOT run" in next(x for x in m.requests[1]["messages"] if x["role"] == "tool")["content"]
    resize = next(s for s in m.requests[1]["schemas"] if s["function"]["name"] == "resize_image")
    assert resize["function"]["parameters"]["required"] == ["source", "destination", "width", "height"]


def test_find_tools_loads_tools_for_the_next_step(troy, monkeypatch):
    seen = []
    monkeypatch.setattr(dispatcher, "execute", lambda name, arg: seen.append((name, arg)) or {"success": True, "message": "resized"})
    m = use(monkeypatch, R("", call("find_tools", {"query": "resize image"})), R("", call("resize_image", {"source": "a.png", "destination": "b.png", "width": 100, "height": 50})), R("Resized."))
    troy.handle_user_input("make a.png smaller")
    assert "resize_image" not in m.requests[0]["tools"] and "resize_image" in m.requests[1]["tools"]
    assert seen == [("resize_image", "a.png|b.png|100|50")] and troy.spoken == ["Resized."]
    assert ("find_tools", "resize image", True) == troy.results[0][:3]


def test_a_tool_that_needs_approval_ends_the_turn_when_the_user_was_already_told(troy, monkeypatch):
    pending = {"success": False, "pending_confirmation": True, "message": "'kill_process' is a medium-risk action. A confirmation prompt is now showing."}
    monkeypatch.setattr(dispatcher, "execute", lambda *a: dict(pending))
    m = use(monkeypatch, R("I'll close Chrome; please approve.", call("kill_process", {"name": "chrome"})))
    troy.handle_user_input("kill chrome")
    assert len(m.requests) == 1 and troy.spoken == ["I'll close Chrome; please approve."]
    assert troy.messages[-1]["content"] == pending["message"]            # not prefixed with FAILED: it isn't a failure


def test_a_tool_that_needs_approval_without_a_word_to_the_user_gets_one_more_step(troy, monkeypatch):
    monkeypatch.setattr(dispatcher, "execute", lambda *a: {"success": False, "pending_confirmation": True, "message": "needs approval"})
    m = use(monkeypatch, R("", call("kill_process", {"name": "chrome"})), R("Waiting for your approval to close Chrome."))
    troy.handle_user_input("kill chrome")
    assert len(m.requests) == 2 and troy.spoken == ["Waiting for your approval to close Chrome."]


def test_approving_resumes_with_a_system_note_the_native_model_keeps(troy, monkeypatch):
    m = use(monkeypatch, R("Closed it."))
    troy.resume_with_observation("[OBSERVATION] kill_process:chrome -> OK - ended")
    sent = [x for x in m.requests[0]["messages"] if x["role"] == "user"]
    assert sent[-1]["content"] == "[SYSTEM] Result of the action the user approved: kill_process:chrome -> OK - ended"
    assert troy.spoken == ["Closed it."]


def test_stopping_mid_batch_skips_the_rest_and_keeps_the_history_valid(troy, monkeypatch):
    def execute(name, arg):
        stop_control.stop_controller.request_stop()
        return {"success": True, "message": "ok"}
    monkeypatch.setattr(dispatcher, "execute", execute)
    use(monkeypatch, R("", call("get_time"), call("get_system_stats"), call("get_storage_info")))
    troy.handle_user_input("everything")
    assert troy.spoken[-1] == "(Stopped.)" and troy.states[-2:] == [("stopped", ""), ("idle", "")]
    assert_valid_pairing(troy.messages[3:])
    assert [m["content"] for m in troy.messages if m["role"] == "tool"][1:] == ["Skipped: stopped by the user."] * 2
    stop_control.stop_controller.clear()


def test_stopping_while_the_model_is_talking_drops_the_turn(troy, monkeypatch):
    use(monkeypatch, StoppedByUser("stop"))
    troy.handle_user_input("hi")
    assert troy.spoken == ["(Stopped.)"] and not any(m.get("content") == "hi" for m in troy.messages)


def test_an_unreachable_model_is_reported_and_the_turn_is_dropped(troy, monkeypatch):
    use(monkeypatch, LLMError("All providers/models failed"))
    troy.handle_user_input("hi")
    assert "couldn't reach any model" in troy.spoken[0] and ("error", "All providers/models failed") in troy.states
    assert troy.messages[3:] == []


def test_the_step_limit_warns_then_stops(troy, monkeypatch):
    monkeypatch.setattr(config, "MAX_STEPS_PER_TURN", 5)
    monkeypatch.setattr(dispatcher, "execute", lambda *a: {"success": True, "message": "ok"})
    m = use(monkeypatch, *[R("", call("get_time")) for _ in range(5)])
    troy.handle_user_input("loop")
    assert len(m.requests) == 5 and troy.spoken[-1] == "(Reached the step limit for this turn.)"
    notes = [x["content"] for x in troy.messages if x["role"] == "user" and "Heads up" in x["content"]]
    assert len(notes) == 3 and "3 step(s) left" in notes[0] and "1 step(s) left" in notes[-1]
    assert_valid_pairing(troy.messages[3:])


def test_an_empty_reply_after_tool_results_is_nudged_once(troy, monkeypatch):
    monkeypatch.setattr(dispatcher, "execute", lambda *a: {"success": True, "message": "ok"})
    m = use(monkeypatch, R("", call("get_time")), R(""), R("It is done."))
    troy.handle_user_input("x")
    assert troy.spoken == ["It is done."] and "haven't told the user" in m.requests[2]["messages"][-1]["content"]
    m2 = use(monkeypatch, R(""))
    troy.spoken.clear()
    troy.handle_user_input("y")
    assert troy.spoken == ["(The model sent an empty reply.)"]


def test_a_model_that_still_says_speak_or_done_is_tolerated(troy, monkeypatch):
    monkeypatch.setattr(dispatcher, "execute", lambda *a: pytest.fail("speak/done never go to the dispatcher"))
    use(monkeypatch, R("", call("speak", {"text": "Hi!"}), call("done")), R("Bye."))
    troy.handle_user_input("x")
    assert troy.spoken == ["Hi!", "Bye."]


def test_the_voice_hint_says_replies_not_speak_lines(troy, monkeypatch):
    use(monkeypatch, R("Hi."))
    troy.handle_user_input("hello", source="voice")
    assert "everything you say is read aloud" in troy.messages[2]["content"] and "speak:" not in troy.messages[2]["content"]
    assert "Likely relevant tools" not in troy.messages[2]["content"]


# ---------------------------------------------------------------- falling back to the text protocol
def test_when_no_model_supports_tools_the_request_finishes_with_the_text_protocol(troy, monkeypatch):
    monkeypatch.setattr(dispatcher, "execute", lambda name, arg: {"is_speech": True, "message": arg} if name == "speak" else {"is_done": True} if name == "done" else {"success": True, "message": "ok"})
    c = call("get_time", {}, "c1")
    use(monkeypatch, R("", c), NoNativeTools("nobody"))
    texts = []
    monkeypatch.setattr(llm_client, "chat", lambda messages, stop_check=None, on_text=None: texts.append([dict(m) for m in messages]) or "speak:Fell back fine.\ndone")
    troy.handle_user_input("time?")
    assert troy.spoken == ["Fell back fine."]
    sent = texts[0]
    assert "OUTPUT: only commands" in sent[0]["content"] or "Reply ONLY with commands" in sent[0]["content"]
    assert not any(tool_history.is_native(m) for m in sent) and any("[OBSERVATION] get_time" in m["content"] for m in sent)
    assert not troy._native_active


def test_native_forced_on_reports_instead_of_falling_back(troy, monkeypatch):
    monkeypatch.setattr(config, "TOOL_CALLING", "native")
    use(monkeypatch, NoNativeTools("nobody"))
    monkeypatch.setattr(llm_client, "chat", lambda *a, **k: pytest.fail("no fallback when forced"))
    troy.handle_user_input("hi")
    assert "forced on" in troy.spoken[0]


def test_text_mode_never_touches_native_calling(troy, monkeypatch):
    monkeypatch.setattr(config, "TOOL_CALLING", "text")
    monkeypatch.setattr(llm_client, "chat_tools", lambda *a, **k: pytest.fail("native must not be used"))
    monkeypatch.setattr(llm_client, "chat", lambda *a, **k: "speak:Text mode.\ndone")
    troy.handle_user_input("hi")
    assert troy.spoken == ["Text mode."]


def test_switching_from_a_native_model_to_a_text_one_flattens_the_history(troy, monkeypatch):
    monkeypatch.setattr(dispatcher, "execute", lambda *a: {"success": True, "message": "10:00"})
    use(monkeypatch, R("", call("get_time")), R("It's 10:00."))
    troy.handle_user_input("time?")
    assert any(m["role"] == "tool" for m in troy.messages)
    monkeypatch.setattr(config, "TOOL_CALLING", "text")
    seen = []
    monkeypatch.setattr(llm_client, "chat", lambda messages, **k: seen.append(messages) or "speak:ok\ndone")
    troy.handle_user_input("again")
    assert not any(tool_history.is_native(m) for m in seen[0][3:])
    assert any("[OBSERVATION] get_time" in m["content"] for m in seen[0])


def test_old_text_history_is_readable_to_a_native_model(troy, monkeypatch):
    troy.load_history([{"role": "user", "content": "open firefox"}, {"role": "assistant", "content": "speak:On it.\nopen_app:firefox\ndone"},
                       {"role": "user", "content": "[OBSERVATION] open_app:firefox -> OK - opened"}, {"role": "assistant", "content": "speak:Done.\ndone"}])
    m = use(monkeypatch, R("Sure."))
    troy.handle_user_input("and now?")
    convo = [x for x in m.requests[0]["messages"] if x["role"] != "system"]
    assert [x["content"] for x in convo] == ["open firefox", "On it.\nDone.", "and now?"]
    assert troy.messages[3]["content"].startswith("open firefox") and "speak:On it." in troy.messages[4]["content"]       # stored history untouched


def test_the_history_survives_a_save_and_load(troy, monkeypatch):
    monkeypatch.setattr(dispatcher, "execute", lambda *a: {"success": True, "message": "ok"})
    use(monkeypatch, R("Hm.", call("get_time")), R("Done."))
    troy.handle_user_input("x")
    saved = json.loads(json.dumps(troy.export_history()))            # sessions are JSON files
    other = agent_mod.TroyAgent(on_speak=lambda t: None)
    other.load_history(saved)
    m = use(monkeypatch, R("Again."))
    other.handle_user_input("more")
    assert_valid_pairing([x for x in m.requests[0]["messages"] if x["role"] != "system"])
    assert any(x["role"] == "tool" for x in m.requests[0]["messages"])


# ---------------------------------------------------------------- scheduled runs and memory
def test_a_scheduled_run_can_report_with_task_result(troy, monkeypatch):
    ctx = task_context.RunContext("t1")
    m = use(monkeypatch, R("", call("task_result", {"status": "done", "summary": "Opened Spotify."})))
    with task_context.activate(ctx):
        troy.handle_user_input("[SCHEDULED TASK] ...", source="task")
    assert "task_result" in m.requests[0]["tools"] and ctx.reported == ("done", "Opened Spotify.")
    assert len(m.requests) == 1                                        # reporting ends a scheduled run: no extra model call


def test_native_calls_use_the_same_tools_for_real(troy, monkeypatch):
    """No fake dispatcher: remember -> recall through the real registry."""
    use(monkeypatch, R("", call("remember", {"fact": "The user likes tea"})), R("Noted."), R("", call("recall", {"query": "tea"})), R("You like tea."))
    troy.handle_user_input("remember I like tea")
    assert [e["fact"] for e in memory.all_memories()] == ["The user likes tea"]
    troy.handle_user_input("what do I like?")
    assert troy.results[-1][0] == "recall" and "tea" in troy.results[-1][3] and troy.spoken[-1] == "You like tea."


def test_the_gate_for_extra_tools_is_not_in_the_way(troy, monkeypatch):
    """The text protocol blocks a tool whose usage was never shown; with native calling the schema IS the usage."""
    use(monkeypatch, R("", call("find_tools", {"query": "battery"})), R("", call("get_battery_info")), R("Battery checked."))
    troy.handle_user_input("battery?")
    name, arg, ok, msg = troy.results[1]
    assert name == "get_battery_info" and "did NOT run" not in msg and "extra tool" not in msg
