"""The task tools Troy calls (schedule_task, list_tasks, cancel_task, modify_task, ...)."""
from datetime import datetime, timedelta

import pytest

from troy import config, confirmation, scheduler as sch, sessions, task_context, tools_all, tools_tasks
from troy.scheduler import Outcome


@pytest.fixture
def s(tmp_path, monkeypatch, isolated_storage):
    clock = [datetime(2026, 10, 19, 15, 0)]
    sc = sch.Scheduler(executor=lambda t, r: Outcome("done"), clock=lambda: clock[0],
                       tasks_file=str(tmp_path / "t.json"), log_file=str(tmp_path / "l.jsonl"))
    sch.install(sc)
    sc.clock = clock
    yield sc
    sch.install(None)


def run(name, arg=""):
    return tools_all.run(name, arg)


def test_tools_are_registered_in_their_own_category():
    names = {t.name for t in tools_all.by_category()["tasks"]}
    assert {"schedule_task", "list_tasks", "cancel_task", "modify_task", "pause_task", "resume_task", "run_task_now", "task_log", "task_result"} <= names
    assert tools_all.get("list_tasks").info and tools_all.get("task_log").info and not tools_all.get("schedule_task").info


def test_schedule_task_creates_a_task_and_reports_when(s):
    r = run("schedule_task", "every day at 22:00|Put the computer to sleep.|Sleep PC")
    assert r["success"] and "Every day at 22:00" in r["message"] and "Mon Oct 19 22:00" in r["message"]
    (t,) = s.list()
    assert t["title"] == "Sleep PC" and t["prompt"] == "Put the computer to sleep." and t["grants"] == []


def test_schedule_task_links_the_task_to_the_chat_that_created_it(s):
    sid = sessions.create_session("Evening routine")
    s.context_provider = lambda: {"session_id": sid, "message_index": 4}
    run("schedule_task", "in 30 minutes|Open Spotify.")
    (t,) = s.list()
    assert t["session_id"] == sid and t["message_index"] == 4
    listing = {x["id"]: x for x in sessions.list_sessions()}[sid]
    assert listing["has_tasks"] is True and listing["task_count"] == 1
    sessions.save_session(sid, "Evening routine", [], [])                       # an autosave must not lose the link
    assert {x["id"]: x for x in sessions.list_sessions()}[sid]["has_tasks"] is True


def test_a_chat_without_tasks_has_no_task_mark(s):
    sid = sessions.create_session("Plain")
    assert {x["id"]: x for x in sessions.list_sessions()}[sid]["has_tasks"] is False


@pytest.mark.parametrize("arg, fragment", [
    ("", "Use schedule_task"), ("tomorrow at 9am", "Use schedule_task"), ("whenever|do it", "understand"),
    ("2026-01-01 09:00|too late", "past"), ("in 5 minutes|a|b|c|d", "Too many"),
])
def test_schedule_task_explains_what_was_wrong(s, arg, fragment):
    r = run("schedule_task", arg)
    assert not r["success"] and fragment in r["message"]
    assert s.list() == []


def test_schedule_task_with_approve_shows_one_approval_card_and_grants_only_after_the_click(s):
    r = run("schedule_task", "at 22:00|Put the computer to sleep.|Sleep|sleep_computer")
    assert r["success"] and "approval card" in r["message"]
    (t,) = s.list()
    assert t["grants"] == []                                                    # nothing is approved until the user clicks
    (pending,) = confirmation.list_pending()
    assert pending.name == "approve_task" and "sleep_computer" in pending.description
    confirmation.resolve(pending.id, approved=True)
    assert s.get(t["id"])["grants"] == ["sleep_computer"]


def test_declining_the_approval_card_grants_nothing(s):
    run("schedule_task", "at 22:00|Put the computer to sleep.|Sleep|sleep_computer")
    (pending,) = confirmation.list_pending()
    confirmation.resolve(pending.id, approved=False)
    assert s.list()[0]["grants"] == []


@pytest.mark.parametrize("approve, fragment", [("not_a_tool", "isn't a tool"), ("get_time", "doesn't need approval")])
def test_approve_list_is_validated_against_real_tools_that_need_approval(s, approve, fragment):
    r = run("schedule_task", f"at 22:00|x|t|{approve}")
    assert not r["success"] and fragment in r["message"] and s.list() == []


def test_a_scheduled_run_cannot_schedule_tasks(s):
    with task_context.activate(task_context.RunContext("x")):
        r = run("schedule_task", "in 5 minutes|again")
    assert not r["success"] and "can't create" in r["message"] and s.list() == []


def test_list_tasks(s):
    assert "No scheduled tasks" in run("list_tasks")["message"]
    run("schedule_task", "every monday at 9am|Weekly report|Report")
    run("schedule_task", "in 10 minutes|Stretch|Break")
    msg = run("list_tasks")["message"]
    assert "2 task(s)" in msg and "Report" in msg and "Break" in msg and "Every Monday at 09:00" in msg
    assert "Break" in run("list_tasks", "break")["message"] and "Report" not in run("list_tasks", "break")["message"]
    assert "No scheduled tasks match" in run("list_tasks", "finished")["message"]


def test_cancel_modify_pause_resume_by_title(s):
    run("schedule_task", "every day at 22:00|Back up|Backup")
    assert run("modify_task", "backup|when|every monday at 9am")["success"]
    assert s.list()[0]["schedule_text"] == "Every Monday at 09:00"
    assert run("modify_task", "backup|retries|4")["success"] and s.list()[0]["max_retries"] == 4
    assert not run("modify_task", "backup|retries|lots")["success"]
    assert not run("modify_task", "backup|colour|red")["success"]
    assert "Paused" in run("pause_task", "backup")["message"] and s.list()[0]["status"] == "paused"
    assert run("resume_task", "backup")["success"] and s.list()[0]["status"] == "scheduled"
    assert "Cancelled" in run("cancel_task", "backup")["message"] and s.list()[0]["status"] == "cancelled"
    assert not run("cancel_task", "nothing here")["success"]


def test_ambiguous_titles_ask_for_the_id(s):
    run("schedule_task", "in 5 minutes|a|Backup one")
    run("schedule_task", "in 6 minutes|b|Backup two")
    r = run("cancel_task", "backup")
    assert not r["success"] and "matches 2" in r["message"]


def test_run_task_now_and_the_log(s):
    run("schedule_task", "in 2 hours|Check mail|Mail")
    assert run("run_task_now", "mail")["success"]
    s.tick(s.clock[0])
    log = run("task_log", "mail")["message"]
    assert "created" in log and "success" in log


def test_task_result_only_works_inside_a_run():
    assert not run("task_result", "done|ok")["success"]
    ctx = task_context.RunContext("t")
    with task_context.activate(ctx):
        assert run("task_result", "ok|All set")["success"]
        assert ctx.reported == ("done", "All set")
        assert not run("task_result", "maybe|?")["success"]
        run("task_result", "blocked")
        assert ctx.reported == ("blocked", "It can't be done.")


def test_everything_reports_unavailable_when_tasks_are_switched_off(s, monkeypatch):
    monkeypatch.setattr(config, "TASKS_ENABLED", False)
    for name in ("schedule_task", "list_tasks", "cancel_task"):
        r = run(name, "in 5 minutes|x")
        assert not r["success"] and "aren't available" in r["message"]
