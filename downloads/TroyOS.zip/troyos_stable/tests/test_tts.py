import threading
import time

import pytest

from troy import config, tts


class FakeEngine(tts.Engine):
    def __init__(self, name="fake", delay=0.0, fail=False):
        self.name, self.delay, self.fail, self.calls = name, delay, fail, []
    def available(self): return True, ""
    def synth(self, text):
        self.calls.append(text)
        if self.fail:
            raise RuntimeError("boom")
        time.sleep(self.delay)
        return text.encode(), tts.WAV


class FakePlayer(tts.Player):
    def __init__(self, play_time=0.05):
        self.played, self.play_time, self.stops, self._cut = [], play_time, 0, threading.Event()
    def play(self, data, fmt):
        self._cut.clear()
        self.played.append(data.decode())
        self._cut.wait(self.play_time)
    def stop(self):
        self.stops += 1; self._cut.set()


def speaker(engines=None, player=None, **kw):
    engines = engines or [FakeEngine()]
    return tts.Speaker(engines=lambda: engines, player=player or FakePlayer(), **kw)


def test_sentences_play_in_order_and_speaking_flag_brackets_them():
    flags = []
    sp = speaker(on_speaking=flags.append)
    n = sp.say("**Hello** there. This is Troy! How can I help?")
    assert n == 3 and sp.speaking
    assert sp.wait_idle(3) and not sp.speaking
    assert sp.player.played == ["Hello there.", "This is Troy!", "How can I help?"]
    assert flags == [True, False]                                    # one continuous "speaking" span


def test_next_sentence_is_synthesized_while_the_current_one_plays():
    eng = FakeEngine(delay=0.08)
    sp = speaker([eng], FakePlayer(play_time=0.3))
    sp.say("One. Two. Three.")
    time.sleep(0.25)
    assert len(eng.calls) >= 2                                       # prefetching ahead of playback
    sp.stop()


def test_stop_cuts_playback_and_drops_the_queue():
    sp = speaker(player=FakePlayer(play_time=2.0))
    sp.say("First sentence. Second sentence. Third sentence.")
    time.sleep(0.15)
    t0 = time.time(); sp.stop()
    assert sp.wait_idle(1.0) and time.time() - t0 < 0.5
    time.sleep(0.2)
    assert sp.player.played == ["First sentence."] and sp.player.stops >= 1 and not sp.speaking


def test_interrupt_replaces_what_was_being_said():
    sp = speaker(player=FakePlayer(play_time=1.0))
    sp.say("Old long answer. More old answer.")
    time.sleep(0.1)
    sp.say("New answer.", interrupt=True)
    assert sp.wait_idle(3)
    assert sp.player.played[-1] == "New answer." and "More old answer." not in sp.player.played


def test_a_failing_engine_falls_back_to_the_next():
    bad, good = FakeEngine("bad", fail=True), FakeEngine("good")
    sp = speaker([bad, good])
    sp.say("Hello.")
    assert sp.wait_idle(2) and sp.player.played == ["Hello."] and bad.calls == ["Hello."]


def test_no_working_engine_is_silent_not_stuck():
    sp = speaker([FakeEngine(fail=True)])
    sp.say("Hello.")
    assert sp.wait_idle(2) and sp.player.played == []


def test_phone_sink_receives_text_without_synthesis_when_it_doesnt_want_audio():
    got = []
    eng = FakeEngine()
    sp = speaker([eng])
    def sink(sentence, audio, fmt): got.append((sentence, audio))
    sink.wants_audio = False
    sp.sink = sink
    sp.say("Hi there. Bye.")
    assert sp.wait_idle(2) and got == [("Hi there.", None), ("Bye.", None)] and eng.calls == [] and sp.player.played == []


def test_phone_sink_can_receive_audio_too():
    got = []
    sp = speaker()
    def sink(sentence, audio, fmt): got.append((sentence, audio, fmt))
    sink.wants_audio = True
    sp.sink = sink
    sp.say("Hi.")
    assert sp.wait_idle(2) and got == [("Hi.", b"Hi.", "wav")]


def test_empty_or_unspeakable_text_says_nothing():
    sp = speaker()
    assert sp.say("") == 0 and sp.say("   ") == 0 and sp.say("\U0001F600") == 0 and sp.wait_idle(0.1)


def test_engine_choice(monkeypatch):
    class Avail(tts.Engine):
        def __init__(self, ok): self.ok = ok
        def available(self): return self.ok, "x"
    monkeypatch.setattr(tts, "_ENGINES", {"sapi": Avail(True), "edge": Avail(True), "piper": Avail(False)})
    assert [e for e in tts.engine_chain("auto")] == [tts._ENGINES["sapi"]]            # no Piper model: built-in voice
    assert tts.engine_chain("edge") == [tts._ENGINES["edge"], tts._ENGINES["sapi"]]
    assert tts.engine_chain("piper") == [tts._ENGINES["sapi"]]                          # unavailable piper falls back
    tts._ENGINES["piper"].ok = True
    assert tts.engine_chain("auto")[0] is tts._ENGINES["piper"]
    assert [r["id"] for r in tts.engine_report()] == ["sapi", "edge", "piper"]
