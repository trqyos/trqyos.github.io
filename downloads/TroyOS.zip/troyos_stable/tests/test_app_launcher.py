import os

import pytest

from troy import app_launcher, config, tools_all


@pytest.fixture
def started(monkeypatch):
    log = []
    monkeypatch.setattr(app_launcher, "_spawn", lambda argv, shell=False, cwd=None: log.append(("spawn", argv)))
    monkeypatch.setattr(app_launcher, "_startfile", lambda target: log.append(("startfile", target)))
    monkeypatch.setattr(app_launcher, "find_executable", lambda n: None)
    monkeypatch.setattr(app_launcher, "IS_WINDOWS", False)
    return log


def test_aliases_and_path_lookup(started, monkeypatch):
    monkeypatch.setattr(app_launcher, "find_executable", lambda n: "/usr/bin/gnome-calculator" if n == "gnome-calculator" else None)
    r = app_launcher.launch("Calculator")
    assert r["success"] and started == [("spawn", ["/usr/bin/gnome-calculator"])]


def test_uri_and_existing_paths_use_the_os_handler(started, tmp_path):
    assert app_launcher.launch("ms-settings:")["success"]
    f = tmp_path / "doc.txt"; f.write_text("x")
    assert app_launcher.launch(str(f))["success"]
    assert started == [("startfile", "ms-settings:"), ("startfile", str(f))]


def test_start_menu_shortcuts_match_loosely(tmp_path, monkeypatch, started):
    root = tmp_path / "Programs"
    (root / "Spotify").mkdir(parents=True)
    (root / "Spotify" / "Spotify.lnk").write_text("")
    (root / "Visual Studio Code.lnk").write_text("")
    (root / "Uninstall Foo.lnk").write_text("")
    index = app_launcher.start_menu_index([str(root)])
    assert set(index) == {"spotify", "visual studio code"}          # uninstallers are ignored
    assert app_launcher.best_match("spotfy", index) == "spotify"      # typo
    assert app_launcher.best_match("studio code", index) == "visual studio code"
    assert app_launcher.best_match("photoshop", index) is None

    monkeypatch.setattr(app_launcher, "IS_WINDOWS", True)
    monkeypatch.setattr(app_launcher, "start_menu_index", lambda *a, **k: index)
    r = app_launcher.launch("Spotify")
    assert r["success"] and started[-1] == ("startfile", index["spotify"])


def test_store_apps_are_the_last_resort(started, monkeypatch):
    monkeypatch.setattr(app_launcher, "IS_WINDOWS", True)
    monkeypatch.setattr(app_launcher, "start_menu_index", lambda *a, **k: {})
    monkeypatch.setattr(app_launcher, "uwp_apps", lambda: {"whatsapp": "5319275A.WhatsAppDesktop_cv1g1gvanyjgm!App"})
    popen = []
    monkeypatch.setattr(app_launcher.subprocess, "Popen", lambda argv, **k: popen.append(argv))
    assert app_launcher.launch("whatsapp")["success"]
    assert popen[0][1].startswith("shell:AppsFolder\\5319275A")


def test_unknown_app_fails_cleanly(started):
    r = app_launcher.launch("definitely not an app")
    assert not r["success"] and "directly" in r["message"]


# ---- the setting decides the method; the model-facing command never changes
def test_open_app_modes(monkeypatch):
    calls = []
    monkeypatch.setattr(tools_all, "_open_app_via_start_menu", lambda n: calls.append("menu") or {"success": True, "message": "menu"})
    monkeypatch.setattr(app_launcher, "launch", lambda n: calls.append("direct") or {"success": n == "found", "message": "x"})
    monkeypatch.setattr(tools_all.time, "sleep", lambda s: None)

    monkeypatch.setattr(config, "APP_LAUNCH_MODE", "start_menu")
    tools_all.open_app("found"); assert calls == ["menu"]; calls.clear()

    monkeypatch.setattr(config, "APP_LAUNCH_MODE", "direct")
    assert tools_all.open_app("found")["success"] and calls == ["direct"]; calls.clear()
    assert not tools_all.open_app("missing")["success"] and calls == ["direct"]; calls.clear()   # no silent fallback

    monkeypatch.setattr(config, "APP_LAUNCH_MODE", "auto")
    assert tools_all.open_app("found")["success"] and calls == ["direct"]; calls.clear()
    r = tools_all.open_app("missing")
    assert r["success"] and calls == ["direct", "menu"] and "couldn't launch it directly" in r["message"]


def test_browser_launch_builds_a_new_tab_command(monkeypatch):
    spawned = []
    monkeypatch.setattr(app_launcher, "_spawn", lambda argv, **k: spawned.append(argv))
    monkeypatch.setattr(app_launcher, "find_executable", lambda n: "/opt/firefox/firefox" if n == "firefox" else None)
    r = app_launcher.launch_browser_url("https://www.youtube.com/watch?v=abc", "firefox")
    assert r["success"] and spawned == [["/opt/firefox/firefox", "-new-tab", "https://www.youtube.com/watch?v=abc"]]


def test_browser_falls_back_to_default_and_rejects_non_http(monkeypatch):
    opened = []
    monkeypatch.setattr(app_launcher, "find_executable", lambda n: None)
    monkeypatch.setattr(app_launcher.webbrowser, "open_new_tab", lambda u: opened.append(u))
    r = app_launcher.launch_browser_url("https://example.com", "firefox")
    assert r["success"] and opened == ["https://example.com"] and "default browser" in r["message"]
    assert not app_launcher.launch_browser_url("file:///etc/passwd", "firefox")["success"]
    assert not app_launcher.launch_browser_url("javascript:alert(1)")["success"]
