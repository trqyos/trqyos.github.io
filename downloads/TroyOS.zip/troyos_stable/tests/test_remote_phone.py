import json
import os
import socket
import threading
import time

import pytest
import requests

from troy import config, mobile_server, remote, screencast


# ------------------------------------------------------------- Tailscale
class Out:
    def __init__(self, stdout="", returncode=0, stderr=""): self.stdout, self.returncode, self.stderr = stdout, returncode, stderr


STATUS = {"BackendState": "Running", "CurrentTailnet": {"Name": "me.ts.net"},
          "Self": {"DNSName": "desktop.tail1234.ts.net.", "HostName": "DESKTOP", "TailscaleIPs": ["100.64.0.5", "fd7a::5"]},
          "Peer": {"a": {"HostName": "pixel", "OS": "android", "Online": True, "TailscaleIPs": ["100.64.0.9"]},
                   "b": {"HostName": "old-laptop", "OS": "linux", "Online": False, "TailscaleIPs": ["100.64.0.7"]}}}


@pytest.fixture
def ts(monkeypatch):
    remote._cache.update(at=0.0, value=None)
    monkeypatch.setattr(remote, "find_tailscale_cli", lambda: "tailscale")
    calls = []
    def run(args, timeout=6):
        calls.append(args)
        if args[:2] == ["status", "--json"]:
            return Out(json.dumps(STATUS))
        if args[:2] == ["serve", "status"]:
            return Out("https://desktop.tail1234.ts.net (tailnet only)\n|-- / proxy http://127.0.0.1:8765")
        return Out("")
    monkeypatch.setattr(remote, "_run", run)
    monkeypatch.setattr(mobile_server, "current_port", lambda: 8765)
    monkeypatch.setattr(mobile_server, "lan_ip", lambda: "192.168.1.20")
    return calls


def test_status_parses_ip_name_tailnet_and_peers(ts):
    s = remote.tailscale_status(force=True)
    assert s["running"] and s["ip"] == "100.64.0.5" and s["dns_name"] == "desktop.tail1234.ts.net" and s["tailnet"] == "me.ts.net"
    assert [p["name"] for p in s["peers"]] == ["pixel", "old-laptop"]            # online first
    assert s["serving"] is True


def test_urls_prefer_https_then_tailscale_then_lan(ts):
    urls = remote.access_urls("TOK")
    assert [u["kind"] for u in urls] == ["tailscale-https", "tailscale", "lan"]
    assert urls[0]["url"] == "https://desktop.tail1234.ts.net/?t=TOK" and urls[0]["recommended"] and not urls[1]["recommended"]
    assert urls[1]["url"] == "http://100.64.0.5:8765/?t=TOK" and urls[2]["url"] == "http://192.168.1.20:8765/?t=TOK"


def test_lan_only_when_tailscale_is_missing_or_signed_out(monkeypatch):
    remote._cache.update(at=0.0, value=None)
    monkeypatch.setattr(remote, "find_tailscale_cli", lambda: None)
    monkeypatch.setattr(mobile_server, "current_port", lambda: 8765)
    monkeypatch.setattr(mobile_server, "lan_ip", lambda: "192.168.1.20")
    assert [u["kind"] for u in remote.access_urls("T")] == ["lan"]
    s = remote.tailscale_status(force=True)
    assert not s["installed"] and s["state"] == "NotInstalled"

    remote._cache.update(at=0.0, value=None)
    monkeypatch.setattr(remote, "find_tailscale_cli", lambda: "ts")
    monkeypatch.setattr(remote, "_run", lambda a, timeout=6: Out(json.dumps({"BackendState": "NeedsLogin"})))
    s = remote.tailscale_status(force=True)
    assert s["installed"] and not s["running"] and "log in" in s["error"].lower()


def test_no_urls_when_the_server_is_not_running(monkeypatch):
    monkeypatch.setattr(mobile_server, "current_port", lambda: None)
    assert remote.access_urls("T") == []


def test_serve_falls_back_to_the_newer_cli_syntax(ts, monkeypatch):
    seen = []
    def run(args, timeout=6):
        seen.append(args)
        return Out("", 1, "unknown flag --https") if "--https=443" in args else Out("Available within your tailnet:\nhttps://desktop.tail1234.ts.net/\n")
    monkeypatch.setattr(remote, "_run", run)
    r = remote.tailscale_serve(True)
    assert r["success"] and r["url"] == "https://desktop.tail1234.ts.net" and seen[-1] == ["serve", "--bg", "8765"]


def test_serve_explains_when_https_is_not_enabled_for_the_tailnet(ts, monkeypatch):
    monkeypatch.setattr(remote, "_run", lambda a, timeout=6: Out("", 1, "HTTPS is not enabled for your tailnet"))
    r = remote.tailscale_serve(True)
    assert not r["success"] and "login.tailscale.com/admin/dns" in r["message"]


# ---------------------------------------------------------- screencast
def test_frames_are_resized_never_enlarged_and_are_jpeg():
    PIL = pytest.importorskip("PIL.Image")
    big = PIL.new("RGB", (2400, 1200), "navy")
    frame = screencast.encode_frame(big, width=800, quality=50, draw_cursor=False)
    assert frame[:2] == b"\xff\xd8"
    from io import BytesIO
    assert PIL.open(BytesIO(frame)).size == (800, 400)
    small = PIL.new("RGB", (300, 200))
    assert PIL.open(BytesIO(screencast.encode_frame(small, width=800, draw_cursor=False))).size == (300, 200)


def test_presets_and_fps_limit(monkeypatch):
    assert screencast.preset("saver")["width"] < screencast.preset("sharp")["width"]
    assert screencast.preset("nonsense") == screencast.preset("balanced")
    frames = []
    class G:
        def monitors(self): return []
        def grab(self, m): return type("I", (), {})()
        def close(self): pass
    monkeypatch.setattr(screencast, "Grabber", G)
    monkeypatch.setattr(screencast, "encode_frame", lambda *a, **k: b"frame")
    t0 = time.time()
    for i, f in enumerate(screencast.stream_frames(fps=100, max_fps=20, should_stop=lambda: len(frames) >= 4)):
        frames.append(f)
    assert len(frames) == 4 and time.time() - t0 >= 0.1          # 20 fps cap => at least 3 gaps of 50ms


# -------------------------------------------------------- HTTP server
class FakeBridge(mobile_server.Bridge):
    def __init__(self):
        self.sent, self.stopped, self.resolved, self.viewer_log = [], [], [], []
        super().__init__(
            enqueue_turn=lambda t: self.sent.append(t), get_display_log=lambda: [{"role": "user", "text": "hi"}],
            get_status=lambda: {"state": {"state": "idle", "detail": ""}, "busy": False}, stop_turn=lambda: self.stopped.append(1),
            list_confirmations=lambda: [{"id": 3, "name": "delete_file", "arg": "x", "risk_level": "high", "description": "d"}],
            resolve_confirmation=lambda i, ok: self.resolved.append((i, ok)), on_viewers=lambda n: self.viewer_log.append(n),
            get_info=lambda: {"user_name": "Alex"})


@pytest.fixture
def server(monkeypatch, tmp_path):
    s = socket.socket(); s.bind(("127.0.0.1", 0)); port = s.getsockname()[1]; s.close()
    monkeypatch.setattr(config, "MOBILE_SCREEN_ENABLED", True)
    monkeypatch.setattr(mobile_server, "_session_token", "T" * 20)
    bridge = FakeBridge()
    mobile_server.configure(bridge)
    mobile_server.start(port)
    base = f"http://127.0.0.1:{port}"
    yield base, bridge
    mobile_server.stop()


H = {"X-Troy-Token": "T" * 20}


def test_static_page_and_assets_are_public_but_nothing_else_is(server):
    base, _ = server
    page = requests.get(base + "/")
    assert page.status_code == 200 and "text/html" in page.headers["content-type"] and "<canvas id=\"face\"" in page.text
    assert requests.get(base + "/assets/phone.js").status_code == 200
    assert requests.get(base + "/assets/avatar.js").status_code == 200
    assert requests.get(base + "/manifest.webmanifest").status_code == 200
    assert requests.get(base + "/assets/../../config.py").status_code == 404
    assert requests.get(base + "/assets/nothing.js").status_code == 404
    assert requests.get(base + "/api/state").status_code == 401
    assert requests.get(base + "/api/state?t=wrong").status_code == 401
    assert requests.get(base + "/screen.mjpg").status_code == 401


def test_state_send_stop_confirm(server):
    base, bridge = server
    st = requests.get(base + "/api/state?t=" + "T" * 20).json()
    assert st["history"][0]["text"] == "hi" and st["confirmations"][0]["id"] == 3 and st["info"]["user_name"] == "Alex" and st["screen"]["enabled"]
    assert requests.post(base + "/api/send", json={"text": "  open firefox "}, headers=H).json() == {"ok": True}
    assert bridge.sent == ["open firefox"]
    assert requests.post(base + "/api/send", json={"text": "  "}, headers=H).status_code == 400
    assert requests.post(base + "/api/send", json={"text": "x"}).status_code == 401
    assert requests.post(base + "/api/send", json={"text": "x", "token": "T" * 20}).status_code == 200      # token in body also works
    requests.post(base + "/api/stop", json={}, headers=H)
    requests.post(base + "/api/confirm", json={"id": 3, "approved": True}, headers=H)
    assert bridge.stopped == [1] and bridge.resolved == [(3, True)]
    assert requests.post(base + "/api/send", data=b"x" * 70000, headers={**H, "Content-Type": "application/json"}).status_code == 413


def test_events_reach_connected_phones(server):
    base, _ = server
    got = []
    def listen():
        with requests.get(base + "/api/stream?t=" + "T" * 20, stream=True, timeout=5) as r:
            for line in r.iter_lines(decode_unicode=True):
                if line.startswith("data:"):
                    got.append(json.loads(line[5:])); return
    t = threading.Thread(target=listen, daemon=True); t.start()
    deadline = time.time() + 3
    while time.time() < deadline and t.is_alive() and not got:
        mobile_server.broadcast({"type": "message", "kind": "troy", "text": "hello phone"}); time.sleep(0.1)
    t.join(2)
    assert got and got[0]["text"] == "hello phone"


def test_live_screen_streams_mjpeg_and_counts_viewers(server, monkeypatch):
    base, bridge = server
    monkeypatch.setattr(screencast, "stream_frames", lambda *a, should_stop=lambda: False, **k: iter([b"\xff\xd8AAA", b"\xff\xd8BBB"]))
    r = requests.get(base + "/screen.mjpg?t=" + "T" * 20 + "&preset=saver", stream=True, timeout=5)
    body = r.raw.read()
    assert r.status_code == 200 and "multipart/x-mixed-replace" in r.headers["content-type"]
    assert body.count(b"--troyframe") == 2 and b"\xff\xd8AAA" in body and b"\xff\xd8BBB" in body
    deadline = time.time() + 2
    while time.time() < deadline and bridge.viewer_log[-1:] != [0]:
        time.sleep(0.05)
    assert bridge.viewer_log[0] == 1 and bridge.viewer_log[-1] == 0


def test_screen_sharing_can_be_switched_off(server, monkeypatch):
    base, _ = server
    monkeypatch.setattr(config, "MOBILE_SCREEN_ENABLED", False)
    assert requests.get(base + "/screen.mjpg?t=" + "T" * 20).status_code == 403
    assert requests.get(base + "/api/screen/shot?t=" + "T" * 20).status_code == 403
    assert requests.get(base + "/api/screen/info?t=" + "T" * 20).json()["enabled"] is False


def test_snapshot_endpoint_returns_a_jpeg(server, monkeypatch):
    base, _ = server
    monkeypatch.setattr(screencast, "snapshot", lambda w, q, m: b"\xff\xd8SNAP")
    r = requests.get(base + "/api/screen/shot?t=" + "T" * 20 + "&w=640")
    assert r.status_code == 200 and r.headers["content-type"] == "image/jpeg" and r.content == b"\xff\xd8SNAP"


def test_token_is_persistent_and_regenerable(monkeypatch, tmp_path):
    monkeypatch.setattr(mobile_server, "TOKEN_FILE", str(tmp_path / "tok.txt"))
    monkeypatch.setattr(config, "MOBILE_UI_TOKEN", "")
    first = mobile_server._load_token()
    assert len(first) >= 16 and mobile_server._load_token() == first          # stable across restarts
    monkeypatch.setattr(mobile_server, "_session_token", first)
    new = mobile_server.regenerate_token()
    assert new != first and mobile_server._load_token() == new


def test_phone_avatar_is_the_same_file_as_the_desktop_one():
    desktop = os.path.join(os.path.dirname(__file__), "..", "electron", "renderer", "avatar.js")
    phone = os.path.join(os.path.dirname(__file__), "..", "troy", "web", "phone", "avatar.js")
    if os.path.exists(desktop):
        assert open(desktop, "rb").read() == open(phone, "rb").read(), "copy electron/renderer/avatar.js to troy/web/phone/avatar.js"


# ------------------------------------------------------------- phone voice
class VoiceBridge(mobile_server.Bridge):
    """FakeBridge + the voice callbacks (troy/voice_mode.py's phone side)."""

    def __init__(self):
        self.sent, self.stopped, self.resolved, self.viewer_log = [], [], [], []
        self.voice_calls = []
        self.audio_store = {1: (b"WAVDATA", "wav"), 2: (b"MPGDATA", "mp3")}
        super().__init__(
            enqueue_turn=lambda t: self.sent.append(t), get_display_log=lambda: [],
            get_status=lambda: {"state": {"state": "idle", "detail": ""}, "busy": False},
            stop_turn=lambda: self.stopped.append(1),
            list_confirmations=lambda: [], resolve_confirmation=lambda i, ok: self.resolved.append((i, ok)),
            on_viewers=lambda n: self.viewer_log.append(n), get_info=lambda: {},
            voice_start=lambda: self.voice_calls.append("start") or {"ok": True, "speaker": "phone", "engine": "stub"},
            voice_stop=lambda: self.voice_calls.append("stop"),
            voice_interrupt=lambda: self.voice_calls.append("interrupt"),
            voice_event=lambda d: self.voice_calls.append(("event", dict(d))),
            voice_audio=lambda pcm, rate: self.voice_calls.append(("audio", rate, len(pcm))) or {"action": "turn", "text": "hi troy"},
            voice_audio_get=lambda aid: self.audio_store.get(int(aid)))


@pytest.fixture
def voice_server(monkeypatch, tmp_path):
    s = socket.socket(); s.bind(("127.0.0.1", 0)); port = s.getsockname()[1]; s.close()
    monkeypatch.setattr(config, "MOBILE_SCREEN_ENABLED", True)
    monkeypatch.setattr(config, "MOBILE_VOICE_ENABLED", True)
    monkeypatch.setattr(mobile_server, "_session_token", "T" * 20)
    bridge = VoiceBridge()
    mobile_server.configure(bridge)
    mobile_server.start(port)
    yield f"http://127.0.0.1:{port}", bridge
    mobile_server.stop()


def test_voice_session_routes(voice_server):
    base, bridge = voice_server
    assert requests.post(base + "/api/voice/start", json={}, headers=H).json() == {"ok": True, "speaker": "phone", "engine": "stub"}
    assert requests.post(base + "/api/voice/stop", json={}, headers=H).json() == {"ok": True}
    requests.post(base + "/api/voice/interrupt", json={}, headers=H)
    requests.post(base + "/api/voice/event", json={"speaking": True}, headers=H)
    assert bridge.voice_calls == ["start", "stop", "interrupt", ("event", {"speaking": True})]
    # session routes still need the token
    assert requests.post(base + "/api/voice/start", json={}).status_code == 401
    assert requests.post(base + "/api/voice/stop", json={}, headers={"X-Troy-Token": "wrong"}).status_code == 401


def test_voice_start_failures_are_reported_as_400s(voice_server, monkeypatch):
    base, bridge = voice_server
    def boom():
        raise ValueError("STT not installed")
    monkeypatch.setattr(bridge, "voice_start", boom)
    r = requests.post(base + "/api/voice/start", json={}, headers=H)
    assert r.status_code == 400 and r.json()["error"] == "STT not installed"
    monkeypatch.setattr(bridge, "voice_start", lambda: {"started": False, "error": "no mic"})
    r = requests.post(base + "/api/voice/start", json={}, headers=H)
    assert r.status_code == 400 and r.json()["error"] == "no mic"


def test_voice_utterance_route(voice_server):
    base, bridge = voice_server
    pcm = b"\x01\x02" * 100
    r = requests.post(base + "/api/voice/utterance?rate=16000&t=" + "T" * 20, data=pcm, headers={"Content-Type": "application/octet-stream"})
    assert r.status_code == 200 and r.json() == {"action": "turn", "text": "hi troy"}
    assert ("audio", 16000, 200) in bridge.voice_calls
    # token in the X-Troy-Token header instead of the query
    r = requests.post(base + "/api/voice/utterance?rate=48000", data=pcm, headers=H)
    assert r.status_code == 200 and ("audio", 48000, 200) in bridge.voice_calls
    # guards: no token, nonsense rate, oversized body, bridge error
    assert requests.post(base + "/api/voice/utterance?rate=16000", data=pcm).status_code == 401
    assert requests.post(base + "/api/voice/utterance?rate=apple&t=" + "T" * 20, data=pcm).json() == requests.post(
        base + "/api/voice/utterance?rate=apple&t=" + "T" * 20, data=pcm).json()
    assert requests.post(base + "/api/voice/utterance?rate=4000&t=" + "T" * 20, data=pcm).status_code == 400


def test_voice_utterance_size_limit_and_errors(voice_server, monkeypatch):
    base, bridge = voice_server
    monkeypatch.setattr(mobile_server, "MAX_VOICE_BYTES", 10)
    assert requests.post(base + "/api/voice/utterance?t=" + "T" * 20, data=b"x" * 11).status_code == 413
    def boom(pcm, rate):
        raise ValueError("voice mode isn't on")
    monkeypatch.setattr(bridge, "voice_audio", boom)
    r = requests.post(base + "/api/voice/utterance?t=" + "T" * 20, data=b"x" * 4)
    assert r.status_code == 400 and r.json()["error"] == "voice mode isn't on"


def test_voice_audio_download_route(voice_server):
    base, _ = voice_server
    r = requests.get(base + "/api/voice/audio/1?t=" + "T" * 20)
    assert r.status_code == 200 and r.headers["content-type"] == "audio/wav" and r.content == b"WAVDATA"
    r = requests.get(base + "/api/voice/audio/2?t=" + "T" * 20)
    assert r.status_code == 200 and r.headers["content-type"] == "audio/mpeg"
    assert requests.get(base + "/api/voice/audio/1").status_code == 401
    assert requests.get(base + "/api/voice/audio/99?t=" + "T" * 20).status_code == 404


def test_state_tells_the_phone_its_voice_options(voice_server, monkeypatch):
    base, _ = voice_server
    monkeypatch.setattr(config, "VOICE_PHONE_SPEAKER", "troy")
    st = requests.get(base + "/api/state?t=" + "T" * 20).json()
    assert st["voice"]["enabled"] is True and st["voice"]["speaker"] == "troy"
    assert st["voice"]["https"] == "" and "https_enabled" in st["voice"]
    monkeypatch.setattr(config, "MOBILE_VOICE_ENABLED", False)
    st = requests.get(base + "/api/state?t=" + "T" * 20).json()
    assert st["voice"]["enabled"] is False
