"""Native function calling over a REAL socket: a tiny local server that speaks the OpenAI-compatible streaming
protocol (tool-call fragments and all), with the real requests library, llm_client, agent and tool registry."""
import json
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

import pytest

from troy import agent as agent_mod, config, llm_client, stop_control


class Server:
    def __init__(self, handler_fn):
        self.bodies = []
        outer = self

        class H(BaseHTTPRequestHandler):
            def log_message(self, *a): pass

            def do_POST(self):
                body = json.loads(self.rfile.read(int(self.headers["Content-Length"])))
                outer.bodies.append(body)
                status, chunks = handler_fn(body, len(outer.bodies))
                if status != 200:
                    data = chunks.encode()
                    self.send_response(status)
                    self.send_header("Content-Type", "application/json")
                    self.send_header("Content-Length", str(len(data)))
                    self.end_headers()
                    self.wfile.write(data)
                    return
                self.send_response(200)
                self.send_header("Content-Type", "text/event-stream")
                self.end_headers()
                for c in chunks:
                    self.wfile.write(f"data: {json.dumps({'choices': [{'delta': c}]})}\n\n".encode())
                    self.wfile.flush()
                self.wfile.write(b"data: [DONE]\n\n")
                self.wfile.flush()

        self.httpd = ThreadingHTTPServer(("127.0.0.1", 0), H)
        self.url = f"http://127.0.0.1:{self.httpd.server_address[1]}"
        threading.Thread(target=self.httpd.serve_forever, daemon=True).start()

    def close(self):
        self.httpd.shutdown()


@pytest.fixture
def world(monkeypatch, isolated_storage):
    llm_client.clear_cooldowns(); llm_client._NO_TOOLS.clear(); llm_client._NO_EXTRAS.clear()
    stop_control.stop_controller.clear()
    servers = []

    def start(fn):
        s = Server(fn)
        servers.append(s)
        for key in ("OPENROUTER_API_KEY", "GEMINI_API_KEY", "NVIDIA_API_KEY"):
            monkeypatch.setattr(config, key, "")
        monkeypatch.setattr(config, "GROQ_BASE_URL", s.url)
        monkeypatch.setattr(config, "GROQ_API_KEY", "test-key")
        monkeypatch.setattr(config, "GROQ_TEXT_MODELS", ["model-a"])
        monkeypatch.setattr(config, "PRIMARY_PROVIDER", "groq")
        monkeypatch.setattr(config, "LMSTUDIO_ENABLED", False)
        monkeypatch.setattr(config, "TOOL_CALLING", "auto")
        spoken, results = [], []
        a = agent_mod.TroyAgent(on_speak=spoken.append, on_tool_result=lambda *x: results.append(x))
        a.spoken, a.results, a.server = spoken, results, s
        return a
    yield start
    for s in servers:
        s.close()
    llm_client._NO_TOOLS.clear()


def test_a_full_tool_round_trip_over_http(world):
    def model(body, n):
        if n == 1:
            return 200, [{"content": "Checking the "}, {"content": "time."},
                         {"tool_calls": [{"index": 0, "id": "call_9", "type": "function", "function": {"name": "get_time", "arguments": ""}}]},
                         {"tool_calls": [{"index": 0, "function": {"arguments": "{}"}}]}]
        return 200, [{"content": "It is "}, {"content": "now known."}]
    troy = world(model)
    troy.handle_user_input("what time is it?")

    first, second = troy.server.bodies
    assert first["stream"] is True and any(t["function"]["name"] == "get_time" for t in first["tools"])
    assert first["messages"][0]["role"] == "system" and "tools you were given" in first["messages"][0]["content"]
    # the second request carries the assistant's call and the real tool's result, correctly paired
    roles = [m["role"] for m in second["messages"]]
    assert roles[-2:] == ["assistant", "tool"]
    assert second["messages"][-2]["tool_calls"][0]["id"] == "call_9"
    assert second["messages"][-1]["tool_call_id"] == "call_9" and second["messages"][-1]["content"]
    assert not any(k in m for m in second["messages"] for k in ("fmt", "ok", "arg"))
    assert troy.spoken == ["Checking the time.", "It is now known."]
    assert troy.results[0][0] == "get_time" and troy.results[0][2] is True


def test_a_model_that_rejects_tools_is_served_with_the_text_protocol(world):
    def model(body, n):
        if "tools" in body:
            return 400, json.dumps({"error": {"message": "tools is not supported by this model"}})
        return 200, [{"content": "speak:Hello from text mode.\ndone"}]
    troy = world(model)
    troy.handle_user_input("hi")
    assert troy.spoken == ["Hello from text mode."]
    assert "tools" in troy.server.bodies[0] and "tools" not in troy.server.bodies[1]
    assert ("groq", "model-a") in llm_client._NO_TOOLS

    troy.handle_user_input("hi again")                    # remembered: no second wasted request with tools
    assert all("tools" not in b for b in troy.server.bodies[2:]) and len(troy.server.bodies) == 3


GARBLED = json.dumps({"error": {"code": "tool_use_failed", "message": "Failed to call a function", "failed_generation": "<function=x>"}})


def test_a_garbled_tool_call_is_retried_once_on_the_same_model(world):
    troy = world(lambda body, n: (400, GARBLED) if n == 1 else (200, [{"content": "Hello."}]))
    troy.handle_user_input("hi")
    assert troy.spoken == ["Hello."] and len(troy.server.bodies) == 2
    assert llm_client._NO_TOOLS == set()                  # the model supports tools; it just flubbed one call


def test_a_model_that_keeps_garbling_is_a_failure_not_a_downgrade(world):
    troy = world(lambda body, n: (400, GARBLED))
    troy.handle_user_input("hi")
    assert llm_client._NO_TOOLS == set() and len(troy.server.bodies) == 2
    assert "couldn't reach any model" in troy.spoken[0]
