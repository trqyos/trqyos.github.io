"""The local MIoT protocol client, against a fake robot on a real UDP socket."""
import json
import socket
import struct
import threading
import time

import pytest

from troy import miot_client as mc

TOKEN = bytes.fromhex("00112233445566778899aabbccddeeff")
DEVICE_ID = bytes.fromhex("0a0b0c0d")

# Generated with python-miio 0.5.12 (miio.protocol.Message.build) for this exact request, token and timestamp.
# If this stops matching, the wire format (checksum / key derivation / padding) has drifted from the reference.
REFERENCE_PAYLOAD = {"id": 1, "method": "get_properties", "params": [{"did": "2-1", "siid": 2, "piid": 1}]}
REFERENCE_PACKET = bytes.fromhex(
    "21310080000000000a0b0c0d6553f100dfe290e6992c5a98e4e921f4d30ae9c82a36b2b7afa85bd6a9f1ed82b485a3d658c96ba3b375bd3a49af5151f5155f1"
    "63087aefff022bc1b2374956dfc606d58e187f733edb5e3044500e5c8a2e4cda23d936a0d4ee942effd29476ed6bd83290a65078f3e2186dd0b12f8821b31bbf6")


def test_packet_is_byte_identical_to_the_python_miio_reference():
    plain = json.dumps(REFERENCE_PAYLOAD).encode() + b"\x00"      # python-miio's default separators
    assert mc.frame(DEVICE_ID, 1700000000, TOKEN, plain) == REFERENCE_PACKET


def test_reference_packet_parses_back():
    device_id, stamp, body = mc.parse_packet(REFERENCE_PACKET, TOKEN)
    assert device_id == DEVICE_ID and stamp == 1700000000 and body == REFERENCE_PAYLOAD


def test_wrong_token_fails_verification():
    with pytest.raises(mc.MiotTokenError):
        mc.parse_packet(REFERENCE_PACKET, bytes(16))


@pytest.mark.parametrize("bad", ["", "abc", "z" * 32, "0" * 31, "0" * 96])
def test_parse_token_rejects_bad_tokens_with_a_useful_message(bad):
    with pytest.raises(ValueError) as e:
        mc.parse_token(bad)
    assert "token" in str(e.value).lower()


def test_parse_token_accepts_spaces_and_case():
    assert mc.parse_token(" 00112233 44556677 8899AABB CCDDEEFF ") == TOKEN


class FakeRobot:
    """A UDP server that behaves like the hardware: answers hellos, silently drops anything it can't verify."""

    def __init__(self, drop_first_hello=False):
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.sock.bind(("127.0.0.1", 0))
        self.port = self.sock.getsockname()[1]
        self.requests, self.hellos = [], 0
        self.drop_first_hello = drop_first_hello
        self.error_for = {}              # method -> error dict
        self.silent_for = set()          # methods that are never answered
        self.props = {}
        self.stamp = 5000
        threading.Thread(target=self._serve, daemon=True).start()

    def close(self):
        self.sock.close()

    def _serve(self):
        while True:
            try:
                data, addr = self.sock.recvfrom(4096)
            except OSError:
                return
            if len(data) == 32:
                self.hellos += 1
                if self.drop_first_hello and self.hellos == 1:
                    continue
                self.sock.sendto(struct.pack(">HHI4sI", 0x2131, 32, 0, DEVICE_ID, self.stamp) + bytes(16), addr)
                continue
            try:
                _, stamp, req = mc.parse_packet(data, TOKEN)
            except mc.MiotError:
                continue                  # like the real thing: no answer at all
            if stamp < self.stamp:
                continue
            self.requests.append(req)
            method = req["method"]
            if method in self.silent_for:
                continue
            if method in self.error_for:
                body = {"id": req["id"], "error": self.error_for[method]}
            elif method == "get_properties":
                body = {"id": req["id"], "result": [dict(p, code=0, value=self.props[(p["siid"], p["piid"])]) if (p["siid"], p["piid"]) in self.props
                                                    else dict(p, code=-4001) for p in req["params"]]}
            elif method == "set_properties":
                for p in req["params"]:
                    self.props[(p["siid"], p["piid"])] = p["value"]
                body = {"id": req["id"], "result": [dict(p, code=0) for p in req["params"]]}
            elif method == "miIO.info":
                body = {"id": req["id"], "result": {"model": "xiaomi.vacuum.b108gl", "fw_ver": "4.5.0"}}
            else:
                body = {"id": req["id"], "result": {"code": 0, "out": []}}
            self.sock.sendto(mc.build_packet(DEVICE_ID, self.stamp + 1, TOKEN, body), addr)


@pytest.fixture
def robot():
    r = FakeRobot()
    yield r
    r.close()


def client(robot, token=TOKEN.hex(), timeout=0.6):
    return mc.MiotClient("127.0.0.1", token, port=robot.port, timeout=timeout)


def test_info_proves_host_and_token(robot):
    assert client(robot).info()["model"] == "xiaomi.vacuum.b108gl"


def test_reads_are_chunked_and_missing_properties_are_left_out(robot):
    robot.props = {(2, i): i for i in range(1, 8)}
    got = client(robot).get_properties([(2, i) for i in range(1, 8)] + [(9, 9)])
    assert got == {(2, i): i for i in range(1, 8)}
    gets = [r for r in robot.requests if r["method"] == "get_properties"]
    assert [len(r["params"]) for r in gets] == [5, 3]            # 8 properties -> 5 + 3


def test_set_property_and_action_payloads(robot):
    c = client(robot)
    c.set_property(2, 8, 3)
    c.action(2, 13, [{"piid": 13, "value": '{"room":[5]}'}])
    assert robot.props[(2, 8)] == 3
    act = robot.requests[-1]
    assert act["method"] == "action" and act["params"]["siid"] == 2 and act["params"]["aiid"] == 13
    assert act["params"]["in"] == [{"piid": 13, "value": '{"room":[5]}'}]


def test_a_dropped_hello_is_retried(robot):
    robot.drop_first_hello = True
    assert client(robot).info()
    assert robot.hellos >= 2


def test_a_wrong_token_looks_like_silence_and_is_reported_as_a_token_problem(robot):
    with pytest.raises(mc.MiotTokenError) as e:
        client(robot, token="ff" * 16, timeout=0.3).info()
    assert "token" in str(e.value).lower()


def test_nothing_listening_is_a_connection_error():
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    s.bind(("127.0.0.1", 0))
    port = s.getsockname()[1]
    s.close()
    with pytest.raises(mc.MiotConnectionError):
        mc.MiotClient("127.0.0.1", TOKEN.hex(), port=port, timeout=0.3).info()


def test_user_ack_timeout_is_its_own_error(robot):
    robot.error_for["action"] = {"code": -9999, "message": "user ack timeout"}
    with pytest.raises(mc.MiotAckTimeout):
        client(robot).action(2, 1)


def test_other_device_errors_carry_the_code(robot):
    robot.error_for["action"] = {"code": -4004, "message": "nope"}
    with pytest.raises(mc.MiotDeviceError) as e:
        client(robot).action(2, 1)
    assert e.value.code == -4004


def test_actions_are_sent_exactly_once_but_reads_are_retried(robot):
    robot.silent_for = {"action", "get_properties"}
    c = client(robot, timeout=0.25)
    with pytest.raises(mc.MiotAckTimeout):
        c.action(2, 1)
    assert len([r for r in robot.requests if r["method"] == "action"]) == 1          # never duplicated
    with pytest.raises(mc.MiotError):
        c.get_properties([(2, 1)])
    assert len([r for r in robot.requests if r["method"] == "get_properties"]) == 3  # reads retried


def test_a_second_call_reuses_the_session(robot):
    c = client(robot)
    c.info()
    c.info()
    assert robot.hellos == 1


def test_missing_host_is_refused():
    with pytest.raises(ValueError):
        mc.MiotClient("", TOKEN.hex())
