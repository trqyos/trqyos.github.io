"""Tasks through the IPC host: the tasks.* methods, reports landing in the chat that created the task, and a run end to end."""
import time
from datetime import datetime, timedelta

import pytest

from troy import config, ipc_host, mobile_server, scheduler as sch, sessions, settings_store


class FakeAgent:
    runs = []

    def __init__(self, on_speak=None, on_state=None, on_tool_result=None):
        self.on_speak, self.on_state, self.on_tool_result = on_speak, on_state, on_tool_result
        self.history, self.notes = [], []

    def handle_user_input(self, text, source="typed"):
        FakeAgent.runs.append((text, source))
        self.on_state("thinking")
        self.on_tool_result("get_time", "", True, "noon")
        self.on_speak("Checked the time.")
        self.on_state("idle")

    def note_event(self, text): self.notes.append(text)
    def export_history(self): return list(self.history)
    def load_history(self, h): self.history = list(h)
    def refresh_memory_context(self): pass
    def refresh_situational_context(self): pass
    def resume_with_observation(self, text): pass


def wait_for(cond, timeout=4.0):
    end = time.time() + timeout
    while time.time() < end:
        if cond():
            return True
        time.sleep(0.02)
    return False


@pytest.fixture
def host(isolated_storage, monkeypatch, tmp_path):
    events = []
    FakeAgent.runs = []
    monkeypatch.setattr(ipc_host, "TroyAgent", FakeAgent)
    monkeypatch.setattr(ipc_host, "_emit", lambda event, data=None: events.append((event, data or {})))
    monkeypatch.setattr(settings_store, "SETTINGS_FILE", str(tmp_path / "troy_settings.json"))
    monkeypatch.setattr(mobile_server, "broadcast", lambda *a, **k: None)
    monkeypatch.setattr(config, "VOICE_OUTPUT_ENABLED", False)
    h = ipc_host.IPCHost()
    h.events = events
    yield h
    h.tasks.stop()
    sch.install(None)


def soon():
    return {"kind": "once", "at": (datetime.now() + timedelta(hours=2)).isoformat()}


def names(host):
    return [e for e, _ in host.events]


def test_the_scheduler_starts_with_the_host_and_is_reachable_by_the_tools(host):
    assert host.tasks.is_running() and sch.get() is host.tasks


def test_scheduler_stays_off_when_tasks_are_disabled(isolated_storage, monkeypatch, tmp_path):
    monkeypatch.setattr(ipc_host, "TroyAgent", FakeAgent)
    monkeypatch.setattr(ipc_host, "_emit", lambda *a, **k: None)
    monkeypatch.setattr(settings_store, "SETTINGS_FILE", str(tmp_path / "s.json"))
    monkeypatch.setattr(mobile_server, "broadcast", lambda *a, **k: None)
    monkeypatch.setattr(config, "TASKS_ENABLED", False)
    h = ipc_host.IPCHost()
    assert not h.tasks.is_running()
    sch.install(None)


def test_preview_explains_a_schedule_or_why_it_cant_be_read(host):
    ok = host._m_tasks_preview({"when": "every monday and friday at 22:00"})
    assert ok["ok"] and ok["text"] == "Every Monday and Friday at 22:00" and len(ok["next"]) == 3
    bad = host._m_tasks_preview({"when": "whenever"})
    assert not bad["ok"] and "Supported" in bad["error"]


def test_create_list_modify_pause_resume_cancel_delete(host):
    created = host._m_tasks_create({"when": "every day at 22:00", "prompt": "Put the computer to sleep.", "title": "Sleep PC", "approve": "sleep_computer"})["task"]
    assert created["grants"] == ["sleep_computer"] and created["session_id"] is None
    listing = host._m_tasks_list({})
    assert listing["enabled"] and listing["scheduler_running"] and [t["id"] for t in listing["tasks"]] == [created["id"]]
    assert host._m_tasks_modify({"id": created["id"], "when": "every monday at 9am", "title": "Weekly"})["task"]["schedule_text"] == "Every Monday at 09:00"
    assert host._m_tasks_pause({"id": created["id"]})["task"]["status"] == "paused"
    assert host._m_tasks_resume({"id": created["id"]})["task"]["status"] == "scheduled"
    assert host._m_tasks_cancel({"id": created["id"]})["task"]["status"] == "cancelled"
    assert host._m_tasks_clear_finished({})["cleared"] == 1 and host._m_tasks_list({})["tasks"] == []
    assert "task.changed" in names(host) and "task.deleted" in names(host)


def test_bad_input_is_reported_not_swallowed(host):
    with pytest.raises(ValueError, match="isn't a tool"):
        host._m_tasks_create({"when": "in 5 minutes", "prompt": "x", "approve": "no_such_tool"})
    with pytest.raises(ValueError):
        host._m_tasks_create({"when": "whenever", "prompt": "x"})
    with pytest.raises(ValueError, match="no longer exists"):
        host._m_tasks_get({"id": "nope"})


def test_the_task_list_says_whether_the_creating_chat_still_exists(host):
    sid = sessions.create_session("Night routine")
    t = host.tasks.add("x", soon(), session_id=sid)
    row = host._m_tasks_list({})["tasks"][0]
    assert row["chat_exists"] and row["chat_title"] == "Night routine"
    sessions.delete_session(sid)
    assert not host._m_tasks_list({})["tasks"][0]["chat_exists"]


def test_a_task_runs_end_to_end_with_an_isolated_agent_and_reports_back(host):
    sid = sessions.create_session("Evening")
    host.current_session_id, host.display_log = sid, [{"role": "user", "text": "remind me"}]
    t = host.tasks.add("Say the time.", soon(), session_id=sid)
    host.tasks.run_now(t["id"])
    assert wait_for(lambda: "task.finished" in names(host))
    assert FakeAgent.runs[0][1] == "task" and "Say the time." in FakeAgent.runs[0][0]
    done = dict(host.events)["task.finished"]
    assert done["ok"] and "Checked the time." in done["text"] and done["in_current_chat"]
    assert host.display_log[-1]["role"] == "task" and host.display_log[-1]["task_id"] == t["id"]
    assert host.tasks.get(t["id"])["status"] == "completed"
    assert host._last_state["state"] == "idle"                      # back to the ready state afterwards
    assert any(e == "task.started" for e in names(host))


def test_the_report_goes_into_a_closed_chat_without_touching_the_open_one(host):
    old = sessions.create_session("Old chat")
    host.current_session_id, host.display_log = None, []
    t = host.tasks.add("Say the time.", soon(), session_id=old)
    host.tasks.run_now(t["id"])
    assert wait_for(lambda: "task.finished" in names(host))
    data = sessions.load_session(old)
    assert data["display_log"][-1]["role"] == "task" and "Checked the time." in data["display_log"][-1]["text"]
    assert data["agent_history"][-1]["content"].startswith("[SYSTEM] Scheduled task") and host.display_log == []
    assert dict(host.events)["task.finished"]["in_current_chat"] is False


def test_a_failure_is_reported_with_the_number_of_attempts(host, monkeypatch):
    monkeypatch.setattr(config, "TASK_MAX_RETRIES", 1)
    monkeypatch.setattr(config, "TASK_RETRY_DELAY_SECONDS", 5)
    monkeypatch.setattr(FakeAgent, "handle_user_input", lambda self, text, source="typed": self.on_state("error", "no model reachable"))
    t = host.tasks.add("Do it.", soon(), max_retries=0)
    host.tasks.run_now(t["id"])
    assert wait_for(lambda: "task.finished" in names(host))
    done = dict(host.events)["task.finished"]
    assert not done["ok"] and "didn't succeed" in done["text"] and "no model reachable" in done["text"]


def test_approve_grants_the_refused_commands_and_runs_the_task_again(host):
    t = host.tasks.add("Sleep.", soon())
    with host.tasks._cond:
        host.tasks._tasks[t["id"]]["needs_approval"] = ["sleep_computer"]
    out = host._m_tasks_approve({"id": t["id"]})["task"]
    assert out["grants"] == ["sleep_computer"] and out["needs_approval"] == [] and out["manual"] is True
    with pytest.raises(ValueError, match="Nothing is waiting"):
        host._m_tasks_approve({"id": t["id"]})


def test_a_missed_task_is_announced(host):
    t = host.tasks.add("x", soon())
    with host.tasks._cond:
        task = host.tasks._tasks[t["id"]]
        host.tasks._mark_missed_locked(task, datetime.now(), timedelta(hours=7))
    assert wait_for(lambda: "task.finished" in names(host))
    done = dict(host.events)["task.finished"]
    assert done["kind"] == "missed" and not done["ok"] and "was missed" in done["text"]


def test_a_tasks_model_switch_is_undone_afterwards(host, monkeypatch):
    monkeypatch.setattr(config, "TEXT_MODEL_OVERRIDE", "")

    def switch(self, text, source="typed"):
        settings_store.apply_settings({"TEXT_MODEL_OVERRIDE": "groq:some-model"}, persist=False)
        self.on_speak("switched")
    monkeypatch.setattr(FakeAgent, "handle_user_input", switch)
    t = host.tasks.add("x", soon())
    host.tasks.run_now(t["id"])
    assert wait_for(lambda: "task.finished" in names(host))
    assert config.TEXT_MODEL_OVERRIDE == ""
