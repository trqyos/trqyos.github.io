"""The voice IPC methods in troy/ipc_host.py -- thin wrappers around
voice_mode (tested fully in test_voice_mode.py) whose job is to translate
between the Electron UI and the orchestrator, including the failure paths
the overlay has to be able to show."""
import pytest

from troy import config, ipc_host, mobile_server, settings_store, tts, voice


class FakeAgent:
    def __init__(self, on_speak=None, on_state=None, on_tool_result=None):
        self.on_speak, self.on_state, self.on_tool_result = on_speak, on_state, on_tool_result
        self.history, self.calls = [], []

    def handle_user_input(self, text, source="typed"):
        self.calls.append((text, source))

    def resume_with_observation(self, text): pass
    def export_history(self): return list(self.history)
    def load_history(self, h): self.history = list(h)
    def refresh_memory_context(self): pass
    def refresh_situational_context(self): pass


@pytest.fixture
def host(isolated_storage, monkeypatch, tmp_path):
    events = []
    monkeypatch.setattr(ipc_host, "TroyAgent", FakeAgent)
    monkeypatch.setattr(ipc_host, "_emit", lambda event, data=None: events.append((event, data or {})))
    monkeypatch.setattr(settings_store, "SETTINGS_FILE", str(tmp_path / "troy_settings.json"))
    monkeypatch.setattr(mobile_server, "broadcast", lambda *a, **k: None)
    monkeypatch.setattr(config, "VOICE_OUTPUT_ENABLED", False)
    h = ipc_host.IPCHost()
    h.events = events
    return h


def names(host):
    return [e for e, _ in host.events]


def test_mode_start_delegates_and_greets(host, monkeypatch):
    seen = []
    monkeypatch.setattr(host.voice, "start", lambda greet=True: seen.append(greet) or {"started": True})
    assert host._m_voice_mode_start({"greet": False}) == {"started": True}
    assert seen == [False]
    assert host._m_voice_mode_start({}) == {"started": True}      # default: greet
    assert seen == [False, True]


def test_mode_start_failure_raises_for_the_ui(host, monkeypatch):
    monkeypatch.setattr(host.voice, "start", lambda greet=True: {"started": False, "error": "no microphone"})
    with pytest.raises(ValueError, match="no microphone"):
        host._m_voice_mode_start({})


def test_mode_stop_interrupt_and_mute_delegate(host, monkeypatch):
    monkeypatch.setattr(host.voice, "stop", lambda reason="user": host.events.append(("stopped", reason)))
    assert host._m_voice_mode_stop({"reason": "idle"}) == {"stopped": True}
    monkeypatch.setattr(host.voice, "interrupt", lambda: host.events.append(("interrupted", None)))
    assert host._m_voice_interrupt({}) == {"ok": True}
    muted = []
    monkeypatch.setattr(host.voice, "set_muted", lambda m: muted.append(m))
    host._m_voice_mute({"muted": True})
    assert muted == [True]


def test_mode_status_merges_reports(host, monkeypatch):
    info = {"active": False, "state": "off", "source": "pc", "muted": False, "phone": {}, "listener": False, "conversation": False}
    monkeypatch.setattr(host.voice, "info", lambda: dict(info))
    monkeypatch.setattr(ipc_host.tts, "engine_report", lambda: [{"engine": "sapi", "available": True, "detail": "pyttsx3"}])
    monkeypatch.setattr(ipc_host.voice, "stt_status", lambda: {"engine": "google", "available": True, "reason": ""})
    st = host._m_voice_mode_status({})
    assert st["active"] is False and st["engines"] == [{"engine": "sapi", "available": True, "detail": "pyttsx3"}]
    assert st["stt"]["engine"] == "google"


def test_devices_and_test_mic_delegate(host, monkeypatch):
    monkeypatch.setattr(host.voice, "devices", lambda: [{"index": 0, "name": "Mic", "default": True}])
    assert host._m_voice_devices({})["devices"][0]["name"] == "Mic"
    monkeypatch.setattr(host.voice, "test_microphone", lambda seconds: {"ok": True, "peak": 0.1, "seconds": seconds})
    assert host._m_voice_test_mic({"seconds": 2})["seconds"] == 2


def test_speak_button_uses_the_engine_chain(host, monkeypatch):
    said = []
    monkeypatch.setattr(host.voice, "say_on_pc", lambda text, interrupt=True: said.append(text))
    assert host._m_voice_speak({"text": "Testing one two."}) == {"queued": True}
    assert said == ["Testing one two."]


def test_list_voices_reports_id_and_name_only(host, monkeypatch):
    monkeypatch.setattr(ipc_host.tts, "list_voices", lambda engine="sapi": [
        {"id": "v1", "name": "Zira", "extra": "field", "engine": "x"}])
    r = host._m_voice_list_voices({"engine": "edge"})
    assert r == {"voices": [{"id": "v1", "name": "Zira"}]}


def test_wake_listener_start_shares_the_voice_hooks(host, monkeypatch):
    hooks = []
    monkeypatch.setattr(host.voice, "install_listener", lambda: hooks.append(1))
    monkeypatch.setattr(ipc_host.wake_listener, "start", lambda: True)
    monkeypatch.setattr(ipc_host.wake_listener, "is_running", lambda: True)
    monkeypatch.setattr(ipc_host.wake_listener, "get_state", lambda: "listening")
    assert host._m_wake_listener_start({}) == {"started": True}
    assert hooks == [1]                                  # level/transcript/barge-in reach the UI even outside voice mode
    assert host._m_wake_listener_status({}) == {"running": True, "state": "listening"}


def test_voice_events_reach_the_frontend(host):
    host.voice._set_state("listening")
    assert "voice.state" in names(host)
    host.voice._on_level(0.4)
    assert "voice.level" in names(host)
