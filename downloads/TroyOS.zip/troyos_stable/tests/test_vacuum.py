"""troy/vacuum.py against a stateful fake S20+ (no network, no sleeping)."""
import json

import pytest

from troy import config, miot_client as mc, settings_store, vacuum as v

ROOMS = {"version": 2, "room_attrs": [["id", "room_name", "fan_level", "water_level", "clean_mode", "clean_times", "mop_mode", "on"],
                                      [3, "Lounge", 4, 1, 1, 1, 0, False], [4, "Mutfak", 2, 1, 4, 1, 0, True],
                                      [5, "Çocuk Odası", 3, 2, 3, 2, 0, False], [6, "Hall", 2, 1, 1, 1, 0, False], [7, "Hall Closet", 2, 1, 1, 1, 0, False]]}


class FakeS20:
    """Enough of the S20+ to exercise the controller. `accepts` = room encodings the 'robot' honours;
    `global_on` = an encoding it mis-reads as 'clean everything'; `no_ack` = actions raise ack-timeout (but still run)."""

    def __init__(self, accepts=("json_tagged",), global_on=(), no_ack=False, mop=True, status=2):
        self.accepts, self.global_on, self.no_ack = set(accepts), set(global_on), no_ack
        self.p = {v.STATUS: status, v.FAULT: 0, v.SWEEP_MOP: 3, v.SWEEP_TYPE: 1, v.AREA: 1250, v.CLEAN_TIME: 840, v.PASSES: 1, v.SUCTION: 2, v.WATER: 1,
                  v.BATTERY: 87, v.CHARGING: 1, v.MOP_ATTACHED: mop, v.STATUS_EXTRA: 0, v.ROOM_INFO: json.dumps(ROOMS),
                  (8, 2): 80, (9, 2): 6, (10, 2): 55, (11, 2): 40}
        self.calls = []

    def info(self):
        return {"model": "xiaomi.vacuum.b108gl", "fw_ver": "4.5.0"}

    def get_properties(self, props):
        return {a: self.p[a] for a in props if a in self.p}

    def set_property(self, siid, piid, value):
        if (siid, piid) == v.SWEEP_MOP and value in (2, 3, 4) and not self.p[v.MOP_ATTACHED]:
            return                                   # the robot silently reverts a mop mode without a pad
        self.p[(siid, piid)] = value

    @staticmethod
    def encoding(args):
        item = args[0]
        tagged = isinstance(item, dict)
        val = item["value"] if tagged else item
        return ("json" if str(val).startswith("{") else "csv") + ("_tagged" if tagged else "")

    def action(self, siid, aiid, args=()):
        self.calls.append(((siid, aiid), list(args)))
        a = (siid, aiid)
        if a == v.A_START:
            self.p.update({v.STATUS: 4, v.SWEEP_TYPE: 1})
        elif a == v.A_STOP:
            self.p[v.STATUS] = 1
        elif a == v.A_PAUSE:
            self.p[v.STATUS] = 5
        elif a == v.A_RESUME:
            self.p[v.STATUS] = 4
        elif a == v.A_DOCK:
            self.p[v.STATUS] = 6
        elif a == v.A_ROOMS:
            enc = self.encoding(args)
            if enc in self.accepts:
                self.p.update({v.STATUS: 4, v.SWEEP_TYPE: 8})
            elif enc in self.global_on:
                self.p.update({v.STATUS: 4, v.SWEEP_TYPE: 1})
        if self.no_ack:
            raise mc.MiotAckTimeout("user ack timeout")
        return {"code": 0}

    def rooms_called(self):
        return [(c, args) for c, args in self.calls if c == v.A_ROOMS]


@pytest.fixture
def setup(monkeypatch, tmp_path):
    t = [0.0]

    def now():
        t[0] += 0.4
        return t[0]

    monkeypatch.setattr(v, "_now", now)
    monkeypatch.setattr(v, "_sleep", lambda s: None)
    monkeypatch.setattr(settings_store, "SETTINGS_FILE", str(tmp_path / "settings.json"))
    for k, val in (("VACUUM_ENABLED", True), ("VACUUM_HOST", "10.0.0.5"), ("VACUUM_TOKEN", "00" * 16), ("VACUUM_ROOM_ENCODING", "auto"), ("VACUUM_TIMEOUT_SECONDS", 1.0)):
        monkeypatch.setattr(config, k, val)

    def use(robot):
        monkeypatch.setattr(v, "_client_factory", lambda h, tk, to: robot)
        v._client_cache.update(key=None, client=None)
        return robot
    return use


# ---------------------------------------------------------------- helpers
def test_fold_is_turkish_aware():
    assert v.fold("Çocuk Odası") == "cocuk odasi" and v.fold("MUTFAK") == "mutfak" and v.fold("İş Odası") == "is odasi" and v.fold("IŞIK") == "isik"


def test_match_rooms_exact_prefix_substring_and_id():
    rooms = v.parse_rooms(json.dumps(ROOMS))
    assert v.match_rooms(["mutfak"], rooms) == ([4], [])
    assert v.match_rooms(["MUTFAK", "cocuk"], rooms) == ([4, 5], [])           # prefix, accent-free
    assert v.match_rooms(["lounge"], rooms) == ([3], [])
    assert v.match_rooms(["hall"], rooms) == ([6], [])                          # exact beats the longer 'Hall Closet'
    assert v.match_rooms(["closet"], rooms) == ([7], [])                        # substring
    assert v.match_rooms(["5"], rooms) == ([5], [])                             # numeric id
    ids, problems = v.match_rooms(["garage"], rooms)
    assert ids == [] and "garage" in problems[0]


def test_parse_rooms_accepts_both_shapes_and_junk():
    assert [r["name"] for r in v.parse_rooms(json.dumps(ROOMS))][:2] == ["Lounge", "Mutfak"]
    obj = {"room_attrs": [{"id": 4, "room_name": "Kitchen", "fan_level": 4, "water_level": 3, "clean_mode": 4, "clean_times": 1, "mop_mode": 0, "on": True}]}
    assert v.parse_rooms(json.dumps(obj))[0]["id"] == 4
    assert v.parse_rooms("") == [] and v.parse_rooms("not json") == [] and v.parse_rooms('{"room_attrs": []}') == []


def test_split_names_in_english_and_turkish():
    assert v.split_names("kitchen, hall and bedroom") == ["kitchen", "hall", "bedroom"]
    assert v.split_names("mutfak ve salon") == ["mutfak", "salon"]


def test_every_room_encoding_is_distinct():
    outs = {json.dumps(v.encode_rooms([5, 6], e)) for e in v.ROOM_ENCODINGS}
    assert len(outs) == 4
    assert v.encode_rooms([5], "json_tagged") == [{"piid": 13, "value": '{"room":[5]}'}] and v.encode_rooms([5, 6], "csv") == ["5,6"]


# ---------------------------------------------------------------- guards
def test_disabled_and_unconfigured_are_explained(setup, monkeypatch):
    monkeypatch.setattr(config, "VACUUM_ENABLED", False)
    r = v.status()
    assert not r["success"] and "turned off" in r["message"]
    monkeypatch.setattr(config, "VACUUM_ENABLED", True)
    monkeypatch.setattr(config, "VACUUM_TOKEN", "")
    assert "token" in v.start()["message"]


def test_bad_token_text_is_reported_not_raised(setup, monkeypatch):
    monkeypatch.setattr(config, "VACUUM_TOKEN", "nothex")
    monkeypatch.setattr(v, "_client_factory", None)
    v._client_cache.update(key=None, client=None)
    r = v.status()
    assert not r["success"] and "32" in r["message"]


def test_network_errors_become_plain_messages(setup):
    class Down:
        def get_properties(self, *_):
            raise mc.MiotConnectionError("The robot at 10.0.0.5 didn't answer.")
    setup(Down())
    r = v.status()
    assert not r["success"] and "didn't answer" in r["message"]


# ---------------------------------------------------------------- reading
def test_status_message(setup):
    setup(FakeS20())
    m = v.status()["message"]
    assert "charging on the dock" in m and "87%" in m and "12.5 m²" in m and "14 min" in m and "suction standard" in m


def test_status_notes_a_missing_mop_and_a_fault(setup):
    r = setup(FakeS20(mop=False))
    r.p[v.FAULT] = 210009
    m = v.status()["message"]
    assert "no mop pad" in m and "210009" in m


def test_rooms_lists_names_ids_and_saved_settings(setup):
    setup(FakeS20())
    m = v.rooms()["message"]
    assert "Mutfak (id 4" in m and "sweep first, then mop" in m and "Çocuk Odası" in m


def test_consumables_flags_low_parts(setup):
    setup(FakeS20())
    m = v.consumables()["message"]
    assert "main brush 80%" in m and "side brush 6%" in m and "Replace soon: side brush" in m


def test_test_reports_model_and_state(setup):
    setup(FakeS20())
    r = v.test()
    assert r["success"] and r["model"] == "xiaomi.vacuum.b108gl" and r["battery"] == 87


# ---------------------------------------------------------------- start / pause / stop / dock
def test_start_verifies_the_robot_is_cleaning(setup):
    r = setup(FakeS20())
    out = v.start()
    assert out["success"] and "whole home" in out["message"] and r.p[v.STATUS] == 4


def test_start_survives_a_missing_ack(setup):
    setup(FakeS20(no_ack=True))
    out = v.start()
    assert out["success"] and "didn't acknowledge" in out["message"]


def test_start_when_nothing_happens_says_so_with_the_fault(setup):
    class Stuck(FakeS20):
        def action(self, *a, **k):
            self.p[v.FAULT] = 100003
            return {"code": 0}
    setup(Stuck())
    out = v.start()
    assert not out["success"] and "not cleaning" in out["message"] and "100003" in out["message"]


def test_start_while_paused_resumes_instead_of_restarting(setup):
    r = setup(FakeS20(status=5))
    out = v.start()
    assert out["success"] and "Resumed" in out["message"] and r.calls[-1][0] == v.A_RESUME


def test_start_with_a_mode_sets_it_first(setup):
    r = setup(FakeS20())
    assert v.start("sweep_then_mop")["success"] and r.p[v.SWEEP_MOP] == 4
    setup(FakeS20())                                  # a fresh, docked robot
    bad = v.start("nonsense")
    assert not bad["success"] and "isn't a valid cleaning mode" in bad["message"]


def test_start_refuses_a_mop_mode_without_a_pad(setup):
    r = setup(FakeS20(mop=False))
    out = v.start("mop")
    assert not out["success"] and "mop pad" in out["message"] and not r.calls


def test_start_when_already_cleaning_does_not_send_another_command(setup):
    r = setup(FakeS20(status=4))
    assert v.start()["success"] and not r.calls


def test_pause_resume_stop_dock_cycle(setup):
    r = setup(FakeS20(status=4))
    assert v.pause()["success"] and r.p[v.STATUS] == 5
    assert v.resume()["success"] and r.p[v.STATUS] == 4
    assert v.stop()["success"] and r.p[v.STATUS] == 1
    assert v.dock()["success"] and r.p[v.STATUS] == 6


def test_commands_that_make_no_sense_in_the_current_state_say_so(setup):
    r = setup(FakeS20(status=2))
    assert not v.pause()["success"] and not v.resume()["success"]
    assert v.stop()["success"] and "Nothing to stop" in v.stop()["message"]
    assert "already on its dock" in v.dock()["message"]
    assert not r.calls


def test_locate_uses_the_find_action(setup):
    r = setup(FakeS20())
    assert v.locate()["success"] and r.calls[-1][0] == (6, 6)


# ---------------------------------------------------------------- settings
def test_set_suction_water_passes_volume(setup):
    r = setup(FakeS20())
    assert v.set_option("suction", "Güçlü")["success"] and r.p[v.SUCTION] == 3
    assert v.set_option("suction", "4")["success"] and r.p[v.SUCTION] == 4
    assert v.set_option("mop_water", "high")["success"] and r.p[v.WATER] == 3
    assert v.set_option("passes", "2")["success"] and r.p[v.PASSES] == 2
    assert v.set_option("volume", "35%")["success"] and r.p[(4, 2)] == 35


def test_set_rejects_bad_values_without_touching_the_robot(setup):
    r = setup(FakeS20())
    before = dict(r.p)
    for opt, val in (("suction", "ludicrous"), ("passes", "7"), ("volume", "300"), ("volume", "loud"), ("colour", "red")):
        assert not v.set_option(opt, val)["success"]
    assert r.p == before


def test_set_mode_detects_a_reverted_mode(setup):
    r = setup(FakeS20(mop=False))
    assert "mop pad" in v.set_option("mode", "mop")["message"]
    r.p[v.MOP_ATTACHED] = True
    assert v.set_option("mode", "sweep")["success"] and r.p[v.SWEEP_MOP] == 1


# ---------------------------------------------------------------- room cleaning
def test_clean_rooms_first_encoding_works(setup):
    r = setup(FakeS20(accepts=("json_tagged",)))
    out = v.clean_rooms("mutfak")
    assert out["success"] and "Mutfak" in out["message"]
    (addr, args), = r.rooms_called()
    assert args == [{"piid": 13, "value": '{"room":[4]}'}]
    assert config.VACUUM_ROOM_ENCODING == "json_tagged"            # remembered


def test_auto_walks_the_encodings_until_one_really_starts_a_room_clean(setup):
    r = setup(FakeS20(accepts=("csv",)))                            # only the comma-separated form works on this 'robot'
    out = v.clean_rooms("mutfak, hall")
    assert out["success"]
    encs = [r_[1] for r_ in r.rooms_called()]
    assert len(encs) == 3 and encs[-1] == ["4,6"]                  # json_tagged, json (ignored), then csv
    assert config.VACUUM_ROOM_ENCODING == "csv"
    saved = json.load(open(settings_store.SETTINGS_FILE))
    assert saved["VACUUM_ROOM_ENCODING"] == "csv"


def test_a_remembered_encoding_is_used_directly(setup, monkeypatch):
    monkeypatch.setattr(config, "VACUUM_ROOM_ENCODING", "csv")
    r = setup(FakeS20(accepts=("csv",)))
    assert v.clean_rooms("hall")["success"] and len(r.rooms_called()) == 1


def test_a_whole_home_start_by_mistake_is_stopped_and_docked(setup):
    r = setup(FakeS20(accepts=(), global_on=("json_tagged",)))
    out = v.clean_rooms("mutfak")
    assert not out["success"] and "whole-home" in out["message"]
    assert [c for c, _ in r.calls][-2:] == [v.A_STOP, v.A_DOCK] and r.p[v.STATUS] == 6
    assert len(r.rooms_called()) == 1                               # didn't keep trying after a bad outcome


def test_when_no_encoding_works_it_says_so_honestly(setup):
    r = setup(FakeS20(accepts=()))
    out = v.clean_rooms("mutfak")
    assert not out["success"] and "never started" in out["message"] and "Xiaomi Home app" in out["message"]
    assert len(r.rooms_called()) == 4


def test_unknown_or_ambiguous_rooms_are_not_sent(setup):
    r = setup(FakeS20())
    out = v.clean_rooms("garage")
    assert not out["success"] and "garage" in out["message"] and "Mutfak" in out["message"] and not r.calls
    assert not v.clean_rooms("")["success"]


def test_switching_rooms_stops_the_current_clean_first(setup):
    r = setup(FakeS20(status=4, accepts=("json_tagged",)))
    assert v.clean_rooms("mutfak")["success"]
    assert [c for c, _ in r.calls][0] == v.A_STOP


def test_room_clean_works_without_acks_too(setup):
    setup(FakeS20(accepts=("json_tagged",), no_ack=True))
    assert v.clean_rooms("mutfak")["success"]


def test_no_rooms_on_the_map(setup):
    r = setup(FakeS20())
    r.p[v.ROOM_INFO] = ""
    assert "no rooms" in v.clean_rooms("kitchen")["message"]
