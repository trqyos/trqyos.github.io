"""One scheduled attempt: the prompt, how the outcome is judged, and the unattended-approval rules --
including a full run through the real agent, dispatcher and tool registry with a scripted model."""
import threading
from datetime import datetime, timedelta

import pytest

import troy.tools_all as tools_all
from troy import agent as agent_mod, config, confirmation, dispatcher, llm_client, scheduler as sch, task_context, task_runner
from troy.scheduler import Outcome


class Script:
    """A fake llm_client.chat that plays back canned replies and remembers what it was sent."""
    def __init__(self, *replies): self.replies, self.sent = list(replies), []
    def __call__(self, messages, stop_check=None, on_text=None):
        self.sent.append([dict(m) for m in messages])
        return self.replies.pop(0)


@pytest.fixture
def world(tmp_path, monkeypatch):
    class W: pass
    w = W()
    w.clock = [datetime(2026, 10, 19, 21, 59)]
    w.script = Script()
    w.slept = []
    monkeypatch.setattr(llm_client, "chat", lambda *a, **k: w.script(*a, **k))
    monkeypatch.setattr(config, "TASK_RETRY_DELAY_SECONDS", 5)
    # a harmless stand-in for the real sleep command (still registered as needing approval)
    original = tools_all.get("sleep_computer")
    monkeypatch.setitem(tools_all._REGISTRY, "sleep_computer",
                        tools_all.ToolDefinition(name="sleep_computer", func=lambda a: (w.slept.append(a), {"success": True, "message": "Computer is sleeping."})[1],
                                                 description=original.description, category="system", risk_level="medium", requires_confirmation=True))
    w.runner = task_runner.TaskRunner(
        agent_factory=lambda **cb: agent_mod.TroyAgent(**cb),
        info_names=tools_all.info_command_names() | dispatcher.INFO_COMMANDS)
    w.s = sch.Scheduler(executor=w.runner.execute, clock=lambda: w.clock[0],
                        tasks_file=str(tmp_path / "t.json"), log_file=str(tmp_path / "l.jsonl"))
    w.advance = lambda **kw: w.clock.__setitem__(0, w.clock[0] + timedelta(**kw))
    w.spoken = []
    return w


def run_due(w, n=1):
    """Moves the clock past the due time, runs n passes, returns the last scheduler view."""
    w.advance(minutes=2)
    for _ in range(n):
        w.s.tick()
        w.advance(seconds=10)


# ---------------------------------------------------------------- the prompt
def test_the_run_prompt_states_the_task_attempt_and_the_reporting_rule():
    run = type("R", (), {"attempt": 2, "max_attempts": 3, "done_actions": [{"name": "copy_file", "arg": "a|b", "message": "copied"}], "last_error": "disk full"})()
    task = {"title": "Backup", "prompt": "Copy the report.", "schedule_text": "Every day at 22:00", "known_tools": {"convert_currency": "convert_currency:amount|from|to"}}
    text = task_runner.build_prompt(task, run)
    assert "SCHEDULED TASK" in text and "Instruction: Copy the report." in text and "Attempt 2 of 3" in text
    assert "do NOT do them again" in text and "copy_file:a|b" in text
    assert "previous attempt failed: disk full" in text
    assert "convert_currency:amount|from|to" in text
    assert "task_result:<done|retry|blocked>" in text and "Never ask the user" in text


# ---------------------------------------------------------------- through the real agent
def test_a_pre_approved_command_runs_unattended_and_the_model_reports_success(world):
    world.script.replies = ["speak:Going to sleep.\nsleep_computer\ntask_result:done|Put the computer to sleep.\ndone\n"]
    t = world.s.add("Put the computer to sleep.", "in 1 minutes", grants=["sleep_computer"])
    run_due(world)
    got = world.s.get(t["id"])
    assert world.slept == [""] and got["status"] == "completed" and got["last_summary"] == "Put the computer to sleep."
    assert [a["name"] for a in world.s.logs(t["id"]) if False] == []           # (logs are checked in test_scheduler)
    assert not confirmation.list_pending()                                      # no Approve prompt was ever raised


def test_a_command_that_was_not_pre_approved_is_refused_and_asks_for_approval(world):
    world.script.replies = ["sleep_computer\ntask_result:blocked|It needs approval.\ndone\n"]
    t = world.s.add("Put the computer to sleep.", "in 1 minutes")             # no grants
    run_due(world)
    got = world.s.get(t["id"])
    assert world.slept == []                                                    # it never ran
    assert got["status"] == "failed" and got["needs_approval"] == ["sleep_computer"] and "pre-approved" in got["last_error"]
    assert not confirmation.list_pending()                                      # and no prompt was left dangling for nobody
    assert len(world.script.sent) == 1                                          # blocked is final: not retried


def test_an_approval_covers_exactly_the_approved_arguments(world):
    world.script.replies = ["sleep_computer:now\ntask_result:done|x\ndone\n"]
    t = world.s.add("Sleep.", "in 1 minutes", grants=["sleep_computer"])          # approved with no argument only
    run_due(world)
    assert world.slept == [] and world.s.get(t["id"])["needs_approval"] == ["sleep_computer:now"]


def test_unattended_runs_cannot_raise_approval_prompts_through_any_path(world):
    ctx = task_context.RunContext("x")
    with task_context.activate(ctx):
        with pytest.raises(confirmation.UnattendedRefusal):
            confirmation.request("change_setting", "A|b", "medium", lambda a: {}, "x")
        r = tools_all.run("delete_file", "C:/x")
        assert not r["success"] and "wasn't pre-approved" in r["message"] and ctx.denied == ["delete_file:C:/x"]
    assert not confirmation.list_pending()


def test_the_same_command_still_asks_normally_outside_a_scheduled_run():
    r = tools_all.run("delete_file", "C:/x")
    assert r.get("pending_confirmation") and len(confirmation.list_pending()) == 1


def test_a_failed_action_is_retried_with_the_already_done_steps_listed(world, monkeypatch):
    copies = []
    monkeypatch.setattr(tools_all, "create_file", lambda arg: {"success": True, "message": "created"})
    monkeypatch.setattr(tools_all, "copy_file", lambda arg: (copies.append(arg), {"success": len(copies) > 1, "message": "copied" if len(copies) > 1 else "disk full"})[1])
    world.script.replies = [
        "create_file:C:/Backup/note.txt|hi\ncopy_file:C:/a|C:/Backup/b\ntask_result:retry|The copy failed.\ndone\n",
        "copy_file:C:/a|C:/Backup/b\ntask_result:done|Copied.\ndone\n",
    ]
    t = world.s.add("Back up a.", "in 1 minutes")
    run_due(world, 2)
    second = [m for m in world.script.sent[1] if m["role"] == "user"][0]["content"]
    done_part = second.split("ALREADY DONE")[1].split("The previous")[0]
    assert "create_file" in done_part and "copy_file" not in done_part      # what succeeded is listed; what failed is not
    assert "previous attempt failed: The copy failed." in second
    assert copies == ["C:/a|C:/Backup/b"] * 2 and world.s.get(t["id"])["status"] == "completed"


def test_each_run_uses_a_fresh_conversation(world):
    world.script.replies = ["task_result:done|ok\ndone\n", "task_result:done|ok\ndone\n"]
    world.s.add("one", "in 1 minutes")
    world.s.add("two", "in 1 minutes")
    run_due(world, 2)
    first, second = world.script.sent
    assert [m for m in second if m["role"] == "user"][0]["content"].count("Instruction: one") == 0
    assert len([m for m in second if m["role"] == "user"]) == 1


def test_a_task_cannot_schedule_more_tasks(world):
    world.script.replies = ["schedule_task:in 1 minutes|again\ntask_result:blocked|can't\ndone\n"]
    from troy import tools_tasks
    t = world.s.add("loop", "in 1 minutes")
    sch.install(world.s)
    try:
        run_due(world)
        assert len(world.s.list()) == 1
    finally:
        sch.install(None)


# ---------------------------------------------------------------- outcome derivation without task_result
class FakeAgent:
    def __init__(self, behaviour, on_speak, on_state, on_tool_result):
        self.b, self.on_speak, self.on_state, self.on_tool_result = behaviour, on_speak, on_state, on_tool_result
    def handle_user_input(self, text, source="typed"): self.b(self)
    def extra_tools_used(self): return {"x_tool": "x_tool:a"}


def judge(behaviour, **runner_kw):
    runner = task_runner.TaskRunner(agent_factory=lambda **cb: FakeAgent(behaviour, **cb), **runner_kw)
    run = type("R", (), {"attempt": 1, "max_attempts": 3, "done_actions": [], "last_error": "", "record_action": lambda *a: None, "log": lambda *a, **k: None})()
    return runner.execute({"id": "t1", "title": "T", "prompt": "p", "schedule_text": "now", "grants": []}, run)


def test_an_action_that_succeeded_counts_as_done_when_the_model_forgot_to_report():
    out = judge(lambda a: (a.on_tool_result("open_app", "notepad", True, "opened"), a.on_speak("Opened.")), info_names=set())
    assert out.status == "done" and out.summary == "Opened." and out.used_tools == {"x_tool": "x_tool:a"}


def test_the_last_action_failing_means_retry():
    out = judge(lambda a: a.on_tool_result("open_app", "nope", False, "not found"))
    assert out.status == "retry" and "open_app failed" in out.error


def test_an_information_only_task_succeeds_with_the_answer():
    out = judge(lambda a: (a.on_tool_result("get_system_stats", "", True, "CPU 5%"), a.on_speak("CPU is 5%.")), info_names={"get_system_stats"})
    assert out.status == "done" and out.summary == "CPU is 5%."


def test_doing_and_saying_nothing_is_a_failed_attempt():
    assert judge(lambda a: None).status == "retry"


def test_a_model_error_is_retried_and_a_stop_is_not():
    assert judge(lambda a: a.on_state("error", "no model reachable")).status == "retry"
    assert judge(lambda a: a.on_state("stopped")).status == "stopped"


def test_the_step_limit_counts_as_unfinished():
    out = judge(lambda a: a.on_speak("(Reached the step limit for this turn.)"))
    assert out.status == "retry" and "steps" in out.error


def test_an_agent_that_crashes_is_a_retry():
    def boom(a): raise RuntimeError("bang")
    assert "bang" in judge(boom).error


def test_the_users_model_choice_is_restored_after_a_task_switched_it():
    state = {"model": "fast"}

    def behave(a):
        state["model"] = "weird"                              # the task switched models
        a.on_speak("ok")
    out = judge(behave, restore_model=(lambda: dict(state), lambda snap: state.update(snap)))
    assert state["model"] == "fast" and out.status == "done"


def test_runs_wait_for_the_turn_lock_so_they_never_overlap_a_chat_turn():
    lock = threading.Lock()
    lock.acquire()
    started = threading.Event()
    result = []

    def run():
        started.set()
        result.append(judge(lambda a: a.on_speak("hi"), turn_lock=lock))
    th = threading.Thread(target=run)
    th.start()
    started.wait(1)
    th.join(0.3)
    assert th.is_alive() and result == []                      # held back by the chat turn
    lock.release()
    th.join(2)
    assert result and result[0].status == "done"


def test_a_refused_command_means_blocked_even_if_the_model_claims_done():
    """A model that says 'done' after its command was refused must not hide the fact that the action never ran."""
    def behave(a):
        task_context.current().deny("sleep_computer")
        task_context.current().reported = ("done", "All done!")
    out = judge(behave)
    assert out.status == "blocked" and out.needs_approval == ["sleep_computer"]
