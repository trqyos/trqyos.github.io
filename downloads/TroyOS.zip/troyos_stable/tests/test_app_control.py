"""Troy controlling its own app (tools_app), power saving and the UI bridge."""
import pytest

from troy import config, confirmation, power, settings_store, tools_all, tools_app, ui_bridge


@pytest.fixture
def ui(monkeypatch, tmp_path):
    monkeypatch.setattr(settings_store, "SETTINGS_FILE", str(tmp_path / "s.json"))
    sent = []
    ui_bridge.set_emitter(lambda ev, data: sent.append((ev, data)))
    ui_bridge.set_host(None)
    monkeypatch.setattr(config, "POWER_SAVING", "auto")
    monkeypatch.setattr(power, "_on_battery", None)
    monkeypatch.setattr(power, "_last", None)
    yield sent
    ui_bridge.set_emitter(None)
    settings_store._listeners.clear()
    confirmation.cancel_all()


def cmds(sent):
    return [d for ev, d in sent if ev == "ui.command"]


def test_all_app_tools_are_registered_in_their_own_category():
    names = {"show_widget", "hide_widget", "toggle_widget", "open_full_app", "ui_status", "new_chat", "open_view", "set_appearance",
             "set_widget_option", "list_settings", "change_setting", "set_power_saving", "power_status"}
    reg = tools_all.all_tools()
    assert names <= set(reg) and all(reg[n].category == "app" for n in names)


def test_widget_and_app_modes(ui):
    assert tools_app.show_widget()["success"] and cmds(ui)[-1] == {"action": "mode", "mode": "widget"}
    assert tools_app.open_full_app()["success"] and cmds(ui)[-1]["mode"] == "app"
    assert tools_app.hide_widget()["success"] and cmds(ui)[-1]["mode"] == "hidden"
    assert tools_app.toggle_widget()["success"] and cmds(ui)[-1]["mode"] == "toggle"


def test_tools_report_failure_when_no_interface_is_connected():
    ui_bridge.set_emitter(None)
    assert tools_app.show_widget()["success"] is False


def test_open_view_and_settings_panes(ui):
    assert tools_app.open_view("memory")["success"] and cmds(ui)[-1] == {"action": "view", "view": "memory", "pane": ""}
    assert tools_app.open_view("settings|widget")["success"] and cmds(ui)[-1]["pane"] == "widget"
    assert tools_app.open_view("power")["success"] and cmds(ui)[-1] == {"action": "view", "view": "settings", "pane": "power"}
    assert tools_app.open_view("nonsense")["success"] is False
    assert tools_app.open_view("settings|nope")["success"] is False


def test_appearance_and_widget_options_are_validated(ui):
    assert tools_app.set_appearance("theme|light")["success"] and cmds(ui)[-1] == {"action": "appearance", "key": "theme", "value": "light"}
    assert tools_app.set_appearance("accent|neon")["success"] is False
    assert tools_app.set_appearance("theme")["success"] is False
    assert tools_app.set_widget_option("onTop|off")["success"] and cmds(ui)[-1]["value"] is False
    assert tools_app.set_widget_option("hotkey|Ctrl+Alt+T")["success"] and cmds(ui)[-1]["value"] == "Ctrl+Alt+T"
    assert tools_app.set_widget_option("hotkey|T")["success"] is False
    assert tools_app.set_widget_option("colour|red")["success"] is False


def test_new_chat_now_or_after_the_running_turn(ui):
    assert tools_app.new_chat()["success"] and cmds(ui)[-1]["action"] == "new_chat"

    class Host:
        called = 0
        def schedule_new_chat(self):
            Host.called += 1
            return "after_turn"
    ui_bridge.set_host(Host())
    r = tools_app.new_chat()
    assert Host.called == 1 and "finish" in r["message"]


def test_change_setting_goes_through_the_same_validation_as_the_ui(ui, monkeypatch):
    monkeypatch.setattr(config, "TTS_RATE", 175)
    heard = []
    settings_store.on_change(lambda keys, src: heard.append((keys, src)))
    r = tools_app.change_setting("TTS_RATE|220")
    assert r["success"] and config.TTS_RATE == 220
    assert heard == [({"TTS_RATE"}, "troy")]                                 # every window hears about it
    assert tools_app.change_setting("TTS_RATE|9999")["success"] is False and config.TTS_RATE == 220
    assert tools_app.change_setting("TTS_RAT|200")["success"] is False       # typo -> suggestion
    assert "TTS_RATE" in tools_app.change_setting("TTS_RAT|200")["message"]


def test_secrets_and_the_model_switch_permission_are_off_limits(ui, monkeypatch):
    monkeypatch.setattr(config, "ALLOW_MODEL_SWITCH", False)
    assert tools_app.change_setting("GROQ_API_KEY|x")["success"] is False
    r = tools_app.change_setting("ALLOW_MODEL_SWITCH|on")
    assert r["success"] is False and config.ALLOW_MODEL_SWITCH is False


def test_network_exposing_settings_need_approval(ui, monkeypatch):
    monkeypatch.setattr(config, "MOBILE_SCREEN_ENABLED", False)
    r = tools_app.change_setting("MOBILE_SCREEN_ENABLED|on")
    assert r.get("pending") and config.MOBILE_SCREEN_ENABLED is False
    pending = confirmation.list_pending()
    assert pending and pending[0].name == "change_setting"
    confirmation.resolve(pending[0].id, True)
    assert config.MOBILE_SCREEN_ENABLED is True


def test_list_settings_hides_keys_and_filters(ui):
    r = tools_app.list_settings("voice")["message"]
    assert "VOICE_INPUT_ENABLED" in r and "GROQ_API_KEY" not in r
    assert tools_app.list_settings("zzzz")["success"] is False
    assert "HOTKEY_COMBO" not in tools_app.list_settings("")["message"]       # the python hotkey is gone


def test_power_saving_modes_and_battery(ui):
    assert tools_app.set_power_saving("on")["success"] and power.active() and config.POWER_SAVING == "on"
    assert tools_app.set_power_saving("off")["success"] and not power.active()
    assert tools_app.set_power_saving("battery")["success"] and config.POWER_SAVING == "auto"
    assert not power.active()                                       # auto + plugged in / unknown
    power.report_battery(True)
    assert power.active()
    power.report_battery(False)
    assert not power.active()
    assert tools_app.set_power_saving("turbo")["success"] is False


def test_power_state_is_announced_once_per_change(ui):
    power.report_battery(True)
    power.report_battery(True)                                      # same state: no second event
    states = [d for ev, d in ui if ev == "power.state"]
    assert len(states) == 1 and states[0] == {"mode": "auto", "on_battery": True, "active": True}


def test_saver_lowers_live_update_rates(ui):
    config.POWER_SAVING = "off"
    assert power.phone_fps(10) == 10 and power.level_interval() == 0.1
    config.POWER_SAVING = "on"
    assert power.phone_fps(10) == power.SAVER_PHONE_FPS and power.level_interval() > 0.1
    assert power.phone_fps(2) == 2


def test_ui_status_reflects_what_electron_reported(ui):
    ui_bridge.report(mode="widget", theme="dark")
    msg = tools_app.ui_status()["message"]
    assert "the widget" in msg and "theme: dark" in msg and "power saving" in msg


def test_the_python_hotkey_is_gone():
    import importlib.util
    assert importlib.util.find_spec("troy.hotkey") is None
    assert not hasattr(config, "HOTKEY_COMBO") and "HOTKEY_COMBO" not in settings_store.SETTINGS
