"""Turn handling, lazy sessions, auto-titles, validation and mobile start in
troy/ipc_host.py, using a fake agent so no model or network is involved."""
import threading
import time

import pytest

from troy import config, ipc_host, settings_store, mobile_server, sessions


class FakeAgent:
    gate = None            # set to a threading.Event to hold a turn open

    def __init__(self, on_speak=None, on_state=None, on_tool_result=None):
        self.on_speak, self.on_state, self.on_tool_result = on_speak, on_state, on_tool_result
        self.history, self.calls = [], []

    def handle_user_input(self, text, source="typed"):
        self.calls.append((text, source))
        self.on_state("thinking")
        if FakeAgent.gate:
            FakeAgent.gate.wait(5)
        self.on_tool_result("get_time", "", True, "noon")
        self.on_speak(f"echo: {text}")
        self.on_state("idle")
        self.history += [{"role": "user", "content": text}]

    def resume_with_observation(self, text):
        self.calls.append((text, "confirmation"))

    def export_history(self): return list(self.history)
    def load_history(self, h): self.history = list(h)
    def refresh_memory_context(self): pass
    def refresh_situational_context(self): pass


def wait_for(cond, timeout=3.0):
    end = time.time() + timeout
    while time.time() < end:
        if cond():
            return True
        time.sleep(0.01)
    return False


@pytest.fixture
def host(isolated_storage, monkeypatch, tmp_path):
    events = []
    monkeypatch.setattr(ipc_host, "TroyAgent", FakeAgent)
    monkeypatch.setattr(ipc_host, "_emit", lambda event, data=None: events.append((event, data or {})))
    monkeypatch.setattr(settings_store, "SETTINGS_FILE", str(tmp_path / "troy_settings.json"))
    monkeypatch.setattr(mobile_server, "broadcast", lambda *a, **k: None)
    monkeypatch.setattr(config, "VOICE_OUTPUT_ENABLED", False)
    FakeAgent.gate = None
    h = ipc_host.IPCHost()
    h.events = events
    return h


def names(host):
    return [e for e, _ in host.events]


def test_send_creates_session_lazily_and_titles_it(host):
    assert host.current_session_id is None and sessions.list_sessions() == []
    host._m_chat_send({"text": "Open Firefox please"})
    assert wait_for(lambda: "chat.turn_complete" in names(host))
    assert host.current_session_id
    listing = sessions.list_sessions()
    assert len(listing) == 1 and listing[0]["title"] == "Open Firefox please"
    order = names(host)
    assert order.index("chat.user_message") < order.index("chat.turn_started") < order.index("agent.speak") < order.index("chat.turn_complete")
    assert dict(host.events)["chat.turn_complete"]["pending"] == 0


def test_busy_blocks_session_changes_and_turns_serialize(host):
    FakeAgent.gate = threading.Event()
    host._m_chat_send({"text": "first"})
    assert wait_for(lambda: host._pending_turns == 1 and host.agent.calls)
    assert host._m_agent_status({})["busy"] is True
    with pytest.raises(ValueError, match="busy"):
        host._m_session_reset({})
    host._m_chat_send({"text": "second"})              # queues behind the first
    time.sleep(0.15)
    assert [c[0] for c in host.agent.calls] == ["first"]
    FakeAgent.gate.set()
    assert wait_for(lambda: host._pending_turns == 0)
    assert [c[0] for c in host.agent.calls] == ["first", "second"]
    assert host._m_agent_status({})["busy"] is False


def test_reset_detaches_without_creating_a_file(host):
    host._m_chat_send({"text": "hello"})
    assert wait_for(lambda: host._pending_turns == 0)
    before = len(sessions.list_sessions())
    host._m_session_reset({})
    assert host.current_session_id is None and host.display_log == []
    assert len(sessions.list_sessions()) == before


def test_voice_source_is_reported_to_frontends(host):
    host._start_turn("what time is it", "voice")
    assert wait_for(lambda: "chat.turn_complete" in names(host))
    assert ("chat.user_message", {"text": "what time is it", "source": "voice"}) in host.events
    assert host.agent.calls[0] == ("what time is it", "voice")


def test_empty_message_rejected(host):
    with pytest.raises(ValueError):
        host._m_chat_send({"text": "   "})


def test_deleting_current_session_resets(host):
    host._m_chat_send({"text": "bye"})
    assert wait_for(lambda: host._pending_turns == 0)
    sid = host.current_session_id
    r = host._m_session_delete({"id": sid})
    assert r["was_current"] and host.current_session_id is None and host.agent.history == []


def test_speak_uses_tts_only_when_enabled(host, monkeypatch):
    # Replies now flow through voice_mode's PC Speaker (engine chain, barge-in),
    # but the gate is the same: only when voice mode or the setting is on.
    said = []
    monkeypatch.setattr(host.voice.pc_speaker, "say", lambda text, interrupt=False: said.append(text))
    host._on_speak("quiet")
    monkeypatch.setattr(config, "VOICE_OUTPUT_ENABLED", True)
    host._on_speak("loud")
    assert said == ["loud"]


@pytest.mark.parametrize("changes", [
    {"TTS_RATE": 5000}, {"MAX_STEPS_PER_TURN": 0}, {"PRIMARY_PROVIDER": "bogus"},
    {"STT_ENGINE": "magic"}, {"TEXT_MODEL_OVERRIDE": "nocolon"}, {"TTS_RATE": "fast"},
])
def test_invalid_settings_rejected_without_side_effects(host, changes):
    before = {k: getattr(config, k) for k in changes}
    with pytest.raises(ValueError):
        host._m_settings_update({"changes": changes})
    assert {k: getattr(config, k) for k in changes} == before


def test_mobile_start_reports_urls_even_if_not_enabled_at_launch(host, monkeypatch):
    from troy import remote
    state = {"on": False}
    monkeypatch.setattr(config, "MOBILE_UI_ENABLED", False)
    monkeypatch.setattr(mobile_server, "start", lambda port=None: state.update(on=True))
    monkeypatch.setattr(mobile_server, "stop", lambda: state.update(on=False))
    monkeypatch.setattr(mobile_server, "is_running", lambda: state["on"])
    monkeypatch.setattr(mobile_server, "current_port", lambda: 8765 if state["on"] else None)
    monkeypatch.setattr(mobile_server, "lan_ip", lambda: "192.168.1.5")
    monkeypatch.setattr(remote, "tailscale_status", lambda force=False: {"installed": False, "running": False, "ip": "", "dns_name": "", "serving": False, "tailnet": ""})
    assert host._m_mobile_ui_status({})["running"] is False and host._m_mobile_ui_status({})["url"] == ""
    started = host._m_mobile_ui_start({})
    assert started["url"].startswith("http://192.168.1.5:8765/?t=") and started["urls"][0]["kind"] == "lan"
    host._m_mobile_ui_stop({})
    assert config.MOBILE_UI_ENABLED is False
