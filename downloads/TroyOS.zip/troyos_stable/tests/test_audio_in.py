import numpy as np
import pytest

from troy import audio_in
from troy.audio_in import Endpointer, has_speech, resample, rms, wav_bytes, wav_to_pcm

R = 16000
rng = np.random.default_rng(1)


def noise(seconds, level=60):
    return (rng.standard_normal(int(R * seconds)) * level).astype(np.int16)


def speech(seconds, level=4000, f=180):
    t = np.arange(int(R * seconds)) / R
    env = 0.6 + 0.4 * np.sin(2 * np.pi * 4 * t)                  # syllable-like wobble
    return (np.sin(2 * np.pi * f * t) * level * env + rng.standard_normal(t.size) * 200).astype(np.int16)


def run(ep, audio, chunk=480):
    ev = []
    for i in range(0, audio.size, chunk):
        ev += ep.feed(audio[i:i + chunk])
    return ev


def kinds(events):
    return [e[0] for e in events if e[0] != "level"]


def test_one_utterance_in_a_quiet_room():
    ep = Endpointer()
    ev = run(ep, np.concatenate([noise(1.0), speech(1.5), noise(1.2)]))
    assert kinds(ev) == ["start", "end"]
    audio = next(e[1] for e in ev if e[0] == "end")
    assert 1.4 * R < audio.size < 2.3 * R                       # the speech plus a little pre/post roll, not the whole minute
    assert rms(audio) > 1500


def test_two_utterances_are_separated():
    ep = Endpointer()
    ev = run(ep, np.concatenate([noise(0.6), speech(1.0), noise(1.0), speech(1.0), noise(1.0)]))
    assert kinds(ev) == ["start", "end", "start", "end"]


def test_a_short_pause_inside_a_sentence_does_not_split_it():
    ep = Endpointer()
    ev = run(ep, np.concatenate([noise(0.5), speech(0.8), noise(0.35), speech(0.8), noise(1.0)]))
    assert kinds(ev) == ["start", "end"]


def test_clicks_and_blips_are_ignored():
    ep = Endpointer()
    blip = np.zeros(int(R * 0.06), dtype=np.int16); blip[:] = 9000
    ev = run(ep, np.concatenate([noise(0.8), blip, noise(1.0), blip, noise(0.8)]))
    assert "start" not in kinds(ev)


def test_it_adapts_to_a_noisy_room():
    ep = Endpointer()
    loud_room = lambda s: noise(s, level=700)                    # fan / street noise
    ev = run(ep, np.concatenate([loud_room(2.0), speech(1.2, level=9000), loud_room(1.2)]))
    assert kinds(ev) == ["start", "end"]
    assert ep.floor > 400


def test_listening_never_runs_forever():
    ep = Endpointer(max_seconds=3.0)
    ev = run(ep, np.concatenate([noise(0.5), speech(8.0), noise(0.5)]))
    ends = [e for e in ev if e[0] == "end"]
    assert ends and ends[0][1].size <= 3.2 * R


def test_raising_sensitivity_makes_it_ignore_quieter_speech():
    ep = Endpointer(); ep.sensitivity = 5.0                      # e.g. while Troy is speaking: only a clearly louder voice interrupts
    assert kinds(run(ep, np.concatenate([noise(1.0), speech(1.0, level=1200), noise(1.0)]))) == []
    ep = Endpointer(); ep.sensitivity = 5.0
    assert kinds(run(ep, np.concatenate([noise(1.0), speech(1.0, level=12000), noise(1.0)]))) == ["start", "end"]


def test_odd_chunk_sizes_and_bytes_input_work():
    ep = Endpointer()
    data = np.concatenate([noise(0.8), speech(1.0), noise(1.0)])
    ev = []
    for i in range(0, data.size, 333):
        ev += ep.feed(data[i:i + 333].tobytes())
    assert kinds(ev) == ["start", "end"]


def test_resample_and_wav_roundtrip():
    tone = speech(1.0)
    down = resample(tone, 48000 if False else R, 8000)
    assert abs(down.size - tone.size // 2) <= 1
    up = resample(tone[:16000], 16000, 48000)
    assert up.size == 48000
    pcm, rate = wav_to_pcm(wav_bytes(tone, R))
    assert rate == R and np.array_equal(pcm, tone)


def test_has_speech_rejects_silence_and_hiss():
    assert not has_speech(noise(2.0, level=40)) and not has_speech(np.zeros(R * 2, dtype=np.int16))
    assert not has_speech(noise(0.1))
    assert has_speech(np.concatenate([noise(0.5), speech(1.0), noise(0.5)]))
