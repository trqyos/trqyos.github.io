import base64
import hashlib
import json
import time
from urllib.parse import parse_qs, urlparse

import pytest

from troy import app_launcher, config, tools_all, youtube


class R:
    def __init__(self, payload, status=200):
        self._p, self.status_code, self.ok, self.text = payload, status, status < 400, json.dumps(payload)
    def json(self): return self._p


@pytest.fixture
def yt(tmp_path, monkeypatch):
    monkeypatch.setattr(config, "YOUTUBE_CLIENT_ID", "cid")
    monkeypatch.setattr(config, "YOUTUBE_CLIENT_SECRET", "secret")
    monkeypatch.setattr(config, "YOUTUBE_TOKEN_FILE", str(tmp_path / "tok.json"))
    monkeypatch.setattr(config, "YOUTUBE_BROWSER", "firefox")
    youtube._pending = None
    return youtube


def sign_in_state(yt, access="AT", expires_in=3600, refresh="RT"):
    yt._write_token({"access_token": access, "refresh_token": refresh, "expires_at": time.time() + expires_in})


# ----------------------------------------------------------------- OAuth
def test_auth_url_uses_pkce_offline_access_and_readonly_scope(yt):
    verifier, challenge = yt._pkce_pair()
    assert challenge == base64.urlsafe_b64encode(hashlib.sha256(verifier.encode()).digest()).rstrip(b"=").decode()
    q = parse_qs(urlparse(yt.build_auth_url("http://127.0.0.1:5555/callback", "st", challenge)).query)
    assert q["scope"] == [yt.SCOPE] and yt.SCOPE.endswith("youtube.readonly")
    assert q["code_challenge_method"] == ["S256"] and q["access_type"] == ["offline"] and q["state"] == ["st"]
    assert q["redirect_uri"] == ["http://127.0.0.1:5555/callback"]


def test_full_sign_in_flow(yt, monkeypatch):
    opened, events, posted = [], [], []
    monkeypatch.setattr(app_launcher, "launch_browser_url", lambda url, browser=None: opened.append((url, browser)) or {"success": True, "message": ""})
    monkeypatch.setattr(yt.requests, "post", lambda url, data=None, **k: posted.append(data) or R({"access_token": "AT", "refresh_token": "RT", "expires_in": 3600, "scope": yt.SCOPE}))
    monkeypatch.setattr(yt.requests, "get", lambda url, **k: R({"items": [{"id": "UC1", "snippet": {"title": "Alex", "thumbnails": {}}, "contentDetails": {"relatedPlaylists": {"likes": "LL"}}}]}))
    yt.on_event(lambda e, d: events.append((e, d)))
    info = yt.begin_auth()
    try:
        assert opened[0][1] == "firefox" and info["auth_url"].startswith(yt.AUTH_URL)
        state = parse_qs(urlparse(info["auth_url"]).query)["state"][0]
        assert yt.handle_callback({"code": "abc", "state": "WRONG"})[0] is False          # CSRF check
        ok, _ = yt.handle_callback({"code": "abc", "state": state})
        assert ok and yt.connected()
        assert posted[0]["grant_type"] == "authorization_code" and posted[0]["code"] == "abc" and posted[0]["code_verifier"]
        assert posted[0]["redirect_uri"] == f"http://127.0.0.1:{info['port']}/callback"
        assert ("youtube.connected", {"channel": {"id": "UC1", "title": "Alex", "thumbnail": "", "playlists": {"likes": "LL"}}}) in events
        assert not yt.signing_in()
    finally:
        yt.cancel_auth()


def test_pasted_redirect_url_completes_sign_in(yt, monkeypatch):
    monkeypatch.setattr(app_launcher, "launch_browser_url", lambda *a, **k: {"success": True, "message": ""})
    monkeypatch.setattr(yt.requests, "post", lambda *a, **k: R({"access_token": "AT", "refresh_token": "RT", "expires_in": 3600}))
    monkeypatch.setattr(yt.requests, "get", lambda *a, **k: R({"items": []}))
    info = yt.begin_auth()
    state = parse_qs(urlparse(info["auth_url"]).query)["state"][0]
    ok, _ = yt.complete_from_url(f"http://127.0.0.1:{info['port']}/callback?state={state}&code=xyz&scope=s")
    assert ok and yt.connected()


def test_denied_consent_reports_cleanly(yt, monkeypatch):
    monkeypatch.setattr(app_launcher, "launch_browser_url", lambda *a, **k: {"success": True, "message": ""})
    events = []
    yt.on_event(lambda e, d: events.append(e))
    info = yt.begin_auth()
    state = parse_qs(urlparse(info["auth_url"]).query)["state"][0]
    ok, msg = yt.handle_callback({"error": "access_denied", "state": state})
    assert not ok and "cancelled" in msg and "youtube.error" in events and not yt.connected()


def test_begin_auth_needs_credentials(yt, monkeypatch):
    monkeypatch.setattr(config, "YOUTUBE_CLIENT_SECRET", "")
    with pytest.raises(yt.YouTubeError):
        yt.begin_auth()


def test_expired_token_is_refreshed_and_saved(yt, monkeypatch):
    sign_in_state(yt, access="OLD", expires_in=-10)
    seen = []
    monkeypatch.setattr(yt.requests, "post", lambda url, data=None, **k: seen.append(data) or R({"access_token": "NEW", "expires_in": 3600}))
    assert yt.access_token() == "NEW"
    assert seen[0]["grant_type"] == "refresh_token" and seen[0]["refresh_token"] == "RT"
    assert yt._read_token()["refresh_token"] == "RT"            # kept, Google doesn't resend it
    assert yt.access_token() == "NEW" and len(seen) == 1         # now fresh: no second refresh


def test_not_connected_message_points_to_settings(yt):
    with pytest.raises(yt.YouTubeError, match="Settings"):
        yt.access_token()


def test_disconnect_revokes_and_deletes(yt, monkeypatch):
    sign_in_state(yt)
    calls = []
    monkeypatch.setattr(yt.requests, "post", lambda url, **k: calls.append(url) or R({}))
    yt.disconnect()
    assert calls == [yt.REVOKE_URL] and not yt.connected()


# --------------------------------------------------------------- the use case
def playlist_page(items, next_token=None):
    return {"items": [{"snippet": {"title": t, "videoOwnerChannelTitle": "Chan", "publishedAt": added, "resourceId": {"videoId": vid}}} for vid, t, added in items],
            **({"nextPageToken": next_token} if next_token else {})}


def fake_api(monkeypatch, yt, routes):
    sign_in_state(yt)
    calls = []
    def get(url, params=None, headers=None, **k):
        path = url.split("/v3/")[1]
        calls.append((path, dict(params or {})))
        assert headers["Authorization"] == "Bearer AT"
        return R(routes[path](params)) if callable(routes[path]) else R(routes[path])
    monkeypatch.setattr(yt.requests, "get", get)
    return calls


def test_open_latest_liked_video_end_to_end(yt, monkeypatch):
    calls = fake_api(monkeypatch, yt, {"playlistItems": playlist_page([("AAAAAAAAAAA", "Newest like", "2026-09-30T10:00:00Z"), ("BBBBBBBBBBB", "Older", "2026-09-01T10:00:00Z")])})
    opened = []
    monkeypatch.setattr(app_launcher, "launch_browser_url", lambda url, browser=None: opened.append((url, browser)) or {"success": True, "message": f"Opened {url} in a new firefox tab."})
    r = tools_all.youtube_open_latest("")
    assert r["success"] and opened == [("https://www.youtube.com/watch?v=AAAAAAAAAAA", "firefox")]
    assert "Newest like" in r["message"]
    assert calls[0][1]["playlistId"] == "LL"


def test_latest_in_a_normal_playlist_is_by_date_added_not_position(yt, monkeypatch):
    pages = {None: playlist_page([("AAAAAAAAAAA", "first by position, added long ago", "2025-01-01T00:00:00Z")], "p2"),
             "p2": playlist_page([("BBBBBBBBBBB", "middle", "2026-02-01T00:00:00Z"), ("CCCCCCCCCCC", "added last", "2026-09-29T00:00:00Z")])}
    fake_api(monkeypatch, yt, {
        "playlists": {"items": [{"id": "PLxyz123456789", "snippet": {"title": "Music Mix"}, "contentDetails": {"itemCount": 3}}]},
        "playlistItems": lambda p: pages[p.get("pageToken")],
    })
    v = yt.latest_in_playlist("music mix")
    assert v["video_id"] == "CCCCCCCCCCC" and v["playlist"] == "Music Mix"


def test_private_and_deleted_videos_are_skipped(yt, monkeypatch):
    fake_api(monkeypatch, yt, {"playlistItems": playlist_page([("XXXXXXXXXXX", "Private video", "2026-10-01T00:00:00Z"), ("BBBBBBBBBBB", "Real", "2026-09-01T00:00:00Z")])})
    assert [v["title"] for v in yt.liked_videos(5)] == ["Real"]


def test_playlist_names_resolve_fuzzily_and_helpfully(yt, monkeypatch):
    fake_api(monkeypatch, yt, {"playlists": {"items": [
        {"id": "PL1", "snippet": {"title": "Workout Playlist"}, "contentDetails": {}},
        {"id": "PL2", "snippet": {"title": "Chill Beats"}, "contentDetails": {}}]}})
    assert yt.resolve_playlist("workout")[0] == "PL1"
    assert yt.resolve_playlist("chil beats")[0] == "PL2"                 # typo
    assert yt.resolve_playlist("Liked Videos")[0] == "LL"
    with pytest.raises(yt.YouTubeError, match="Your playlists: Workout Playlist, Chill Beats"):
        yt.resolve_playlist("nonexistent thing")
    with pytest.raises(yt.YouTubeError, match="Watch Later"):
        yt.resolve_playlist("watch later")


def test_api_errors_become_readable_messages(yt, monkeypatch):
    sign_in_state(yt)
    def err(reason, status=403, message=""):
        monkeypatch.setattr(yt.requests, "get", lambda *a, **k: R({"error": {"message": message, "errors": [{"reason": reason}]}}, status))
    err("quotaExceeded")
    assert "quota" in tools_all.youtube_liked("")["message"]
    err("accessNotConfigured")
    assert "isn't enabled" in tools_all.youtube_liked("")["message"]


def test_tools_say_what_to_do_when_not_connected(yt):
    r = tools_all.youtube_open_latest("")
    assert not r["success"] and "Settings > Integrations" in r["message"]


def test_search_open_and_video_parsing(yt, monkeypatch):
    fake_api(monkeypatch, yt, {"search": {"items": [{"id": {"videoId": "ZZZZZZZZZZZ"}, "snippet": {"title": "Lo-fi mix", "channelTitle": "Radio"}}]}})
    opened = []
    monkeypatch.setattr(app_launcher, "launch_browser_url", lambda url, browser=None: opened.append(url) or {"success": True, "message": "ok"})
    assert tools_all.youtube_open_video("lofi beats")["success"] and opened == ["https://www.youtube.com/watch?v=ZZZZZZZZZZZ"]
    opened.clear()
    tools_all.youtube_open_video("https://youtu.be/dQw4w9WgXcQ?t=3")
    assert opened == ["https://www.youtube.com/watch?v=dQw4w9WgXcQ"]
    assert yt.parse_video_id("dQw4w9WgXcQ") == "dQw4w9WgXcQ" and yt.parse_video_id("not a video") is None


def test_youtube_tools_are_registered_in_their_own_category():
    names = {n for n, t in tools_all.all_tools().items() if t.category == "youtube"}
    assert {"youtube_open_latest", "youtube_liked", "youtube_search", "youtube_status"} <= names
