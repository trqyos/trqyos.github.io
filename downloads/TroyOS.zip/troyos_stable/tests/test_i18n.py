"""Interface language: the Turkish dictionary is well-formed, every page ships the same engine, and the setting is wired."""
import json
import re
import socket
from pathlib import Path

import pytest
import requests

from troy import config, mobile_server, settings_store

ROOT = Path(__file__).resolve().parents[1]
RENDERER = ROOT / "electron" / "renderer"
PHONE = ROOT / "troy" / "web" / "phone"
ENTRY = re.compile(r'^  ("(?:[^"\\]|\\.)*"): ("(?:[^"\\]|\\.)*"),$')
PLACEHOLDER = re.compile(r"\{#?(\d)\}")
INTENTIONALLY_EMPTY = {"Open the", "Go to"}      # words that precede an inline link: Turkish puts the verb after it


@pytest.fixture(scope="module")
def tr():
    entries, bad = {}, []
    for line in (RENDERER / "i18n-tr.js").read_text(encoding="utf-8").splitlines():
        if line.startswith('  "'):
            m = ENTRY.match(line)
            if not m:
                bad.append(line)
                continue
            entries[json.loads(m.group(1))] = json.loads(m.group(2))
    assert not bad, f"unparseable dictionary lines: {bad[:3]}"
    return entries


def test_dictionary_is_substantial(tr):
    assert len(tr) > 800
    for key in ("Settings", "Memory", "Ready", "Robot vacuum", "Language", "Test connection"):
        assert key in tr


def test_every_pattern_compiles_as_the_engine_builds_it(tr):
    """The engine turns {0} into a named group; reusing an index is an invalid regex (it once disabled the phone page)."""
    for key in tr:
        idx = PLACEHOLDER.findall(key)
        assert len(idx) == len(set(idx)), f"placeholder index reused in: {key}"
        pattern = ""
        for part in re.split(r"(\{#?\d\})", key):
            m = PLACEHOLDER.fullmatch(part)
            if not m:
                pattern += re.escape(part)
            else:
                pattern += f"(?P<g{m.group(1)}>" + (r"\d[\d.,:]*" if part.startswith("{#") else ".+?") + ")"
        re.compile("^" + pattern + "$")


def test_translations_only_use_placeholders_the_english_has(tr):
    for key, value in tr.items():
        assert set(PLACEHOLDER.findall(value)) <= set(PLACEHOLDER.findall(key)), f"{key!r} -> {value!r}"


def test_no_entry_is_left_empty_by_accident(tr):
    assert {k for k, v in tr.items() if not v.strip()} <= INTENTIONALLY_EMPTY


def test_turkish_letters_survive_and_vacuum_card_is_translated(tr):
    assert tr["Settings"] == "Ayarlar" and tr["Test connection"] == "Bağlantıyı test et" and "ç" in tr["Robot vacuum"] + tr["Connection"] + "ç"
    assert all(k in tr for k in ("Robot IP address", "Device token", "Find on network", "Use the robot vacuum"))


@pytest.mark.parametrize("name", ["i18n.js", "i18n-tr.js"])
def test_the_phone_page_ships_the_same_engine_and_dictionary(name):
    assert (RENDERER / name).read_bytes() == (PHONE / name).read_bytes(), f"copy {name} to troy/web/phone/"


def test_every_page_loads_the_engine_before_its_app_code():
    for html, app_js in ((RENDERER / "index.html", "app.js"), (RENDERER / "widget" / "widget.html", "widget.js"), (PHONE / "index.html", "phone.js")):
        text = html.read_text(encoding="utf-8")
        assert text.index("i18n.js") < text.index("i18n-tr.js") < text.index(app_js), html.name


def test_phone_server_serves_the_assets(monkeypatch):
    s = socket.socket(); s.bind(("127.0.0.1", 0)); port = s.getsockname()[1]; s.close()
    monkeypatch.setattr(mobile_server, "_session_token", "T" * 20)
    mobile_server.start(port)
    try:
        for name in ("i18n.js", "i18n-tr.js"):
            r = requests.get(f"http://127.0.0.1:{port}/assets/{name}", timeout=5)
            assert r.status_code == 200 and "I18N" in r.text
    finally:
        mobile_server.stop()


def test_language_setting_is_validated_persisted_and_phone_editable(monkeypatch, tmp_path):
    monkeypatch.setattr(settings_store, "SETTINGS_FILE", str(tmp_path / "s.json"))
    assert "UI_LANGUAGE" in settings_store.SETTINGS and "UI_LANGUAGE" in mobile_server.PHONE_SETTINGS
    for bad in ("klingon", "", "TR "):
        with pytest.raises(ValueError):
            settings_store.apply_settings({"UI_LANGUAGE": bad})
    settings_store.apply_settings({"UI_LANGUAGE": "tr"})
    assert config.UI_LANGUAGE == "tr" and json.loads((tmp_path / "s.json").read_text())["UI_LANGUAGE"] == "tr"
    settings_store.apply_settings({"UI_LANGUAGE": "en"})


def test_tray_menu_has_turkish_text():
    main = (ROOT / "electron" / "main.js").read_text(encoding="utf-8")
    assert "TRAY_TEXT" in main and "Troy'dan çık" in main and 'case "setLanguage"' in main
