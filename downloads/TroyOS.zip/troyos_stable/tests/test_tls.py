"""troy/tls.py -- the self-signed certificate that puts the phone page on
https so the phone's microphone is allowed (getUserMedia needs a secure
context), and the https server in troy/mobile_server.py that serves it.

The certificate functions run against the real `cryptography` package; the
https server test hits it with `verify=False` because -- being self-signed --
it is *supposed* to fail normal verification. That's the documented one-tap
"proceed anyway" trade-off.
"""
import ipaddress
import ssl
import socket
import time

import pytest
import requests

from troy import config, mobile_server, tls


@pytest.fixture
def pair_paths(tmp_path, monkeypatch):
    """Cert/key in a temp dir, never the real project root."""
    cert, key = tmp_path / "cert.pem", tmp_path / "key.pem"
    monkeypatch.setattr(tls, "CERT_FILE", str(cert))
    monkeypatch.setattr(tls, "KEY_FILE", str(key))
    return str(cert), str(key)


def test_san_list_covers_all_the_ways_in():
    from cryptography import x509
    sans = tls._subject_alt_names("192.168.1.42")
    assert x509.DNSName("localhost") in sans
    assert x509.IPAddress(ipaddress.ip_address("192.168.1.42")) in sans
    assert x509.IPAddress(ipaddress.ip_address("127.0.0.1")) in sans
    assert any(type(g) is x509.DNSName and g.value != "localhost" for g in sans)   # the hostname


def test_san_list_survives_a_missing_lan_ip():
    sans = tls._subject_alt_names("")
    assert all("192" not in str(g) for g in sans)          # no IP -> just the DNS names + loopback


def test_generate_makes_a_usable_pair(pair_paths):
    cert_path, key_path = pair_paths
    tls.generate(cert_path, key_path, "10.1.2.3")
    from cryptography import x509
    cert = x509.load_pem_x509_certificate(open(cert_path, "rb").read())
    san = cert.extensions.get_extension_for_class(x509.SubjectAlternativeName).value
    assert ipaddress.ip_address("10.1.2.3") in san.get_values_for_type(x509.IPAddress)
    assert "localhost" in san.get_values_for_type(x509.DNSName)
    assert cert.subject == cert.issuer                                        # self-signed
    assert cert.not_valid_after_utc.year >= 2035                              # YEARS = 10
    key = open(key_path, "rb").read()
    assert b"PRIVATE KEY" in key


def test_generate_locks_the_key_down(pair_paths):
    cert_path, key_path = pair_paths
    tls.generate(cert_path, key_path, "10.1.2.3")
    assert oct(os_stat_mode(key_path) & 0o777) == oct(0o600)


def os_stat_mode(path):
    import os
    return os.stat(path).st_mode


def test_ensure_pair_generates_once_then_reuses(pair_paths):
    cert_path, key_path = pair_paths
    assert tls.ensure_pair("192.0.2.7") == (cert_path, key_path)
    first = open(cert_path, "rb").read()
    import os
    mtime = os.path.getmtime(cert_path)
    tls.ensure_pair("192.0.2.8")                # different IP, same files: no regen
    assert open(cert_path, "rb").read() == first
    assert os.path.getmtime(cert_path) == mtime


def test_ensure_pair_degrades_to_none_when_cryptography_is_missing(pair_paths, monkeypatch):
    def no_crypto(cert_path, key_path, lan_ip):
        raise ImportError("no cryptography")
    monkeypatch.setattr(tls, "generate", no_crypto)
    assert tls.ensure_pair("1.2.3.4") == (None, None)


def test_ensure_pair_degrades_to_none_on_failure(pair_paths, monkeypatch):
    def boom(cert_path, key_path, lan_ip):
        raise OSError("disk full")
    monkeypatch.setattr(tls, "generate", boom)
    assert tls.ensure_pair("1.2.3.4") == (None, None)


def test_ssl_context_loads_the_pair(pair_paths):
    assert isinstance(tls.ssl_context("192.0.2.1"), ssl.SSLContext)


def test_ssl_context_none_when_unavailable(pair_paths, monkeypatch):
    monkeypatch.setattr(tls, "ensure_pair", lambda lan_ip=None: (None, None))
    assert tls.ssl_context() is None


# ----------------------------------------------------- the https server
@pytest.fixture
def https_server(pair_paths, monkeypatch):
    s = socket.socket(); s.bind(("127.0.0.1", 0)); port = s.getsockname()[1]; s.close()
    monkeypatch.setattr(config, "MOBILE_UI_ENABLED", True)
    monkeypatch.setattr(config, "MOBILE_HTTPS_ENABLED", True)
    monkeypatch.setattr(mobile_server, "_session_token", "T" * 20)
    mobile_server.configure(mobile_server.Bridge(
        enqueue_turn=lambda t: None, get_display_log=lambda: [], get_status=lambda: {},
        stop_turn=lambda: None, list_confirmations=lambda: [], resolve_confirmation=lambda i, ok: None,
        on_viewers=lambda n: None, get_info=lambda: {}))
    mobile_server.start(port)
    yield port
    mobile_server.stop()


def test_https_serves_the_same_phone_page_on_port_plus_one(https_server):
    port = https_server
    assert mobile_server.https_running() and mobile_server.https_port() == port + 1
    assert mobile_server.https_url().startswith(f"https://") and f":{port + 1}/" in mobile_server.https_url()
    r = requests.get(f"https://127.0.0.1:{port + 1}/", verify=False, timeout=5)
    assert r.status_code == 200 and "<canvas id=\"face\"" in r.text
    st = requests.get(f"https://127.0.0.1:{port + 1}/api/state?t=" + "T" * 20, verify=False, timeout=5).json()
    assert st["voice"]["https"] == mobile_server.https_url()


def test_https_needs_the_setting_on(monkeypatch, https_server):
    port = https_server                                    # already running from the fixture
    mobile_server.stop()
    monkeypatch.setattr(config, "MOBILE_HTTPS_ENABLED", False)
    s = socket.socket(); s.bind(("127.0.0.1", 0)); p2 = s.getsockname()[1]; s.close()
    mobile_server.start(p2)
    try:
        assert mobile_server.https_running() is False and mobile_server.https_url() == ""
        assert mobile_server.https_port() == p2 + 1         # the slot is still reserved, just not served
    finally:
        mobile_server.stop()
