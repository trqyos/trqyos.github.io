"""
uiautomation is a Windows-only COM wrapper and cannot run on Linux at
all, so these tests fake the module entirely -- same approach as
test_browser_worker.py faking playwright. This verifies troy/ui_automation.py's
own logic (tree walking, depth/count caps, name matching, fallback from
ValuePattern to click+SendKeys, error handling) is correct; it cannot
verify real Windows UIA semantics, which can only be confirmed on an
actual Windows machine.
"""

import sys
import types

import pytest


class _Rect:
    def __init__(self, left=0, top=0, width=100, height=50):
        self.left, self.top, self.width, self.height = left, top, width, height


class _ValuePattern:
    def __init__(self, control):
        self.control = control

    def SetValue(self, text):
        self.control._value = text


class FakeControl:
    def __init__(self, name="", control_type="Pane", automation_id="", enabled=True,
                 children=None, supports_value=False, raises_on_name=False):
        self.Name = name
        self.ControlTypeName = control_type
        self.AutomationId = automation_id
        self.IsEnabled = enabled
        self.ClassName = "FakeClass"
        self.BoundingRectangle = _Rect()
        self._children = children or []
        self._supports_value = supports_value
        self._value = ""
        self.clicked = False
        self.keys_sent = None
        self._raises_on_name = raises_on_name

    def GetChildren(self):
        return self._children

    def Click(self):
        self.clicked = True

    def SendKeys(self, text):
        self.keys_sent = text

    def GetValuePattern(self):
        return _ValuePattern(self) if self._supports_value else None


@pytest.fixture
def fake_uia(monkeypatch):
    module = types.ModuleType("uiautomation")
    module.FakeControl = FakeControl  # exposed for convenience, not real API

    module._foreground_hwnd = 111
    module._foreground_control = FakeControl(name="Untitled - Notepad", control_type="Window")
    module._desktop_children = []

    module.GetForegroundWindow = lambda: module._foreground_hwnd
    module.ControlFromHandle = lambda hwnd: module._foreground_control if hwnd == module._foreground_hwnd else None

    class _Desktop:
        def GetChildren(self):
            return module._desktop_children

    module.GetRootControl = lambda: _Desktop()

    monkeypatch.setitem(sys.modules, "uiautomation", module)
    return module


class TestInspectWindow:
    def test_foreground_window_with_no_children(self, fake_uia):
        from troy import ui_automation as ui
        result = ui.inspect_window("")
        assert result["success"] is True
        assert "Untitled - Notepad" in result["message"]

    def test_named_controls_are_listed(self, fake_uia):
        from troy import ui_automation as ui
        save_btn = FakeControl(name="Save", control_type="Button", automation_id="btnSave")
        window = FakeControl(name="Save As", control_type="Window", children=[save_btn])
        fake_uia._foreground_control = window

        result = ui.inspect_window("")
        assert 'Button: "Save"' in result["message"]
        assert "[id=btnSave]" in result["message"]

    def test_unnamed_structural_containers_are_skipped_but_children_still_walked(self, fake_uia):
        from troy import ui_automation as ui
        ok_btn = FakeControl(name="OK", control_type="Button")
        unnamed_pane = FakeControl(name="", control_type="Pane", children=[ok_btn])
        window = FakeControl(name="Dialog", control_type="Window", children=[unnamed_pane])
        fake_uia._foreground_control = window

        result = ui.inspect_window("")
        assert "Pane:" not in result["message"]
        assert 'Button: "OK"' in result["message"]

    def test_disabled_controls_are_marked(self, fake_uia):
        from troy import ui_automation as ui
        disabled_btn = FakeControl(name="Submit", control_type="Button", enabled=False)
        window = FakeControl(name="Form", control_type="Window", children=[disabled_btn])
        fake_uia._foreground_control = window

        result = ui.inspect_window("")
        assert "(disabled)" in result["message"]

    def test_window_search_by_title_substring(self, fake_uia):
        from troy import ui_automation as ui
        chrome = FakeControl(name="Google Chrome", control_type="Window")
        notepad = FakeControl(name="Untitled - Notepad", control_type="Window")
        fake_uia._desktop_children = [chrome, notepad]

        result = ui.inspect_window("chrome")
        assert result["success"] is True
        assert "Google Chrome" in result["message"]

    def test_no_matching_window_fails_cleanly(self, fake_uia):
        from troy import ui_automation as ui
        result = ui.inspect_window("Definitely Not Open")
        assert result["success"] is False

    def test_window_with_no_readable_controls_gets_a_helpful_message(self, fake_uia):
        from troy import ui_automation as ui
        window = FakeControl(name="Game Canvas", control_type="Pane", children=[])
        fake_uia._foreground_control = window
        result = ui.inspect_window("")
        assert result["success"] is True
        assert "canvas" in result["message"].lower() or "no readable controls" in result["message"].lower()

    def test_no_foreground_window_at_all(self, fake_uia):
        from troy import ui_automation as ui
        fake_uia.GetForegroundWindow = lambda: None
        result = ui.inspect_window("")
        assert result["success"] is False

    def test_missing_package_fails_cleanly(self, monkeypatch):
        import builtins
        real_import = builtins.__import__
        def _fake_import(name, *a, **k):
            if name == "uiautomation":
                raise ImportError("no module")
            return real_import(name, *a, **k)
        monkeypatch.setattr(builtins, "__import__", _fake_import)

        from troy import ui_automation as ui
        result = ui.inspect_window("")
        assert result["success"] is False
        assert "uiautomation" in result["message"]

    def test_depth_and_count_caps_prevent_runaway_trees(self, fake_uia):
        from troy import ui_automation as ui
        # build a deeply nested chain far beyond MAX_DEPTH
        leaf = FakeControl(name="Leaf", control_type="Text")
        current = leaf
        for i in range(ui.MAX_DEPTH + 10):
            current = FakeControl(name=f"Level{i}", control_type="Group", children=[current])
        fake_uia._foreground_control = current

        result = ui.inspect_window("")
        # must not hang or raise -- and must not include the deepest leaf
        assert result["success"] is True
        assert "Leaf" not in result["message"]

    def test_a_property_that_raises_does_not_break_the_whole_inspection(self, fake_uia):
        from troy import ui_automation as ui

        class FlakyControl(FakeControl):
            @property
            def Name(self):
                raise RuntimeError("COM element vanished")

            @Name.setter
            def Name(self, value):
                pass

        flaky = FlakyControl(name="irrelevant", control_type="Button")
        good = FakeControl(name="Good Button", control_type="Button")
        window = FakeControl(name="Window", control_type="Window", children=[flaky, good])
        fake_uia._foreground_control = window

        result = ui.inspect_window("")
        assert result["success"] is True
        assert "Good Button" in result["message"]


class TestClickElement:
    def test_click_by_exact_name(self, fake_uia):
        from troy import ui_automation as ui
        save_btn = FakeControl(name="Save", control_type="Button")
        window = FakeControl(name="Dialog", control_type="Window", children=[save_btn])
        fake_uia._foreground_control = window

        result = ui.click_element("Save")
        assert result["success"] is True
        assert save_btn.clicked is True

    def test_click_by_automation_id(self, fake_uia):
        from troy import ui_automation as ui
        btn = FakeControl(name="", control_type="Button", automation_id="btnOK")
        window = FakeControl(name="Dialog", control_type="Window", children=[btn])
        fake_uia._foreground_control = window

        result = ui.click_element("btnOK")
        assert result["success"] is True
        assert btn.clicked is True

    def test_click_nested_element(self, fake_uia):
        from troy import ui_automation as ui
        ok_btn = FakeControl(name="OK", control_type="Button")
        pane = FakeControl(name="", control_type="Pane", children=[ok_btn])
        window = FakeControl(name="Dialog", control_type="Window", children=[pane])
        fake_uia._foreground_control = window

        result = ui.click_element("OK")
        assert result["success"] is True
        assert ok_btn.clicked is True

    def test_click_missing_element_query_fails_cleanly(self, fake_uia):
        from troy import ui_automation as ui
        result = ui.click_element("")
        assert result["success"] is False

    def test_click_element_not_found(self, fake_uia):
        from troy import ui_automation as ui
        window = FakeControl(name="Dialog", control_type="Window", children=[])
        fake_uia._foreground_control = window
        result = ui.click_element("Nonexistent")
        assert result["success"] is False

    def test_click_targets_a_specific_window_by_title(self, fake_uia):
        from troy import ui_automation as ui
        btn_a = FakeControl(name="Save", control_type="Button")
        window_a = FakeControl(name="App A", control_type="Window", children=[btn_a])
        btn_b = FakeControl(name="Save", control_type="Button")
        window_b = FakeControl(name="App B", control_type="Window", children=[btn_b])
        fake_uia._desktop_children = [window_a, window_b]

        result = ui.click_element("Save|App B")
        assert result["success"] is True
        assert btn_b.clicked is True
        assert btn_a.clicked is False

    def test_click_that_raises_is_reported_not_crashed(self, fake_uia):
        from troy import ui_automation as ui
        btn = FakeControl(name="Broken", control_type="Button")
        def _boom():
            raise RuntimeError("element detached")
        btn.Click = _boom
        window = FakeControl(name="Dialog", control_type="Window", children=[btn])
        fake_uia._foreground_control = window

        result = ui.click_element("Broken")
        assert result["success"] is False
        assert "element detached" in result["message"]


class TestTypeIntoElement:
    def test_uses_value_pattern_when_available(self, fake_uia):
        from troy import ui_automation as ui
        field = FakeControl(name="filename", control_type="Edit", supports_value=True)
        window = FakeControl(name="Save As", control_type="Window", children=[field])
        fake_uia._foreground_control = window

        result = ui.type_into_element("filename|report.txt")
        assert result["success"] is True
        assert field._value == "report.txt"
        assert field.keys_sent is None  # value pattern used, not simulated keystrokes

    def test_falls_back_to_click_and_sendkeys_without_value_pattern(self, fake_uia):
        from troy import ui_automation as ui
        field = FakeControl(name="search", control_type="Edit", supports_value=False)
        window = FakeControl(name="App", control_type="Window", children=[field])
        fake_uia._foreground_control = window

        result = ui.type_into_element("search|hello world")
        assert result["success"] is True
        assert field.clicked is True
        assert field.keys_sent == "hello world"

    def test_missing_pipe_separator_fails_cleanly(self, fake_uia):
        from troy import ui_automation as ui
        result = ui.type_into_element("just_a_field_name_no_text")
        assert result["success"] is False

    def test_element_not_found(self, fake_uia):
        from troy import ui_automation as ui
        window = FakeControl(name="App", control_type="Window", children=[])
        fake_uia._foreground_control = window
        result = ui.type_into_element("nosuchfield|text")
        assert result["success"] is False

    def test_optional_window_targeting(self, fake_uia):
        from troy import ui_automation as ui
        field_a = FakeControl(name="username", control_type="Edit", supports_value=True)
        window_a = FakeControl(name="Login A", control_type="Window", children=[field_a])
        field_b = FakeControl(name="username", control_type="Edit", supports_value=True)
        window_b = FakeControl(name="Login B", control_type="Window", children=[field_b])
        fake_uia._desktop_children = [window_a, window_b]

        result = ui.type_into_element("username|bob|Login B")
        assert result["success"] is True
        assert field_b._value == "bob"
        assert field_a._value == ""


class TestGetForegroundWindowInfo:
    def test_returns_name_class_and_bounds(self, fake_uia):
        from troy import ui_automation as ui
        fake_uia._foreground_control = FakeControl(name="Calculator", control_type="Window")
        result = ui.get_foreground_window_info("")
        assert result["success"] is True
        assert "Calculator" in result["message"]
        assert "FakeClass" in result["message"]

    def test_no_focused_window(self, fake_uia):
        from troy import ui_automation as ui
        fake_uia.GetForegroundWindow = lambda: None
        result = ui.get_foreground_window_info("")
        assert result["success"] is True
        assert "No window" in result["message"]
