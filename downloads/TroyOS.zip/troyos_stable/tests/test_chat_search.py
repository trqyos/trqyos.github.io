import pytest

from troy import sessions, tools_all


@pytest.fixture
def chats(isolated_storage):
    def make(title, log):
        sid = sessions.create_session(title)
        sessions.save_session(sid, title, [], log)
        return sid
    a = make("Trip planning", [{"role": "user", "text": "Find flights to Lisbon in March"}, {"role": "assistant", "text": "I found three options."},
                               {"role": "tool", "name": "web_open", "arg": "kayak.com", "success": True, "message": "Opened Kayak"}])
    b = make("Cooking", [{"role": "user", "text": "Recipe for a caf\u00e9 au lait"}, {"role": "assistant", "text": "Warm the milk, brew strong coffee. Lisbon style is nice."}])
    c = make("Lisbon notes", [{"role": "user", "text": "hello"}])
    return a, b, c


def test_title_matches_rank_first_then_message_hits(chats):
    a, b, c = chats
    r = sessions.search_sessions("lisbon")
    ids = [x["id"] for x in r["results"]]
    assert ids[0] == c and set(ids) == {a, b, c} and r["total_chats"] == 3
    assert r["results"][0]["title_match"] and r["results"][0]["hits"] == []


def test_message_hits_carry_index_snippet_and_position(chats):
    a, *_ = chats
    hit = next(x for x in sessions.search_sessions("flights")["results"] if x["id"] == a)["hits"][0]
    assert hit["index"] == 0 and hit["role"] == "user" and "flights" in hit["snippet"].lower()
    assert hit["snippet"][hit["start"]:hit["start"] + hit["length"]].lower() == "flights"


def test_search_ignores_case_and_accents_and_needs_every_word(chats):
    assert len(sessions.search_sessions("CAFE")["results"]) == 1
    assert len(sessions.search_sessions("milk coffee")["results"]) == 1
    assert sessions.search_sessions("milk flights")["results"] == []
    assert sessions.search_sessions("   ")["results"] == []


def test_tool_messages_are_searchable_too(chats):
    r = sessions.search_sessions("kayak")["results"]
    assert len(r) == 1 and r[0]["hits"][0]["role"] == "tool"


def test_cache_follows_edits(chats):
    a, *_ = chats
    assert sessions.search_sessions("brandnewword")["results"] == []
    sessions.save_session(a, "Trip planning", [], [{"role": "user", "text": "brandnewword here"}])
    assert len(sessions.search_sessions("brandnewword")["results"]) == 1


def test_llm_tool_summarises_matches(chats):
    r = tools_all.search_chats("lisbon")
    assert r["success"] and "3 chat(s) match" in r["message"] and "Trip planning" in r["message"]
    assert not tools_all.search_chats("zzzzqqq")["success"]
