from troy import config, llm_client


def test_nvidia_is_in_provider_chain(monkeypatch):
    monkeypatch.setattr(config, "NVIDIA_API_KEY", "nv-key")
    monkeypatch.setattr(config, "PRIMARY_PROVIDER", "nvidia")
    order = llm_client._provider_order()
    assert order[0][0] == "nvidia"
    assert order[0][1] == "https://integrate.api.nvidia.com/v1"
    assert "z-ai/glm-5.3" in llm_client._models_for("nvidia", "text")
    assert "moonshotai/kimi-k3" in llm_client._models_for("nvidia", "vision")


def test_nvidia_override_moves_model_first():
    chain = [("nvidia", "u", "k", ["a", "b"])]
    assert llm_client._apply_override(chain, "nvidia:b")[0][3] == ["b", "a"]
