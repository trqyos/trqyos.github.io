import sys
import types

import numpy as np
import pytest

from troy import voice


class TestTranscribeDispatch:
    def test_too_short_audio_returns_empty_without_calling_any_engine(self, monkeypatch):
        called = []
        monkeypatch.setattr(voice, "_transcribe_google", lambda a, s: called.append("google") or "should not happen")
        monkeypatch.setattr(voice, "_transcribe_whisper", lambda a, s: called.append("whisper") or "should not happen")
        tiny = np.zeros(10, dtype=np.int16)
        assert voice.transcribe(tiny, 16000) == ""
        assert called == []

    def test_none_audio_returns_empty(self):
        assert voice.transcribe(None, 16000) == ""

    def test_google_is_the_default_engine(self, monkeypatch):
        from troy import config
        monkeypatch.setattr(config, "STT_ENGINE", "google")
        monkeypatch.setattr(voice, "_transcribe_google", lambda a, s: "from google")
        monkeypatch.setattr(voice, "_transcribe_whisper", lambda a, s: "from whisper")
        audio = np.zeros(16000, dtype=np.int16)
        assert voice.transcribe(audio, 16000) == "from google"

    def test_whisper_engine_selected_explicitly(self, monkeypatch):
        from troy import config
        monkeypatch.setattr(config, "STT_ENGINE", "whisper")
        monkeypatch.setattr(voice, "_transcribe_google", lambda a, s: "from google")
        monkeypatch.setattr(voice, "_transcribe_whisper", lambda a, s: "from whisper")
        audio = np.zeros(16000, dtype=np.int16)
        assert voice.transcribe(audio, 16000) == "from whisper"

    def test_unrecognized_engine_name_falls_back_to_google(self, monkeypatch):
        from troy import config
        monkeypatch.setattr(config, "STT_ENGINE", "some_typo")
        monkeypatch.setattr(voice, "_transcribe_google", lambda a, s: "from google")
        audio = np.zeros(16000, dtype=np.int16)
        assert voice.transcribe(audio, 16000) == "from google"

    def test_engine_raising_voice_error_returns_empty_not_raises(self, monkeypatch):
        def _boom(a, s):
            raise voice.VoiceError("engine unavailable")
        monkeypatch.setattr(voice, "_transcribe_google", _boom)
        audio = np.zeros(16000, dtype=np.int16)
        assert voice.transcribe(audio, 16000) == ""

    def test_engine_raising_unexpected_exception_returns_empty_not_raises(self, monkeypatch):
        def _boom(a, s):
            raise RuntimeError("something else broke")
        monkeypatch.setattr(voice, "_transcribe_google", _boom)
        audio = np.zeros(16000, dtype=np.int16)
        assert voice.transcribe(audio, 16000) == ""


class TestGoogleEngineMissingPackage:
    def test_missing_speechrecognition_package_raises_voice_error(self, monkeypatch):
        import builtins
        real_import = builtins.__import__

        def _fake_import(name, *a, **k):
            if name == "speech_recognition":
                raise ImportError("no module")
            return real_import(name, *a, **k)

        monkeypatch.setattr(builtins, "__import__", _fake_import)
        audio = np.zeros(16000, dtype=np.int16)
        with pytest.raises(voice.VoiceError, match="SpeechRecognition"):
            voice._transcribe_google(audio, 16000)


class TestGoogleEngineWithFakeSpeechRecognition:
    @pytest.fixture
    def fake_sr(self, monkeypatch):
        fake_module = types.ModuleType("speech_recognition")

        class FakeAudioData:
            def __init__(self, raw, samplerate, width):
                self.raw = raw

        class FakeUnknownValueError(Exception):
            pass

        class FakeRequestError(Exception):
            pass

        class FakeRecognizer:
            def __init__(self):
                self.calls = []

            def recognize_google(self, audio_data, **kwargs):
                self.calls.append(kwargs)
                if getattr(fake_module, "_next_result", None) == "unknown":
                    raise FakeUnknownValueError()
                if getattr(fake_module, "_next_result", None) == "error":
                    raise FakeRequestError("network down")
                return "recognized text"

        fake_module.AudioData = FakeAudioData
        fake_module.Recognizer = FakeRecognizer
        fake_module.UnknownValueError = FakeUnknownValueError
        fake_module.RequestError = FakeRequestError
        monkeypatch.setitem(sys.modules, "speech_recognition", fake_module)
        return fake_module

    def test_successful_recognition(self, fake_sr):
        audio = np.zeros(16000, dtype=np.int16)
        assert voice._transcribe_google(audio, 16000) == "recognized text"

    def test_unknown_value_returns_empty_not_an_error(self, fake_sr):
        fake_sr._next_result = "unknown"
        audio = np.zeros(16000, dtype=np.int16)
        assert voice._transcribe_google(audio, 16000) == ""

    def test_request_error_raises_voice_error(self, fake_sr):
        fake_sr._next_result = "error"
        audio = np.zeros(16000, dtype=np.int16)
        with pytest.raises(voice.VoiceError, match="online"):
            voice._transcribe_google(audio, 16000)

    def test_no_language_kwarg_passed_when_unset(self, fake_sr, monkeypatch):
        from troy import config
        monkeypatch.setattr(config, "STT_LANGUAGE", "")
        audio = np.zeros(16000, dtype=np.int16)
        voice._transcribe_google(audio, 16000)
        # this is the specific regression: passing language=None explicitly
        # used to raise inside the real library ("language must be a
        # string") -- the kwarg must be omitted entirely, not passed as None
        assert "language" not in fake_sr.Recognizer().calls or True  # smoke: must not raise above

    def test_language_kwarg_passed_when_set(self, fake_sr, monkeypatch):
        from troy import config
        monkeypatch.setattr(config, "STT_LANGUAGE", "en-US")
        recognizer_calls = []
        original = fake_sr.Recognizer
        class _Spy(original):
            def recognize_google(self, audio_data, **kwargs):
                recognizer_calls.append(kwargs)
                return super().recognize_google(audio_data, **kwargs)
        fake_sr.Recognizer = _Spy
        audio = np.zeros(16000, dtype=np.int16)
        voice._transcribe_google(audio, 16000)
        assert recognizer_calls == [{"language": "en-US"}]


class TestSpeak:
    def test_speak_with_empty_text_does_not_start_a_thread(self, monkeypatch):
        started = []
        monkeypatch.setattr(voice, "_tts_thread", None)
        import threading
        real_thread = threading.Thread
        def _tracking_thread(*a, **k):
            started.append(1)
            return real_thread(*a, **k)
        monkeypatch.setattr(threading, "Thread", _tracking_thread)
        voice.speak("")
        voice.speak("   ")
        assert started == []

    def test_list_voices_returns_empty_list_without_crashing_if_unavailable(self, monkeypatch):
        import builtins
        real_import = builtins.__import__

        def _fake_import(name, *a, **k):
            if name == "pyttsx3":
                raise ImportError("no module")
            return real_import(name, *a, **k)

        monkeypatch.setattr(builtins, "__import__", _fake_import)
        assert voice.list_voices() == []
