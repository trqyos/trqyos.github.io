# Troy — TROYOS STABLE

A private, local Windows 11 desktop assistant: an Electron-based panel
backed by a Python LLM-driven action loop with real control over the
machine it runs on — files, windows, processes, the network, the screen,
and the mouse/keyboard.

## Newest: native function calling

Troy used to call tools with a text protocol: the system prompt listed every command, the model wrote lines like
`click:100,200` / `speak:On it.` / `done`, and `command_parser.py` split them apart. That works, but small models
mis-format lines, a `|` inside an argument breaks the split, the prompt pays for the tool list on every request, and
everything is a string. Troy now uses the providers' own **function calling** (the `tools` field of the OpenAI-compatible
API, which Groq, OpenRouter, Gemini, NVIDIA NIM and LM Studio all speak): tools are sent as JSON schemas, the model answers
with structured arguments, and its plain text is simply what Troy says.

| Piece | File | What it does |
| --- | --- | --- |
| Schemas | `troy/tool_schema.py` | Builds a JSON schema for every tool (270): hand-written for the built-in commands, derived from `arg_hint` for registry tools, explicit overrides for odd ones (enums, `x,y` pairs). Validates and coerces the model's arguments (`"20"`, `20.0` and `20` all work; a wrong type or missing field comes back as a readable error the model can fix) and turns them into the **same `name` + `arg` string the text protocol produced**, so every existing tool, approval card, scheduled-task grant and stop check works unchanged. A test checks that every registered tool yields a valid schema. |
| Tool loading | `Toolbox` in the same file | ~28 core tools are always sent (16 for small local models); tools matching the request (e.g. "volume") are added; `find_tools` searches all 270 and loads matches; calling a real but unloaded tool loads it and tells the model to retry with the schema. About 1.8k tokens of schemas plus a 0.6k prompt, instead of the 1.5k-token compact prompt plus `list_extra_tools` round trips. |
| History | `troy/tool_history.py` | Native `assistant{tool_calls}` / `tool` messages; `repair()` guarantees every call has exactly one result (a stop mid-batch or context trimming can't produce the 400 that providers return for dangling calls); converts native history to the text protocol and old text-protocol sessions to plain conversation, so switching models mid-chat or loading an old session just works. |
| Transport | `troy/llm_client.py` | Streams `delta.tool_calls` fragments (including servers that omit `index` or send decoded arguments), `chat_tools()` through the existing provider/model fallback chain. A model that rejects `tools` is remembered and served with text instead (no cooldown: it works fine as a text model); Groq's `tool_use_failed` (a garbled call) is retried once on the same model. |
| Loop | `troy/native_loop.py` | One request step = build wire messages, call, speak the text (the sentence before a tool call is spoken the moment the call starts arriving), run each call through `dispatcher.execute`, return `tool` messages. No `speak`/`done`: answering without a tool call ends the turn. Ends early after an approval card (if the user was told what is pending) and after a scheduled run reports `task_result`. |
| Native prompt | `system_prompt.build_native_prompt()` | Personality and rules only; no command list or output format. |

**Setting:** `TROY_TOOL_CALLING` / Settings > Tool calling: `auto` (default; native, per-model fallback to text), `native`
(never fall back; errors are shown), `text` (the original protocol, unchanged). If no available model supports tools, `auto`
finishes the request with the text protocol, so nothing breaks for a local model without tool support.

**Known limits:** a `|` can't appear inside a non-final parameter of a multi-parameter tool (the legacy tools split on it); the
model is told so and rephrases. Parallel tool calls from one reply run one after another (they drive one desktop). Ideas not
done: per-model capability table with measured success rates, routing easy turns to a cheaper model, and a real JSON schema
on each registered tool (today derived from `arg_hint`).

Tests: `tests/test_native_calls.py` (85: schemas, history repair, streaming, provider chain, the agent loop with a scripted model),
`tests/test_native_http.py` (4: the whole stack over a real local socket, including a model that rejects tools). Most existing
tests fake `llm_client.chat()`, so `conftest.py` runs them with `TOOL_CALLING=text`. pytest total: 680.

## Previously: scheduled tasks, and tools found on demand

### Scheduled tasks ("put the computer to sleep at 10 PM")

Say it in chat and Troy turns it into a stored task: it writes a short instruction for its
future self, registers it with a background scheduler, and tells you what it set and when.
The scheduler runs on its own thread and **never calls the model while it waits**; the model
is invoked only at the moment a task is due, with the stored instruction, using the same
tools as any chat turn.

| you say | meaning |
|---|---|
| `every day at 22:00` | daily clock time |
| `every Monday, Wednesday and Friday at 22:00` | specific weekdays |
| `October 25, 2026 at 14:30` | one exact date and time |
| `every 2 weeks on Monday at 9am`, `every month on the 15th`, `on the last day of every month`, `every year on March 3` | weekly / monthly / yearly / stepped recurrence |
| `every 90 minutes`, `every 2 days at 9am` | interval recurrence |
| `in 30 minutes`, `tomorrow at 9 AM`, `friday at 8pm`, `at 22:00` | relative / next occurrence |

Times are the PC's local clock. Anything the parser isn't sure of (`at 5pm sometime next
quarter`) is refused with the list of supported forms rather than guessed. The model may also
pass a JSON spec. Ask Troy to list, change (`modify_task`), pause, resume, run now, or cancel
tasks, or use the **Tasks** screen.

**Execution.** A run uses a fresh, isolated agent (it never reads or writes the open chat),
holds the same turn lock as chat turns (so it can't fight you for the mouse), and ends with
`task_result:<done|retry|blocked>|<summary>`. Failures are handled by what the model reports:
`retry` (transient: app not ready, network down) is retried up to `TROY_TASK_MAX_RETRIES`
times, waiting `TROY_TASK_RETRY_DELAY_SECONDS`; `blocked` (missing permission/file/tool) and
a user Stop are final. A retry is told which actions already succeeded in the run and must
not repeat them. Each task can override the retry count and delay. When it ends, the result
is spoken, toasted, and written into the chat that created the task (even if that chat is
closed); a recurring task goes back to waiting for its next occurrence, a one-time one is
marked completed or failed, and the assistant returns to its normal ready state.

**Persistence and recovery.** Every change is saved atomically to `troy_tasks.json` and every
event is appended to `troy_task_runs.jsonl` (also shown per task in the Tasks screen). After a
restart a run that was cut off continues as a retry with its progress. If a task was due while
Troy or the PC was off or asleep it still runs when back within `TROY_TASK_MISSED_GRACE_MINUTES`
(default 10); later than that it is marked **missed** (a "sleep at 10 PM" firing at 7 AM
would be worse than useless) and a recurring task simply waits for its next time.

**Unattended means no Approve buttons, so approval happens ahead of time.** A run can only use
commands that need approval (sleep, shutdown, delete, shell...) if the user pre-approved those
exact `name:argument` strings for that task: Troy passes them as the 4th part of
`schedule_task`, the user gets one approval card, and nothing is granted until they click. A
refused command never runs and never leaves a prompt waiting for nobody: the task reports
"needs approval" and the Tasks screen shows an **Approve and run now** button. A model that
says "done" after being refused is still reported as blocked. A scheduled run cannot create
tasks, and editing a task's instruction clears its approvals.

**UI.** A **Tasks** screen (Ctrl+6, `/tasks`, palette) with Active / Finished / All, search,
live "in 1h 40m" countdowns, Run now / Pause / Edit / Cancel / Log, a form that previews what
your wording means ("Every Monday and Friday at 22:00, next: ..."), and an **Open chat** button
on every task that jumps to the chat (and message) that created it. Chats that created tasks
carry a task icon in the sidebar, and the `schedule_task` step is marked in the transcript.

### Extra tools found on demand (`list_extra_tools`)

The compact prompt now states only the core tools and says how many more exist; it dropped
from about 2,600 to about 1,500 tokens (tiny: about 500). When a request needs more, Troy calls
`list_extra_tools` (optionally `list_extra_tools:<category or words>`) and gets every extra
tool with its exact usage. A tool is "extra" exactly when its name is not in the prompt it was
given, so this works for the tiny, compact and detailed prompts alike (detailed lists
everything, so it truthfully answers "no extra tools").

Because this is where hallucination creeps in, it is built defensively:

- The list is complete or says what it omits: too big for the context budget it drops to
  names only, then to categories only, and says so. It is exempt from per-message truncation,
  so a half-list can never look complete.
- The prompt and the list both say: only commands you were shown exist; if none fits, tell
  the user plainly that you can't; never invent a command. An unknown command comes back as
  FAILED with the nearest real names (and cannot be ended by a bundled `done`).
- An extra tool never shown to the model does **not** run on its first call: it returns its
  exact usage instead, so a guessed argument shape can't act. After that it runs.
- When the request ends, the list is cut out of the chat history and replaced by a one-line
  stub that keeps only the usage of the extra tools that were actually used; everything else
  reverts to the original prompt's capabilities. A scheduled task remembers the extras it used.

`TROY_EXTRA_TOOLS_ENABLED=false` (Settings > Speed) restores the old behaviour exactly.

New files: `troy/schedule_spec.py` (parsing, next-run maths), `troy/scheduler.py` (persistent
scheduler), `troy/task_runner.py` (one attempt), `troy/task_context.py` (unattended-run
rules), `troy/tools_tasks.py` (the task tools), `troy/extra_tools.py` (the on-demand tool list).
IPC: `tasks.*` methods and `task.*` events (see `electron/README.md`). Not done: the phone page
has no Tasks view (tasks still run and report to it as normal messages).

## Previously: the widget, a liquid-glass redesign, Troy controls his own app, power saving

- **Widget mode.** Troy now lives in a small always-on-top glass pill at the top
  centre of the screen (right under a laptop webcam): avatar, status, an input, a
  voice button and an activity log. **Only one of the widget and the full app is
  shown at a time** (opening the app hides the widget, closing it brings the widget
  back). `Ctrl+Alt+T` (changeable) shows/hides the widget from anywhere. See
  `electron/README.md` > *The widget*.
- **Redesign.** The whole app moved to a new liquid-glass look (smoky glass with a
  specular rim, drifting colour, spring motion) shared by the widget and the app.
  The retired "keep on top" and "close to tray" options are gone from the app.
- **New Nova animations.** Eyebrows, glinting eyes, heart eyes, wink, curious head
  tilt, sparkles, thinking dots, sound rings that follow the voice level, an
  "executing" scanner, and an idle personality (it winks and tilts its head on its
  own). Click the face: hop, then wink, then hearts.
- **Troy controls his own app** (`troy/tools_app.py`, category `app`): `show_widget`,
  `hide_widget`, `toggle_widget`, `open_full_app`, `new_chat`, `open_view`,
  `set_appearance`, `set_widget_option`, `list_settings`, `change_setting`,
  `set_power_saving`, `power_status`, `ui_status`. API keys and the model-switch
  permission are off limits; settings that expose the PC to the network need a click.
- **Power saving** (`TROY_POWER_SAVING` / Settings > Power): `off`, `auto` (on while
  on battery) or `on`. Calmer visuals (20 fps avatar, no blur or drifting), slower
  voice-level updates and phone screen-share fps. Troy's work is unchanged.

## Previously: full voice mode, the phone as Troy's headset, Troy switches its own brain

- **Full voice mode — a real conversation, no wake word.** Click *Voice mode*
  in the header (or **Ctrl+Shift+V**, or say *"hey Troy, voice mode on"*): a
  full-screen overlay with the avatar, a live transcript and a mic-level ring
  takes over, and Troy just talks **with** you. Everything is hands-free:
  follow-ups need no wake word for up to `TROY_VOICE_CONVERSATION_IDLE_SECONDS`
  (30 s default), the avatar's face mirrors the pipeline (listening → heard
  you → thinking → working → speaking), **barge-in** works — start talking over
  Troy and it stops mid-sentence and listens (`TROY_VOICE_BARGE_IN`), and
  saying *"stop" / "never mind"* cancels whatever it's doing. Leave by saying
  *"goodbye" / "that's all"* or pressing End. `troy/voice_mode.py` is the
  orchestrator: same state machine on both the PC and the phone UIs
  (`voice.state / voice.level / voice.transcript / voice.ended` events).
- **The voice itself got better.** Three TTS engines, tried in order and
  switchable live (Settings > Voice): **Piper** (offline, genuinely natural —
  drop a `.onnx` voice from
  [rhasspy/piper-voices](https://huggingface.co/rhasspy/piper-voices) and set
  `TROY_PIPER_MODEL`), **Edge** (online neural voices, `pip install edge-tts`,
  pick any of Microsoft's voices like `en-US-AriaNeural`), and the built-in
  SAPI5 voice as the always-there safety net (`TTS_ENGINE=auto|piper|edge|sapi`).
  Replies are **sentence-streamed** (the first sentence starts playing while
  the rest is still being synthesized), code blocks and links are skipped
  ("(code)" instead of listening to punctuation), and `voice.speak` gained
  prefetch + instant-stop so barge-in is actually instant.
- **The phone is Troy's headset.** On the phone page, the mic button turns the
  phone into Troy's **ears and mouth**: the phone runs its own endpointer
  (a faithful JS port of the PC's adaptive VAD — it decides locally when
  you've finished a sentence, so nothing streams while you're thinking), then
  posts the utterance as raw PCM; the PC transcribes it (same engines as
  above) and the reply plays **on the phone** — either its own
  `speechSynthesis` voice (instant, `VOICE_PHONE_SPEAKER=phone`) or Troy's
  chosen voice streamed from the PC (`=troy`). Browsers only allow `getUserMedia`
  on secure pages, so Troy now **also serves the phone page over HTTPS**
  (`MOBILE_UI_PORT+1`, self-signed cert in `troy/tls.py`, SANs cover
  localhost/hostname/LAN IP — expect exactly one "not trusted" warning, then
  accept; or use Tailscale HTTPS for zero warnings). The mic route has its own
  2 MB body limit, token check and silence/noise rejection server-side.
- **Troy can change its own model mid-chat.** New tools `set_model` ("switch
  to fast", "use the strong model", "go local only"), `list_models`,
  `current_model`, `reset_model`, `set_vision_model` — so mid-conversation it
  can drop to a quick model for simple lookups and climb back for hard
  reasoning. Settings persist (`troy/settings_store.py`), local→cloud switches
  require your approval like any risky action, the agent re-reads its prompt
  after a switch so the new model knows what it is, and both UIs get a
  `model.changed` event (the desktop shows a toast: *"Troy switched its own
  brain: Groq · llama-3.3-70b"*). Gate it with `ALLOW_MODEL_SWITCH` in
  Settings > Models if you'd rather it didn't.
- **Everything degrades loudly, not fatally**: no `cryptography` → no HTTPS
  page (http still fine, mic needs Tailscale); no `edge-tts`/`piper-tts` →
  those engines are reported "not installed" and skipped; no `sounddevice` →
  a clear error from the mic-test button instead of a crash. 78 new tests
  cover voice_mode, the voice IPC methods, the phone voice routes, and the
  HTTPS path (407 total, was 329).

## Latest: faster replies, LM Studio vision, YouTube, Tailscale, new phone page

- **Speed / the Groq 413 error.** The system prompt was ~9,000 tokens, which made
  every reply slow and broke Groq's free tier (8,000 tokens/minute). Now:
  a **compact prompt (~2k tokens)** (tiny ~450 for small local models; the
  original is still available as "detailed"); the ~170 tools are listed by name
  and the few relevant to your message are described in full each turn
  (`list_tools` / `tool_help` let the model look up the rest); every request is
  **fitted to a token budget** (old messages dropped, long tool output trimmed);
  a **413 with a stated limit is retried automatically, trimmed**; models that
  fail (rate limit, too big, retired) are **skipped for a while** instead of being
  retried on every message; reasoning models are asked to **think less**
  (Groq gpt-oss/Qwen3, Gemini 2.5, ...). Tune it in Settings > Speed.
- **LM Studio.** Reads models from LM Studio's own API: **vision models are
  detected and selectable** (Settings > Models), loaded models come first, and the
  prompt is sized to the model's real **context length** (so a 4k local model
  now works). Screenshots are shrunk for local vision models, and click
  coordinates are scaled back. The Settings "providers/models" hang was
  LM Studio's model lookup blocking 3 s on every call; it's now cached and
  skipped when LM Studio is off.
- **YouTube (OAuth 2.0).** Settings > Integrations: paste a Google "Desktop app"
  client id/secret, press Connect. Tools: `youtube_open_latest` ("open the last
  video on my liked videos"), `youtube_liked`, `youtube_playlists`,
  `youtube_playlist_items`, `youtube_latest`, `youtube_search`,
  `youtube_open_video`, `youtube_subscriptions`, `youtube_video_info`. The newest
  video is found by the date it was added to the playlist, then opened in a new
  Firefox tab (`open_in_browser` is also a tool). Read-only scope; PKCE; tokens
  refresh automatically; a paste-the-URL fallback if loopback is blocked.
- **Direct app launching.** Settings > General > Launching apps: *direct* starts
  the program itself (PATH, App Paths, Start Menu shortcuts, Store apps) instead
  of pressing the Windows key; *auto* falls back to the Start menu. The model
  still just says `open_app:<name>`.
- **Search chats.** Sidebar search covers titles **and messages** (with
  snippets; clicking a hit opens the chat at that message); Ctrl+F finds inside
  the open chat; `search_chats` is also a tool so Troy can find old conversations.
- **New phone page.** Same glass look with Troy's animated face, the chat, tool
  steps, approvals, stop, voice input (over HTTPS), and a **live view of the PC
  screen** (view only: quality presets, monitor picker, pinch-zoom, pause,
  screenshot, full screen). The desktop shows "Phone watching" while someone is
  looking, and screen sharing can be switched off. The access link now survives
  restarts and can be regenerated.
- **Tailscale.** Settings > Phone shows your Tailscale address and devices and
  can turn on HTTPS (`tailscale serve`), so the phone page works from anywhere,
  encrypted, no router changes. `troy/remote.py` lists every way to reach Troy,
  so more transports can be added in one place.

## Newest: glass UI with the Nova avatar, real tray/hotkey, sturdier backend

- **New interface** (`electron/renderer/`): glassmorphism design with the Nova
  animated face wired to the agent's real state (thinking / working / speaking /
  listening / done / error / asleep). Chat with collapsible tool steps and
  approval cards, sessions, memory, tool browser, logs, a provider + API-key
  manager with live model fetching, model pickers, voice, phone page,
  light/dark + accent + blur, command palette (Ctrl+K), slash commands.
  `npm run demo` previews it with no Python; `npm run test:ui` runs 47 UI checks.
- **Electron shell:** hidden-to-tray close, global hotkey show/hide, single
  instance, remembered window size/position, always-on-top, friendly error when
  Python is missing (previously an unhandled crash), links open in your browser.
- **Backend fixes found while building it:** replies are now spoken when
  "Speak replies" is on (the Electron port had dropped this); voice and phone
  messages now appear in the UI; turns run one at a time instead of overlapping;
  new chats no longer litter empty session files and get titled from your first
  message; the phone page now reports its URL when started at runtime; wake-word
  listening starts at launch if enabled; TTS speed/voice changes apply
  immediately; settings values are range-checked.
- **Avatar fix:** the original avatar's blink spring diverged on slow frames
  (eyes exploded to NaN-sized shapes); it now integrates in fixed sub-steps.

## Latest: encoding fix, NVIDIA NIM, public-API tools

- **`'charmap' codec can't encode character '\u2011'` fixed.** On Windows
  the Python backend's stdout/stderr are pipes (Electron spawns it), and
  Python falls back to the legacy cp1252 codepage for pipes, which can't
  encode non-breaking hyphens, curly quotes, etc. `main.py` now forces
  UTF-8 on stdin/stdout/stderr before anything else runs, `electron/main.js`
  sets `PYTHONUTF8=1`/`PYTHONIOENCODING=utf-8` on the child, and the log
  console handler is hardened too. Reproduced and verified with a forced
  cp1252 environment.
- **NVIDIA NIM (build.nvidia.com) provider.** Set `TROY_NVIDIA_API_KEY`
  (or plain `NVIDIA_API_KEY`); use `TROY_PRIMARY_PROVIDER=nvidia` or
  `TROY_TEXT_MODEL_OVERRIDE=nvidia:z-ai/glm-5.3`. Text and vision model
  lists are `NVIDIA_TEXT_MODELS` / `NVIDIA_VISION_MODELS` in `troy/config.py`
  (your prototype models; kimi-k3 and diffusiongemma are the vision ones).
  Advanced per-model knobs from the samples (`reasoning_effort`,
  `reasoning_budget`, `enable_thinking`) are not sent; `reasoning_content`
  streaming is parsed.
- **New "api" tools:** Open-Meteo (`geocode_place`, `get_weather_forecast`),
  Frankfurter (`convert_currency`, `get_exchange_rates`,
  `get_historical_rate`, `list_currencies`), Wikipedia (`wikipedia_search`,
  `wikipedia_summary`), NewsAPI (`news_top_headlines`, `news_search`; needs
  `TROY_NEWSAPI_KEY`). The rest need no key. `get_weather` already used Open-Meteo.

## This round: Electron frontend, context awareness, skills removed, web tools reorganized

- **The desktop frontend is now Electron, not PySide6/Qt.** `ui/` (the old
  Qt panel) is gone. `electron/` is a new, self-contained Electron app
  that talks to the Python backend over **stdio IPC** — `main.py --ipc`
  is spawned as a child process and communicates over plain
  stdin/stdout, one JSON object per line (see `troy/ipc_host.py`'s
  docstring for the exact protocol). This deliberately does not open an
  HTTP server on `127.0.0.1:8000` or any other port for the frontend to
  poll — that approach doesn't work reliably here (port conflicts,
  firewall prompts, the server not being up yet when the window opens).
  `electron/renderer/index.html` is intentionally a bare wiring template,
  not a finished design — every `window.troy.*` call in it already works
  end-to-end against the real backend; only the visuals need replacing.
  See `electron/README.md` for how to run it and the full list of
  IPC methods/events available to build a UI against.
- **Context awareness.** Every turn now automatically includes a live
  "situational context" snapshot (current time, active window, how many
  windows are open, CPU/RAM, whether the web research browser is
  running) alongside the existing long-term-memory context, so Troy
  starts each turn already oriented instead of having to ask. The same
  snapshot is also available on demand as the `get_context` command
  (`troy/tools_all.py`'s `get_context_snapshot`). Troy also now gets
  direct feedback about its own turn budget: as a turn nears
  `MAX_STEPS_PER_TURN`, a `[SYSTEM] Heads up: N step(s) left...` line is
  injected into its own observations so it wraps up instead of being cut
  off with no warning.
- **Skills removed.** `troy/skills.py`, `troy_skills/`, and the
  `list_skills`/`run_skill`/`create_skill`/`delete_skill` commands are
  gone. This was the saved-Python-actions feature from an earlier round
  (see the changelog further down) — removed as an unnecessary layer of
  indirection on top of the tool library that's already there.
- **Browser tools reorganized and renamed.** The old `browser_*` tool
  names have been renamed to `web_*` (`web_open`, `web_click`,
  `web_type`, ...), and the system prompt now has an explicit
  "YOUR BROWSER vs. WEB RESEARCH TOOLS" section that keeps two
  previously-conflated things clearly separate:
  - `open_app:firefox` / `open_url:<url>` / `search_newtab:<query>` —
    your own real, visible browser (whatever's actually installed:
    Firefox, Chrome, ...), with your own logins and window on screen.
    Use this whenever you ask for "my browser"/"Firefox" by name, or want
    to actually see/keep using a page yourself.
  - `web_open` / `web_click` / `web_type` / `web_read_page` / ... — Troy's
    own separate, invisible, headless-by-default Chromium instance
    (still Playwright under the hood — same engine as before, new name
    and category: `"web"` instead of `"browser"`), for autonomous
    background research/form-filling the user doesn't need to watch.
    `TROY_BROWSER_HEADLESS` now defaults to `true` to match this (it's
    meant to run invisibly by default now).
  This is a straight rename plus a clarified prompt — no change to what
  the tools themselves do. If you had anything hardcoding the old
  `browser_*` names, update it to `web_*`.

## Older: real desktop UI inspection

- **Troy can now "see" native Windows apps structurally, not just
  visually.** `troy/ui_automation.py` reads the real Windows UI
  Automation accessibility tree (the same API screen readers use) — every
  control's actual type, name, id, position, and enabled state — instead
  of a vision model guessing pixel coordinates from a screenshot. This is
  the desktop equivalent of what the `web_*` tools already do for web
  pages:
  - `inspect_window:<title>` (or blank for whatever's focused) lists a
    window's real controls, depth- and count-capped so even a huge,
    deeply-nested window (an IDE, a browser) stays readable.
  - `click_element:<name>[|<window>]` clicks a real control by its
    accessible name — no coordinates.
  - `type_into_element:<name>|<text>[|<window>]` sets a field's text
    through the accessibility API directly where supported (more
    reliable than simulated keystrokes, works even unfocused).
  - `get_foreground_window_info` — a cheap "what actually has focus"
    check, structural rather than visual.
  Requires `pip install uiautomation`. Every call is wrapped defensively
  (COM automation is flaky — a control can throw on a property read that
  should be harmless) so one bad element never breaks a whole inspection;
  verified with 25 tests against a faked control tree, including a test
  that a property raising mid-walk doesn't take down the rest of the
  read. This can only be structurally tested outside a real Windows
  machine, though — genuinely worth trying for real and reporting back
  anything that doesn't match a real app's actual behavior.

## Older: consolidation/optimization pass

This was a consolidation/optimization pass over an earlier version, not a
feature-by-feature rewrite. Nothing in the tool library was removed at
the time (skills were removed in a later round — see above).

- **One file for every tool.** Every tool (the original hand-written
  primitives and everything added since) lives in `troy/tools_all.py`
  instead of being spread across 18 files plus a separate registry and
  registrations module. Same functions, same behavior, one place to look
  or extend.
- **Coordinate targeting.** `locate_on_screen:<description>` takes a
  screenshot and asks a vision model directly for the pixel (x, y) of
  what you described, instead of a prose description Troy then has to
  re-derive coordinates from. `click_target:<description>` chains
  screenshot → locate → click into a single call.
- **Real approvals, not model text.** High-risk actions (delete, shutdown,
  restart, empty Recycle Bin, environment variables, raw shell commands)
  used to require the model to resend a command with a `CONFIRM|` text
  prefix once you'd agreed in chat. That's gone. Now a risky action creates
  a pending confirmation in real application state (`troy/confirmation.py`)
  and the frontend shows an actual Approve/Cancel prompt (see
  `confirmation.request`/`confirmation.resolve` in `electron/README.md`) —
  the tool only ever runs from that button click.
- **No task planner.** The persistent multi-step plan system
  (`troy/planner.py`, the Tasks panel, `plan_*` commands) has been removed.
  Troy still handles multi-step requests turn by turn; it just doesn't
  maintain a separate disk-persisted plan object for them anymore.
- **Real PC control.** `run_shell_command` runs any shell command and
  returns captured output (approval-gated). `get_full_system_report`
  returns CPU/memory/disk/battery/network/uptime in one call instead of
  six round trips.
- **A shorter system prompt.** Rewritten to cut repetition; the extended
  tool section is still generated directly from the tool registry so it
  can't drift out of sync with what's actually registered.

## Older: browser automation, voice, global hotkey

- **Real browser automation, not pixel-clicking.** `troy/browser_worker.py`
  runs a persistent, real Chromium instance (via Playwright) on a
  dedicated background thread, and a set of tools — now named `web_*`,
  see the reorganization note above (`web_open`, `web_click`, `web_type`,
  `web_read_page`, `web_get_links`, tabs, navigation, ...) — act on actual
  page elements by their visible text/label instead of guessing screen
  coordinates. Verified live against real sites in development, including
  a full navigate → fill a login form by label → click "Sign in" flow —
  and that testing caught and fixed a real bug where an ambiguous label
  (e.g. "Password" substring-matching a "Forgot password?" link) could
  select the wrong element; exact-match is now always preferred over
  substring match. Requires `pip install playwright` then `playwright
  install chromium` once. Off by default in the sense that nothing
  launches this browser until a `web_*` tool is actually called.
- **Voice.** `troy/voice.py` + `troy/wake_listener.py` — always-on,
  hands-free voice control (no button): say the wake word and Troy starts
  listening, captures until you stop talking, and sends it — see
  **Voice setup** below for the full picture, including which of the two
  speech engines to pick and the real setup gotchas for each.
- **Global hotkey.** Lives in the Electron shell now (default `Ctrl+Alt+T`,
  changeable in Settings > Widget): it opens the widget and closes it again.
  The old Python/pynput hotkey (`troy/hotkey.py`, `TROY_HOTKEY_COMBO`) was removed.

## Voice setup

Voice is off by default. Turn it on via `.env` (`TROY_VOICE_INPUT_ENABLED=true`
for spoken input, `TROY_VOICE_OUTPUT_ENABLED=true` for spoken replies — independent
of each other).

**How it actually works, once on:** Troy listens continuously in the
background — there's no push-to-talk button to hold. Say the wake word
("Troy" by default) and whatever comes right after it in the same breath
is sent immediately: *"Troy, what's my CPU doing"* → sent as soon as you
stop talking, no button. If you just say *"Troy"* on its own, it opens a
short follow-up window (8 seconds by default, `TROY_VOICE_FOLLOWUP_SECONDS`) where you
can say the actual command without repeating the wake word — a real
back-and-forth, not one wake word per sentence. Anything said that never
mentions the wake word (and isn't inside that follow-up window) is simply
ignored — background chatter, a TV, other people talking, never gets
sent anywhere. End-of-speech detection is automatic (it cuts on ~0.6s of
silence by default — tune `TROY_VAD_SILENCE_HANGOVER_SECONDS` for
snappier or more patient cutoffs), and mic sensitivity adapts to your
room's background noise automatically (`TROY_VAD_ENERGY_MULTIPLIER` if
you need to tune it — raise it if it's triggering on background sound,
lower it if quiet speech isn't picked up). The mic button in the composer
is just a mute toggle and a live status indicator (color-coded:
listening / hearing you / thinking / awake-in-a-conversation) — nothing
to press and hold.

**Two interchangeable speech-to-text engines** (`TROY_STT_ENGINE`, also
) — pick whichever fits, switch anytime:

| | `google` (default) | `whisper` |
|---|---|---|
| Setup | `pip install SpeechRecognition` | `pip install faster-whisper` |
| Needs | Internet connection | Nothing, once the model's downloaded |
| Cost | Free, no account, no API key | Free |
| Privacy | Audio goes to Google's free recognition endpoint | Fully offline/local, nothing leaves the machine |
| Speed | Fast (small network round trip) | Depends on your hardware/model size |
| Setup pain | Genuinely none | See below — this is the one that bites people |

**If you pick Whisper, here's what actually trips people up** (this
section exists because setting it up was a real pain in an earlier
version of this project — read this before opening an issue about it):

1. **First run downloads a model from Hugging Face.** `TROY_WHISPER_MODEL_SIZE`
   (`tiny`/`base`/`small`/`medium`/`large-v3`) is fetched the first time
   Whisper is actually used, not at install time — so the first thing you
   say will hang for a while with no visible progress bar. This needs
   internet even though transcription itself doesn't, afterward. If it
   fails here, it's almost always a network/firewall/proxy problem, not a
   code problem.
2. **GPU acceleration is not automatic just because you have a GPU.**
   `TROY_WHISPER_DEVICE=auto` tries CUDA first and silently falls back to
   CPU if that fails — which means a broken CUDA setup won't error, it'll
   just be quietly slow. If transcription feels sluggish, that's usually
   why. Getting real GPU acceleration means: an NVIDIA GPU, a CUDA
   toolkit install, AND a matching cuDNN install that `ctranslate2`
   (Whisper's backend) can actually find on your `PATH` — these three
   have to be version-compatible with each other, and mismatches are the
   #1 cause of "it just uses CPU and I don't know why." If you don't want
   to deal with this at all: set `TROY_WHISPER_DEVICE=cpu` explicitly, or
   just use the `google` engine instead — this whole problem doesn't
   exist there.
3. **`tiny`/`base` mishear things more than you'd expect**, especially
   short wake-word-only utterances and names. If "Troy" isn't reliably
   triggering, try `small` — meaningfully better accuracy, still fast
   enough on CPU for short utterances.
4. **This is transcription-based wake-word detection, not a dedicated
   wake-word model** (like Picovoice Porcupine) — it's listening for
   volume changes, then transcribing what it captured, then checking if
   the wake word is in the text. That's why it needs no extra native
   dependency or paid account, but it does mean the wake word can
   occasionally be missed or misheard like any other word would be,
   especially on `tiny`. This is a deliberate trade-off for "install one
   pure-Python package and it works," not an oversight.

**Both engines share the same microphone capture** (`sounddevice`) —
that one's needed no matter which engine you pick. On Windows this
normally just works (the wheel bundles PortAudio); if you ever see
`OSError: PortAudio library not found`, voice input degrades to a clear
log message instead of crashing Troy, and reinstalling `sounddevice`
(`pip install --force-reinstall sounddevice`) fixes it in the rare case
it doesn't.

**Text-to-speech** (spoken replies) is separate from both of the above —
`pyttsx3`, driving Windows' own built-in SAPI5 voices. Offline, no model,
no GPU, and generally the one piece of voice that "just works" with zero
fuss — pick a voice (`TROY_TTS_VOICE_ID`, or the `voice.list_voices` IPC method) and adjust rate (`TROY_TTS_RATE`).

### Full voice mode — the hands-free conversation

Wake-word listening is for occasional *"Troy, …"* commands while you do
other things. **Voice mode** is for when talking *is* the interface:
cooking with wet hands, lying on the couch, walking around the room.
Start it with the **Voice mode** button next to the title (or
**Ctrl+Shift+V**, or Settings > Voice > Start, or just *"hey Troy, voice
mode on"* — then put the keyboard away).

What you get, and how to leave:

- **No wake word while it's on.** Say anything and it's a turn. Troy keeps
  the window open as long as you keep talking, and for
  `TROY_VOICE_CONVERSATION_IDLE_SECONDS` (30 s) after each reply — then it
  politely goes back to plain wake-word listening rather than hanging up.
- **Say "stop" (or "never mind", "cancel", "be quiet")** — Troy stops
  speaking and drops whatever it was doing, instantly.
- **Barge-in:** just start talking *over* Troy — it detects you within a
  word or two, stops, and listens. (Thresholds rise while it's speaking so
  its own voice from the speakers doesn't trip it.)
- **Say "goodbye" / "that's all" / "go to sleep"** — Troy says bye and the
  mode ends cleanly.
- The overlay shows the live state (listening → heard you → thinking →
  working → speaking), a live transcript of both sides, a mic-level ring,
  and Mute / Stop / End buttons. Escape hides the overlay without ending
  the mode (the header button stays lit).

Everything is shared with the phone: start voice on the phone page and
the same conversation continues there (see below).

**The phone as Troy's headset.** On the phone page tap the mic button:
now the phone's microphone is Troy's ears and its speaker is Troy's
mouth — the PC can be across the room or lid-closed in a bag (the
browser page keeps working as long as the phone has network to the PC).
The phone runs the same adaptive endpointing locally (a JS port of the
PC's VAD), sends each finished utterance as one small PCM upload, and
the reply is spoken on the phone. Two sound sources for the reply
(Settings > Phone):

- `VOICE_PHONE_SPEAKER=phone` — the phone's own `speechSynthesis` voice.
  Zero latency, works even on a weak link, sounds like the phone's
  built-in assistant voice.
- `VOICE_PHONE_SPEAKER=troy` — the actual TTS engine chain from Settings >
  Voice (Piper/Edge/SAPI) runs on the PC and streams audio to the phone,
  so Troy's voice sounds the same everywhere.

One browser rule, handled for you: `getUserMedia` (the microphone) only
works on **secure pages**. Plain Wi-Fi http isn't one, so Troy serves the
exact same page on **https://…:MOBILE_UI_PORT+1** with a self-signed
certificate (`troy/tls.py`, `pip install cryptography`, SANs for
localhost/hostname/LAN IP). Your phone will warn "not trusted" exactly
once — accept it (it's your own PC cert) and the mic button comes alive.
Tailscale HTTPS (Settings > Phone) is the zero-warning alternative. The
phone page shows the https link to use whenever the mic can't start.

Two settings keep phone voice sane: `TROY_MOBILE_VOICE_ENABLED=false`
hides the mic button entirely (Settings > Phone), and while the phone is
talking for Troy the PC stays quiet — whoever asked last gets the ears.

### Troy changing its own model

Mid-chat, Troy can decide the current model is overkill (or not enough)
and switch itself: *"quick one — who wrote this?"* → it drops to the
fast lane; *"analyze this whole document"* → it climbs to the strong
model. The tools: `set_model` (takes a name, `provider|model`, or the
aliases **fast / strong / local**), `list_models`, `current_model`,
`reset_model`, `set_vision_model`. Rules that keep it safe:

- Switching **to a local model**, or between cloud models of providers
  you already configured: instant, no questions.
- Switching from a **local to a paid cloud** model is treated like any
  risky action: you get an approval card first.
- The choice persists across restarts (`troy/settings_store.py`) and the
  agent re-reads its system prompt after a switch, so the new model knows
  who it is mid-conversation.
- Both UIs hear `model.changed`; the desktop shows
  *"Troy switched its own brain: Groq · llama-3.3-70b"*.
- Don't want it? `ALLOW_MODEL_SWITCH=false` (Settings > Models) and the
  tools answer with a clear refusal instead.

## Fixes from this round (voice was a real pain point — this addresses it directly)

- **Was push-to-talk, now always-on wake-word listening.** The mic button
  used to require pressing, holding, speaking, and pressing again — and
  even then the transcribed text just sat in the input box instead of
  being sent. Both gone: `troy/wake_listener.py` is a new always-on
  background listener (adaptive energy-based speech detection, no extra
  native dependency), and a recognized, wake-word-gated command is now
  sent immediately and automatically, exactly like a typed message —
  never left sitting anywhere.
- **A second, free speech-to-text engine.** `TROY_STT_ENGINE=google` (now
  the default) uses the free, keyless Google Web Speech endpoint via the
  `SpeechRecognition` package — internet connection and one `pip install`,
  nothing else. Whisper is still there (`TROY_STT_ENGINE=whisper`) for
  fully offline/private use; see **Voice setup** above for exactly what
  makes its setup harder and how to avoid the usual pitfalls.
- **A real bug caught in testing:** the Google engine path initially threw
  `` `language` must be a string `` on every call — `recognize_google()`
  needs its `language` kwarg omitted entirely when unset, not passed as
  `None`. Fixed, and locked in with a regression test.
- **A real startup crash caught in testing:** if `sounddevice`'s native
  PortAudio library is missing or broken, it raises `OSError` at import
  time — not `ImportError` — which wasn't being caught, so a broken audio
  driver could crash the whole app at launch before you ever saw the main
  window. Now caught broadly, at every call site, with a clear log
  message instead.
- **Removed the initial greeting message** ("Hi. I'm Troy...") — a new
  session now just opens on an empty chat.

## Fixes from the previous round (bug reports from real use)

- **Mojibake / "weird symbols" in messages.** `llm_client.py` never forced
  `response.encoding = "utf-8"` on the streamed API response, so `requests`
  fell back to Latin-1 decoding of UTF-8 bytes — the classic cause of
  seeing "Â" before curly quotes, ®, em dashes, etc. One-line fix.
- **Icons not showing / a stray blank-looking control in the top bar.**
  The window controls (nav toggle, minimize, close) were using raw Unicode
  glyphs (`☰`, `—`, `×`) that a lot of Windows font configurations don't
  have glyphs for — they render blank. Replaced with the same hand-drawn
  vector icons the rest of the app already uses. Also replaced the
  translucent + drop-shadowed + animated top-level window (a known
  Qt-on-Windows source of DWM redraw corruption) with a hard-masked,
  non-translucent window shape — same rounded-corner look, no compositing
  artifacts.
- **No "New chat" button.** Genuinely missing after the previous rewrite —
  restored to the top bar.
- **The model giving up too fast.** Rewrote the failure-handling section of
  the system prompt to distinguish a real adapted retry from repeating the
  same failed command, and added a WORKED EXAMPLES section with 5 full
  scenarios (launching an app, recovering from a `click_target` miss, a
  risky-action approval flow, creating a skill, and when to escalate).
- **`create_skill` was silently broken for any multi-statement skill.**
  The command protocol is one command per physical line, so a real newline
  inside a skill's code was impossible to send — but nothing ever unescaped
  the literal `\n` the model was implicitly expected to use instead. Fixed
  with a small, safe unescaper in `dispatcher.py` (only on this one
  LLM-facing path; Skill Studio's own Save button still passes real
  multi-line code untouched). Verified end-to-end.
- **Gemini / Google AI Studio support.** Added as a full provider via
  Google's OpenAI-compatible endpoint — same fallback chain as Groq/
  OpenRouter, configurable via `.env` (see `troy/config.py`).
- **Mobile web UI.** `troy/mobile_server.py` is a small, dependency-free
  local HTTP server serving a mobile-responsive chat page, bridged to the
  exact same running agent (not a second assistant). Enable it from
  `.env` (`TROY_MOBILE_UI_ENABLED=true`) — it shows the address and pairing token to open on
  your phone while it's on the same Wi-Fi. Desktop and phone stay in sync
  live in both directions.

## Running it

**Python backend:**
```
pip install "setuptools<81"
pip install -r requirements.txt
playwright install chromium   # once, for the web_* research tools
```

**Electron frontend:**
```
cd electron
npm install
npm start
```
`npm start` launches Electron, which spawns `python -u main.py --ipc` in
the project root as a child process automatically — you don't need to
run the Python backend yourself. If Python isn't on your PATH as
`python`/`python3`, set `TROY_PYTHON` to the exact interpreter to use
(e.g. `set TROY_PYTHON=C:\path\to\venv\Scripts\python.exe` on Windows)
before `npm start`.

Configure API keys (Groq, OpenRouter, Gemini, and/or NVIDIA NIM) and preferences via
environment variables — copy `.env.example` to `.env` and fill it in; see
`troy/config.py` for the full list. A handful of settings are also
readable/hot-reloadable at runtime over IPC (`settings.get`/`settings.set`
— see `electron/README.md`).

## Tests

A real pytest suite covering the dispatcher, the tool registry (including
the confirmation-gating contract), the web research browser worker's
threading model, the wake-word listener's state machine, both
speech-to-text engines, and the generated system prompt (including a
regression test that the "your browser" vs. "web research tools"
disambiguation stays documented) — 578 tests, added specifically so
future changes to any of this fail CI instead of failing silently at
runtime.

```
pip install -r requirements-dev.txt
pytest
```

Every test is isolated from your real `troy_sessions/` and
`troy_memory.json` (see `tests/conftest.py`'s `isolated_storage` fixture)
and from needing a real display, browser, microphone, or API keys (a
pyautogui stub is installed automatically if there's no real display, and
the browser/voice tests fake out `playwright`, `speech_recognition`, and
`sounddevice` entirely). The Electron frontend has no automated tests of
its own yet — `main.js`/`preload.js`/`troy/ipc_host.py`'s protocol was
exercised manually end to end (`app.ping`, `context.get`, `settings.get`).

## Layout

```
main.py                     entry point -- `python -u main.py --ipc`, spawned by electron/main.js
tests/                      pytest suite (see "Tests" above)
electron/                   the Electron desktop frontend (see electron/README.md)
  main.js                   spawns the Python backend, bridges stdio IPC <-> Electron IPC
  preload.js                exposes window.troy.{request,on,off} to the renderer
  renderer/index.html       bare wiring template -- every window.troy call works, styling doesn't matter yet
  package.json
troy/
  ipc_host.py                the whole Electron-facing API surface -- read this first
  agent.py                  the observe -> think -> act loop; also builds memory + situational context
  dispatcher.py              command name -> executor, normalizes results
  tools_all.py               every tool + the tool registry + registrations (includes get_context_snapshot)
  confirmation.py            real app-state approval queue
  system_prompt.py           builds the prompt (tool list is generated)
  schedule_spec.py           "every Monday at 22:00" -> a schedule spec; next-run maths; wording
  scheduler.py               persistent background task scheduler (retries, missed runs, recovery, logs)
  task_runner.py             one scheduled attempt: prompt, isolated agent, outcome
  task_context.py            unattended-run rules (pre-approved commands only)
  tools_tasks.py             schedule_task, list_tasks, cancel_task, modify_task, ..., task_result
  extra_tools.py             list_extra_tools, the usage gate, forgetting the list afterwards
  sessions.py / memory.py    persistence
  escalation.py               last-resort hand-off to a secondary model
  llm_client.py               provider calls (Groq / OpenRouter / Gemini / NVIDIA NIM / LM Studio)
  mobile_server.py            local-network mobile web UI (stdlib http.server) -- separate from electron/
                              phone voice routes: /api/voice/* (session, utterance, audio download)
  browser_worker.py           persistent Playwright browser on its own thread (backs the web_* tools)
  ui_automation.py             real Windows UI Automation (accessibility tree)
  voice.py                    STT engines (Google, faster-whisper) + TTS (pyttsx3)
  tts.py                      the TTS engine chain (Piper / Edge / SAPI) + streaming Speaker
  speech_text.py              clean-for-speech, sentence splitting, stop/end phrase detection
  audio_in.py                 shared audio plumbing: Endpointer (adaptive VAD), resampling
  voice_mode.py               full hands-free voice mode orchestrator (PC + phone ears/mouth)
  wake_listener.py            always-on wake-word background listener
  settings_store.py           persistent settings (written by the model-switch tools too)
  tls.py                      self-signed certificate + https for the phone's microphone
  remote.py                   every way to reach Troy (LAN, LAN-HTTPS, Tailscale)
  power.py                    power saving mode (off / auto on battery / on)
  ui_bridge.py                how Troy's tools reach the UI (widget, views, theme)
  tools_app.py                Troy controlling his own app: widget, new chat, settings
```
