"""
Troy Assistant - Entry Point

The frontend is Electron (see electron/); this process is its backend.
Electron's main process spawns this exact command as a child process and
talks to it over stdin/stdout (troy/ipc_host.py) -- deliberately NOT an
HTTP server on 127.0.0.1:8000 or any other port, which is the approach
that was tried and didn't work reliably here. There is no GUI code in
this file or in troy/ipc_host.py at all; the window itself is entirely
Electron's job.

Usage (this is exactly the command electron/main.js runs):
    python -u main.py --ipc

`-u` (unbuffered stdout) matters: without it, Python may buffer stdout in
a way that delays every line Electron is waiting to read, since stdout
isn't attached to a real terminal when it's a child process's pipe.
"""

import sys

# Force UTF-8 on stdin/stdout/stderr before anything else runs (including
# before any `troy.*` import below, since importing troy.logger sets up a
# console log handler that writes to stderr immediately). This is the fix
# for a real, reported crash:
#   UnicodeEncodeError: 'charmap' codec can't encode character '\u2011'
#   in position 89: character maps to <undefined>
# On Windows, a pipe (which is what stdout/stderr actually are once
# Electron spawns this as a child process -- never a real console) doesn't
# get UTF-8 by default the way an interactive terminal might: Python falls
# back to the process's legacy ANSI codepage ("mbcs"/cp1252, i.e.
# "charmap"), which cannot encode most non-ASCII text -- em dashes, curly
# quotes, non-breaking hyphens, accented names, most emoji, ... all of
# which show up constantly in normal LLM output and in web/API results
# (Wikipedia summaries, news headlines, etc.). `.reconfigure()` (Python
# 3.7+) is safe to call unconditionally on every platform; where a stream
# is already UTF-8 (Linux/macOS, or PYTHONUTF8=1) this is a no-op.
# `errors="replace"` is a last-resort safety net on top of that -- utf-8
# itself can represent every Unicode code point, so this should never
# actually trigger, but a substituted "?" beats a hard crash either way.
for _stream in (sys.stdin, sys.stdout, sys.stderr):
    if hasattr(_stream, "reconfigure"):
        _stream.reconfigure(encoding="utf-8", errors="replace")


def main():
    if "--ipc" not in sys.argv:
        print(
            "Troy's desktop frontend is now Electron (see electron/), not a "
            "console mode -- this process only speaks the IPC protocol on "
            "stdin/stdout. Run it as: python -u main.py --ipc\n"
            "(Electron's main.js does this for you automatically -- you "
            "shouldn't normally need to run this by hand.)",
            file=sys.stderr,
        )
        sys.exit(1)

    from troy.ipc_host import run_forever
    run_forever()


if __name__ == "__main__":
    main()
