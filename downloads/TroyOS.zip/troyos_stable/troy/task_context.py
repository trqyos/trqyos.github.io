"""
What a scheduled-task run is allowed to do, and what it has done so far.

A scheduled task runs with nobody watching, so the usual "show an Approve button
and wait" safety model can't work for it: the prompt would sit there unanswered
at 22:00. Instead:

  * the user approves SPECIFIC commands for a task ahead of time (an Approve card
    shown when the task is created, or the Approve button in the Tasks screen);
  * during a run, a command that needs approval executes only if it matches one of
    those exact `name` / `name:arg` strings. Anything else is refused and reported
    back as "needs approval" -- it is never silently run, and never queued as a
    prompt that could later be answered in the wrong chat.

This module is just the shared state for that: tools_all.run() asks it whether a
risky command is pre-approved, the task tools report into it, and the scheduler
reads the result. It is thread-local, so a run on its own worker thread never
leaks into a normal chat turn happening on another thread.
"""

import threading
from contextlib import contextmanager

_local = threading.local()


def normalise(name: str, arg: str = "") -> str:
    """'sleep_computer' or 'shutdown_computer:30' -- the exact form grants are stored in."""
    name, arg = (name or "").strip(), (arg or "").strip()
    return f"{name}:{arg}" if arg else name


class RunContext:
    def __init__(self, task_id: str, grants=(), attempt: int = 1, on_action=None):
        self.task_id = task_id
        self.grants = {g.strip() for g in grants if g and g.strip()}
        self.attempt = attempt
        self.on_action = on_action          # callback(name, arg, message) after every successful action
        self.denied: list = []              # commands refused for lack of pre-approval
        self.reported = None                # (status, summary) from task_result
        self.preapproved_used: list = []

    def allows(self, name: str, arg: str = "") -> bool:
        return normalise(name, arg) in self.grants

    def deny(self, name: str, arg: str = "") -> None:
        key = normalise(name, arg)
        if key not in self.denied:
            self.denied.append(key)


def current():
    return getattr(_local, "ctx", None)


@contextmanager
def activate(ctx: RunContext):
    previous = getattr(_local, "ctx", None)
    _local.ctx = ctx
    try:
        yield ctx
    finally:
        _local.ctx = previous
