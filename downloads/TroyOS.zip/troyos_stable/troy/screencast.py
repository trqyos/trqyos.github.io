"""
Live screen sharing for the phone page.

Frames are captured, resized and JPEG-encoded here; troy/mobile_server.py
streams them as MJPEG (multipart/x-mixed-replace), which any phone browser
plays inside a plain <img> tag -- no plugins, no WebRTC, works over Wi-Fi and
Tailscale. It is view-only: nothing here can click or type.

Capture backends, fastest first: `mss`, Pillow's ImageGrab, pyautogui.
Each streaming thread creates its own grabber (mss is not thread-safe).
"""

import io
import time

from .logger import logger

_PRESETS = {
    "saver": {"width": 640, "quality": 40, "fps": 4},
    "balanced": {"width": 960, "quality": 55, "fps": 8},
    "sharp": {"width": 1440, "quality": 72, "fps": 10},
}


def preset(name: str) -> dict:
    return dict(_PRESETS.get(name, _PRESETS["balanced"]))


class ScreenError(Exception):
    pass


class Grabber:
    def __init__(self):
        self._mss = None
        try:
            import mss
            self._mss = mss.mss()
            self.backend = "mss"
        except Exception:  # noqa: BLE001 - not installed / no display
            self.backend = "pillow"

    def monitors(self) -> list:
        """[{index, width, height, left, top, primary}] -- index 0 is "all screens"."""
        if self._mss is not None:
            return [{"index": i, "left": m["left"], "top": m["top"], "width": m["width"], "height": m["height"], "primary": i == 1}
                    for i, m in enumerate(self._mss.monitors)]
        try:
            import pyautogui
            w, h = pyautogui.size()
            return [{"index": 1, "left": 0, "top": 0, "width": w, "height": h, "primary": True}]
        except Exception:  # noqa: BLE001
            return []

    def grab(self, monitor: int = 1):
        """-> a PIL RGB image of that monitor (0 = every screen together)."""
        from PIL import Image
        if self._mss is not None:
            mons = self._mss.monitors
            shot = self._mss.grab(mons[monitor if 0 <= monitor < len(mons) else 1])
            return Image.frombytes("RGB", shot.size, shot.bgra, "raw", "BGRX")
        try:
            from PIL import ImageGrab
            return ImageGrab.grab(all_screens=(monitor == 0)).convert("RGB")
        except Exception:  # noqa: BLE001
            import pyautogui
            return pyautogui.screenshot().convert("RGB")

    def close(self):
        if self._mss is not None:
            try:
                self._mss.close()
            except Exception:  # noqa: BLE001
                pass


def _draw_cursor(img, monitor_info, scale):
    """Marks where the mouse is, since screen grabbers don't capture the pointer."""
    try:
        import pyautogui
        from PIL import ImageDraw
        x, y = pyautogui.position()
        x = (x - (monitor_info or {}).get("left", 0)) * scale
        y = (y - (monitor_info or {}).get("top", 0)) * scale
        if 0 <= x < img.width and 0 <= y < img.height:
            d = ImageDraw.Draw(img)
            r = max(6, int(img.width / 110))
            d.ellipse([x - r, y - r, x + r, y + r], outline=(255, 255, 255), width=2)
            d.ellipse([x - 2, y - 2, x + 2, y + 2], fill=(255, 80, 80))
    except Exception:  # noqa: BLE001 - the pointer is a nicety
        pass


def encode_frame(image, width: int = 960, quality: int = 55, cursor_info=None, draw_cursor: bool = True) -> bytes:
    """Resize to `width` (never enlarge) and encode as JPEG."""
    from PIL import Image
    scale = 1.0
    if image.width > width:
        scale = width / image.width
        image = image.resize((width, max(1, round(image.height * scale))), Image.BILINEAR)
    if draw_cursor:
        _draw_cursor(image, cursor_info, scale)
    buf = io.BytesIO()
    image.save(buf, format="JPEG", quality=max(20, min(90, int(quality))), optimize=False)
    return buf.getvalue()


def stream_frames(width=960, quality=55, fps=8, monitor=1, should_stop=lambda: False, max_fps=10):
    """Yields JPEG bytes at roughly `fps` until should_stop() is true."""
    fps = max(1, min(int(fps), int(max_fps), 30))
    interval = 1.0 / fps
    grabber = Grabber()
    try:
        info = next((m for m in grabber.monitors() if m["index"] == monitor), None)
        while not should_stop():
            started = time.time()
            try:
                frame = encode_frame(grabber.grab(monitor), width, quality, info)
            except Exception as exc:  # noqa: BLE001
                logger.warning("Screen capture failed: %s", exc)
                raise ScreenError(str(exc)) from exc
            yield frame
            time.sleep(max(0.0, interval - (time.time() - started)))
    finally:
        grabber.close()


def snapshot(width=1280, quality=70, monitor=1) -> bytes:
    grabber = Grabber()
    try:
        info = next((m for m in grabber.monitors() if m["index"] == monitor), None)
        return encode_frame(grabber.grab(monitor), width, quality, info)
    finally:
        grabber.close()
