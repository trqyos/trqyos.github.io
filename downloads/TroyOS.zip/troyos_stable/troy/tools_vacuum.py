"""
Model-facing tools for the Xiaomi Robot Vacuum S20+ (category "vacuum").

All logic lives in troy/vacuum.py; these are thin wrappers so the registry, the native-schema builder and the approval
model stay unchanged. Nothing here needs an Approve card: starting, pausing, docking and changing suction are harmless
and reversible, and keeping them card-free is what lets a scheduled task ("start the vacuum at 10 every weekday")
run unattended. (Resetting consumable counters is deliberately NOT a tool: see docs/VACUUM.md.)
"""

from . import vacuum
from .command_parser import split_args
from .tools_all import register


def vacuum_status(_arg: str = "") -> dict:
    return vacuum.status()


def vacuum_rooms(_arg: str = "") -> dict:
    return vacuum.rooms()


def vacuum_consumables(_arg: str = "") -> dict:
    return vacuum.consumables()


def vacuum_start(arg: str = "") -> dict:
    return vacuum.start((arg or "").strip() or None)


def vacuum_clean_rooms(arg: str = "") -> dict:
    return vacuum.clean_rooms(arg)


def vacuum_pause(_arg: str = "") -> dict:
    return vacuum.pause()


def vacuum_resume(_arg: str = "") -> dict:
    return vacuum.resume()


def vacuum_stop(_arg: str = "") -> dict:
    return vacuum.stop()


def vacuum_dock(_arg: str = "") -> dict:
    return vacuum.dock()


def vacuum_locate(_arg: str = "") -> dict:
    return vacuum.locate()


def vacuum_set(arg: str = "") -> dict:
    parts = split_args(arg)
    if len(parts) < 2:
        return {"success": False, "message": f"Use vacuum_set:<setting>|<value>. Settings: {', '.join(vacuum.SETTING_NAMES)}."}
    return vacuum.set_option(parts[0], "|".join(parts[1:]))


register("vacuum_status", vacuum_status, "Robot vacuum (Xiaomi S20+): what it is doing now, battery, and its current cleaning settings.", category="vacuum", info=True)
register("vacuum_rooms", vacuum_rooms, "Robot vacuum: the rooms on its map (names and ids) with each room's saved cleaning settings.", category="vacuum", info=True)
register("vacuum_consumables", vacuum_consumables, "Robot vacuum: how much life is left in the brushes, filter and mop pad.", category="vacuum", info=True)
register("vacuum_start", vacuum_start, "Robot vacuum: start cleaning the whole home (resumes if it was paused). Optional mode: sweep, mop, sweep_mop or sweep_then_mop.",
         category="vacuum", arg_hint="[<mode>]")
register("vacuum_clean_rooms", vacuum_clean_rooms, "Robot vacuum: clean only the named rooms (names from vacuum_rooms, comma-separated), using each room's saved settings.",
         category="vacuum", arg_hint="<rooms>")
register("vacuum_pause", vacuum_pause, "Robot vacuum: pause the current cleaning (it stays where it is).", category="vacuum")
register("vacuum_resume", vacuum_resume, "Robot vacuum: continue a paused cleaning.", category="vacuum")
register("vacuum_stop", vacuum_stop, "Robot vacuum: stop cleaning for good (not the same as pause); it stays where it is.", category="vacuum")
register("vacuum_dock", vacuum_dock, "Robot vacuum: send it back to its charging dock.", category="vacuum")
register("vacuum_locate", vacuum_locate, "Robot vacuum: make it announce itself so the user can find it.", category="vacuum")
register("vacuum_set", vacuum_set, "Robot vacuum settings: suction (silent/standard/strong/max), mop_water (off/low/medium/high), mode (sweep/mop/sweep_mop/sweep_then_mop), "
         "passes (1 or 2) or volume (0-100).", category="vacuum", arg_hint="<suction|mop_water|mode|passes|volume>|<value>")
