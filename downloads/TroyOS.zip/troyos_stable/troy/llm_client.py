"""
Troy Assistant - LLM Client

Thin wrapper around every provider's OpenAI-compatible chat completion API
(Groq, OpenRouter, Gemini, NVIDIA NIM/build.nvidia.com, and optionally a
local LM Studio server) -- one function, `_call_openai_compatible`, handles
all of them, since they all speak the same request/response shape. Because
free model slugs get renamed/retired often (this has already happened once
in this project), this client doesn't hardcode one model name per
provider -- it tries an ordered list of candidates and uses the first one
that works. If everything fails, the raised error lists every attempt, so
you can see exactly what broke instead of one misleading "last error" line.

Streaming + force-stop: `chat()` streams the response (Server-Sent Events)
instead of waiting for the whole completion, and accepts an optional
`stop_check` callable that's polled between chunks. The moment it returns
True, the in-flight HTTP connection is closed and StoppedByUser is raised --
this is what lets the UI's Force Stop button interrupt Troy mid-generation,
not just in between commands. See troy/stop_control.py for the flag itself.
"""

import json
import time
import re
from dataclasses import dataclass, field

import requests

from . import config, context_budget
from .logger import logger


class LLMError(Exception):
    pass


class StoppedByUser(LLMError):
    """Raised when generation is aborted mid-stream by the force-stop button.
    Deliberately a distinct type from a normal LLMError: agent.py needs to
    treat this as 'stop the whole turn quietly', not 'log an error and try
    the next provider'."""
    pass


# Some models on the Groq free tier (qwen3 family in particular) are
# "reasoning" models that emit their chain-of-thought inline in the message
# content, wrapped in <think>...</think>, instead of (or in addition to) a
# separate `reasoning` field. Left alone, that raw scratchpad text leaks
# straight into the command parser (breaking the strict command-line format)
# and into vision descriptions (showing up verbatim in the UI's tool-result
# badges instead of a clean description). Every response goes through this
# before it's used anywhere.
_THINK_BLOCK_RE = re.compile(r"<think>.*?</think>", re.IGNORECASE | re.DOTALL)
_OPEN_THINK_RE = re.compile(r"<think>.*", re.IGNORECASE | re.DOTALL)  # unclosed at truncation


def _strip_reasoning(text: str) -> str:
    if not text:
        return text
    text = _THINK_BLOCK_RE.sub("", text)
    text = _OPEN_THINK_RE.sub("", text)
    return text.strip()


_NO_EXTRAS = set()      # (provider, model) pairs that rejected the speed-up parameters


def _extra_params(label: str, model: str) -> dict:
    """Parameters that make reasoning models answer faster. They are only sent
    to models known to accept them, and dropped for good (see _NO_EXTRAS) the
    first time a model rejects them."""
    if not config.LLM_FAST or (label, model) in _NO_EXTRAS:
        return {}
    m = model.lower()
    if label == "groq":
        if "gpt-oss" in m:
            return {"reasoning_effort": "low"}
        if "qwen3" in m:
            return {"reasoning_effort": "none"}
    if label == "openrouter" and "gpt-oss" in m:
        return {"reasoning": {"effort": "low"}}
    if label == "gemini" and "2.5-flash" in m:
        return {"reasoning_effort": "none"}
    if label == "nvidia" and "nemotron-3.5" in m:
        return {"chat_template_kwargs": {"enable_thinking": False}}
    return {}


class NoNativeTools(LLMError):
    """No model in the chain accepts native tool calls right now: the caller should use the text protocol."""


class ToolsUnsupported(LLMError):
    """This one model/server rejected the `tools` field."""


_NO_TOOLS = set()       # (provider, model) pairs that rejected native tool calling (remembered until restart)


@dataclass
class Reply:
    """One model answer in native mode: what it said, and the tool calls it made (arguments are still a JSON string)."""
    text: str = ""
    tool_calls: list = field(default_factory=list)       # [{"id", "name", "arguments"}]
    provider: str = ""
    model: str = ""

    def __bool__(self):                                  # an empty reply is still a reply (the chain must not retry it)
        return True


def _tools_rejected(status: int, body: str) -> bool:
    low = body.lower()
    if "tool_use_failed" in low or "failed_generation" in low:
        return False                                     # the model flubbed a call; it does support tools
    return status in (400, 404, 405, 422) and any(w in low for w in ("tool", "function call", "function_call", "functions"))


def _stream_completion(
    base_url: str, api_key: str, model: str, messages: list,
    stop_check=None, timeout=None, label: str = "", max_tokens: int = None, on_text=None,
    tools: list = None, on_tool_start=None,
) -> tuple:
    """Streams a chat completion and reassembles it, polling stop_check between chunks so a force-stop can abort
    generation immediately instead of waiting for the whole response to arrive.
    -> (text, tool_calls) where tool_calls is [{"id", "name", "arguments": <json string>}]."""
    if not api_key:
        raise LLMError(f"No API key configured for endpoint {base_url}")
    if timeout is None:
        # (connect, read-between-chunks). A local model may need a long time
        # to load before its first token; a cloud API that hasn't answered in
        # 45s is not going to.
        timeout = (8, 150) if label == "lmstudio" else (8, 45)
    max_tokens = max_tokens or config.LLM_MAX_OUTPUT_TOKENS

    def _post(extra: dict):
        body = {"model": model, "messages": messages, "temperature": 0.2 if tools else 0.4, "stream": True, "max_tokens": max_tokens}
        if tools:
            body["tools"] = tools
        body.update(extra)
        return requests.post(
            f"{base_url}/chat/completions",
            headers={"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"},
            json=body, timeout=timeout, stream=True,
        )

    extra = _extra_params(label, model)
    response = _post(extra)
    if not response.ok and extra and response.status_code in (400, 422):
        # This model doesn't understand the speed-up parameter: remember that
        # and retry once plain, rather than failing the whole turn over it.
        response.close()
        _NO_EXTRAS.add((label, model))
        response = _post({})
    if not response.ok:
        # Surface the API's own error body -- it usually says exactly what's
        # wrong (decommissioned model, bad key, rate limit, etc). Have to
        # read the body before it's closed below.
        body = response.text[:300]
        status = response.status_code
        response.close()
        if tools and _tools_rejected(status, body):
            raise ToolsUnsupported(f"{status} {response.reason}: {body}")
        raise LLMError(f"{status} {response.reason}: {body}")

    # requests guesses response.encoding from the Content-Type header, and
    # falls back to ISO-8859-1 per the old HTTP spec default when no charset
    # is given -- which most of these APIs don't send on a streamed
    # text/event-stream response. Every one of them actually sends UTF-8.
    response.encoding = "utf-8"

    content_parts = []
    reasoning_parts = []
    calls: dict = {}                 # stream index -> {"id", "name", "arguments"}
    last_index = None
    if on_text:
        on_text("")                                  # a new attempt: whatever was streamed before is void
    try:
        for raw_line in response.iter_lines(decode_unicode=True):
            if stop_check is not None and stop_check():
                raise StoppedByUser("Generation stopped by user.")
            if not raw_line:
                continue
            if not raw_line.startswith("data:"):
                continue
            payload = raw_line[len("data:"):].strip()
            if payload == "[DONE]":
                break
            try:
                chunk = json.loads(payload)
            except json.JSONDecodeError:
                continue
            choices = chunk.get("choices") or []
            if not choices:
                continue
            delta = choices[0].get("delta") or {}
            piece = delta.get("content")
            if piece:
                content_parts.append(piece)
                if on_text:
                    on_text("".join(content_parts))
            reasoning_piece = delta.get("reasoning") or delta.get("reasoning_content")
            if reasoning_piece:
                reasoning_parts.append(reasoning_piece)
            for tc in delta.get("tool_calls") or []:
                fn = tc.get("function") or {}
                idx = tc.get("index")
                if idx is None:      # some servers omit the index: a new id starts a new call, otherwise it continues the last
                    idx = last_index if (last_index is not None and not tc.get("id")) else len(calls)
                last_index = idx
                call = calls.get(idx)
                if call is None:
                    call = calls[idx] = {"id": "", "name": "", "arguments": ""}
                    if on_tool_start:
                        on_tool_start()
                if tc.get("id") and not call["id"]:
                    call["id"] = tc["id"]
                if fn.get("name") and not call["name"]:
                    call["name"] = fn["name"]
                args = fn.get("arguments")
                if isinstance(args, dict):           # a few local servers send the arguments already decoded
                    call["arguments"] = json.dumps(args)
                elif args:
                    call["arguments"] += args
    finally:
        response.close()

    content = _strip_reasoning("".join(content_parts))
    tool_calls = [calls[i] for i in sorted(calls) if calls[i]["name"]]
    for n, c in enumerate(tool_calls):
        c["id"] = c["id"] or f"call_{n}_{int(time.time() * 1000) % 100000}"
    if not content and not tool_calls:
        # Some reasoning models put EVERYTHING in a separate `reasoning`
        # field and leave `content` empty on intermediate turns -- fall back
        # to that rather than returning nothing, which would otherwise look
        # like a silent, unexplained failure to the agent loop.
        content = _strip_reasoning("".join(reasoning_parts))
    return content, tool_calls


def _call_openai_compatible(
    base_url: str, api_key: str, model: str, messages: list,
    stop_check=None, timeout=None, label: str = "", max_tokens: int = None, on_text=None,
) -> str:
    """Text protocol: streams a chat completion and returns the text."""
    content, _ = _stream_completion(base_url, api_key, model, messages, stop_check=stop_check, timeout=timeout,
                                    label=label, max_tokens=max_tokens, on_text=on_text)
    return content


def _call_native(base_url, api_key, model, messages, tools, stop_check=None, timeout=None, label="",
                 max_tokens=None, on_text=None, on_tool_start=None) -> Reply:
    """Native function calling: the same request with a `tools` field; returns the text and the tool calls."""
    text, calls = _stream_completion(base_url, api_key, model, messages, stop_check=stop_check, timeout=timeout, label=label,
                                     max_tokens=max_tokens, on_text=on_text, tools=tools, on_tool_start=on_tool_start)
    return Reply(text=text, tool_calls=calls, provider=label, model=model)


# ---------------------------------------------------------------------------
# Failure memory. Without this, a model that is over its rate limit, too small
# for the request, or has been retired is retried (and fails) on EVERY turn,
# adding a wasted round trip each time -- the main reason replies felt slow
# whenever the first model in a list was unusable.
# ---------------------------------------------------------------------------
_cooldowns = {}  # (provider, model or None) -> (expires_at, reason)


def _cooldown_for(error: str):
    """-> (seconds, provider_wide) for an error string like '429 Too Many ...'."""
    low = error.lower()
    m = re.match(r"\s*(\d{3})", error)
    code = int(m.group(1)) if m else 0
    if code == 413 or "request too large" in low or "payload too large" in low:
        return 600, False
    if code == 429 or "rate limit" in low or "quota" in low:
        wait = 60.0
        t = re.search(r"try again in (?:(\d+)m)?\s*(?:([\d.]+)s)?", low)
        if t and (t.group(1) or t.group(2)):
            wait = int(t.group(1) or 0) * 60 + float(t.group(2) or 0) + 1
        return min(max(wait, 15), 900), False
    if code in (401, 403) or "invalid api key" in low:
        return 900, True
    if code == 404 or "decommissioned" in low or "does not exist" in low or "not found" in low:
        return 6 * 3600, False
    if code >= 500 or "timed out" in low or "timeout" in low or "connection" in low:
        return 45, False
    if code == 400:
        return 300, False
    return 30, False


def _penalize(label: str, model: str, error: str):
    seconds, provider_wide = _cooldown_for(error)
    _cooldowns[(label, None if provider_wide else model)] = (time.time() + seconds, error.strip()[:90])


def _cooling(label: str, model) -> int:
    """Seconds left on a cooldown for this model/provider (0 = usable)."""
    now = time.time()
    left = 0
    for key in ((label, None), (label, model)):
        entry = _cooldowns.get(key)
        if entry and entry[0] > now:
            left = max(left, int(entry[0] - now) + 1)
    return left


def clear_cooldowns():
    _cooldowns.clear()


def _budget_for(label: str) -> tuple:
    """-> (token budget for the request, max chars per message)."""
    if label == "lmstudio":
        ctx = lmstudio_context()
        out = min(config.LLM_MAX_OUTPUT_TOKENS, max(256, ctx // 4))
        return max(700, ctx - out - 150), 700
    return config.CONTEXT_BUDGET_TOKENS, 1800


def _max_out_for(label: str) -> int:
    if label == "lmstudio":
        return min(config.LLM_MAX_OUTPUT_TOKENS, max(256, lmstudio_context() // 4))
    return config.LLM_MAX_OUTPUT_TOKENS


def _provider_limit(error: str):
    """Pulls 'Limit 8000' out of a 413 body, if the provider states it."""
    m = re.search(r"limit[^\d]{0,12}(\d{3,6})", error, re.IGNORECASE)
    return int(m.group(1)) if m else None


def _try_provider_chain(providers_and_models: list, messages, stop_check=None, trim: bool = True,
                        build_messages=None, on_text=None, native: dict = None):
    """
    providers_and_models: list of (provider_label, base_url, api_key, [model, ...])
    Tries every model for every provider, in order, and returns the first
    success. If all fail, raises LLMError listing every attempt. A
    StoppedByUser from any attempt is propagated immediately rather than
    being treated as 'try the next candidate' -- the user asked for
    everything to stop, not for Troy to keep trying other models.

    Each request is first fitted to that provider's token budget; models that
    recently failed are skipped (see the cooldown notes above) unless nothing
    else is left to try.
    """
    attempts = []
    skipped = []
    no_tools = [0]            # native mode: candidates that can't do tool calls (skipped or rejected them)
    other_fail = [0]          # native mode: candidates that failed for some OTHER reason (network, rate limit, ...)

    def attempt(label, base_url, api_key, model):
        if native is not None:
            # native function calling: build_messages(label) returns the already-trimmed wire messages for that provider
            def once():
                return _call_native(base_url, api_key, model, build_messages(label), native["tools"], stop_check=stop_check, label=label,
                                    max_tokens=_max_out_for(label), on_text=on_text, on_tool_start=native.get("on_tool_start"))
            try:
                return once()
            except LLMError as exc:
                if "tool_use_failed" not in str(exc) and "failed_generation" not in str(exc):
                    raise
                logger.info("%s/%s produced a malformed tool call; retrying once.", label, model)
                return once()                      # the model flubbed one call (random): a second sample usually gets it right
        if build_messages is not None:
            msgs = build_messages(label)
        elif trim:
            budget, cap = _budget_for(label)
            msgs = context_budget.fit_messages(messages, budget, message_cap_chars=cap)
        else:
            msgs = messages
        max_out = _max_out_for(label)
        try:
            return _call_openai_compatible(base_url, api_key, model, msgs, stop_check=stop_check, label=label, max_tokens=max_out, on_text=on_text)
        except LLMError as exc:
            limit = _provider_limit(str(exc)) if str(exc).lstrip().startswith("413") else None
            if limit and trim and build_messages is None:
                # The provider told us its real limit: shrink to it and retry once.
                shrunk = context_budget.fit_messages(messages, limit - max_out - 400, message_cap_chars=900)
                logger.info("%s/%s said its limit is %s tokens; retrying with a trimmed request.", label, model, limit)
                return _call_openai_compatible(base_url, api_key, model, shrunk, stop_check=stop_check, label=label, max_tokens=max_out, on_text=on_text)
            raise

    def run(label, base_url, api_key, model):
        try:
            return attempt(label, base_url, api_key, model), None
        except StoppedByUser:
            raise
        except ToolsUnsupported as exc:
            # works fine as a text model: remember it can't do tools, but don't put it on cooldown
            _NO_TOOLS.add((label, model))
            no_tools[0] += 1
            attempts.append(f"{label}/{model}: no native tool support ({exc})")
            logger.info("%s/%s rejected native tool calls; using the text protocol for it.", label, model)
            return None, exc
        except Exception as exc:  # noqa: BLE001 - try the next candidate on ANY error
            other_fail[0] += 1
            _penalize(label, model, str(exc))
            attempts.append(f"{label}/{model}: {exc}")
            logger.warning("LLM attempt failed: %s/%s: %s", label, model, exc)
            return None, exc

    for label, base_url, api_key, models in providers_and_models:
        if stop_check is not None and stop_check():
            raise StoppedByUser("Generation stopped by user.")
        if not api_key:
            attempts.append(f"{label}: skipped (no API key set)")
            continue
        for model in models:
            if stop_check is not None and stop_check():
                raise StoppedByUser("Generation stopped by user.")
            if native is not None:
                if (label, model) in _NO_TOOLS:
                    no_tools[0] += 1
                    attempts.append(f"{label}/{model}: skipped (no native tool support)")
                    continue
            wait = _cooling(label, model)
            if wait:
                attempts.append(f"{label}/{model}: skipped (failed recently, retry in {wait}s)")
                skipped.append((label, base_url, api_key, model))
                continue
            result, _ = run(label, base_url, api_key, model)
            if result is not None:
                return result

    # Everything usable failed: rather than give up, give the skipped ones a go.
    for label, base_url, api_key, model in skipped:
        if stop_check is not None and stop_check():
            raise StoppedByUser("Generation stopped by user.")
        result, _ = run(label, base_url, api_key, model)
        if result is not None:
            return result

    details = "\n".join(f"  - {line}" for line in attempts)
    if native is not None and no_tools[0] and not other_fail[0]:
        raise NoNativeTools(f"No available model accepts native tool calls:\n{details}")
    raise LLMError(f"All providers/models failed:\n{details}")


def _apply_override(chain: list, override: str) -> list:
    """
    Moves a manually-selected model to the front of its provider's candidate
    list, if the override matches one of the providers in this chain. Never
    removes the rest of the chain -- a bad manual pick still falls back
    through the normal candidates instead of hard-failing the assistant.
    override format: "provider:model_slug", e.g. "groq:openai/gpt-oss-120b".
    """
    if not override or ":" not in override:
        return chain

    provider, model = override.split(":", 1)
    provider = provider.strip().lower()
    model = model.strip()
    if not model:
        return chain

    new_chain = []
    for label, base_url, api_key, models in chain:
        if label == provider:
            models = [model] + [m for m in models if m != model]
        new_chain.append((label, base_url, api_key, models))
    return new_chain


_LM = {"at": 0.0, "models": [], "error": ""}
_LM_TTL_OK, _LM_TTL_FAIL = 20.0, 8.0
# Names of common local vision-language models, used only when LM Studio's
# own API doesn't say which models can see images.
_VISION_NAME = re.compile(
    r"(-vl\b|-vl-|vl-|vision|llava|bakllava|gemma-?3|gemma-?4|minicpm-v|pixtral|moondream|smolvlm|internvl|"
    r"qwen2(\.5)?-vl|qwen3-vl|mistral-small-3|ministral|magistral|llama-?3\.2.*(11b|90b)|llama-?4|phi-?3.*vision|phi-?4.*multimodal|granite.*vision)",
    re.IGNORECASE)


def _lmstudio_root() -> str:
    return re.sub(r"/v1/?$", "", config.LMSTUDIO_BASE_URL.rstrip("/"))


def lmstudio_models_info(force: bool = False) -> list:
    """What LM Studio has: [{id, vision, loaded, context, max_context, type}].

    Uses LM Studio's own REST API (/api/v0/models), which says which models
    are vision-language models ("vlm"), which are loaded, and their context
    length; falls back to the OpenAI-style /v1/models list plus a name
    heuristic. Cached for a few seconds and given a short timeout so that
    asking about LM Studio can never stall the app when it isn't running --
    that stall was what made the Settings pages hang."""
    if not config.LMSTUDIO_ENABLED and not force:
        return []
    now = time.time()
    ttl = _LM_TTL_OK if _LM["models"] else _LM_TTL_FAIL
    if not force and now - _LM["at"] < ttl:
        return _LM["models"]
    models, error = [], ""
    try:
        resp = requests.get(_lmstudio_root() + "/api/v0/models", timeout=1.5)
        if resp.ok:
            for m in resp.json().get("data", []):
                mid, typ = m.get("id"), (m.get("type") or "llm").lower()
                if not mid or typ.startswith("embed"):
                    continue
                models.append({
                    "id": mid, "type": typ, "vision": typ == "vlm",
                    "loaded": (m.get("state") or "") == "loaded",
                    "context": int(m.get("loaded_context_length") or 0),
                    "max_context": int(m.get("max_context_length") or 0),
                })
        else:
            raise LLMError(f"{resp.status_code} from /api/v0/models")
    except Exception as exc:  # noqa: BLE001 - older LM Studio, or not running: try the plain endpoint
        error = str(exc)
        try:
            resp = requests.get(f"{config.LMSTUDIO_BASE_URL}/models", timeout=1.5)
            if resp.ok:
                for m in resp.json().get("data", []):
                    mid = m.get("id")
                    if mid and "embed" not in mid.lower():
                        models.append({"id": mid, "type": "llm", "vision": bool(_VISION_NAME.search(mid)),
                                       "loaded": True, "context": 0, "max_context": 0})
                error = ""
        except Exception as exc2:  # noqa: BLE001
            error = str(exc2)
            logger.debug("LM Studio model discovery failed: %s", exc2)
    _LM.update(at=now, models=models, error=error)
    return models


def lmstudio_error() -> str:
    return _LM["error"]


def lmstudio_context() -> int:
    """Context window (tokens) of the model Troy will use, so the prompt and
    history can be sized to fit it. Falls back to LMSTUDIO_CONTEXT_TOKENS."""
    info = lmstudio_models_info()
    if config.LMSTUDIO_TEXT_MODEL:
        info = [m for m in info if m["id"] == config.LMSTUDIO_TEXT_MODEL] or info
    for m in info:
        if m["loaded"] and m["context"]:
            return m["context"]
    return max(1024, config.LMSTUDIO_CONTEXT_TOKENS)


def _lmstudio_models(kind: str) -> list:
    override = config.LMSTUDIO_TEXT_MODEL if kind == "text" else config.LMSTUDIO_VISION_MODEL
    if override:
        return [override]
    info = lmstudio_models_info()
    if kind == "vision":
        info = [m for m in info if m["vision"]]
    # Loaded models first: trying an unloaded one makes LM Studio load it, which can take a while.
    ordered = [m for m in info if m["loaded"]] + [m for m in info if not m["loaded"]][:2]
    ids = [m["id"] for m in ordered]
    return ids or (["local-model"] if kind == "text" else [])


def _all_providers() -> dict:
    """label -> (label, base_url, api_key). LM Studio is only included when
    explicitly enabled, since attempting it otherwise would mean a slow
    'connection refused' on every single turn for anyone not running it."""
    providers = {
        "groq": ("groq", config.GROQ_BASE_URL, config.GROQ_API_KEY),
        "openrouter": ("openrouter", config.OPENROUTER_BASE_URL, config.OPENROUTER_API_KEY),
        "gemini": ("gemini", config.GEMINI_BASE_URL, config.GEMINI_API_KEY),
        "nvidia": ("nvidia", config.NVIDIA_BASE_URL, config.NVIDIA_API_KEY),
    }
    if config.LMSTUDIO_ENABLED:
        providers["lmstudio"] = ("lmstudio", config.LMSTUDIO_BASE_URL, config.LMSTUDIO_API_KEY)
    return providers


def _provider_order() -> list:
    """PRIMARY_PROVIDER first, then whatever else is available, in a fixed
    order -- so an unrecognized PRIMARY_PROVIDER value just falls back to
    trying everything rather than erroring out."""
    providers = _all_providers()
    order = [config.PRIMARY_PROVIDER] + [p for p in ("groq", "openrouter", "gemini", "nvidia", "lmstudio") if p != config.PRIMARY_PROVIDER]
    return [providers[label] for label in order if label in providers]


def _models_for(label: str, kind: str) -> list:
    if label == "groq":
        return config.GROQ_TEXT_MODELS if kind == "text" else config.GROQ_VISION_MODELS
    if label == "openrouter":
        return config.OPENROUTER_TEXT_MODELS if kind == "text" else config.OPENROUTER_VISION_MODELS
    if label == "gemini":
        return config.GEMINI_TEXT_MODELS if kind == "text" else config.GEMINI_VISION_MODELS
    if label == "nvidia":
        return config.NVIDIA_TEXT_MODELS if kind == "text" else config.NVIDIA_VISION_MODELS
    if label == "lmstudio":
        return _lmstudio_models(kind)
    return []


def current_text_model_label() -> str:
    """Best-effort label of the model that WOULD be tried first right now --
    used by the escalation prompt so Gemini knows what Troy is running on."""
    if config.TEXT_MODEL_OVERRIDE:
        return config.TEXT_MODEL_OVERRIDE
    order = _provider_order()
    if not order:
        return "(no provider configured)"
    label = order[0][0]
    models = _models_for(label, "text")
    return f"{label}:{models[0]}" if models else label


def chat(messages: list, stop_check=None, on_text=None) -> str:
    """Sends `messages` (OpenAI chat format) through the provider/model
    fallback chain. `stop_check`, if given, is polled during streaming and
    raises StoppedByUser the moment it returns True."""
    chain = [(label, base_url, api_key, _models_for(label, "text")) for label, base_url, api_key in _provider_order()]
    chain = _apply_override(chain, config.TEXT_MODEL_OVERRIDE)
    return _try_provider_chain(chain, messages, stop_check=stop_check, on_text=on_text)


def budget_for(label: str) -> tuple:
    """(token budget for a request to this provider, max chars per message) -- see context_budget."""
    return _budget_for(label)


def chat_tools(build_messages, tools: list, stop_check=None, on_text=None, on_tool_start=None) -> Reply:
    """Native function calling through the same provider/model fallback chain as chat().

    `build_messages(label)` returns the wire messages for that provider (the caller trims them to
    budget_for(label) and removes private keys); `tools` is the list of JSON schemas. Models that reject the
    `tools` field are remembered and skipped; when none is left, NoNativeTools is raised so the caller can fall
    back to the text protocol. `on_text(text_so_far)` streams the spoken part; `on_tool_start()` fires once, when
    the first tool call begins to arrive (the text before it is complete by then)."""
    chain = [(label, base_url, api_key, _models_for(label, "text")) for label, base_url, api_key in _provider_order()]
    chain = _apply_override(chain, config.TEXT_MODEL_OVERRIDE)
    return _try_provider_chain(chain, None, stop_check=stop_check, build_messages=build_messages, on_text=on_text,
                               native={"tools": tools, "on_tool_start": on_tool_start})


def _resize_b64(b64: str, max_side: int, size=None):
    """Shrinks a base64 image so its longest side is at most `max_side`.
    Returns (base64, (width, height) or None). Without Pillow, or if the image
    is already small enough, the original is returned untouched."""
    try:
        import base64
        import io
        from PIL import Image
        img = Image.open(io.BytesIO(base64.b64decode(b64)))
        w, h = img.size
        if max(w, h) <= max_side:
            return b64, (w, h)
        scale = max_side / max(w, h)
        img = img.convert("RGB").resize((max(1, round(w * scale)), max(1, round(h * scale))))
        buf = io.BytesIO()
        img.save(buf, format="JPEG", quality=82)
        return base64.b64encode(buf.getvalue()).decode("ascii"), img.size
    except Exception as exc:  # noqa: BLE001 - sending the original is always acceptable
        logger.debug("Image resize skipped: %s", exc)
        return b64, size


def describe_image_ex(image_base64: str, question: str = None, stop_check=None, size=None) -> tuple:
    """Like describe_image, but also returns the (width, height) of the image
    the answering model actually saw. Local models get a smaller picture than
    cloud ones; callers that ask for pixel coordinates must scale them back.
    Any "{size}" in `question` becomes that final "WxH"."""
    question = question or (
        "Describe what's currently on screen in one or two short sentences, "
        "focusing on anything relevant to a task being performed."
    )
    seen = {}

    def build(label):
        side = config.LMSTUDIO_VISION_MAX_SIDE if label == "lmstudio" else config.VISION_MAX_SIDE
        data, used = _resize_b64(image_base64, side, size)
        seen["size"] = used
        text = question.replace("{size}", f"{used[0]}x{used[1]}") if used else question.replace("{size}", "full-size")
        mime = "jpeg" if data is not image_base64 or label == "lmstudio" else "png"
        return [{"role": "user", "content": [
            {"type": "text", "text": text},
            {"type": "image_url", "image_url": {"url": f"data:image/{mime};base64,{data}"}},
        ]}]

    chain = [(label, base_url, api_key, _models_for(label, "vision")) for label, base_url, api_key in _provider_order()]
    chain = _apply_override(chain, config.VISION_MODEL_OVERRIDE)
    description = _try_provider_chain(chain, None, stop_check=stop_check, trim=False, build_messages=build).strip()
    if not description:
        raise LLMError("Vision model returned an empty description.")
    return description, seen.get("size")


def describe_image(image_base64: str, question: str = None, stop_check=None) -> str:
    """Sends a base64-encoded screenshot through the vision-model fallback chain."""
    return describe_image_ex(image_base64, question, stop_check)[0]
