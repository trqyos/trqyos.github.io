"""
TROYOS STABLE - IPC Host (Electron backend bridge)

This is what the Electron frontend actually talks to. It replaces the old
PySide6 desktop window (ui/main_window.py, removed) as the app's real
entry point, and deliberately does NOT open an HTTP server on
127.0.0.1:8000 or any other port for the desktop frontend to poll -- that
approach was tried and didn't work reliably (port conflicts, firewall
prompts, the server not being up yet when the window opens, ...).
Instead, Electron's main process spawns this file as a child process
(`python -u main.py --ipc`, see main.py) and talks to it over plain
stdin/stdout: real OS-level inter-process communication, no network stack
involved at all. Electron's own internal ipcMain/ipcRenderer/contextBridge
then relays between its renderer (the HTML/JS UI) and this child process --
see electron/main.js and electron/preload.js for that half.

PROTOCOL
One JSON object per line in both directions (newline-delimited JSON,
a.k.a. NDJSON) -- simple, streamable, and trivial to parse incrementally
from Node's child_process stdout, unlike a single giant JSON blob.

  Electron -> Python (stdin), a REQUEST:
    {"id": "<any string/number the caller picks>", "method": "<name>", "params": {...}}

  Python -> Electron (stdout), a RESPONSE to a specific request:
    {"type": "response", "id": "<the same id>", "ok": true,  "result": {...}}
    {"type": "response", "id": "<the same id>", "ok": false, "error": "message"}

  Python -> Electron (stdout), an unsolicited EVENT (no request caused
  this specific line -- the agent is mid-turn, a background listener fired,
  etc.):
    {"type": "event", "event": "<name>", "data": {...}}

See METHODS and EVENTS below for the full catalog of each. This module
intentionally has NO GUI code and NO knowledge of Electron at all beyond
this stdio contract -- every method here just calls straight into the
same troy/*.py modules the old Qt UI called into (agent, sessions,
memory, confirmation, config, voice, wake_listener, mobile_server).
"""

import json
import os
import re
import sys
import threading
import traceback
from datetime import datetime

import requests

from . import (
    app_launcher,
    config,
    dispatcher,
    llm_client,
    confirmation,
    memory,
    mobile_server,
    power,
    ui_bridge,
    remote,
    scheduler as scheduler_mod,
    schedule_spec,
    sessions,
    stop_control,
    task_runner,
    tts,
    youtube,
    tools_all,
    voice,
    voice_mode,
    wake_listener,
)
from . import settings_store
from .settings_store import apply_settings, read_saved as _read_saved, SETTINGS as _SETTINGS, SECRETS as _SECRETS, RESTART_REQUIRED as _RESTART_REQUIRED, PROVIDERS as _PROVIDERS
from .agent import TroyAgent
from .logger import logger

_stdout_lock = threading.Lock()


def _write(obj: dict):
    """Writes one JSON object as one line to stdout. Thread-safe (multiple
    threads -- the stdin reader, the agent's own turn thread, the hotkey/
    wake-word listener threads -- all emit events concurrently) and
    flushes immediately since Node reads this as a live stream, not a
    file it waits to be closed."""
    line = json.dumps(obj, ensure_ascii=False)
    with _stdout_lock:
        sys.stdout.write(line + "\n")
        sys.stdout.flush()


# Events the phone page mirrors, so it stays in step with the PC app (tasks, chats, settings,
# power saving, face animation) without polling. Everything else is already broadcast
# by the specific handlers below (messages, tool steps, state, approvals, voice).
_MIRROR_TO_PHONE = ("task.", "settings.changed", "model.changed", "power.state", "session.changed", "face.")


def _emit(event: str, data: dict = None):
    _write({"type": "event", "event": event, "data": data or {}})
    if event.startswith(_MIRROR_TO_PHONE):
        try:
            mobile_server.broadcast({"type": "event", "event": event, "data": data or {}})
        except Exception:  # noqa: BLE001 - a phone problem must never break the PC app
            logger.debug("couldn't mirror %s to the phone", event, exc_info=True)


def _respond_ok(request_id, result=None):
    _write({"type": "response", "id": request_id, "ok": True, "result": result if result is not None else {}})


def _respond_err(request_id, message: str):
    _write({"type": "response", "id": request_id, "ok": False, "error": message})


_DEFAULT_TITLE = re.compile(r"^(New session|Session [A-Z][a-z]{2} \d{1,2}, \d{2}:\d{2})$")
class IPCHost:
    """
    Owns the one TroyAgent instance for the process's lifetime, the
    current session id, and the current display_log (the UI-facing
    transcript -- separate from agent.messages, same distinction the old
    Qt UI made: agent.export_history() is what gets replayed to the LLM,
    display_log is what a human reads, and they're not the same shape --
    the display log also carries confirmation prompts and tool-call
    labels that never go anywhere near the model).
    """

    def __init__(self):
        try:
            apply_settings(_read_saved(), persist=False)
        except Exception as exc:  # noqa: BLE001 - a bad settings file must not stop startup
            logger.warning("Ignoring invalid troy_settings.json: %s", exc)
        self.current_session_id = None
        self.display_log = []
        self._last_state = {"state": "idle"}
        # Turns (typed, voice, phone, or a resumed-after-approval one) all go
        # through _begin_turn(): the lock makes them run strictly one at a
        # time (a second request queues instead of two agent loops stomping
        # on the same message history), and the counter is what "busy" means.
        self._turn_lock = threading.Lock()
        self._busy_lock = threading.Lock()
        self._pending_turns = 0
        self._new_chat_after_turn = False
        ui_bridge.set_emitter(_emit)       # lets Troy's own tools drive the UI (troy/tools_app.py)
        ui_bridge.set_host(self)
        self.agent = TroyAgent(
            on_speak=self._on_speak,
            on_state=self._on_state,
            on_tool_result=self._on_tool_result,
        )
        confirmation.set_listener(self._on_confirmation_requested)
        # Full voice mode (troy/voice_mode.py) owns hands-free conversation on
        # the PC mic AND the phone-as-mic-and-speaker session. It talks back to
        # this host through the small adapter methods below (emit/broadcast/
        # start_turn/stop_turn), so it never touches IPC details itself.
        self.voice = voice_mode.VoiceMode(self)
        self._init_tasks()
        self._maybe_start_mobile_server()

    def _maybe_start_mobile_server(self):
        """The phone page (a phone on the same Wi-Fi, or anywhere via Tailscale)
        is independent of the Electron window: both are just surfaces onto the
        one running agent."""
        mobile_server.configure(mobile_server.Bridge(
            enqueue_turn=lambda text: self._start_turn(text, "mobile"),
            get_display_log=lambda: self.display_log,
            get_status=lambda: {"state": self._last_state, "busy": self._pending_turns > 0, "session_id": self.current_session_id},
            stop_turn=lambda: stop_control.stop_controller.request_stop(),
            list_confirmations=lambda: self._pending_confirmations(),
            resolve_confirmation=lambda cid, ok: self._m_confirmation_resolve({"id": cid, "approved": ok}),
            on_viewers=lambda n: _emit("mobile_ui.viewers", {"count": n}),
            get_info=lambda: {"user_name": config.USER_NAME, "version": config.VERSION_LABEL},
            voice_start=self.voice.phone_start,
            voice_stop=self.voice.phone_stop,
            voice_interrupt=self.voice.phone_interrupt,
            voice_event=self.voice.phone_event,
            voice_audio=self.voice.handle_phone_audio,
            voice_audio_get=self.voice.audio,
            rpc=self.phone_rpc,
        ))
        youtube.on_event(lambda event, data: _emit(event, data))
        settings_store.on_change(self._on_settings_changed_by_troy)
        if config.MOBILE_UI_ENABLED:
            mobile_server.start()
            _emit("mobile_ui.started", {"url": self._phone_url()})


    # ---- scheduled tasks -------------------------------------------------
    # troy/scheduler.py decides WHEN (its own thread, no model involved while it waits);
    # troy/task_runner.py carries one attempt out with a fresh, isolated agent; this host
    # just lends it the turn lock, relays its events to the UI and reports results into the chat.

    def _init_tasks(self):
        self._task_runner = task_runner.TaskRunner(
            agent_factory=lambda **callbacks: TroyAgent(**callbacks),
            turn_lock=self._turn_lock,
            on_state=self._on_task_state,
            on_step=self._on_task_step,
            info_names=tools_all.info_command_names() | dispatcher.INFO_COMMANDS,
            restore_model=(self._model_snapshot, self._model_restore),
        )
        self.tasks = scheduler_mod.Scheduler(
            executor=self._task_runner.execute,
            on_event=self._on_task_event,
            context_provider=lambda: {"session_id": self.current_session_id, "message_index": len(self.display_log)},
            stop_current=lambda: stop_control.stop_controller.request_stop(),
        )
        scheduler_mod.install(self.tasks)
        if config.TASKS_ENABLED:
            self.tasks.start()

    @staticmethod
    def _model_snapshot() -> dict:
        return {k: getattr(config, k) for k in ("PRIMARY_PROVIDER", "TEXT_MODEL_OVERRIDE", "VISION_MODEL_OVERRIDE")}

    @staticmethod
    def _model_restore(snapshot: dict):
        """A task may have switched models; the user's own choice comes back when it is over."""
        if any(getattr(config, k) != v for k, v in snapshot.items()):
            apply_settings(snapshot)
            _emit("settings.changed", {"keys": sorted(snapshot)})

    def _on_task_state(self, state: str, detail: str = ""):
        self._last_state = {"state": state, "detail": detail}
        _emit("agent.state", {"state": state, "detail": detail})
        mobile_server.broadcast({"type": "status", "status": self._last_state})

    def _on_task_step(self, task_id, name, arg, ok, message):
        _emit("task.step", {"id": task_id, "name": name, "arg": arg, "success": ok, "message": message[:300]})

    def _on_task_event(self, name: str, payload: dict):
        if name == "finished":
            task = payload["task"]
            if payload.get("ok"):
                text = f"Scheduled task \u201c{task['title']}\u201d is done: {payload.get('summary') or 'finished.'}"
            else:
                n = payload.get("attempts", 1)
                text = f"Scheduled task \u201c{task['title']}\u201d didn't succeed" + (f" after {n} attempts" if n > 1 else "") + f": {payload.get('summary') or payload.get('error') or 'it failed.'}"
                if task.get("needs_approval"):
                    text += " Open Tasks and press Approve to let it run those commands unattended."
            self._report_task(task, payload.get("ok", False), text)
        elif name == "missed":
            task = payload["task"]
            self._report_task(task, False, f"Scheduled task \u201c{task['title']}\u201d was missed: {task.get('last_summary', '')}", kind="missed")
        else:
            _emit(f"task.{name}", payload)

    def _report_task(self, task: dict, ok: bool, text: str, kind: str = "finished"):
        """Tells the user how a task went: a note in the chat that created it, an event for every window, the phone, and speech."""
        sid = task.get("session_id")
        entry = {"role": "task", "text": text, "task_id": task["id"], "title": task["title"], "ok": ok, "kind": kind}
        in_current = bool(sid) and sid == self.current_session_id
        try:
            if in_current:
                with self._turn_lock:                       # never write into a conversation mid-turn
                    self.display_log.append(entry)
                    note = getattr(self.agent, "note_event", None)
                    if note:
                        note(text)
                    self._autosave()
            elif sid:
                sessions.append_entries(sid, entry, {"role": "user", "content": f"[SYSTEM] {text}"})
        except Exception as exc:  # noqa: BLE001 - reporting must never break the scheduler
            logger.warning("Couldn't write the task report into its chat: %s", exc)
        _emit("task.finished", {"task": task, "ok": ok, "text": text, "kind": kind, "session_id": sid, "in_current_chat": in_current, "entry": entry})
        mobile_server.broadcast({"type": "message", "kind": "troy", "text": text})
        try:
            self.voice.speak(text)
        except Exception as exc:  # noqa: BLE001
            logger.warning("Voice output failed: %s", exc)

    def _task_view(self, t: dict, titles: dict) -> dict:
        sid = t.get("session_id")
        t["chat_exists"] = bool(sid) and sid in titles
        t["chat_title"] = titles.get(sid, "")
        return t

    def _m_tasks_list(self, params):
        titles = {s["id"]: s["title"] for s in sessions.list_sessions()}
        return {"tasks": [self._task_view(t, titles) for t in self.tasks.list()], "enabled": config.TASKS_ENABLED,
                "scheduler_running": self.tasks.is_running(),
                "defaults": {"max_retries": config.TASK_MAX_RETRIES, "retry_delay": config.TASK_RETRY_DELAY_SECONDS,
                             "grace_minutes": config.TASK_MISSED_GRACE_MINUTES}}

    def _task_or_raise(self, params) -> dict:
        t = self.tasks.get(params.get("id"))
        if t is None:
            raise ValueError("That task no longer exists.")
        return t

    def _reply_task(self, view: dict) -> dict:
        return {"task": self._task_view(view, {s["id"]: s["title"] for s in sessions.list_sessions()})}

    def _m_tasks_get(self, params):
        return self._reply_task(self._task_or_raise(params))

    def _m_tasks_preview(self, params):
        """What would 'every Monday at 9' mean? Answers instead of raising so the form can show it live."""
        try:
            now = datetime.now()
            spec = schedule_spec.parse_when(params.get("when") or "", now)
        except schedule_spec.ScheduleError as exc:
            return {"ok": False, "error": str(exc)}
        runs = schedule_spec.occurrences(spec, now, 3)
        return {"ok": True, "spec": spec, "text": schedule_spec.describe(spec), "next": [r.isoformat() for r in runs]}

    def _m_tasks_create(self, params):
        from . import tools_tasks
        commands, err = tools_tasks._parse_approve(params.get("approve") or "")
        if err:
            raise ValueError(err)
        view = self.tasks.add(params.get("prompt"), params.get("when"), title=params.get("title") or "", session_id=None,
                              message_index=None, grants=commands)
        return self._reply_task(view)

    def _m_tasks_modify(self, params):
        kw = {}
        for key in ("title", "prompt", "when"):
            if params.get(key) is not None:
                kw[key] = params[key]
        for key in ("max_retries", "retry_delay"):
            if params.get(key) not in (None, ""):
                kw[key] = int(params[key])
        if params.get("default_retries"):
            kw["clear_retries"] = True
        return self._reply_task(self.tasks.modify(params.get("id"), **kw))

    def _m_tasks_cancel(self, params):
        return self._reply_task(self.tasks.cancel(params.get("id")))

    def _m_tasks_pause(self, params):
        return self._reply_task(self.tasks.pause(params.get("id")))

    def _m_tasks_resume(self, params):
        return self._reply_task(self.tasks.resume(params.get("id")))

    def _m_tasks_run_now(self, params):
        return self._reply_task(self.tasks.run_now(params.get("id")))

    def _m_tasks_delete(self, params):
        return {"ok": self.tasks.delete(params.get("id"))}

    def _m_tasks_clear_finished(self, params):
        return {"cleared": self.tasks.clear_finished()}

    def _m_tasks_approve(self, params):
        """The Approve button on a task that was refused a command: grants exactly those commands and runs it again."""
        t = self._task_or_raise(params)
        commands = params.get("commands") or t.get("needs_approval") or []
        if not commands:
            raise ValueError("Nothing is waiting for approval on that task.")
        self.tasks.grant(t["id"], commands)
        return self._reply_task(self.tasks.run_now(t["id"]))

    def _m_tasks_logs(self, params):
        return {"entries": self.tasks.logs(params.get("id"), int(params.get("limit") or 100))}

    def _sync_tasks_enabled(self, keys):
        """TASKS_ENABLED was flipped (Settings screen or Troy): start or stop the scheduler thread right away."""
        if "TASKS_ENABLED" in keys:
            if config.TASKS_ENABLED:
                self.tasks.start()
            else:
                self.tasks.stop()

    def _on_settings_changed_by_troy(self, keys, source):
        """Troy switched its own model (or similar): tell every surface, so the
        header's model label updates and the user sees it happen."""
        self._sync_tasks_enabled(keys)
        _emit("settings.changed", {"keys": sorted(keys)})
        if source == "troy" and keys & {"TEXT_MODEL_OVERRIDE", "PRIMARY_PROVIDER", "VISION_MODEL_OVERRIDE"}:
            _emit("model.changed", {"text": config.TEXT_MODEL_OVERRIDE, "primary": config.PRIMARY_PROVIDER,
                                    "vision": config.VISION_MODEL_OVERRIDE, "by": "troy"})

    def _pending_confirmations(self):
        return [{"id": p.id, "name": p.name, "arg": p.arg, "risk_level": p.risk_level, "description": p.description}
                for p in confirmation.list_pending()]

    def _phone_url(self) -> str:
        urls = remote.access_urls(mobile_server.get_token())
        return urls[0]["url"] if urls else ""

    # ---- what the phone page may ask for ---------------------------------
    def phone_rpc(self, method: str, params: dict = None):
        """One door for the phone page's chats / tasks / memory / settings screens: the same handlers
        the PC app calls, but only an allow-list of them, and only the settings that are safe to change
        from a phone (never API keys, never the phone's own access settings)."""
        if method not in mobile_server.PHONE_METHODS:
            raise ValueError(f"The phone can't call {method}.")
        params = dict(params or {})
        if method in ("settings.update", "settings.set"):
            changes = params.get("changes") if method == "settings.update" else {params.get("key"): params.get("value")}
            changes = dict(changes or {})
            refused = sorted(str(k) for k in changes if k not in mobile_server.PHONE_SETTINGS)
            if refused:
                raise ValueError("The phone can't change: " + ", ".join(refused) + ". Use the PC app for that.")
            method, params = "settings.update", {"changes": changes}
        params["_by"] = "phone"
        return self.handle_request(method, params)

    def _session_changed(self, action: str, params=None, **extra):
        """Tells every surface that the list of chats or the open chat changed, and who did it."""
        payload = {"action": action, "by": (params or {}).get("_by", "pc"), "id": self.current_session_id}
        payload.update(extra)
        _emit("session.changed", payload)

    def _m_face_relay(self, params):
        """A face (PC window or phone) reports a poke / wake so every other face does the same, in step."""
        kind = str(params.get("kind") or "")
        if kind not in ("poke", "wake"):
            raise ValueError("Unknown face event.")
        _emit("face.event", {"kind": kind, "origin": str(params.get("origin") or "")[:40]})
        return {"ok": True}

    # ---- voice-mode host adapter -----------------------------------------
    # Everything troy/voice_mode.py needs from its host, as plain methods so
    # the orchestrator stays IPC-agnostic (and easy to fake in tests).

    def emit(self, event: str, data: dict = None):
        _emit(event, data)

    def broadcast(self, event: dict):
        """Same dict mobile_server.broadcast takes: pushes to connected phones."""
        mobile_server.broadcast(event)

    def start_turn(self, text: str, source: str = "typed"):
        """Public name for _start_turn: voice_mode.py calls host.start_turn(text, source)
        for both PC-mic and phone-mic utterances. (Missing before -> the phone's voice mode
        failed with "'IPCHost' object has no attribute 'start_turn'".)"""
        self._start_turn(text, source)

    def stop_turn(self):
        stop_control.stop_controller.request_stop()

    # ---- TroyAgent callbacks -> IPC events -------------------------------

    def _on_speak(self, text: str):
        self.display_log.append({"role": "assistant", "text": text})
        self._autosave()
        _emit("agent.speak", {"text": text})
        try:
            self.voice.speak(text)
        except Exception as exc:  # noqa: BLE001 - TTS trouble must never break a turn
            logger.warning("Voice output failed: %s", exc)
        mobile_server.broadcast({"type": "message", "kind": "troy", "text": text})

    def _on_state(self, state: str, detail: str = ""):
        self._last_state = {"state": state, "detail": detail}
        _emit("agent.state", {"state": state, "detail": detail})
        self.voice.agent_state(state, detail)
        mobile_server.broadcast({"type": "status", "status": self._last_state})

    def _on_tool_result(self, name: str, arg: str, success: bool, message: str):
        self.display_log.append({
            "role": "tool", "name": name, "arg": arg,
            "success": success, "message": message,
        })
        _emit("agent.tool_result", {
            "name": name, "arg": arg, "success": success, "message": message,
        })
        mobile_server.broadcast({
            "type": "tool", "name": name, "arg": arg,
            "success": success, "message": message,
        })

    def _on_confirmation_requested(self, pc):
        """Fired from troy/confirmation.py the instant a risky command
        creates a pending approval -- may be called from whatever thread
        was running the agent turn, which is fine here since _emit() is
        already thread-safe (no Qt-signal marshalling needed, unlike the
        old UI)."""
        info = {"id": pc.id, "name": pc.name, "arg": pc.arg, "risk_level": pc.risk_level, "description": pc.description}
        _emit("confirmation.request", info)
        mobile_server.broadcast({"type": "confirmation", "action": "request", **info})

    def _autosave(self):
        """Keeps the current session's file on disk roughly in sync as
        the conversation goes, not just on an explicit session.save call
        -- so a crash or force-quit doesn't lose the last few turns."""
        if not self.current_session_id:
            return
        try:
            sessions.save_session(
                self.current_session_id,
                title=self._current_title(),
                agent_history=self.agent.export_history(),
                display_log=self.display_log,
            )
        except Exception as exc:  # noqa: BLE001 - autosave must never crash a turn
            logger.warning("Autosave failed: %s", exc)

    def _current_title(self) -> str:
        """Keeps a title the user chose; replaces the auto-generated
        placeholder ("Session Sep 27, 21:44") with the first thing they
        actually asked, which is what makes the sidebar list readable."""
        existing = (sessions.load_session(self.current_session_id) or {}).get("title") or ""
        if not existing or _DEFAULT_TITLE.match(existing):
            first = next((e.get("text", "") for e in self.display_log if e.get("role") == "user"), "")
            first = " ".join(first.split())
            if first:
                return first[:48] + ("\u2026" if len(first) > 48 else "")
        return existing or "New session"

    def _ensure_idle(self):
        if self._pending_turns > 0:
            raise ValueError("Troy is busy with a request -- stop it or wait for it to finish first.")

    def _begin_turn(self, runner, source: str):
        """Runs `runner` (a zero-arg callable that drives the agent) on a
        worker thread, serialized behind any turn already in progress, and
        brackets it with chat.turn_started / chat.turn_complete events so
        every frontend can show a correct busy state no matter who started
        the turn."""
        with self._busy_lock:
            self._pending_turns += 1
        _emit("chat.turn_started", {"source": source})
        mobile_server.broadcast({"type": "turn", "state": "started"})

        def _run():
            try:
                with self._turn_lock:
                    runner()
            except Exception as exc:  # noqa: BLE001 - a turn crashing must not kill the whole host
                logger.error("Agent turn crashed: %s\n%s", exc, traceback.format_exc())
                _emit("agent.error", {"message": str(exc)})
            finally:
                self._autosave()
                with self._busy_lock:
                    self._pending_turns -= 1
                    pending = self._pending_turns
                _emit("chat.turn_complete", {"pending": pending})
                mobile_server.broadcast({"type": "turn", "state": "complete", "pending": pending})
                if pending == 0 and self._new_chat_after_turn:
                    self._new_chat_after_turn = False
                    self._do_new_chat()

        threading.Thread(target=_run, daemon=True, name="troy-turn").start()

    def _do_new_chat(self):
        self.current_session_id = None
        self.display_log = []
        self.agent.load_history([])
        _emit("ui.command", {"action": "new_chat"})
        self._session_changed("reset", by="troy")

    def schedule_new_chat(self) -> str:
        """Troy asked for a fresh chat (new_chat tool). A turn is normally running, so
        it happens as soon as that turn is over; if nothing is running it happens now."""
        with self._busy_lock:
            busy = self._pending_turns > 0
        if busy:
            self._new_chat_after_turn = True
            return "after_turn"
        self._do_new_chat()
        return "now"

    def _start_turn(self, text: str, source: str = "typed"):
        """The one entry point for anything the user says, from any surface."""
        text = (text or "").strip()
        if not text:
            raise ValueError("Nothing to send -- the message is empty.")
        if not self.current_session_id:
            # Sessions are created lazily on the first message, so opening
            # the app (or clicking New chat) never leaves empty sessions behind.
            self.current_session_id = sessions.create_session()
            self.display_log = []
            self._session_changed("created")
        self.display_log.append({"role": "user", "text": text})
        if source != "mobile":  # the phone page already shows what it sent
            mobile_server.broadcast({"type": "message", "kind": "user", "text": text})
        _emit("chat.user_message", {"text": text, "source": source})
        self._begin_turn(lambda: self.agent.handle_user_input(text, source=source), source)

    # ---- methods (requests FROM Electron) --------------------------------

    def handle_request(self, method: str, params: dict) -> dict:
        """Dispatches one request to its handler. Returns the `result`
        dict on success; raises on failure (caught by the main loop, which
        turns it into a `{"ok": false, "error": ...}` response) -- keeps
        every individual handler below free of its own try/except
        boilerplate."""
        handler = _METHODS.get(method)
        if handler is None:
            raise ValueError(f"Unknown method: {method}")
        return handler(self, params or {})

    # -- chat --
    def _m_chat_send(self, params):
        self._start_turn(params.get("text"), params.get("source") or "typed")
        return {"accepted": True, "session_id": self.current_session_id}

    def _m_chat_stop(self, params):
        stop_control.stop_controller.request_stop()
        return {"stopped": True}

    # -- sessions --
    def _m_session_new(self, params):
        self._ensure_idle()
        session_id = sessions.create_session(params.get("title"))
        self.current_session_id = session_id
        self.display_log = []
        self.agent.load_history([])
        self._session_changed("loaded", params, title=params.get("title") or "")
        return {"id": session_id}

    def _m_session_reset(self, params):
        """Detaches from the current session without creating a new file --
        the next chat.send creates one lazily. This is what a UI's
        "New chat" button should call."""
        self._ensure_idle()
        self.current_session_id = None
        self.display_log = []
        self.agent.load_history([])
        self._session_changed("reset", params)
        return {"id": None}

    # -- power saving + what the UI is showing --
    def _m_power_status(self, params):
        return power.status()

    def _m_power_report(self, params):
        """Electron tells us whether the machine runs on battery (drives POWER_SAVING=auto)."""
        return power.report_battery(params.get("on_battery"))

    def _m_ui_report(self, params):
        """Electron tells us what it is showing (widget / full app, theme, ...) so Troy can answer questions about it."""
        return ui_bridge.report(**{k: v for k, v in (params or {}).items()})

    def _m_session_list(self, params):
        return {"sessions": sessions.list_sessions()}

    def _m_session_load(self, params):
        self._ensure_idle()
        session_id = params.get("id")
        data = sessions.load_session(session_id)
        if data is None:
            raise ValueError(f"No such session: {session_id}")
        self.current_session_id = session_id
        self.display_log = data.get("display_log", [])
        self.agent.load_history(data.get("agent_history", []))
        self._session_changed("loaded", params, title=data.get("title") or "")
        return {
            "id": session_id,
            "title": data.get("title"),
            "display_log": self.display_log,
        }

    def _m_session_save(self, params):
        if not self.current_session_id:
            raise ValueError("No active session to save.")
        title = params.get("title") or self._current_title()
        sessions.save_session(self.current_session_id, title, self.agent.export_history(), self.display_log)
        return {"id": self.current_session_id, "title": title}

    def _m_session_rename(self, params):
        ok = sessions.rename_session(params.get("id"), params.get("title", ""))
        self._session_changed("renamed", params)
        return {"ok": ok}

    def _m_session_delete(self, params):
        deleting_current = params.get("id") == self.current_session_id
        if deleting_current:
            self._ensure_idle()
        ok = sessions.delete_session(params.get("id"))
        if deleting_current:
            self.current_session_id = None
            self.display_log = []
            self.agent.load_history([])
        self._session_changed("deleted", params, deleted=params.get("id"), was_current=deleting_current)
        return {"ok": ok, "was_current": deleting_current}

    # -- memory --
    def _m_memory_list(self, params):
        return {"memories": memory.all_memories()}

    def _m_memory_add(self, params):
        message = memory.remember(params.get("fact", ""))
        self.agent.refresh_memory_context()
        return {"message": message}

    def _m_memory_delete(self, params):
        ok = memory.delete_memory(int(params.get("index", -1)))
        self.agent.refresh_memory_context()
        return {"ok": ok}

    def _m_memory_clear(self, params):
        count = memory.clear_all()
        self.agent.refresh_memory_context()
        return {"cleared": count}

    # -- live context snapshot (also see the get_context command itself) --
    def _m_context_get(self, params):
        return tools_all.get_context_snapshot()

    # -- confirmations --
    def _m_confirmation_list(self, params):
        pending = confirmation.list_pending()
        return {"pending": [
            {"id": p.id, "name": p.name, "arg": p.arg,
             "risk_level": p.risk_level, "description": p.description}
            for p in pending
        ]}

    def _m_confirmation_resolve(self, params):
        confirmation_id = int(params.get("id"))
        approved = bool(params.get("approved"))
        result = confirmation.resolve(confirmation_id, approved)
        observation = (
            f"[OBSERVATION] {result.get('name')}:{result.get('arg')} -> "
            f"{'OK' if result.get('success') else 'FAILED'} - {result.get('message')}"
        )
        _emit("confirmation.resolved", {"id": confirmation_id, "approved": approved, "result": result})
        mobile_server.broadcast({"type": "confirmation", "action": "resolved", "id": confirmation_id})
        # Let Troy actually react to the outcome instead of the turn just
        # having silently ended back when it first issued the command.
        self._begin_turn(lambda: self.agent.resume_with_observation(observation), "confirmation")
        return {"result": result}

    # -- settings / providers / models --
    def _m_settings_get(self, params):
        return {
            "values": {k: getattr(config, k, None) for k in _SETTINGS},
            "secrets_configured": {k: bool(getattr(config, k, "")) for k in _SECRETS},
            "assistant_name": config.ASSISTANT_NAME,
            "version": config.VERSION, "version_label": config.VERSION_LABEL,
            "restart_required_keys": sorted(_RESTART_REQUIRED),
        }

    def _m_settings_update(self, params):
        """{changes: {KEY: value, ...}} -> applied + saved to troy_settings.json.
        API keys are accepted here (write-only: settings.get only reports
        whether each is set, never the value)."""
        applied = apply_settings(params.get("changes") or {})
        self._sync_tasks_enabled(applied)
        _emit("settings.changed", {"keys": sorted(applied)})
        return {"applied": sorted(applied), "restart_required": sorted(set(applied) & _RESTART_REQUIRED)}

    def _m_settings_set(self, params):
        return self._m_settings_update({"changes": {params.get("key"): params.get("value")}})

    def _m_provider_list(self, params):
        out = []
        for pid, (label, secret) in _PROVIDERS.items():
            configured = config.LMSTUDIO_ENABLED if secret is None else bool(getattr(config, secret, ""))
            models = {}
            for kind in ("text", "vision"):
                try:
                    models[kind] = list(llm_client._models_for(pid, kind))
                except Exception:  # noqa: BLE001 - e.g. LM Studio not running
                    models[kind] = []
            entry = {"id": pid, "label": label, "configured": configured,
                     "primary": config.PRIMARY_PROVIDER == pid, "models": models}
            if pid == "lmstudio":
                entry["details"] = {m["id"]: {"vision": m["vision"], "loaded": m["loaded"], "context": m["context"]}
                                    for m in llm_client.lmstudio_models_info()}
            out.append(entry)
        return {"providers": out,
                "overrides": {"text": config.TEXT_MODEL_OVERRIDE, "vision": config.VISION_MODEL_OVERRIDE}}

    def _m_provider_set_primary(self, params):
        pid = params.get("provider")
        if pid not in _PROVIDERS:
            raise ValueError(f"Unknown provider: {pid}")
        return self._m_settings_update({"changes": {"PRIMARY_PROVIDER": pid}})

    def _m_provider_fetch_models(self, params):
        """Asks the provider itself which models it serves right now. For LM
        Studio this also reports which are vision models, which are loaded, and
        their context length (it works before LM Studio is enabled in Troy)."""
        pid = params.get("provider")
        if pid == "lmstudio":
            info = llm_client.lmstudio_models_info(force=True)
            if not info and llm_client.lmstudio_error():
                raise ValueError(f"Couldn't reach LM Studio at {config.LMSTUDIO_BASE_URL}: {llm_client.lmstudio_error()}. "
                                 "Start LM Studio's local server (Developer tab).")
            return {"models": [m["id"] for m in info],
                    "details": {m["id"]: {"vision": m["vision"], "loaded": m["loaded"], "context": m["context"], "max_context": m["max_context"]} for m in info}}
        entry = next((p for p in llm_client._all_providers().values() if p[0] == pid), None)
        if entry is None:
            raise ValueError("Provider not available (enable/configure it first).")
        _, base, key = entry
        resp = requests.get(base + "/models", headers={"Authorization": f"Bearer {key}"}, timeout=15)
        resp.raise_for_status()
        return {"models": sorted(m.get("id", "") for m in resp.json().get("data", []) if m.get("id")), "details": {}}

    def _m_prompt_info(self, params):
        from .context_budget import estimate_tokens
        from .system_prompt import build_system_prompt
        mode = self.agent._prompt_mode()
        return {"mode": mode, "setting": config.PROMPT_MODE, "prompt_tokens": estimate_tokens(build_system_prompt(mode)),
                "budget_tokens": config.CONTEXT_BUDGET_TOKENS,
                "lmstudio_context": llm_client.lmstudio_context() if config.LMSTUDIO_ENABLED else None}

    def _m_session_search(self, params):
        return sessions.search_sessions(params.get("query", ""), int(params.get("limit", 30)))

    # -- youtube / browser / apps --
    def _m_youtube_status(self, params):
        return youtube.status()

    def _m_youtube_connect(self, params):
        try:
            return youtube.begin_auth()
        except youtube.YouTubeError as exc:
            raise ValueError(str(exc)) from None

    def _m_youtube_complete(self, params):
        ok, message = youtube.complete_from_url(params.get("url", ""))
        if not ok:
            raise ValueError(message)
        return {"message": message}

    def _m_youtube_cancel(self, params):
        youtube.cancel_auth()
        return {"cancelled": True}

    def _m_youtube_disconnect(self, params):
        return {"ok": youtube.disconnect()}

    def _m_youtube_test(self, params):
        """Shows what 'open the last video I liked' would open, without opening it."""
        try:
            return tools_all.youtube_latest("liked") | {"video": youtube.latest_in_playlist("liked")}
        except youtube.YouTubeError as exc:
            raise ValueError(str(exc)) from None

    def _m_browser_open(self, params):
        return app_launcher.launch_browser_url(params.get("url", ""), params.get("browser"))

    def _m_apps_test(self, params):
        """Launches an app with the DIRECT method regardless of the setting, so
        the user can see whether direct launching works for their apps."""
        return app_launcher.launch(params.get("name", ""))

    # -- remote access (Tailscale) --
    def _m_remote_tailscale(self, params):
        return remote.tailscale_status(force=bool(params.get("force")))

    def _m_remote_tailscale_serve(self, params):
        result = remote.tailscale_serve(bool(params.get("enable")))
        remote.tailscale_status(force=True)
        return result

    def _m_model_set(self, params):
        """{kind: "text"|"vision", provider, model}; empty provider/model = automatic."""
        kind = params.get("kind")
        if kind not in ("text", "vision"):
            raise ValueError("kind must be 'text' or 'vision'.")
        provider, model = params.get("provider") or "", params.get("model") or ""
        value = f"{provider}:{model}" if provider and model else ""
        return self._m_settings_update({"changes": {f"{kind.upper()}_MODEL_OVERRIDE": value}})

    def _m_tools_list(self, params):
        return {"tools": [
            {"name": t.name, "description": t.description, "category": t.category,
             "risk_level": t.risk_level, "requires_confirmation": t.requires_confirmation,
             "arg_hint": t.arg_hint}
            for cat in tools_all.by_category().values() for t in cat
        ]}

    def _m_agent_status(self, params):
        return {"state": self._last_state, "session_id": self.current_session_id,
                "busy": self._pending_turns > 0,
                "pending_confirmations": len(confirmation.list_pending()),
                "wake_listener": wake_listener.get_state() if wake_listener.is_running() else "off"}

    def _m_voice_list_voices(self, params):
        """Voices for one TTS engine ("sapi" by default -- the old behaviour --
        but "edge" and "piper" work too, see troy/tts.py)."""
        return {"voices": [{"id": v["id"], "name": v["name"]} for v in tts.list_voices(params.get("engine") or "sapi")]}

    def _m_voice_speak(self, params):
        """The Settings > Voice 'Test' button: says one line through the full
        engine chain (whichever TTS engine is selected), not the legacy queue."""
        self.voice.say_on_pc(params.get("text", ""))
        return {"queued": True}

    # -- full voice mode (troy/voice_mode.py) --
    def _m_voice_mode_start(self, params):
        result = self.voice.start(greet=params.get("greet", True))
        if not result.get("started"):
            raise ValueError(result.get("error", "Couldn't start voice mode."))
        return result

    def _m_voice_mode_stop(self, params):
        self.voice.stop(reason=str(params.get("reason") or "user"))
        return {"stopped": True}

    def _m_voice_mode_status(self, params):
        """One call for the whole Voice overlay: mode state, which TTS engines
        can run here, and whether speech recognition is installed."""
        info = self.voice.info()
        info["engines"] = tts.engine_report()
        info["stt"] = voice.stt_status()
        return info

    def _m_voice_mute(self, params):
        self.voice.set_muted(bool(params.get("muted")))
        return self.voice.info()

    def _m_voice_interrupt(self, params):
        """Stop button in the voice overlay: silence Troy and cancel the turn."""
        self.voice.interrupt()
        return {"ok": True}

    def _m_voice_devices(self, params):
        return {"devices": self.voice.devices()}

    def _m_voice_test_mic(self, params):
        return self.voice.test_microphone(float(params.get("seconds", 4)))

    def _m_wake_listener_start(self, params):
        # Installing the voice-mode hooks first means even the plain wake-word
        # listener feeds mic level / transcripts to the UI and shares barge-in.
        self.voice.install_listener()
        ok = wake_listener.start()
        return {"started": ok}

    def _m_wake_listener_stop(self, params):
        wake_listener.stop()
        return {"stopped": True}

    def _m_wake_listener_status(self, params):
        return {"running": wake_listener.is_running(), "state": wake_listener.get_state()}

    def _m_logs_tail(self, params):
        lines = int(params.get("lines", 200))
        path = os.path.join(config.LOGS_DIR, "troy.log")
        if not os.path.exists(path):
            return {"lines": []}
        with open(path, "r", encoding="utf-8", errors="replace") as f:
            all_lines = f.readlines()
        return {"lines": [line.rstrip("\n") for line in all_lines[-lines:]]}

    def _m_app_ping(self, params):
        return {"pong": True, "version": config.VERSION, "version_label": config.VERSION_LABEL}

    # -- mobile web UI (independent optional surface -- a phone on the same Wi-Fi) --
    def _m_mobile_ui_start(self, params):
        # lan_url() returns "" unless this flag is set, so flip it first or
        # a runtime start would succeed but report no address to open.
        config.MOBILE_UI_ENABLED = True
        mobile_server.start(params.get("port"))
        return self._m_mobile_ui_status({})

    def _m_mobile_ui_stop(self, params):
        mobile_server.stop()
        config.MOBILE_UI_ENABLED = False
        return {"stopped": True}

    def _m_mobile_ui_status(self, params):
        running = mobile_server.is_running()
        urls = remote.access_urls(mobile_server.get_token()) if running else []
        return {"running": running, "url": urls[0]["url"] if urls else "", "urls": urls,
                "viewers": mobile_server.viewer_count(), "screen_enabled": config.MOBILE_SCREEN_ENABLED,
                "port": mobile_server.current_port(), "tailscale": remote.tailscale_status()}

    def _m_mobile_ui_regenerate_token(self, params):
        mobile_server.regenerate_token()
        return self._m_mobile_ui_status({})

_METHODS = {
    "app.ping": IPCHost._m_app_ping,
    "chat.send": IPCHost._m_chat_send,
    "chat.stop": IPCHost._m_chat_stop,
    "face.relay": IPCHost._m_face_relay,
    "session.new": IPCHost._m_session_new,
    "session.reset": IPCHost._m_session_reset,
    "power.status": IPCHost._m_power_status,
    "power.report": IPCHost._m_power_report,
    "ui.report": IPCHost._m_ui_report,
    "session.list": IPCHost._m_session_list,
    "session.load": IPCHost._m_session_load,
    "session.save": IPCHost._m_session_save,
    "session.rename": IPCHost._m_session_rename,
    "session.delete": IPCHost._m_session_delete,
    "memory.list": IPCHost._m_memory_list,
    "memory.add": IPCHost._m_memory_add,
    "memory.delete": IPCHost._m_memory_delete,
    "memory.clear": IPCHost._m_memory_clear,
    "context.get": IPCHost._m_context_get,
    "confirmation.list": IPCHost._m_confirmation_list,
    "confirmation.resolve": IPCHost._m_confirmation_resolve,
    "settings.get": IPCHost._m_settings_get,
    "settings.set": IPCHost._m_settings_set,
    "settings.update": IPCHost._m_settings_update,
    "provider.list": IPCHost._m_provider_list,
    "provider.set_primary": IPCHost._m_provider_set_primary,
    "provider.fetch_models": IPCHost._m_provider_fetch_models,
    "model.set": IPCHost._m_model_set,
    "tools.list": IPCHost._m_tools_list,
    "agent.status": IPCHost._m_agent_status,
    "voice.list_voices": IPCHost._m_voice_list_voices,
    "voice.speak": IPCHost._m_voice_speak,
    "voice.mode_start": IPCHost._m_voice_mode_start,
    "voice.mode_stop": IPCHost._m_voice_mode_stop,
    "voice.mode_status": IPCHost._m_voice_mode_status,
    "voice.mute": IPCHost._m_voice_mute,
    "voice.interrupt": IPCHost._m_voice_interrupt,
    "voice.devices": IPCHost._m_voice_devices,
    "voice.test_mic": IPCHost._m_voice_test_mic,
    "wake_listener.start": IPCHost._m_wake_listener_start,
    "wake_listener.stop": IPCHost._m_wake_listener_stop,
    "wake_listener.status": IPCHost._m_wake_listener_status,
    "logs.tail": IPCHost._m_logs_tail,
    "mobile_ui.start": IPCHost._m_mobile_ui_start,
    "mobile_ui.stop": IPCHost._m_mobile_ui_stop,
    "mobile_ui.status": IPCHost._m_mobile_ui_status,
    "mobile_ui.regenerate_token": IPCHost._m_mobile_ui_regenerate_token,
    "remote.tailscale": IPCHost._m_remote_tailscale,
    "remote.tailscale_serve": IPCHost._m_remote_tailscale_serve,
    "session.search": IPCHost._m_session_search,
    "prompt.info": IPCHost._m_prompt_info,
    "youtube.status": IPCHost._m_youtube_status,
    "youtube.connect": IPCHost._m_youtube_connect,
    "youtube.complete": IPCHost._m_youtube_complete,
    "youtube.cancel": IPCHost._m_youtube_cancel,
    "youtube.disconnect": IPCHost._m_youtube_disconnect,
    "youtube.test": IPCHost._m_youtube_test,
    "browser.open": IPCHost._m_browser_open,
    "apps.test": IPCHost._m_apps_test,
    "tasks.list": IPCHost._m_tasks_list,
    "tasks.get": IPCHost._m_tasks_get,
    "tasks.preview": IPCHost._m_tasks_preview,
    "tasks.create": IPCHost._m_tasks_create,
    "tasks.modify": IPCHost._m_tasks_modify,
    "tasks.cancel": IPCHost._m_tasks_cancel,
    "tasks.pause": IPCHost._m_tasks_pause,
    "tasks.resume": IPCHost._m_tasks_resume,
    "tasks.run_now": IPCHost._m_tasks_run_now,
    "tasks.delete": IPCHost._m_tasks_delete,
    "tasks.clear_finished": IPCHost._m_tasks_clear_finished,
    "tasks.approve": IPCHost._m_tasks_approve,
    "tasks.logs": IPCHost._m_tasks_logs,
}


def run_forever():
    """The process's whole life once started with `python main.py --ipc`:
    read one JSON request per line from stdin until it closes (which
    happens when Electron quits or kills this child process), dispatch
    each one, and keep emitting events in the background the entire time.
    Never returns on its own under normal operation."""
    host = IPCHost()

    # Hands-free voice is only useful if it's already listening when the window
    # is hidden in the tray, so honour the saved setting at startup rather than
    # waiting for a frontend to ask.
    if config.VOICE_INPUT_ENABLED:
        try:
            host._m_wake_listener_start({})
        except Exception as exc:  # noqa: BLE001 - a missing mic must never stop startup
            logger.warning("Couldn't start voice input at launch: %s", exc)

    _emit("app.ready", {"version": config.VERSION, "version_label": config.VERSION_LABEL})
    logger.info("IPC host ready, listening on stdin.")

    for raw_line in sys.stdin:
        raw_line = raw_line.strip()
        if not raw_line:
            continue
        try:
            request = json.loads(raw_line)
        except json.JSONDecodeError as exc:
            logger.warning("Malformed IPC request line, ignoring: %s", exc)
            continue

        request_id = request.get("id")
        method = request.get("method", "")
        params = request.get("params", {})

        def _handle(request_id=request_id, method=method, params=params):
            try:
                result = host.handle_request(method, params)
                _respond_ok(request_id, result)
            except Exception as exc:  # noqa: BLE001 - one bad request must never kill the host process
                logger.error("IPC method '%s' failed: %s\n%s", method, exc, traceback.format_exc())
                _respond_err(request_id, str(exc))

        # Each request handled on its own thread: a slow one (an agent
        # turn especially, but also e.g. voice.list_voices initializing a
        # TTS engine) must never block the stdin reader from picking up
        # the NEXT request (like chat.stop, which has to arrive and be
        # acted on while a turn is still running).
        threading.Thread(target=_handle, daemon=True, name=f"troy-ipc-{method}").start()

    logger.info("stdin closed -- Electron parent process is gone. Shutting down.")
    try:
        host.voice.stop("shutdown", say="")
    except Exception:  # noqa: BLE001 - never block shutdown on a stuck speaker
        pass
    wake_listener.stop()
    host.tasks.stop()
    mobile_server.stop()
