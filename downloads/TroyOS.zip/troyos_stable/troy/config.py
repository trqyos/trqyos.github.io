"""
Troy Assistant - Configuration

Reads API keys and settings from environment variables (loaded from a local
.env file). Copy .env.example to .env and fill in your keys before running.
"""

import os
from dotenv import load_dotenv

load_dotenv()

# --- Project root ---
# Resolved from this file's location (troy/config.py -> parent is project root),
# NOT from the current working directory. This matters: relative paths break
# if Troy is ever launched from a shortcut, a different folder, or a scheduled
# task with a different cwd -- you'd silently get a brand new empty memory
# file instead of your real one. Everything persistent is anchored here.
PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

# --- Versioning ---
VERSION = "v1.0.0"
VERSION_LABEL = "TROYOS STABLE"

# --- API Keys ---
GROQ_API_KEY = os.getenv("GROQ_API_KEY", "")
OPENROUTER_API_KEY = os.getenv("OPENROUTER_API_KEY", "")
# Google AI Studio key (https://aistudio.google.com/apikey) -- used through
# Google's own OpenAI-compatibility endpoint, so it's just another entry in
# the same provider chain as Groq/OpenRouter, not a separate code path.
GEMINI_API_KEY = os.getenv("GEMINI_API_KEY", "")

# --- Provider endpoints (all OpenAI-compatible) ---
GROQ_BASE_URL = "https://api.groq.com/openai/v1"
OPENROUTER_BASE_URL = "https://openrouter.ai/api/v1"
GEMINI_BASE_URL = "https://generativelanguage.googleapis.com/v1beta/openai"

# --- Models ---
# NOTE: Groq in particular retires free model slugs often. Rather than
# hardcode one name and break every few months, each provider gets an
# ORDERED LIST of candidates -- the client tries them top to bottom and
# uses the first one that works. If ALL candidates for a provider fail,
# run `python check_models.py` to print every model your API keys
# currently have access to, then add the right slug to the top of the
# relevant list below.
#   Groq's current list:       https://console.groq.com/docs/models
#   OpenRouter's current list: https://openrouter.ai/models  (filter by "free")

# Fast text models for the main agent loop (tool calling / reasoning)
GROQ_TEXT_MODELS = [
    "openai/gpt-oss-120b",
    "openai/gpt-oss-20b",
    "qwen/qwen3-32b",
]
OPENROUTER_TEXT_MODELS = [
    "google/gemma-4-31b-it:free",
    "z-ai/glm-5.2:free",
    "nvidia/nemotron-3.5-lightning:free",
    "thinkingmachines/inkling:free",
    "minimax/minimax-m2.7:free",
    "nvidia/llama-nemotron-embed-vl-1b-v2:free",
]

# Vision-capable models for screenshot feedback.
# qwen/qwen3.6-27b confirmed working on Groq -- tried first. The llama-4
# models are kept as a fallback in case qwen gets retired/renamed later.
GROQ_VISION_MODELS = [
    "qwen/qwen3.6-27b",
    "meta-llama/llama-4-scout-17b-16e-instruct",
    "meta-llama/llama-4-maverick-17b-128e-instruct",
]
OPENROUTER_VISION_MODELS = [
    "meta-llama/llama-3.2-11b-vision-instruct:free",
    "qwen/qwen2.5-vl-32b-instruct:free",
]

# Gemini models are natively multimodal, so the same models cover both
# text and vision -- no separate vision list needed.
GEMINI_TEXT_MODELS = [
    "gemini-2.5-flash",
    "gemini-2.0-flash",
    "gemini-1.5-flash",
]
GEMINI_VISION_MODELS = GEMINI_TEXT_MODELS

# --- NVIDIA NIM (build.nvidia.com) ---
# NVIDIA's hosted model catalog (https://build.nvidia.com), reached through
# the same OpenAI-compatible /chat/completions shape as every other
# provider here -- no separate code path needed. Get a key from
# https://build.nvidia.com (top-right -> Get API Key) after picking any
# model on the site. Accepts either env var name since NVIDIA's own docs
# and sample code (what you get from build.nvidia.com's "View Code" button)
# always say plain `NVIDIA_API_KEY`, not the `TROY_`-prefixed convention
# used elsewhere here -- both work, TROY_NVIDIA_API_KEY takes precedence
# if somehow both are set.
NVIDIA_API_KEY = os.getenv("TROY_NVIDIA_API_KEY", "").strip() or os.getenv("NVIDIA_API_KEY", "").strip()
NVIDIA_BASE_URL = os.getenv("TROY_NVIDIA_BASE_URL", "https://integrate.api.nvidia.com/v1").strip().rstrip("/")
# Ordered like the other providers: tried top to bottom, first one that
# works wins. Reordering this list (or overriding via TEXT_MODEL_OVERRIDE
# = "nvidia:<slug>") is the way to change which one Troy actually uses --
# there's no separate "pick a model" setting beyond this list + the
# override.
NVIDIA_TEXT_MODELS = [
    "nvidia/nemotron-3-super-120b-a12b",
    "z-ai/glm-5.3",
    "nvidia/nemotron-3.5-lightning-30b-a3b",
    "z-ai/glm-5.3-flash",
    "openai/gpt-oss-20b",
    "meta/muse-glimmer-30b",
    "mistralai/mistral-nemotron",
    "poolside/laguna-xs-2.1",
    "google/gemma-4-31b-it",
]
# Only the models actually documented as accepting an image_url content
# part (see build.nvidia.com's own sample code for each model) go here.
NVIDIA_VISION_MODELS = [
    "moonshotai/kimi-k3",
    "google/diffusiongemma-26b-a4b-it",
]

# --- NewsAPI (https://newsapi.org) -- backs the news_top_headlines / news_search tools ---
# Free developer key: https://newsapi.org/register. Blank = those two tools
# return a clear "not configured" message instead of failing obscurely.
# (Open-Meteo, Frankfurter and Wikipedia, used by the other api tools,
# are keyless and need no configuration.)
NEWSAPI_KEY = os.getenv("TROY_NEWSAPI_KEY", "").strip() or os.getenv("NEWSAPI_KEY", "").strip()

# --- LM Studio (local, private, no API key or internet required) ---
# LM Studio (https://lmstudio.ai) runs an OpenAI-compatible server on your
# own machine -- point it at whatever model you've loaded there and Troy
# talks to it exactly like it talks to Groq/OpenRouter, just with a
# different base_url. Off by default: it only makes sense to try it once
# you actually have LM Studio's local server running, so enabling it is
# opt-in rather than something that silently adds a slow "connection
# refused" attempt to every turn.
LMSTUDIO_ENABLED = os.getenv("TROY_LMSTUDIO_ENABLED", "false").strip().lower() == "true"
LMSTUDIO_BASE_URL = os.getenv("TROY_LMSTUDIO_BASE_URL", "http://localhost:1234/v1").strip().rstrip("/")
# LM Studio's local server doesn't actually check this -- it just needs to
# be a non-empty string so the client's "is a key configured" check passes.
LMSTUDIO_API_KEY = os.getenv("TROY_LMSTUDIO_API_KEY", "lm-studio").strip() or "lm-studio"
# Leave blank to auto-detect whatever model(s) LM Studio currently has
# loaded (queried from its /v1/models endpoint each call); set explicitly
# to pin one, e.g. if multiple models are loaded at once.
LMSTUDIO_TEXT_MODEL = os.getenv("TROY_LMSTUDIO_TEXT_MODEL", "").strip()
LMSTUDIO_VISION_MODEL = os.getenv("TROY_LMSTUDIO_VISION_MODEL", "").strip()

# Which provider to try first. Automatically falls back to the others on
# any failure (rate limit, model retired, network error, connection
# refused, etc).
PRIMARY_PROVIDER = os.getenv("TROY_PRIMARY_PROVIDER", "groq")  # "groq", "openrouter", "gemini", "nvidia", or "lmstudio"

# --- Manual model overrides (set from the UI's Settings > Models panel) ---
# Format: "provider:model_slug", e.g. "groq:openai/gpt-oss-120b" or
# "nvidia:z-ai/glm-5.3". Empty
# string means "auto" -- just use the candidate lists above as-is. When
# set, the chosen model is moved to the FRONT of its provider's candidate
# list rather than replacing the list -- so a bad manual pick still falls
# back through the rest of the chain instead of hard-failing. This is the
# stability trade-off: you get control, but a stale/wrong override can
# never fully break the assistant.
TEXT_MODEL_OVERRIDE = os.getenv("TROY_TEXT_MODEL_OVERRIDE", "").strip()
VISION_MODEL_OVERRIDE = os.getenv("TROY_VISION_MODEL_OVERRIDE", "").strip()

# --- Agent behaviour ---
MAX_STEPS_PER_TURN = 12           # safety cap on the observe/react loop per user turn
SCREENSHOT_DIR = os.path.join(PROJECT_ROOT, "troy_screenshots")
MEMORY_FILE = os.path.join(PROJECT_ROOT, "troy_memory.json")
SESSIONS_DIR = os.path.join(PROJECT_ROOT, "troy_sessions")
MAX_MEMORIES_IN_CONTEXT = 40      # cap how many stored facts get injected into every turn

# --- Logging (troy/logger.py) ---
LOGS_DIR = os.path.join(PROJECT_ROOT, "troy_logs")
LOG_LEVEL = os.getenv("TROY_LOG_LEVEL", "INFO").strip().upper()

# --- Escalation (troy/escalation.py) ---
# When Troy genuinely cannot complete something itself, it can escalate to
# Gemini's web app as a last resort: it opens https://gemini.google.com/app,
# submits a structured description of the problem, and reads back the
# answer (OCR first, vision description as a fallback) as an observation.
ESCALATION_URL = os.getenv("TROY_ESCALATION_URL", "https://gemini.google.com/app").strip()
ESCALATION_ENABLED = os.getenv("TROY_ESCALATION_ENABLED", "true").strip().lower() == "true"

# --- Assistant / user identity ---
ASSISTANT_NAME = "Troy"
# Fill this in with your real name -- Troy uses it in conversation. Can also
# be set via TROY_USER_NAME in .env instead of editing this file directly.
USER_NAME = os.getenv("TROY_USER_NAME", "").strip() or "the user"

# --- Mobile web UI (troy/mobile_server.py) ---
# A small local HTTP server exposing the same running TroyAgent through a
# phone-friendly web page, for remote control over the local network (no
# internet exposure, no cloud relay). Off by default -- opt in from
# Settings, since it opens a port other devices on the LAN can reach.
MOBILE_UI_ENABLED = os.getenv("TROY_MOBILE_UI_ENABLED", "false").strip().lower() == "true"
MOBILE_UI_PORT = int(os.getenv("TROY_MOBILE_UI_PORT", "8765"))
# Random per-install token so a phone has to be paired with the URL Troy
# shows in Settings -- anyone else on the same Wi-Fi can't just guess the
# port and start issuing commands.
MOBILE_UI_TOKEN = os.getenv("TROY_MOBILE_UI_TOKEN", "").strip()

# --- Power saving (troy/power.py) ---
# off  = full animations and refresh rates
# auto = turns itself on while the laptop runs on battery
# on   = always on (calmer visuals, slower live updates, lower phone-screen fps)
POWER_SAVING = os.getenv("TROY_POWER_SAVING", "auto").strip().lower()

# --- Voice (troy/voice.py, troy/wake_listener.py) ---
# Always-on voice: a background thread listens to the mic continuously
# (no push-to-talk button), waits for the wake word, then captures and
# auto-sends what's said next -- no button, no manual "send". Off by
# default; enable from Settings > Voice or TROY_VOICE_INPUT_ENABLED=true.
VOICE_INPUT_ENABLED = os.getenv("TROY_VOICE_INPUT_ENABLED", "false").strip().lower() == "true"
VOICE_OUTPUT_ENABLED = os.getenv("TROY_VOICE_OUTPUT_ENABLED", "false").strip().lower() == "true"

# Said (case-insensitively, as a whole word) to wake Troy up. "Troy, open
# Chrome" in one breath works immediately; saying just "Troy" opens a
# short follow-up window (WAKE_WORD_FOLLOWUP_SECONDS) where whatever's
# said next doesn't need the wake word repeated -- a normal back-and-forth
# voice exchange rather than one wake word per sentence.
WAKE_WORD = os.getenv("TROY_WAKE_WORD", "troy").strip().lower()
WAKE_WORD_FOLLOWUP_SECONDS = float(os.getenv("TROY_WAKE_WORD_FOLLOWUP_SECONDS", "8"))

# Which speech-to-text engine to use -- pick whichever fits: "google" needs
# nothing but an internet connection (uses the free, keyless Google Web
# Speech endpoint via the `SpeechRecognition` package -- rate-limited and
# not for heavy/commercial use, but free and effectively zero setup).
# "whisper" runs fully offline/locally via faster-whisper -- private, no
# rate limit, but a one-time model download and meaningfully more setup
# (see README > Voice setup). Both are always available side by side;
# this just picks the default.
STT_ENGINE = os.getenv("TROY_STT_ENGINE", "google").strip().lower()  # "google" or "whisper"
# BCP-47 language code for recognition, e.g. "en-US". Blank lets each
# engine auto-detect/use its own default.
STT_LANGUAGE = os.getenv("TROY_STT_LANGUAGE", "").strip()

# tiny / base / small / medium / large-v3 -- bigger = more accurate, slower,
# more VRAM/RAM. "base" is a reasonable default on a GPU; drop to "tiny" on
# CPU-only machines. Only relevant when STT_ENGINE="whisper".
WHISPER_MODEL_SIZE = os.getenv("TROY_WHISPER_MODEL_SIZE", "base").strip()
# "cuda" to force GPU, "cpu" to force CPU, "auto" to try GPU then fall back.
WHISPER_DEVICE = os.getenv("TROY_WHISPER_DEVICE", "auto").strip()

# How much louder than the room's own background noise a sound needs to be
# before it's treated as someone speaking (a simple adaptive energy gate,
# not a heavyweight VAD model -- see troy/wake_listener.py). Raise this in
# a noisy room if it's triggering on background sound; lower it if quiet
# speech isn't being picked up.
VAD_ENERGY_MULTIPLIER = float(os.getenv("TROY_VAD_ENERGY_MULTIPLIER", "3.0"))
# How much trailing silence ends an utterance -- this is the knob for
# "detects when speech ends quickly": lower = snappier turn-taking, higher
# = more tolerant of mid-sentence pauses.
VAD_SILENCE_HANGOVER_SECONDS = float(os.getenv("TROY_VAD_SILENCE_HANGOVER_SECONDS", "0.6"))
VAD_MAX_UTTERANCE_SECONDS = float(os.getenv("TROY_VAD_MAX_UTTERANCE_SECONDS", "15"))

TTS_VOICE_ID = os.getenv("TROY_TTS_VOICE_ID", "").strip()  # blank = system default voice
TTS_RATE = int(os.getenv("TROY_TTS_RATE", "185"))           # words per minute, pyttsx3 default ~200

# --- Web research browser (troy/browser_worker.py, the web_* tools) ---
# A real, persistent Chromium instance driven through Playwright, for
# reliable, INVISIBLE background web research -- reading actual page
# structure and clicking real elements by role/text, instead of guessing
# pixel coordinates from a screenshot. This is a separate browser/profile
# from the user's actual Firefox/Chrome (opened via open_app/open_url) --
# see system_prompt.py's WEB RESEARCH TOOLS vs. YOUR BROWSER section.
# Requires `playwright install chromium` once after pip installing the
# `playwright` package (see requirements.txt).
BROWSER_HEADLESS = os.getenv("TROY_BROWSER_HEADLESS", "true").strip().lower() == "true"
# Reusing a real Chrome profile directory (rather than a throwaway one)
# means Troy's research browser stays logged into whatever you're normally
# logged into there -- opt-in since that's meaningfully more access than a
# blank profile.
BROWSER_PROFILE_DIR = os.getenv("TROY_BROWSER_PROFILE_DIR", os.path.join(PROJECT_ROOT, "troy_browser_profile")).strip()


# --- Speed and context size (troy/context_budget.py, troy/llm_client.py) ---
# Every request is fitted to a token budget before it is sent. The defaults
# keep a typical request well under Groq's free-tier 8000 tokens-per-minute
# cap and make replies noticeably faster on every provider.
# Which system prompt to use: "auto" (compact for cloud models, tiny for a
# small local context window), "compact", "tiny", or "detailed" (the original
# ~9k-token prompt: slow, only worth it on a big-context model).
PROMPT_MODE = os.getenv("TROY_PROMPT_MODE", "auto").strip().lower()
# Most tokens of conversation + prompt sent per request (cloud providers).
CONTEXT_BUDGET_TOKENS = int(os.getenv("TROY_CONTEXT_BUDGET_TOKENS", "5500"))
# Cap on the reply length. Providers count this against rate limits too.
LLM_MAX_OUTPUT_TOKENS = int(os.getenv("TROY_LLM_MAX_OUTPUT_TOKENS", "1200"))
# Ask reasoning models to think less (Groq gpt-oss/qwen3, Gemini 2.5, ...).
# Troy's replies are short command lines, so long hidden reasoning is wasted time.
LLM_FAST = os.getenv("TROY_LLM_FAST", "true").strip().lower() == "true"
# Longest tool output kept in the conversation (characters).
OBSERVATION_MAX_CHARS = int(os.getenv("TROY_OBSERVATION_MAX_CHARS", "1800"))
# LM Studio: used when the server doesn't report the loaded model's context
# length. Set it to what you loaded the model with (LM Studio defaults to 4096).
LMSTUDIO_CONTEXT_TOKENS = int(os.getenv("TROY_LMSTUDIO_CONTEXT_TOKENS", "4096"))
# Screenshots are shrunk before being sent to a vision model; local models in
# particular spend thousands of tokens on a full-resolution desktop.
LMSTUDIO_VISION_MAX_SIDE = int(os.getenv("TROY_LMSTUDIO_VISION_MAX_SIDE", "1024"))
VISION_MAX_SIDE = int(os.getenv("TROY_VISION_MAX_SIDE", "1600"))

# --- Launching apps (troy/tools_all.py open_app) ---
# "direct": start the program itself (PATH, App Paths, Start Menu shortcuts,
#           Store apps) -- no keyboard simulation, doesn't touch what you're doing.
# "start_menu": press the Windows key, type the name, press Enter (the original way).
# "auto": try direct first, fall back to the Start menu. The model-facing
# command is always just open_app:<name>.
APP_LAUNCH_MODE = os.getenv("TROY_APP_LAUNCH_MODE", "auto").strip().lower()

# --- Phone page: live screen + remote access (troy/mobile_server.py, troy/remote.py) ---
MOBILE_SCREEN_ENABLED = os.getenv("TROY_MOBILE_SCREEN_ENABLED", "true").strip().lower() == "true"
MOBILE_SCREEN_MAX_FPS = int(os.getenv("TROY_MOBILE_SCREEN_MAX_FPS", "10"))

# --- YouTube Data API v3 with OAuth 2.0 (troy/youtube.py) ---
# Create an OAuth client of type "Desktop app" at
# https://console.cloud.google.com/apis/credentials (and enable "YouTube Data
# API v3"), then paste the client id/secret in Settings > Integrations.
YOUTUBE_CLIENT_ID = os.getenv("TROY_YOUTUBE_CLIENT_ID", "").strip()
YOUTUBE_CLIENT_SECRET = os.getenv("TROY_YOUTUBE_CLIENT_SECRET", "").strip()
# Browser used by youtube_open_*: "firefox" (default), "chrome", "edge" or
# "default" for the system default.
YOUTUBE_BROWSER = os.getenv("TROY_YOUTUBE_BROWSER", "firefox").strip().lower()
YOUTUBE_TOKEN_FILE = os.path.join(PROJECT_ROOT, "troy_youtube_token.json")


# --- Letting Troy change its own model mid-chat (set_model / reset_model tools) ---
# Switching is applied immediately and saved, exactly like picking a model in the
# UI. Moving from a LOCAL model to a cloud one always asks for approval first,
# since that sends your conversation off the machine.
ALLOW_MODEL_SWITCH = os.getenv("TROY_ALLOW_MODEL_SWITCH", "true").strip().lower() == "true"


# --- Full voice mode (troy/voice_mode.py, troy/tts.py, troy/audio_in.py) ---
# Text-to-speech engine: "auto" (Piper if a model is set, else Windows voices),
# "sapi" (built-in Windows voices, offline), "edge" (Microsoft's neural voices:
# much more natural, needs internet + `pip install edge-tts`), or "piper"
# (natural and fully offline: `pip install piper-tts` + a voice file, below).
TTS_ENGINE = os.getenv("TROY_TTS_ENGINE", "auto").strip().lower()
EDGE_VOICE = os.getenv("TROY_EDGE_VOICE", "en-US-AriaNeural").strip()
# Path to a Piper voice (.onnx; its .onnx.json sits next to it). Voices:
# https://huggingface.co/rhasspy/piper-voices
PIPER_MODEL = os.getenv("TROY_PIPER_MODEL", "").strip()
# In voice mode, how long Troy keeps listening for a follow-up with no wake word.
VOICE_CONVERSATION_IDLE_SECONDS = int(os.getenv("TROY_VOICE_CONVERSATION_IDLE_SECONDS", "25"))
# Let the user interrupt Troy by talking over it (a clearly louder voice).
VOICE_BARGE_IN = os.getenv("TROY_VOICE_BARGE_IN", "true").strip().lower() == "true"
# Substring of the microphone's name to use ("" = system default). Pick it in Settings > Voice.
VOICE_INPUT_DEVICE = os.getenv("TROY_VOICE_INPUT_DEVICE", "").strip()
# Ask the model for short, speakable replies (no lists/links/markdown) while voice is in use.
VOICE_SPOKEN_STYLE = os.getenv("TROY_VOICE_SPOKEN_STYLE", "true").strip().lower() == "true"
# Phone as microphone + speaker (needs HTTPS on the phone: Tailscale HTTPS or the Wi-Fi HTTPS link).
MOBILE_VOICE_ENABLED = os.getenv("TROY_MOBILE_VOICE_ENABLED", "true").strip().lower() == "true"
# What speaks Troy's replies during a phone voice session: "phone" (the phone's own
# voice: instant) or "troy" (Troy's chosen voice, generated on the PC and streamed).
VOICE_PHONE_SPEAKER = os.getenv("TROY_VOICE_PHONE_SPEAKER", "phone").strip().lower()
# Serve the phone page over HTTPS on the LAN too (self-signed certificate, needed for
# the phone's microphone on plain Wi-Fi). The port is MOBILE_UI_PORT + 1.
MOBILE_HTTPS_ENABLED = os.getenv("TROY_MOBILE_HTTPS_ENABLED", "true").strip().lower() == "true"


# --- Scheduled tasks (troy/scheduler.py, troy/task_runner.py, troy/tools_tasks.py) ---
# "Put the computer to sleep at 10 PM", "every Monday at 9 remind me ...": Troy stores the task
# and its own short instruction, a background scheduler (no model involved while it waits)
# wakes at the right moment, and only then is the model asked to carry the instruction out.
TASKS_ENABLED = os.getenv("TROY_TASKS_ENABLED", "true").strip().lower() == "true"
TASKS_FILE = os.path.join(PROJECT_ROOT, "troy_tasks.json")          # tasks + their state (survives restarts)
TASK_LOG_FILE = os.path.join(PROJECT_ROOT, "troy_task_runs.jsonl")  # one JSON line per run event
# A failed run is tried again this many times (so 1 + retries attempts in all), waiting this
# long between attempts. Each task can override both.
TASK_MAX_RETRIES = int(os.getenv("TROY_TASK_MAX_RETRIES", "2"))
TASK_RETRY_DELAY_SECONDS = int(os.getenv("TROY_TASK_RETRY_DELAY_SECONDS", "30"))
# If Troy wasn't running (or the PC was asleep) when a task was due, it still runs when it comes
# back within this many minutes; later than that it is marked "missed" instead of firing out of the blue.
TASK_MISSED_GRACE_MINUTES = int(os.getenv("TROY_TASK_MISSED_GRACE_MINUTES", "10"))

# --- On-demand extra tools (troy/extra_tools.py) ---
# The prompt states only the core tools. The rest are found with the list_extra_tools command
# when a request needs them, and forgotten again when the request is done (only the ones that
# were actually used stay in the chat history). false = the old behaviour: every tool in the prompt.
EXTRA_TOOLS_ENABLED = os.getenv("TROY_EXTRA_TOOLS_ENABLED", "true").strip().lower() == "true"

# How Troy calls tools. "native" = the provider's own function calling (tools travel in the API's `tools` field, answers
# come back as structured JSON: troy/tool_schema.py, tool_history.py, native_loop.py). "text" = the original protocol
# (commands written as `name:arg|arg` lines and parsed). "auto" (default) = native, and a model/provider that doesn't
# support it is remembered and served with the text protocol instead.
TOOL_CALLING = os.getenv("TROY_TOOL_CALLING", "auto").strip().lower()
if TOOL_CALLING not in ("auto", "native", "text"):
    TOOL_CALLING = "auto"


# --- Xiaomi robot vacuum (troy/vacuum.py, troy/miot_client.py, troy/tools_vacuum.py) ---
# Local control of a Xiaomi Robot Vacuum S20+ (xiaomi.vacuum.b108gl) over the LAN: no cloud account is used at run time.
# You need the robot's IP address and its 32-character device token (see docs/VACUUM.md for how to get it).
VACUUM_ENABLED = os.getenv("TROY_VACUUM_ENABLED", "false").strip().lower() == "true"
VACUUM_HOST = os.getenv("TROY_VACUUM_HOST", "").strip()
VACUUM_TOKEN = os.getenv("TROY_VACUUM_TOKEN", "").strip()          # a secret: write-only in the Settings screen
VACUUM_TIMEOUT_SECONDS = float(os.getenv("TROY_VACUUM_TIMEOUT_SECONDS", "3"))
# How a room-clean command is encoded for the S20+. Different stacks report different encodings working, so "auto" tries
# them in turn, checks that the robot really started a room clean, and remembers the one that worked.
VACUUM_ROOM_ENCODING = os.getenv("TROY_VACUUM_ROOM_ENCODING", "auto").strip().lower()

# --- Interface language (the Electron app, its widget and the phone page) ---
# "en" | "tr" | "auto" (follow the system language). Changed in Settings > General > Language.
UI_LANGUAGE = os.getenv("TROY_UI_LANGUAGE", "en").strip().lower()
if UI_LANGUAGE not in ("en", "tr", "auto"):
    UI_LANGUAGE = "en"
