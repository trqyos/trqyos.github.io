"""
On-demand extra tools.

The system prompt states only the core tools. Everything else Troy can do is an
"extra" tool: real and registered, but not described up front. When a request needs
more than the prompt offers, Troy calls

    list_extra_tools            -> every extra tool, by category, with exact usage
    list_extra_tools:<filter>   -> one category, or the tools matching some words

and the list is handed back to it as an observation. A tool is "extra" exactly when its
name does not appear in the system prompt it was given (so this works the same for the
tiny, compact and detailed prompts, and says honestly "nothing extra" when the prompt
already lists everything).

Why this is built the way it is -- the risk is hallucination, so every step is explicit:

  * The list is complete or it says exactly what it leaves out. Too long for the model's
    budget? It drops to names only and says so, never silently cut in the middle.
  * The prompt and the list both carry the same rule: only commands that were shown exist;
    if none fits, tell the user you can't. An unknown command name comes back as FAILED
    with the nearest real names, not as a shrug.
  * An extra tool is run only after its exact usage was shown in this request (by the list,
    by "Likely relevant tools", or by an earlier use). The first call of one that was never
    shown does NOT run: it returns the usage instead, so a guessed argument shape can't act.
  * When the request is over, the list is cut out of the chat history again (collapse()),
    leaving a one-line stub plus the usage of only the tools that were actually used. The
    next request starts from the original prompt's capabilities.
"""

import difflib
import re
import threading
from contextlib import contextmanager

from . import config, context_budget, tools_all

LIST_OPEN, LIST_CLOSE = context_budget.EXTRA_LIST_MARKER, "[/EXTRA-TOOLS-LIST]"
KEPT_OPEN, KEPT_CLOSE = "[EXTRA-TOOLS-KEPT]", "[/EXTRA-TOOLS-KEPT]"

# Usable without ever being listed: the discovery commands themselves and the task report.
UNGATED = {"list_extra_tools", "tool_help", "list_tools", "task_result"}

# Built-in commands (handled in dispatcher.py, not in the registry): usage for those a short prompt may leave out.
BUILTIN_USAGE = {
    "close_active_window": "Closes the active window (Alt+F4).", "minimize_window": "Minimizes the active window.",
    "maximize_window": "Maximizes the active window.", "switch_window": "Opens the Alt+Tab switcher.",
    "move_mouse": "move_mouse:<x>,<y> -- moves the pointer.", "window_exists": "window_exists:<query> -- is a window with that title open?",
    "get_media_info": "What is playing right now.", "get_storage_info": "Disk space.",
    "move_file": "move_file:<src>|<dst>", "copy_file": "copy_file:<src>|<dst>",
    "play_audio": "Toggles play/pause.", "pause_audio": "Toggles play/pause.",
    "locate_on_screen": "locate_on_screen:<description> -- pixel position of something on screen.",
    "get_context": "Live snapshot: time, active window, CPU/RAM.", "escalate": "Last resort: asks a bigger model for help.",
}

# Every command dispatcher.py handles itself (not in the registry). A test keeps this in step with the dispatcher.
BUILTIN_COMMANDS = frozenset("""click click_target close_active_window copy_file create_file done escalate find_files get_active_window get_clipboard
get_context get_media_info get_storage_info get_system_stats get_time get_weather hotkey kill_process list_dir list_processes list_tools
list_windows locate_on_screen maximize_window minimize_window move_file move_mouse open_app open_url pause_audio play_audio press_key
read_file read_screen_text recall remember screenshot scroll search_newtab set_clipboard speak switch_window tool_help type_text
volume_down volume_mute volume_up wait window_exists""".split())

_local = threading.local()


# ---------------------------------------------------------------- the catalog
def _tokens(text: str) -> set:
    return set(re.findall(r"[A-Za-z0-9_]+", text or ""))


def catalog() -> dict:
    """Every tool that exists: name -> dict(category, usage, description, approval, info)."""
    out = {}
    for name, t in tools_all.all_tools().items():
        out[name] = {"name": name, "category": t.category, "args": (t.arg_hint or "").replace("<", "").replace(">", "").strip(),
                     "description": t.description, "approval": t.requires_confirmation, "info": t.info}
    for name, text in BUILTIN_USAGE.items():
        out.setdefault(name, {"name": name, "category": "basic", "args": "", "description": text, "approval": False, "info": False})
    return out


def stated_names(text: str) -> set:
    """Tool names that appear (as whole words) in `text`, e.g. a system prompt."""
    return _tokens(text) & set(catalog())


def usage_line(name: str, with_description: bool = True) -> str:
    t = catalog().get(name)
    if not t:
        return name
    head = f"{name}:{t['args']}" if t["args"] else name
    flags = ("!" if t["approval"] else "") + ("*" if t["info"] else "")
    return f"{head}{flags}" + (f" -- {t['description'][:140]}" if with_description else "")


def _limit_chars() -> int:
    return int(min(6000, max(1500, config.CONTEXT_BUDGET_TOKENS * context_budget.CHARS_PER_TOKEN * 0.3)))


# ---------------------------------------------------------------- one request's state
class RequestTools:
    """What has been shown to the model during one request, and which extras it used."""

    def __init__(self, messages_provider):
        self._messages = messages_provider
        self.revealed: set = set()
        self.used: dict = {}                 # name -> usage line

    def _msgs(self):
        try:
            return self._messages() or []
        except Exception:  # noqa: BLE001
            return []

    def prompt_stated(self) -> set:
        """Names in the system prompt plus the per-turn 'Likely relevant tools' hint."""
        msgs = self._msgs()
        text = msgs[0].get("content", "") if msgs else ""
        if len(msgs) > 2 and isinstance(msgs[2].get("content"), str):
            ctx = msgs[2]["content"]
            marker = ctx.find("Likely relevant tools")
            if marker >= 0:
                text += "\n" + ctx[marker:]
        return stated_names(text)

    def kept_names(self) -> set:
        """Extras used in earlier requests whose usage was kept in the chat history."""
        names = set()
        for m in self._msgs()[3:]:
            c = m.get("content")
            if isinstance(c, str) and KEPT_OPEN in c:
                for block in re.findall(re.escape(KEPT_OPEN) + r"(.*?)" + re.escape(KEPT_CLOSE), c, re.S):
                    names |= {x.strip().split(":")[0].split(" ")[0].rstrip("!*") for x in block.split(";") if x.strip()}
        return names & set(catalog())

    def is_extra(self, name: str) -> bool:
        return name in catalog() and name not in self.prompt_stated()


def begin(messages_provider) -> RequestTools:
    return RequestTools(messages_provider)


def current():
    return getattr(_local, "req", None)


@contextmanager
def activate(req):
    previous = getattr(_local, "req", None)
    _local.req = req
    try:
        yield req
    finally:
        _local.req = previous


# ---------------------------------------------------------------- guarding execution
def gate(name: str, arg: str):
    """Called by the dispatcher before a registry tool runs. Returns None to let it run, or a FAILED result."""
    req = current()
    if req is None or not config.EXTRA_TOOLS_ENABLED or name in UNGATED or tools_all.get(name) is None:
        return None
    if not req.is_extra(name) or name in req.revealed or name in req.kept_names():
        return None
    req.revealed.add(name)
    return {"success": False, "needs_followup": True, "message": (
        f"'{name}' is an extra tool whose usage hadn't been shown to you yet, so it did NOT run. Exact usage: {usage_line(name)}. "
        "If that is what you need, call it again exactly that way; if not, call list_extra_tools.")}


def note_use(name: str, result: dict) -> None:
    req = current()
    if req is not None and req.is_extra(name):
        req.used[name] = usage_line(name)


def unknown_command(name: str) -> dict:
    """FAILED result for a command that doesn't exist, steering the model to real names instead of guesses."""
    close = difflib.get_close_matches(name, list(catalog()), n=3, cutoff=0.6)
    hint = f" Did you mean: {', '.join(close)}?" if close else ""
    advice = "Call list_extra_tools to see the other tools." if config.EXTRA_TOOLS_ENABLED else "Check the command list in your prompt."
    return {"success": False, "needs_followup": True, "message": (
        f"'{name}' is not a command: it doesn't exist.{hint} Only commands from your prompt or the tool lists you were shown exist. "
        f"{advice} If nothing can do what the user asked, tell them plainly that you can't; never invent a command.")}


# ---------------------------------------------------------------- list_extra_tools
def _group(tools: list) -> dict:
    out: dict = {}
    for t in sorted(tools, key=lambda t: (t["category"], t["name"])):
        out.setdefault(t["category"], []).append(t)
    return out


def _compact(t, with_args=True) -> str:
    args = t["args"] if with_args else ""
    return f"{t['name']}{'(' + args + ')' if args else ''}{'!' if t['approval'] else ''}{'*' if t['info'] else ''}"


def list_extra_tools(arg: str = "") -> dict:
    """The tools that are NOT described in the prompt, with exact usage -- see the module docstring."""
    req = current()
    if req is not None:
        stated = req.prompt_stated()
    else:
        from . import system_prompt
        stated = stated_names(system_prompt.build_system_prompt("compact"))
    extras = [t for n, t in catalog().items() if n not in stated]
    if not extras:
        return {"success": True, "message": "There are no extra tools: every tool that exists is already described in your prompt. "
                "If none of them can do what the user asked, tell them plainly that you can't."}

    query = (arg or "").strip().lower()
    groups = _group(extras)
    chosen, scope = extras, "all"
    if query:
        words = [w for w in re.split(r"[\s,]+", query) if w]
        if query in groups:
            chosen, scope = groups[query], f"category '{query}'"
        else:
            chosen = [t for t in extras if all(w in f"{t['name']} {t['description']} {t['category']}".lower() for w in words)]
            scope = f"matching '{query}'"
        if not chosen:
            return {"success": True, "message": (
                f"No extra tool matches '{arg}'. Extra tool categories: " + ", ".join(f"{c} ({len(ts)})" for c, ts in groups.items()) +
                ". Try one of those names, or other words; if nothing in them fits, tell the user you can't do it. Do not invent a command.")}

    limit = _limit_chars()
    header = (f"EXTRA TOOLS ({len(chosen)} of {len(extras)} extra tools not in your prompt; {scope}). Call one as name:arg. "
              "Only commands from your prompt, 'Likely relevant tools' and this list exist: if none of them can do what the user asked, "
              "say so plainly with speak: and done -- never invent a command. ! = needs the user's approval, * = returns information (wait for it).")
    shown_usage = True
    if query:                                   # a narrowed list gets full lines: usage and what each does
        lines, used_chars, dropped = [], len(header), 0
        for t in chosen:
            line = usage_line(t["name"])
            if used_chars + len(line) + 1 > limit:
                dropped += 1
                continue
            lines.append(line)
            used_chars += len(line) + 1
        body = "\n".join(lines) + (f"\n(+{dropped} more match; narrow the filter to see them.)" if dropped else "")
        revealed = [t["name"] for t in chosen][:len(lines)]
    else:
        by_cat = _group(chosen)
        usage = "\n".join(f"[{c}] " + " ".join(_compact(t) for t in ts) for c, ts in by_cat.items())
        if len(header) + len(usage) <= limit:
            body, revealed = usage, [t["name"] for t in chosen]
        else:                                    # too big for the budget: every name, and an honest note that usage is left out
            shown_usage = False
            names = "\n".join(f"[{c}] " + " ".join(t["name"] + ("!" if t["approval"] else "") for t in ts) for c, ts in by_cat.items())
            if len(header) + len(names) <= limit:
                body = names + "\n(Names only, to fit. For exact usage call list_extra_tools:<category> or tool_help:<name>.)"
            else:                                # not even the names fit: the categories, and how to open one
                body = ("\n".join(f"[{c}] {len(ts)} tools" for c, ts in by_cat.items())
                        + "\n(Categories only, to fit. Call list_extra_tools:<category> to see one category's tools with their usage.)")
            revealed = []
    if req is not None:
        req.revealed.update(revealed)
    message = f"{LIST_OPEN}\n{header}\n{body}\n{LIST_CLOSE}"
    return {"success": True, "message": message, "full": True,
            "ui_message": f"Listed {len(chosen)} extra tool{'s' if len(chosen) != 1 else ''} ({scope}{'' if shown_usage else ', names only' if 'Names only' in body else ', categories only'})."}


# ---------------------------------------------------------------- forgetting
def collapse(messages: list, req) -> int:
    """After a request: replaces every extra-tool list in `messages` with a short stub that keeps only the
    usage of the extra tools that were actually used. Returns how many lists were trimmed."""
    used = list(req.used.values()) if req is not None else []
    pattern = re.compile(re.escape(LIST_OPEN) + r".*?" + re.escape(LIST_CLOSE), re.S)
    positions = [(i, m) for i, m in enumerate(messages) if isinstance(m.get("content"), str) and LIST_OPEN in m["content"]]
    trimmed = 0
    for n, (i, m) in enumerate(positions):
        last = n == len(positions) - 1
        if used and last:
            stub = ("[Extra tool list removed now that the request is finished. Extra tools used from it, kept: "
                    f"{KEPT_OPEN} {'; '.join(used)} {KEPT_CLOSE}. Other extra tools are not in your prompt; call list_extra_tools again if a later request needs one.]")
        else:
            stub = ("[Extra tool list removed now that the request is finished; none of its tools were used. "
                    "Call list_extra_tools again if a later request needs more than your prompt offers.]")
        m["content"] = pattern.sub(lambda _m: stub, m["content"])
        trimmed += 1
    return trimmed


# Registers itself like the other tool modules (tools_all imports this at the end of the file).
tools_all.register(
    "list_extra_tools", list_extra_tools,
    "Lists the extra tools that are NOT described in your prompt, with exact usage. Use it when the request needs something your commands can't do; "
    "optional filter: a category or some words. If nothing listed fits, tell the user you can't.",
    category="meta", info=True, arg_hint="[<category or words>]")
