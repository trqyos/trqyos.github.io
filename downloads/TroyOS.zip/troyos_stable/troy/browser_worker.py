"""
TROYOS STABLE - Web research browser worker

Backs the `web_*` tools (troy/tools_all.py, category "web") -- Troy's own
invisible, Playwright-driven Chromium instance for background research and
form-filling. This is a SEPARATE browser/profile from the user's actual
Firefox/Chrome (opened via open_app/open_url) -- see the WEB RESEARCH TOOLS
vs. YOUR BROWSER section of troy/system_prompt.py for how the two are kept
distinct in the model's instructions.

Playwright's sync API ties its objects to whichever thread created them --
calling them from a different thread raises an error. Tool calls, though,
can arrive on whichever worker thread happens to be running the current
agent turn, which varies. So instead of creating Playwright objects
wherever a tool happens to run, there's exactly one dedicated background
thread that owns them for the app's whole lifetime, and every tool
submits a small callable to it and blocks for the result -- same shape as
the mobile server and confirmation banner needing to hop onto a specific
thread, just in the other direction.

The browser itself is a persistent context (a real, cookie/login-
preserving Chromium profile on disk at config.BROWSER_PROFILE_DIR) rather
than a one-shot throwaway browser, so a task that logs into something
stays logged in next time. It defaults to headless (see
config.BROWSER_HEADLESS) precisely because it's meant to run invisibly in
the background -- if you want to actually watch a page load or interact
with a browser window yourself, use open_app:firefox / open_url instead,
not this.
"""

import queue
import threading

from . import config
from .logger import logger

_job_queue: "queue.Queue" = queue.Queue()
_thread = None
_playwright = None
_context = None
_pages = []
_active_index = 0
_started = threading.Event()
_start_error = ""


def _worker_loop():
    global _playwright, _context, _start_error
    try:
        from playwright.sync_api import sync_playwright
    except ImportError:
        _start_error = "Browser automation needs the 'playwright' package: pip install playwright, then run: playwright install chromium"
        _started.set()
        return

    try:
        _playwright = sync_playwright().start()
        _context = _playwright.chromium.launch_persistent_context(
            config.BROWSER_PROFILE_DIR,
            headless=config.BROWSER_HEADLESS,
            viewport={"width": 1280, "height": 800},
        )
        page = _context.new_page()
        _pages.append(page)
    except Exception as exc:  # noqa: BLE001
        _start_error = (
            f"Couldn't start the browser: {exc}. If this is the first run, "
            f"you likely need: playwright install chromium"
        )
        _started.set()
        return

    _started.set()
    logger.info("Browser automation started (profile: %s).", config.BROWSER_PROFILE_DIR)

    while True:
        job = _job_queue.get()
        if job is None:  # shutdown sentinel
            break
        fn, result_holder, done_event = job
        try:
            result_holder["value"] = fn()
        except Exception as exc:  # noqa: BLE001
            result_holder["error"] = exc
        done_event.set()

    try:
        _context.close()
        _playwright.stop()
    except Exception:  # noqa: BLE001
        pass


def ensure_started(timeout: float = 30.0) -> str:
    """Starts the worker thread on first use (idempotent). Returns an
    error message string on failure, empty string on success."""
    global _thread
    if _thread is None:
        _thread = threading.Thread(target=_worker_loop, daemon=True, name="troy-browser")
        _thread.start()
    if not _started.wait(timeout=timeout):
        return "Browser is taking too long to start."
    return _start_error


def run(fn, timeout: float = 20.0):
    """Runs fn() (with no arguments -- fn should close over get_active_page()
    etc. internally) on the browser's dedicated thread, blocking until it
    completes. Raises RuntimeError/whatever fn raised on the CALLING
    thread, so a tool function can just try/except this normally."""
    err = ensure_started()
    if err:
        raise RuntimeError(err)
    result_holder = {}
    done_event = threading.Event()
    _job_queue.put((fn, result_holder, done_event))
    if not done_event.wait(timeout=timeout):
        raise RuntimeError(f"Browser action timed out after {timeout}s.")
    if "error" in result_holder:
        raise result_holder["error"]
    return result_holder.get("value")


# ---- state accessors -- only ever actually read/written from the worker
# thread itself (i.e. from inside a callable passed to run()), so there's
# no locking needed despite these being module-level globals.

def get_active_page():
    return _pages[_active_index]


def get_context():
    return _context


def add_page(page):
    _pages.append(page)


def list_pages() -> list:
    return list(_pages)


def get_active_index() -> int:
    return _active_index


def set_active_index(index: int):
    global _active_index
    _active_index = index


def is_running() -> bool:
    return _thread is not None and _thread.is_alive() and not _start_error


def shutdown():
    if _thread is not None:
        _job_queue.put(None)
