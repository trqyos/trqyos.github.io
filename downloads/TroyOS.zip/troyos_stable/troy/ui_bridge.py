"""
Troy <-> its own app.

Lets the agent's tools (troy/tools_app.py) reach the user interface without
knowing anything about Electron: a tool calls `command("widget", mode="show")`
and the host forwards it as a `ui.command` event that main.js / the renderers
act on. Electron reports back what it is currently showing through the
`ui.report` IPC method, so Troy can answer "is the widget open?".

ipc_host.py installs the emitter and the host at startup; everything here is a
harmless no-op before that (unit tests, headless runs).
"""

import threading

_lock = threading.Lock()
_emitter = None
_host = None
_state = {"mode": "unknown", "widget_visible": None, "theme": None, "layout": None, "view": None}


def set_emitter(fn):
    global _emitter
    _emitter = fn


def set_host(host):
    global _host
    _host = host


def emit(event: str, data: dict | None = None) -> bool:
    fn = _emitter
    if fn is None:
        return False
    try:
        fn(event, data or {})
        return True
    except Exception:  # noqa: BLE001 - UI plumbing must never break a tool call
        return False


def command(action: str, **payload) -> bool:
    """Sends a UI command to every frontend. False when nothing is listening yet."""
    return emit("ui.command", {"action": action, **payload})


def report(**fields) -> dict:
    with _lock:
        for key in _state:
            if key in fields:
                _state[key] = fields[key]
        return dict(_state)


def state() -> dict:
    with _lock:
        return dict(_state)


def request_new_chat() -> str:
    """Starts a fresh chat. If a turn is running (the usual case: Troy itself asked
    for it), it happens the moment that turn ends. Returns 'now' or 'after_turn'."""
    host = _host
    if host is None:
        command("new_chat")
        return "now"
    return host.schedule_new_chat()
