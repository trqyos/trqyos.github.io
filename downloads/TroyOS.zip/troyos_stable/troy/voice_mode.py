"""
Full voice mode: talk to Troy hands-free, with the PC's microphone and speakers
or -- through the phone page -- with the phone's microphone and speaker.

One orchestrator, two kinds of "ears" and two kinds of "mouth":

  ears   the PC microphone (troy/wake_listener.py, in conversation mode: no wake
         word needed, follow-ups welcome) or an utterance uploaded by the phone
  mouth  the PC speakers (troy/tts.py Speaker) or the phone (text for its own
         voice, or audio generated here in Troy's chosen voice)

and a small state machine the UIs draw: listening -> hearing -> transcribing ->
thinking -> speaking -> listening ... Everything that makes it feel like a
conversation lives here: barge-in (talk over Troy and it stops), "stop" /
"never mind", "goodbye" to leave, replies routed to wherever you asked from.
"""

import collections
import threading
import time

from . import audio_in, config, power, speech_text, tts, voice, wake_listener
from .logger import logger

PHONE_ALIVE_SECONDS = 90


class _Sink:
    """A callable the Speaker can hand sentences to; `wants_audio` says whether it needs synthesized audio."""

    def __init__(self, fn):
        self._fn, self.wants_audio = fn, False

    def __call__(self, sentence, audio, fmt):
        self._fn(sentence, audio, fmt)


class VoiceMode:
    def __init__(self, host, pc_speaker=None, phone_speaker=None):
        """host provides: start_turn(text, source), stop_turn(), emit(event, data),
        broadcast(dict) (to phones), agent (TroyAgent) for the spoken-style flag."""
        self.host = host
        self.pc_speaker = pc_speaker or tts.Speaker(on_speaking=self._on_pc_speaking)
        self.phone_speaker = phone_speaker or tts.Speaker(player=tts.NullPlayer())
        self.phone_speaker.sink = _Sink(self._phone_sink)
        self.active = False
        self.source = "pc"
        self.state = "off"
        self.muted = False
        self._started_listener = False
        self._ending = False
        self._last_input = "typed"
        self._level_at = 0.0
        self._phone_seen = 0.0
        self._phone_voice = False
        self._audio = collections.OrderedDict()
        self._audio_id = 0
        self._lock = threading.Lock()

    # ------------------------------------------------------------ state
    def _set_state(self, state: str, **extra):
        self.state = state
        info = self.info(); info.update(extra)
        self.host.emit("voice.state", info)
        self.host.broadcast({"type": "voice", "action": "state", **{k: info[k] for k in ("state", "active", "source")}})

    def info(self) -> dict:
        return {"active": self.active, "state": self.state, "source": self.source, "muted": self.muted,
                "phone": {"connected": self._phone_alive(), "voice": self._phone_voice, "speaker": config.VOICE_PHONE_SPEAKER},
                "listener": wake_listener.is_running(), "conversation": wake_listener.in_conversation()}

    # ---------------------------------------------------------- PC voice
    def _install_hooks(self):
        wake_listener.set_hooks(is_speaking=lambda: self.pc_speaker.speaking, on_level=self._on_level, on_barge_in=self._on_barge_in,
                                on_transcript=self._on_transcript, on_interrupt=self._on_interrupt,
                                on_conversation_end=self._on_conversation_end)
        wake_listener.set_callbacks(on_command=self._on_pc_command, on_state_change=self._on_listener_state)

    def install_listener(self):
        """Used by the plain wake-word listener too, so both share the same hooks."""
        self._install_hooks()

    def start(self, greet: bool = True) -> dict:
        """Starts hands-free voice mode on the PC microphone."""
        if self.active and self.source == "pc":
            return {"started": True, "already": True}
        stt = voice.stt_status()
        if not stt["available"]:
            return {"started": False, "error": f"Speech recognition isn't installed ({stt['reason']})."}
        self._install_hooks()
        if not wake_listener.is_running():
            if not wake_listener.start():
                return {"started": False, "error": "Couldn't open the microphone. Check the input device in Settings > Voice and that 'sounddevice' is installed."}
            self._started_listener = True
        wake_listener.set_paused(False)
        wake_listener.set_conversation(True)
        self.active, self.source, self.muted, self._ending = True, "pc", False, False
        self.host.agent.voice_forced = True
        self._set_state("listening")
        if greet:
            self.pc_speaker.say("Voice mode on. I'm listening.")
        return {"started": True}

    def stop(self, reason: str = "user", say: str = ""):
        was = self.active
        wake_listener.set_conversation(False)
        wake_listener.set_paused(False)
        self.pc_speaker.stop()
        self.host.agent.voice_forced = False
        self.active, self.muted = False, False
        if self._started_listener and not config.VOICE_INPUT_ENABLED:
            wake_listener.stop()
        self._started_listener = False
        if say and was:
            self.pc_speaker.say(say)
        self._set_state("off", reason=reason)
        if was:
            self.host.emit("voice.ended", {"reason": reason})

    def set_muted(self, muted: bool):
        self.muted = bool(muted)
        wake_listener.set_paused(self.muted)
        if self.active:
            self._set_state("muted" if self.muted else "listening")

    def interrupt(self):
        """The UI's Stop button: silence both speakers, cancel whatever turn is
        running, and go back to listening (when voice mode is on)."""
        self._on_interrupt()

    def _on_pc_command(self, text: str):
        self._last_input = "pc"
        self.host.start_turn(text, "voice")
        if self.active:
            self._set_state("thinking")

    def _on_listener_state(self, state: str):
        self.host.emit("wake_listener.state", {"state": state})
        self.host.broadcast({"type": "voice", "action": "listener", "state": state})   # the phone's face hears it too
        if not self.active or self.pc_speaker.speaking or self.state in ("thinking", "muted"):
            return
        self._set_state({"hearing": "hearing", "thinking": "transcribing"}.get(state, "listening"))

    def _on_level(self, level: float):
        now = time.monotonic()
        if now - self._level_at >= power.level_interval():
            self._level_at = now
            self.host.emit("voice.level", {"level": round(float(level), 1), "state": self.state})
            self.host.broadcast({"type": "voice", "action": "level", "level": round(float(level), 1), "state": self.state})

    def _on_transcript(self, text: str):
        self.host.emit("voice.transcript", {"text": text, "source": "pc"})
        self.host.broadcast({"type": "voice", "action": "transcript", "text": text, "source": "pc"})

    def _on_barge_in(self):
        """The user started talking over Troy: be quiet and stop what it was doing."""
        self.pc_speaker.stop()
        self.host.stop_turn()

    def _on_interrupt(self):
        self.pc_speaker.stop()
        self.phone_speaker.stop()
        self.host.stop_turn()
        if self.active:
            self._set_state("listening")

    def _on_conversation_end(self, reason: str):
        self.active = False
        self.host.agent.voice_forced = False
        if reason == "goodbye":
            self._ending = True
            self.pc_speaker.say("Okay, bye for now.")
            if not self.pc_speaker.speaking:
                self._finish_ending()
        else:
            self._finish_ending(reason)

    def _finish_ending(self, reason: str = "goodbye"):
        self._ending = False
        if self._started_listener and not config.VOICE_INPUT_ENABLED:
            wake_listener.stop()
        self._started_listener = False
        self._set_state("off", reason=reason)
        self.host.emit("voice.ended", {"reason": reason})

    def _on_pc_speaking(self, speaking: bool):
        if speaking:
            self._set_state("speaking")
            return
        wake_listener.extend_conversation()
        if self._ending:
            self._finish_ending()
        elif self.active:
            self._set_state("muted" if self.muted else "listening")

    # ----------------------------------------------------------- output
    def agent_state(self, state: str, detail: str = ""):
        """Fed from the agent so voice UIs can show 'thinking' / 'working'."""
        if (self.active or self._phone_voice) and state in ("thinking", "executing") and not self.pc_speaker.speaking:
            self._set_state("thinking", detail=detail)
        elif state == "idle" and self.active and not self.pc_speaker.speaking and self.state == "thinking":
            self._set_state("listening")

    def speak(self, text: str):
        """Called with every reply. Goes to whoever asked: the phone if that's
        where the last voice request came from, else the PC speakers (when voice
        mode or 'speak replies' is on)."""
        if self._last_input == "phone" and self._phone_alive() and self._phone_voice:
            self.phone_speaker.sink.wants_audio = config.VOICE_PHONE_SPEAKER == "troy"
            self.phone_speaker.say(text)
        elif self.active or config.VOICE_OUTPUT_ENABLED:
            self.pc_speaker.say(text)

    def say_on_pc(self, text: str, interrupt: bool = True):
        self.pc_speaker.say(text, interrupt=interrupt)

    # ------------------------------------------------------------- phone
    def _phone_alive(self) -> bool:
        return time.monotonic() - self._phone_seen < PHONE_ALIVE_SECONDS

    def phone_ping(self):
        self._phone_seen = time.monotonic()

    def phone_start(self) -> dict:
        if not config.MOBILE_VOICE_ENABLED:
            raise ValueError("Phone voice is turned off on the PC (Settings > Phone).")
        stt = voice.stt_status()
        if not stt["available"]:
            raise ValueError(f"The PC can't transcribe speech yet ({stt['reason']}).")
        self.phone_ping()
        self._phone_voice = True
        self._set_state(self.state, source="phone")
        self.host.emit("voice.phone", {"active": True})
        return {"ok": True, "speaker": config.VOICE_PHONE_SPEAKER, "engine": stt["engine"]}

    def phone_stop(self):
        self._phone_voice = False
        self.phone_speaker.stop()
        self.host.emit("voice.phone", {"active": False})

    def phone_interrupt(self):
        self.phone_speaker.stop()
        self.host.stop_turn()

    def phone_event(self, data: dict):
        self.phone_ping()
        if "speaking" in data:
            self.host.emit("voice.phone", {"active": self._phone_voice, "speaking": bool(data["speaking"])})

    def handle_phone_audio(self, data: bytes, rate: int = 16000) -> dict:
        """One utterance from the phone's microphone (16-bit mono PCM): check
        it, transcribe it, then act on it. Blocks until transcription is done."""
        self.phone_ping()
        if not self._phone_voice:
            raise ValueError("Voice mode isn't on for the phone.")
        pcm = audio_in.resample(audio_in.to_int16(data), int(rate), audio_in.RATE)
        if not audio_in.has_speech(pcm):
            return {"action": "ignored", "reason": "silence"}
        text = voice.transcribe(pcm, audio_in.RATE)
        if not text or speech_text.looks_like_noise(text):
            return {"action": "ignored", "reason": "nothing understood"}
        triggered, remainder = wake_listener._split_wake_word(text, config.WAKE_WORD)
        heard = remainder if triggered and remainder else text
        self.host.emit("voice.transcript", {"text": heard, "source": "phone"})
        if speech_text.is_end_phrase(heard):
            self.phone_stop()
            return {"action": "end", "text": heard}
        if speech_text.is_stop_phrase(heard):
            self.phone_interrupt()
            return {"action": "stop", "text": heard}
        self._last_input = "phone"
        self.phone_speaker.stop()                       # whatever it was still saying is stale
        self.host.start_turn(heard, "phone-voice")
        return {"action": "turn", "text": heard}

    def _phone_sink(self, sentence: str, audio, fmt: str):
        with self._lock:
            self._audio_id += 1
            aid = self._audio_id
            if audio:
                self._audio[aid] = (audio, fmt)
                while len(self._audio) > 24:
                    self._audio.popitem(last=False)
        self.host.broadcast({"type": "voice", "action": "speak", "id": aid, "text": sentence,
                             "audio": f"/api/voice/audio/{aid}" if audio else None, "fmt": fmt})

    def audio(self, audio_id: int):
        with self._lock:
            return self._audio.get(int(audio_id))

    # ----------------------------------------------------------- devices
    def devices(self) -> list:
        try:
            import sounddevice as sd
            default_in = sd.default.device[0] if hasattr(sd.default, "device") else None
            return [{"index": i, "name": d["name"], "default": i == default_in}
                    for i, d in enumerate(sd.query_devices()) if d.get("max_input_channels", 0) > 0]
        except Exception as exc:  # noqa: BLE001
            logger.debug("Couldn't list microphones: %s", exc)
            return []

    def test_microphone(self, seconds: float = 4.0) -> dict:
        """Records a few seconds from the selected microphone, reports the peak
        level and what speech recognition made of it -- the 'is my mic working?' button."""
        try:
            import numpy as np
            import sounddevice as sd
        except Exception as exc:  # noqa: BLE001
            return {"ok": False, "error": f"sounddevice isn't available: {exc}"}
        seconds = max(1.0, min(8.0, float(seconds)))
        try:
            dev = wake_listener._pick_input_device(sd)
            rec = sd.rec(int(seconds * audio_in.RATE), samplerate=audio_in.RATE, channels=1, dtype="int16", device=dev)
            t0 = time.monotonic()
            while time.monotonic() - t0 < seconds:
                time.sleep(0.1)
                done = int((time.monotonic() - t0) * audio_in.RATE)
                self.host.emit("voice.level", {"level": round(audio_in.rms(rec[max(0, done - 1600):done, 0]), 1), "state": "test"})
            sd.wait()
            pcm = rec[:, 0]
        except Exception as exc:  # noqa: BLE001
            return {"ok": False, "error": f"Couldn't record: {exc}"}
        peak = float(np.max(np.abs(pcm))) if pcm.size else 0.0
        heard = voice.transcribe(pcm, audio_in.RATE) if audio_in.has_speech(pcm) else ""
        return {"ok": True, "peak": round(peak / 32768, 3), "heard": heard, "silent": peak < 300}
