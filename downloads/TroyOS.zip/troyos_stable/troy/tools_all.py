"""
TROYOS STABLE - Consolidated Tool Library (troy/tools_all.py)

Every tool Troy can call used to live scattered across ~18 files under
troy/tools/. That made sense while the library was small, but at ~150
tools it just meant more places to jump between to find or change one.
Everything is now in this single file, grouped by category with a plain
comment banner, in the same order they're documented in the system
prompt. Nothing was removed -- every function name, signature, and
behavior below is unchanged from the original module it came from.

This file also owns the tool registry (metadata: category, risk level,
whether a tool needs confirmation, whether it's an information-gathering
command) and the registrations themselves, which used to be two more
separate files (tool_registry.py, tool_registrations.py). One file, one
place to look.
"""

import base64
import csv
import fnmatch
import hashlib
import io
import json
import os
import platform
import re
import shutil
import socket
import string
import subprocess
import sys
import tarfile
import time
import webbrowser
import zipfile
from collections import defaultdict
from dataclasses import dataclass
from datetime import datetime
from typing import Callable
from urllib.parse import quote, quote_plus

import pyautogui
import requests

from . import browser_worker, config, confirmation, llm_client, task_context, ui_automation
from .command_parser import split_args
from .logger import logger




# ==========================================================================
# originally troy/tools/app_control.py
# ==========================================================================
def _open_app_via_start_menu(name: str) -> dict:
    """The original method: Win key, type the name, Enter."""
    pyautogui.press("win")
    time.sleep(0.6)
    pyautogui.typewrite(name, interval=0.03)
    time.sleep(0.4)
    pyautogui.press("enter")
    time.sleep(1.0)
    return {"success": True, "message": f"Requested to open '{name}' via Start menu search."}


def open_app(name: str) -> dict:
    """Opens an application. HOW is a setting (APP_LAUNCH_MODE), not something
    the model chooses -- the command is always just open_app:<name>:
      direct      start the program itself (troy/app_launcher.py)
      start_menu  press Win, type the name, press Enter
      auto        direct first, then the Start menu if nothing was found"""
    from . import app_launcher
    if not name:
        return {"success": False, "message": "open_app called with no app name."}
    mode = config.APP_LAUNCH_MODE
    if mode == "start_menu":
        return _open_app_via_start_menu(name)
    result = app_launcher.launch(name)
    if result["success"]:
        time.sleep(0.4)
        return result
    if mode == "direct":
        return result
    fallback = _open_app_via_start_menu(name)
    fallback["message"] += " (couldn't launch it directly)"
    return fallback


def close_active_window() -> dict:
    pyautogui.hotkey("alt", "f4")
    return {"success": True, "message": "Sent Alt+F4 to close the active window."}


def minimize_active_window() -> dict:
    pyautogui.hotkey("win", "down")
    return {"success": True, "message": "Minimized the active window."}


def maximize_active_window() -> dict:
    pyautogui.hotkey("win", "up")
    return {"success": True, "message": "Maximized the active window."}


def switch_window() -> dict:
    """Opens the Alt+Tab window switcher. Troy can't see or choose a
    specific entry in it -- pair this with a screenshot/read_screen_text to
    verify what actually ended up focused, or with press_key:enter to
    accept whatever the switcher currently has highlighted."""
    pyautogui.hotkey("alt", "tab")
    return {"success": True, "message": "Opened the window switcher (Alt+Tab)."}



# ==========================================================================
# originally troy/tools/browser.py
# ==========================================================================
def open_url(url: str) -> dict:
    if not url:
        return {"success": False, "message": "open_url called with no URL."}
    if not url.startswith(("http://", "https://")):
        url = "https://" + url
    webbrowser.open(url)
    return {"success": True, "message": f"Opened URL: {url}"}


def search_newtab(query: str) -> dict:
    if not query:
        return {"success": False, "message": "search_newtab called with no query."}
    url = f"https://www.google.com/search?q={quote_plus(query)}"
    webbrowser.open_new_tab(url)
    return {"success": True, "message": f"Searched for: {query}"}



# ==========================================================================
# originally troy/tools/audio.py
# ==========================================================================
def play_pause() -> dict:
    pyautogui.press("playpause")
    return {"success": True, "message": "Toggled play/pause."}


def volume_up() -> dict:
    pyautogui.press("volumeup")
    return {"success": True, "message": "Increased volume."}


def volume_down() -> dict:
    pyautogui.press("volumedown")
    return {"success": True, "message": "Decreased volume."}


def volume_mute() -> dict:
    pyautogui.press("volumemute")
    return {"success": True, "message": "Toggled mute."}



# ==========================================================================
# originally troy/tools/input_control.py
# ==========================================================================
# Moving the mouse to a screen corner acts as a physical kill-switch: if Troy
# ever goes haywire, slam the mouse into a corner and pyautogui raises
# FailSafeException, stopping execution immediately.
pyautogui.FAILSAFE = True


def type_text(text: str) -> dict:
    pyautogui.typewrite(text, interval=0.02)
    return {"success": True, "message": f"Typed text ({len(text)} characters)."}


def press_key(key: str) -> dict:
    key = key.strip().lower()
    if not key:
        return {"success": False, "message": "press_key called with no key."}
    pyautogui.press(key)
    return {"success": True, "message": f"Pressed key '{key}'."}


def hotkey(combo: str) -> dict:
    keys = [k.strip().lower() for k in combo.split("+") if k.strip()]
    if not keys:
        return {"success": False, "message": "hotkey called with no keys."}
    pyautogui.hotkey(*keys)
    return {"success": True, "message": f"Pressed hotkey {'+'.join(keys)}."}


def click(x: int, y: int) -> dict:
    pyautogui.click(x, y)
    return {"success": True, "message": f"Clicked at ({x}, {y})."}


def move_mouse(x: int, y: int) -> dict:
    pyautogui.moveTo(x, y)
    return {"success": True, "message": f"Moved mouse to ({x}, {y})."}


def scroll(amount: int) -> dict:
    pyautogui.scroll(amount)
    return {"success": True, "message": f"Scrolled by {amount}."}


# ---------- extended mouse/keyboard tools (registry-style: single string arg) ----------

def _parse_xy(arg: str):
    parts = arg.replace("|", ",").split(",")
    if len(parts) != 2:
        raise ValueError("expected 'x,y'")
    return int(float(parts[0].strip())), int(float(parts[1].strip()))


def double_click(arg: str) -> dict:
    try:
        x, y = _parse_xy(arg)
    except (ValueError, IndexError):
        return {"success": False, "message": "double_click needs 'x,y'."}
    pyautogui.doubleClick(x, y)
    return {"success": True, "message": f"Double-clicked at ({x}, {y})."}


def right_click(arg: str) -> dict:
    try:
        x, y = _parse_xy(arg)
    except (ValueError, IndexError):
        return {"success": False, "message": "right_click needs 'x,y'."}
    pyautogui.rightClick(x, y)
    return {"success": True, "message": f"Right-clicked at ({x}, {y})."}


def drag_mouse(arg: str) -> dict:
    """arg format: 'x1,y1|x2,y2' -- drags from the first point to the
    second with the left button held."""
    if "|" not in arg:
        return {"success": False, "message": "drag_mouse needs 'x1,y1|x2,y2'."}
    start_str, end_str = arg.split("|", 1)
    try:
        x1, y1 = _parse_xy(start_str)
        x2, y2 = _parse_xy(end_str)
    except (ValueError, IndexError):
        return {"success": False, "message": "drag_mouse's coordinates must be numbers."}
    pyautogui.moveTo(x1, y1)
    pyautogui.dragTo(x2, y2, duration=0.3, button="left")
    return {"success": True, "message": f"Dragged from ({x1}, {y1}) to ({x2}, {y2})."}


def mouse_down(arg: str) -> dict:
    try:
        x, y = _parse_xy(arg)
    except (ValueError, IndexError):
        return {"success": False, "message": "mouse_down needs 'x,y'."}
    pyautogui.moveTo(x, y)
    pyautogui.mouseDown()
    return {"success": True, "message": f"Mouse button pressed down at ({x}, {y})."}


def mouse_up(arg: str) -> dict:
    if arg.strip():
        try:
            x, y = _parse_xy(arg)
            pyautogui.moveTo(x, y)
        except (ValueError, IndexError):
            pass
    pyautogui.mouseUp()
    return {"success": True, "message": "Mouse button released."}


def press_keys(arg: str) -> dict:
    """Presses a sequence of keys ONE AT A TIME (not simultaneously) --
    use this for e.g. 'tab,tab,enter' navigation. For a simultaneous
    combination like Ctrl+C, use hotkey instead."""
    keys = [k.strip().lower() for k in arg.split(",") if k.strip()]
    if not keys:
        return {"success": False, "message": "press_keys needs a comma-separated key sequence."}
    for key in keys:
        pyautogui.press(key)
    return {"success": True, "message": f"Pressed keys in sequence: {', '.join(keys)}."}


def hold_key(arg: str) -> dict:
    key = arg.strip().lower()
    if not key:
        return {"success": False, "message": "hold_key needs a key name."}
    pyautogui.keyDown(key)
    return {"success": True, "message": f"Holding key '{key}' down. Use release_key to let go."}


def release_key(arg: str) -> dict:
    key = arg.strip().lower()
    if not key:
        return {"success": False, "message": "release_key needs a key name."}
    pyautogui.keyUp(key)
    return {"success": True, "message": f"Released key '{key}'."}


def copy_selected(_arg: str = "") -> dict:
    pyautogui.hotkey("ctrl", "c")
    return {"success": True, "message": "Copied current selection (Ctrl+C)."}


def cut_selected(_arg: str = "") -> dict:
    pyautogui.hotkey("ctrl", "x")
    return {"success": True, "message": "Cut current selection (Ctrl+X)."}


def paste_clipboard(_arg: str = "") -> dict:
    pyautogui.hotkey("ctrl", "v")
    return {"success": True, "message": "Pasted clipboard content (Ctrl+V)."}


def select_all(_arg: str = "") -> dict:
    pyautogui.hotkey("ctrl", "a")
    return {"success": True, "message": "Selected all (Ctrl+A)."}


def undo(_arg: str = "") -> dict:
    pyautogui.hotkey("ctrl", "z")
    return {"success": True, "message": "Undo (Ctrl+Z)."}


def redo(_arg: str = "") -> dict:
    pyautogui.hotkey("ctrl", "y")
    return {"success": True, "message": "Redo (Ctrl+Y)."}



# ==========================================================================
# originally troy/tools/windows.py
# ==========================================================================
def _process_name_for_pid(pid):
    if not pid:
        return "?"
    try:
        import psutil
        return psutil.Process(pid).name()
    except Exception:  # noqa: BLE001 - psutil missing, pid gone, access denied, etc.
        return "?"


def _enumerate_windows():
    """Returns a list of {title, process, minimized, hwnd} dicts for every
    visible top-level window with a non-empty title. Untitled/tooltip/
    helper windows are skipped since they're never what a verification
    check is looking for and would just add noise."""
    import win32gui
    import win32process

    windows = []

    def _callback(hwnd, _extra):
        if not win32gui.IsWindowVisible(hwnd):
            return True
        title = win32gui.GetWindowText(hwnd).strip()
        if not title:
            return True
        try:
            _, pid = win32process.GetWindowThreadProcessId(hwnd)
        except Exception:  # noqa: BLE001
            pid = None
        windows.append({
            "title": title,
            "process": _process_name_for_pid(pid),
            "minimized": bool(win32gui.IsIconic(hwnd)),
            "hwnd": hwnd,
        })
        return True

    win32gui.EnumWindows(_callback, None)
    return windows


def get_active_window() -> dict:
    """What currently has keyboard focus. Use this to confirm a click/
    alt-tab/window-open actually landed on the window you expect before
    sending further keystrokes to it."""
    try:
        import win32gui
        import win32process
    except ImportError:
        return {
            "success": False,
            "message": "Window inspection isn't available -- the 'pywin32' package isn't installed.",
        }

    hwnd = win32gui.GetForegroundWindow()
    if not hwnd:
        return {"success": True, "message": "No window currently has focus."}

    title = win32gui.GetWindowText(hwnd).strip() or "(untitled)"
    try:
        _, pid = win32process.GetWindowThreadProcessId(hwnd)
    except Exception:  # noqa: BLE001
        pid = None
    process = _process_name_for_pid(pid)
    state = "minimized" if win32gui.IsIconic(hwnd) else "normal"

    return {
        "success": True,
        "message": f"Active window: '{title}' ({process}, pid {pid or '?'}), {state}.",
    }


def list_windows(limit: int = 25) -> dict:
    """Every visible top-level window with a title, newest/most-recently-
    interacted windows aren't guaranteed to sort first (Win32 gives z-order,
    not recency) -- use get_active_window if you specifically need the
    focused one. Capped at `limit` entries so a desktop with dozens of
    windows open doesn't flood the conversation."""
    try:
        windows = _enumerate_windows()
    except ImportError:
        return {
            "success": False,
            "message": "Window inspection isn't available -- the 'pywin32' package isn't installed.",
        }

    if not windows:
        return {"success": True, "message": "No visible top-level windows found."}

    shown = windows[:limit]
    lines = [
        f"'{w['title']}' ({w['process']}{', minimized' if w['minimized'] else ''})"
        for w in shown
    ]
    overflow = f" (+{len(windows) - limit} more not shown)" if len(windows) > limit else ""
    return {"success": True, "message": f"{len(windows)} window(s){overflow}: " + " | ".join(lines)}


def window_exists(query: str) -> dict:
    """arg: a substring to look for. Matches case-insensitively against
    both the window title and the owning process name, since callers will
    reasonably ask for either ('notepad' the process, or 'Untitled -
    Notepad' the title). This is the cheap primitive for 'wait until X
    opens/closes' loops -- pair it with `wait:<seconds>` instead of polling
    with repeated screenshots."""
    query = (query or "").strip().lower()
    if not query:
        return {"success": False, "message": "window_exists needs a title or process name to search for."}

    try:
        windows = _enumerate_windows()
    except ImportError:
        return {
            "success": False,
            "message": "Window inspection isn't available -- the 'pywin32' package isn't installed.",
        }

    matches = [
        w for w in windows
        if query in w["title"].lower() or query in w["process"].lower()
    ]
    if not matches:
        return {"success": True, "message": f"No window matching '{query}' found."}

    lines = [f"'{w['title']}' ({w['process']}{', minimized' if w['minimized'] else ''})" for w in matches[:10]]
    return {"success": True, "message": f"Found {len(matches)} matching window(s): " + " | ".join(lines)}


# ---------- window management (move/resize/snap/focus) ----------
# All of these resolve their target the same way: a substring match against
# _enumerate_windows() (title or process name), same as window_exists, so a
# caller can say "focus_window:notepad" without needing a raw HWND. This
# keeps them consistent with the existing single-string-argument command
# format instead of inventing a separate "find the handle first" step.

def _find_hwnd(query: str):
    """Returns (hwnd, title) for the first visible window matching `query`,
    or (None, None) if nothing matches. Internal helper shared by every
    window-management function below."""
    import win32gui
    import win32process

    query = (query or "").strip().lower()
    if not query:
        return None, None

    match = {"hwnd": None, "title": None}

    def _cb(hwnd, _extra):
        if match["hwnd"] is not None or not win32gui.IsWindowVisible(hwnd):
            return True
        title = win32gui.GetWindowText(hwnd).strip()
        if not title:
            return True
        try:
            _, pid = win32process.GetWindowThreadProcessId(hwnd)
        except Exception:  # noqa: BLE001
            pid = None
        process = _process_name_for_pid(pid)
        if query in title.lower() or query in process.lower():
            match["hwnd"] = hwnd
            match["title"] = title
        return True

    win32gui.EnumWindows(_cb, None)
    return match["hwnd"], match["title"]


def _with_window(query: str, action):
    """Shared boilerplate: resolve the window, run `action(hwnd)`, wrap
    failures consistently. `action` returns the success message body."""
    try:
        import win32gui  # noqa: F401 - import check, used inside action()
    except ImportError:
        return {"success": False, "message": "Window control isn't available -- the 'pywin32' package isn't installed."}

    hwnd, title = _find_hwnd(query)
    if hwnd is None:
        return {"success": False, "message": f"No window matching '{query}' found."}
    try:
        message = action(hwnd, title)
    except Exception as exc:  # noqa: BLE001 - Win32 calls fail in varied ways
        return {"success": False, "message": f"Couldn't control window '{title}': {exc}"}
    return {"success": True, "message": message}


def focus_window(arg: str) -> dict:
    import win32gui
    import win32con

    def _action(hwnd, title):
        if win32gui.IsIconic(hwnd):
            win32gui.ShowWindow(hwnd, win32con.SW_RESTORE)
        win32gui.SetForegroundWindow(hwnd)
        return f"Focused '{title}'."

    return _with_window(arg, _action)


def restore_window(arg: str) -> dict:
    import win32gui
    import win32con

    def _action(hwnd, title):
        win32gui.ShowWindow(hwnd, win32con.SW_RESTORE)
        return f"Restored '{title}'."

    return _with_window(arg, _action)


def close_window(arg: str) -> dict:
    import win32gui
    import win32con

    def _action(hwnd, title):
        win32gui.PostMessage(hwnd, win32con.WM_CLOSE, 0, 0)
        return f"Sent close to '{title}'."

    return _with_window(arg, _action)


def get_window_bounds(arg: str) -> dict:
    import win32gui

    def _action(hwnd, title):
        left, top, right, bottom = win32gui.GetWindowRect(hwnd)
        return f"'{title}': x={left}, y={top}, width={right - left}, height={bottom - top}."

    return _with_window(arg, _action)


def get_window_process(arg: str) -> dict:
    import win32gui
    import win32process

    def _action(hwnd, title):
        _, pid = win32process.GetWindowThreadProcessId(hwnd)
        return f"'{title}' is owned by {_process_name_for_pid(pid)} (pid {pid})."

    return _with_window(arg, _action)


def move_window(arg: str) -> dict:
    """arg: 'query|x|y', e.g. 'notepad|100|100'."""
    parts = [p.strip() for p in arg.split("|")]
    if len(parts) != 3:
        return {"success": False, "message": "move_window needs 'query|x|y'."}
    query, x_str, y_str = parts
    try:
        x, y = int(x_str), int(y_str)
    except ValueError:
        return {"success": False, "message": "move_window's x/y must be integers."}

    import win32gui

    def _action(hwnd, title):
        _, _, right, bottom = win32gui.GetWindowRect(hwnd)
        left, top, old_right, old_bottom = win32gui.GetWindowRect(hwnd)
        width, height = old_right - left, old_bottom - top
        win32gui.MoveWindow(hwnd, x, y, width, height, True)
        return f"Moved '{title}' to ({x}, {y})."

    return _with_window(query, _action)


def resize_window(arg: str) -> dict:
    """arg: 'query|width|height'."""
    parts = [p.strip() for p in arg.split("|")]
    if len(parts) != 3:
        return {"success": False, "message": "resize_window needs 'query|width|height'."}
    query, w_str, h_str = parts
    try:
        width, height = int(w_str), int(h_str)
    except ValueError:
        return {"success": False, "message": "resize_window's width/height must be integers."}

    import win32gui

    def _action(hwnd, title):
        left, top, _, _ = win32gui.GetWindowRect(hwnd)
        win32gui.MoveWindow(hwnd, left, top, width, height, True)
        return f"Resized '{title}' to {width}x{height}."

    return _with_window(query, _action)


def _work_area():
    """Returns the primary monitor's usable (taskbar-excluded) work area as
    (left, top, right, bottom)."""
    import win32api
    import win32con
    return win32api.SystemParametersInfo(win32con.SPI_GETWORKAREA)


def center_window(arg: str) -> dict:
    import win32gui

    def _action(hwnd, title):
        left, top, right, bottom = _work_area()
        screen_w, screen_h = right - left, bottom - top
        wl, wt, wr, wb = win32gui.GetWindowRect(hwnd)
        width, height = wr - wl, wb - wt
        new_x = left + max(0, (screen_w - width) // 2)
        new_y = top + max(0, (screen_h - height) // 2)
        win32gui.MoveWindow(hwnd, new_x, new_y, width, height, True)
        return f"Centered '{title}'."

    return _with_window(arg, _action)


def _snap(arg: str, quadrant: str) -> dict:
    import win32gui

    def _action(hwnd, title):
        left, top, right, bottom = _work_area()
        w, h = right - left, bottom - top
        boxes = {
            "left": (left, top, w // 2, h),
            "right": (left + w // 2, top, w // 2, h),
            "top": (left, top, w, h // 2),
            "bottom": (left, top + h // 2, w, h // 2),
        }
        x, y, width, height = boxes[quadrant]
        win32gui.MoveWindow(hwnd, x, y, width, height, True)
        return f"Snapped '{title}' to the {quadrant}."

    return _with_window(arg, _action)


def snap_window_left(arg: str) -> dict:
    return _snap(arg, "left")


def snap_window_right(arg: str) -> dict:
    return _snap(arg, "right")


def snap_window_top(arg: str) -> dict:
    return _snap(arg, "top")


def snap_window_bottom(arg: str) -> dict:
    return _snap(arg, "bottom")


def minimize_all_windows(_arg: str = "") -> dict:
    """Sends the same signal the taskbar's 'Show Desktop' corner sends
    (Win+D), rather than iterating windows individually -- more reliable
    and matches native OS behavior exactly."""
    import pyautogui
    pyautogui.hotkey("win", "d")
    return {"success": True, "message": "Minimized all windows (Show Desktop)."}


def restore_all_windows(_arg: str = "") -> dict:
    """Win+D again toggles back -- restores whatever was minimized by the
    last Show Desktop."""
    import pyautogui
    pyautogui.hotkey("win", "d")
    return {"success": True, "message": "Restored windows (toggled Show Desktop)."}


def get_monitors(_arg: str = "") -> dict:
    try:
        import win32api
    except ImportError:
        return {"success": False, "message": "Monitor info isn't available -- the 'pywin32' package isn't installed."}
    monitors = win32api.EnumDisplayMonitors()
    lines = []
    for i, (_handle, _hdc, rect) in enumerate(monitors):
        left, top, right, bottom = rect
        lines.append(f"Monitor {i}: {right - left}x{bottom - top} at ({left},{top})")
    return {"success": True, "message": f"{len(lines)} monitor(s): " + " | ".join(lines)}


def get_primary_monitor(_arg: str = "") -> dict:
    try:
        import win32api
    except ImportError:
        return {"success": False, "message": "Monitor info isn't available -- the 'pywin32' package isn't installed."}
    width = win32api.GetSystemMetrics(0)
    height = win32api.GetSystemMetrics(1)
    return {"success": True, "message": f"Primary monitor: {width}x{height}"}


def get_screen_resolution(_arg: str = "") -> dict:
    return get_primary_monitor(_arg)



# ==========================================================================
# originally troy/tools/display.py
# ==========================================================================
def take_screenshot_region(arg: str) -> dict:
    """arg format: 'left,top,width,height'. Saves to troy_screenshots/ and
    returns the path -- pair with read_file/OCR/vision tools if the
    content needs to be examined afterward."""
    try:
        parts = [int(float(p.strip())) for p in arg.split(",")]
        if len(parts) != 4:
            raise ValueError
        left, top, width, height = parts
    except ValueError:
        return {"success": False, "message": "take_screenshot_region needs 'left,top,width,height'."}

    os.makedirs(config.SCREENSHOT_DIR, exist_ok=True)
    try:
        image = pyautogui.screenshot(region=(left, top, width, height))
    except Exception as exc:  # noqa: BLE001 - pyautogui/Pillow raise varied errors
        return {"success": False, "message": f"Couldn't capture region: {exc}"}

    path = os.path.join(config.SCREENSHOT_DIR, f"region_{int(time.time())}.png")
    image.save(path)
    return {"success": True, "message": f"Saved region screenshot: {path}"}


def save_screenshot(arg: str) -> dict:
    """arg = destination path (optional -- defaults to troy_screenshots/
    with a timestamped name)."""
    os.makedirs(config.SCREENSHOT_DIR, exist_ok=True)
    dest = arg.strip() if arg.strip() else os.path.join(config.SCREENSHOT_DIR, f"shot_{int(time.time())}.png")
    dest = os.path.abspath(os.path.expanduser(dest))
    if os.path.exists(dest):
        return {"success": False, "message": f"'{dest}' already exists -- not overwriting."}

    try:
        image = pyautogui.screenshot()
        os.makedirs(os.path.dirname(dest), exist_ok=True)
        image.save(dest)
    except Exception as exc:  # noqa: BLE001
        return {"success": False, "message": f"Couldn't save screenshot: {exc}"}
    return {"success": True, "message": f"Saved screenshot: {dest}"}


def get_screen_size(_arg: str = "") -> dict:
    width, height = pyautogui.size()
    return {"success": True, "message": f"{width}x{height}"}


def get_cursor_position(_arg: str = "") -> dict:
    x, y = pyautogui.position()
    return {"success": True, "message": f"({x}, {y})"}


def set_cursor_position(arg: str) -> dict:
    try:
        parts = [int(float(p.strip())) for p in arg.replace("|", ",").split(",")]
        if len(parts) != 2:
            raise ValueError
        x, y = parts
    except ValueError:
        return {"success": False, "message": "set_cursor_position needs 'x,y'."}
    pyautogui.moveTo(x, y)
    return {"success": True, "message": f"Moved cursor to ({x}, {y})."}


def get_pixel_color(arg: str) -> dict:
    try:
        parts = [int(float(p.strip())) for p in arg.replace("|", ",").split(",")]
        if len(parts) != 2:
            raise ValueError
        x, y = parts
    except ValueError:
        return {"success": False, "message": "get_pixel_color needs 'x,y'."}

    try:
        r, g, b = pyautogui.pixel(x, y)
    except Exception as exc:  # noqa: BLE001
        return {"success": False, "message": f"Couldn't read pixel color: {exc}"}
    return {"success": True, "message": f"RGB({r}, {g}, {b}) = #{r:02x}{g:02x}{b:02x}"}



# ==========================================================================
# originally troy/tools/vision.py
# ==========================================================================
def take_screenshot_and_describe() -> dict:
    os.makedirs(config.SCREENSHOT_DIR, exist_ok=True)
    image = pyautogui.screenshot()

    filename = os.path.join(config.SCREENSHOT_DIR, f"shot_{int(time.time())}.jpg")
    image.save(filename)

    buffer = io.BytesIO()
    image.save(buffer, format="JPG")
    encoded = base64.b64encode(buffer.getvalue()).decode("utf-8")

    try:
        description = llm_client.describe_image(encoded)
    except Exception as exc:  # noqa: BLE001
        return {
            "success": False,
            "message": f"Screenshot saved to {filename}, but vision description failed: {exc}",
        }

    return {"success": True, "message": f"Screen shows: {description}"}


def compare_screenshots(arg: str) -> dict:
    """arg format: 'path_a|path_b'. Cheap structural check for 'did the
    screen actually change' without a vision-model call -- reuses the same
    approximate-difference approach as image_tools.compare_images."""
    if "|" not in arg:
        return {"success": False, "message": "compare_screenshots needs 'path_a|path_b'."}
    try:
        from PIL import Image
    except ImportError:
        return {"success": False, "message": "compare_screenshots needs the 'Pillow' package (pip install Pillow)."}

    a, b = (part.strip() for part in arg.split("|", 1))
    a = os.path.abspath(os.path.expanduser(a))
    b = os.path.abspath(os.path.expanduser(b))
    if not os.path.isfile(a) or not os.path.isfile(b):
        return {"success": False, "message": "Both paths must be existing image files."}

    try:
        with Image.open(a) as img_a, Image.open(b) as img_b:
            size = (128, 128)
            pixels_a = list(img_a.convert("RGB").resize(size).getdata())
            pixels_b = list(img_b.convert("RGB").resize(size).getdata())
    except OSError as exc:
        return {"success": False, "message": f"Couldn't compare screenshots: {exc}"}

    total_diff = sum(
        abs(pa[0] - pb[0]) + abs(pa[1] - pb[1]) + abs(pa[2] - pb[2])
        for pa, pb in zip(pixels_a, pixels_b)
    )
    max_diff = len(pixels_a) * 255 * 3
    pct = (total_diff / max_diff) * 100 if max_diff else 0
    changed = pct > 1.5  # small threshold to absorb cursor blink / clock ticking, etc.
    return {"success": True, "message": f"Screens are {'different' if changed else 'effectively the same'} ({pct:.1f}% difference)."}


def wait_for_screen_change(arg: str) -> dict:
    """arg = timeout in seconds (default 10). Takes a screenshot, polls
    every second for the screen to change noticeably, and returns as soon
    as it does (or when the timeout elapses) -- a cheap structural
    alternative to guessing a fixed `wait` duration before checking with a
    full vision screenshot."""
    try:
        timeout = max(1, min(60, float(arg.strip()))) if arg.strip() else 10.0
    except ValueError:
        timeout = 10.0

    baseline = pyautogui.screenshot()
    deadline = time.time() + timeout
    while time.time() < deadline:
        time.sleep(1)
        current = pyautogui.screenshot()
        size = (128, 128)
        pixels_a = list(baseline.convert("RGB").resize(size).getdata())
        pixels_b = list(current.convert("RGB").resize(size).getdata())
        total_diff = sum(
            abs(pa[0] - pb[0]) + abs(pa[1] - pb[1]) + abs(pa[2] - pb[2])
            for pa, pb in zip(pixels_a, pixels_b)
        )
        pct = (total_diff / (len(pixels_a) * 255 * 3)) * 100
        if pct > 1.5:
            return {"success": True, "message": f"Screen changed ({pct:.1f}% difference)."}
    return {"success": True, "message": f"No significant screen change within {timeout:.0f}s."}



# ==========================================================================
# originally troy/tools/ocr.py
# ==========================================================================
def _configure_tesseract():
    """Find Tesseract on Windows and configure pytesseract explicitly."""
    import pytesseract

    # 1. Respect an existing PATH installation first.
    path = shutil.which("tesseract")
    if path and os.path.isfile(path):
        pytesseract.pytesseract.tesseract_cmd = path
        return path

    # 2. Common Windows installation locations.
    candidates = [
        r"C:\Program Files\Tesseract-OCR\tesseract.exe",
        r"C:\Program Files (x86)\Tesseract-OCR\tesseract.exe",
    ]

    for path in candidates:
        if os.path.isfile(path):
            pytesseract.pytesseract.tesseract_cmd = path
            return path

    return None


def read_screen_text(region: tuple = None) -> dict:
    """Read text from the screen using local Tesseract OCR."""
    try:
        import pytesseract
    except ImportError:
        return {
            "success": False,
            "message": (
                "OCR isn't available because 'pytesseract' is not installed. "
                "Run: pip install pytesseract"
            ),
        }

    tesseract_path = _configure_tesseract()

    if not tesseract_path:
        return {
            "success": False,
            "message": (
                "Tesseract OCR executable was not found. "
                "Install Tesseract or set its path in troy/tools/ocr.py."
            ),
        }

    try:
        image = (
            pyautogui.screenshot(region=region)
            if region
            else pyautogui.screenshot()
        )

        text = pytesseract.image_to_string(image)

    except Exception as exc:
        return {
            "success": False,
            "message": f"OCR failed: {exc}",
        }

    text = text.strip()

    if not text:
        return {
            "success": True,
            "message": "No readable text detected on screen.",
        }

    truncated = text[:2000]
    suffix = " (truncated)" if len(text) > 2000 else ""

    return {
        "success": True,
        "message": truncated + suffix,
    }


def find_text_on_screen(query: str) -> dict:
    """Runs OCR on the current screen and reports whether `query` appears
    in it, with surrounding context. Cheaper than a vision-model call when
    the question is 'is this specific text visible' rather than 'describe
    what's on screen'."""
    query = (query or "").strip()
    if not query:
        return {"success": False, "message": "find_text_on_screen needs text to search for."}

    result = read_screen_text()
    if not result.get("success"):
        return result

    text = result["message"]
    if query.lower() not in text.lower():
        return {"success": True, "message": f"'{query}' was not found in the visible screen text."}

    idx = text.lower().find(query.lower())
    start = max(0, idx - 40)
    end = min(len(text), idx + len(query) + 40)
    context = text[start:end].replace("\n", " ")
    return {"success": True, "message": f"Found '{query}' on screen. Context: ...{context}..."}



# ==========================================================================
# originally troy/tools/files.py
# ==========================================================================
def _resolve(path: str) -> str:
    return os.path.abspath(os.path.expanduser(os.path.expandvars(path.strip())))


# Locations Troy will never delete, move-from, or rename, regardless of
# confirmation -- these are either whole-drive roots or well-known system
# folders where a mistaken match (e.g. an empty/near-empty pattern) could
# be catastrophic. This is a hard floor, not something a "CONFIRM|" prefix
# can override.
_PROTECTED_ROOTS = {
    os.path.expandvars(r"%WINDIR%").lower(),
    os.path.expandvars(r"%PROGRAMFILES%").lower(),
    os.path.expandvars(r"%PROGRAMFILES(X86)%").lower(),
    os.path.expandvars(r"%SYSTEMROOT%").lower(),
    os.path.expanduser("~").lower(),
}


def _is_protected(path: str) -> bool:
    normalized = os.path.normpath(path).lower()
    # A drive root (e.g. "C:\\") or any of the named system folders themselves.
    if os.path.splitdrive(normalized)[1] in ("", "\\", "/"):
        return True
    return normalized in _PROTECTED_ROOTS


def _recycle(path: str) -> bool:
    """Moves a file/folder to the Recycle Bin via the Windows shell API
    (SHFileOperationW with FOF_ALLOWUNDO), rather than a hard delete --
    recoverable by design. Pure ctypes/stdlib, no extra dependency. Returns
    True on success; raises OSError with a readable message on failure or
    on non-Windows platforms (where there's no Recycle Bin to use)."""
    if sys.platform != "win32":
        raise OSError("Recycle Bin deletion is only available on Windows.")

    import ctypes

    class SHFILEOPSTRUCTW(ctypes.Structure):
        _fields_ = [
            ("hwnd", ctypes.c_void_p),
            ("wFunc", ctypes.c_uint),
            ("pFrom", ctypes.c_wchar_p),
            ("pTo", ctypes.c_wchar_p),
            ("fFlags", ctypes.c_uint16),
            ("fAnyOperationsAborted", ctypes.c_int),
            ("hNameMappings", ctypes.c_void_p),
            ("lpszProgressTitle", ctypes.c_wchar_p),
        ]

    FO_DELETE = 3
    FOF_ALLOWUNDO = 0x40
    FOF_NOCONFIRMATION = 0x10
    FOF_SILENT = 0x4

    # pFrom must be double-null-terminated.
    op = SHFILEOPSTRUCTW()
    op.hwnd = None
    op.wFunc = FO_DELETE
    op.pFrom = path + "\0"
    op.pTo = None
    op.fFlags = FOF_ALLOWUNDO | FOF_NOCONFIRMATION | FOF_SILENT
    result = ctypes.windll.shell32.SHFileOperationW(ctypes.byref(op))
    if result != 0:
        raise OSError(f"Recycle Bin operation failed (code {result}).")
    return True


def create_file(arg: str) -> dict:
    """arg format: 'path' or 'path|content'."""
    if "|" in arg:
        path, content = arg.split("|", 1)
    else:
        path, content = arg, ""
    path = _resolve(path)

    if os.path.exists(path):
        return {"success": False, "message": f"'{path}' already exists -- not overwriting."}

    try:
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with open(path, "w", encoding="utf-8") as f:
            f.write(content)
        return {"success": True, "message": f"Created file: {path}"}
    except OSError as exc:
        return {"success": False, "message": f"Couldn't create '{path}': {exc}"}


def move_file(arg: str) -> dict:
    """arg format: 'source_path|destination_path'."""
    if "|" not in arg:
        return {"success": False, "message": "move_file needs 'source|destination'."}
    src, dest = (part.strip() for part in arg.split("|", 1))
    src, dest = _resolve(src), _resolve(dest)

    if not os.path.exists(src):
        return {"success": False, "message": f"Source doesn't exist: {src}"}
    if os.path.exists(dest):
        return {"success": False, "message": f"Destination already exists, not overwriting: {dest}"}

    try:
        os.makedirs(os.path.dirname(dest), exist_ok=True)
        shutil.move(src, dest)
        return {"success": True, "message": f"Moved '{src}' to '{dest}'."}
    except OSError as exc:
        return {"success": False, "message": f"Couldn't move '{src}' to '{dest}': {exc}"}


def copy_file(arg: str) -> dict:
    """arg format: 'source_path|destination_path'. Same not-overwriting
    stance as move_file -- copying is normally safe, but a silent overwrite
    of an existing file at the destination isn't."""
    if "|" not in arg:
        return {"success": False, "message": "copy_file needs 'source|destination'."}
    src, dest = (part.strip() for part in arg.split("|", 1))
    src, dest = _resolve(src), _resolve(dest)

    if not os.path.exists(src):
        return {"success": False, "message": f"Source doesn't exist: {src}"}
    if os.path.exists(dest):
        return {"success": False, "message": f"Destination already exists, not overwriting: {dest}"}

    try:
        os.makedirs(os.path.dirname(dest), exist_ok=True)
        if os.path.isdir(src):
            shutil.copytree(src, dest)
        else:
            shutil.copy2(src, dest)
        return {"success": True, "message": f"Copied '{src}' to '{dest}'."}
    except OSError as exc:
        return {"success": False, "message": f"Couldn't copy '{src}' to '{dest}': {exc}"}


def read_file(arg: str) -> dict:
    """Reads a text file's content back as an observation, capped so huge
    files don't blow up the conversation context."""
    path = _resolve(arg)
    if not os.path.isfile(path):
        return {"success": False, "message": f"Not a file: {path}"}

    try:
        with open(path, "r", encoding="utf-8", errors="replace") as f:
            content = f.read()
    except OSError as exc:
        return {"success": False, "message": f"Couldn't read '{path}': {exc}"}

    truncated = content[:3000]
    suffix = " (truncated)" if len(content) > 3000 else ""
    return {"success": True, "message": f"{path}:\n{truncated}{suffix}"}


def find_files(arg: str) -> dict:
    """arg format: 'pattern' or 'pattern|root'. pattern supports glob
    wildcards (*, ?), matched case-insensitively against filenames only --
    matching full paths would make it trivial to accidentally walk far more
    of the disk than the user meant to search. Root defaults to the home
    folder; the walk stops once it has collected enough matches so a broad
    pattern over a huge tree doesn't hang the agent loop."""
    if "|" in arg:
        pattern, root = (part.strip() for part in arg.split("|", 1))
    else:
        pattern, root = arg.strip(), ""
    if not pattern:
        return {"success": False, "message": "find_files needs a filename pattern, e.g. '*.pdf'."}

    root = _resolve(root) if root else os.path.expanduser("~")
    if not os.path.isdir(root):
        return {"success": False, "message": f"Not a directory: {root}"}

    matches = []
    max_matches = 40
    max_scanned = 20000
    scanned = 0
    for dirpath, _dirnames, filenames in os.walk(root):
        for name in filenames:
            scanned += 1
            if fnmatch.fnmatch(name.lower(), pattern.lower()):
                matches.append(os.path.join(dirpath, name))
                if len(matches) >= max_matches:
                    break
        if len(matches) >= max_matches or scanned >= max_scanned:
            break

    if not matches:
        return {"success": True, "message": f"No files matching '{pattern}' found under {root}."}

    suffix = " (stopped early, more may exist)" if len(matches) >= max_matches or scanned >= max_scanned else ""
    return {"success": True, "message": f"Found {len(matches)} match(es){suffix}: " + ", ".join(matches)}


def list_dir(arg: str) -> dict:
    path = _resolve(arg) if arg else os.path.expanduser("~")
    if not os.path.isdir(path):
        return {"success": False, "message": f"Not a directory: {path}"}

    try:
        entries = sorted(os.listdir(path))
    except OSError as exc:
        return {"success": False, "message": f"Couldn't list '{path}': {exc}"}

    if not entries:
        return {"success": True, "message": f"{path} is empty."}

    labeled = []
    for name in entries[:60]:  # keep observations from ballooning on huge folders
        full = os.path.join(path, name)
        labeled.append(f"{name}/" if os.path.isdir(full) else name)

    more = f" (+{len(entries) - 60} more)" if len(entries) > 60 else ""
    return {"success": True, "message": f"{path}: " + ", ".join(labeled) + more}


def delete_file(arg: str) -> dict:
    """Moves a file to the Recycle Bin (never a permanent delete). Requires
    confirmation via the tool registry -- this function assumes the
    confirmation gate has already passed and `arg` is the bare path."""
    path = _resolve(arg)
    if _is_protected(path):
        return {"success": False, "message": f"Refusing to delete a protected system location: {path}"}
    if not os.path.exists(path):
        return {"success": False, "message": f"Nothing to delete -- doesn't exist: {path}"}
    if os.path.isdir(path):
        return {"success": False, "message": f"'{path}' is a folder -- use delete_folder instead."}

    try:
        _recycle(path)
    except OSError as exc:
        return {"success": False, "message": f"Couldn't delete '{path}': {exc}"}
    return {"success": True, "message": f"Moved to Recycle Bin: {path}"}


def delete_folder(arg: str) -> dict:
    """Moves a folder (and everything in it) to the Recycle Bin. Requires
    confirmation via the tool registry."""
    path = _resolve(arg)
    if _is_protected(path):
        return {"success": False, "message": f"Refusing to delete a protected system location: {path}"}
    if not os.path.isdir(path):
        return {"success": False, "message": f"Not a folder: {path}"}

    try:
        _recycle(path)
    except OSError as exc:
        return {"success": False, "message": f"Couldn't delete '{path}': {exc}"}
    return {"success": True, "message": f"Moved to Recycle Bin: {path}"}


def rename_file(arg: str) -> dict:
    """arg format: 'path|new_name'. new_name is a bare filename (not a
    path) -- the file stays in the same folder, just renamed. Use move_file
    if you actually want to relocate it."""
    if "|" not in arg:
        return {"success": False, "message": "rename_file needs 'path|new_name'."}
    path, new_name = (part.strip() for part in arg.split("|", 1))
    path = _resolve(path)
    new_name = os.path.basename(new_name)
    if not new_name:
        return {"success": False, "message": "rename_file needs a non-empty new name."}
    if not os.path.exists(path):
        return {"success": False, "message": f"Doesn't exist: {path}"}

    dest = os.path.join(os.path.dirname(path), new_name)
    if os.path.exists(dest):
        return {"success": False, "message": f"'{dest}' already exists -- not overwriting."}

    try:
        os.rename(path, dest)
    except OSError as exc:
        return {"success": False, "message": f"Couldn't rename '{path}': {exc}"}
    return {"success": True, "message": f"Renamed '{path}' to '{dest}'."}


def create_folder(arg: str) -> dict:
    path = _resolve(arg)
    if os.path.exists(path):
        return {"success": False, "message": f"'{path}' already exists."}
    try:
        os.makedirs(path)
    except OSError as exc:
        return {"success": False, "message": f"Couldn't create folder '{path}': {exc}"}
    return {"success": True, "message": f"Created folder: {path}"}


def list_folder_tree(arg: str) -> dict:
    """arg format: 'path' or 'path|max_depth' (default depth 2). Capped in
    both depth and total entries so a huge tree can't flood the model's
    context window."""
    if "|" in arg:
        path, depth_str = (part.strip() for part in arg.split("|", 1))
        try:
            max_depth = max(1, min(6, int(depth_str)))
        except ValueError:
            max_depth = 2
    else:
        path, max_depth = arg.strip(), 2

    path = _resolve(path) if path else os.path.expanduser("~")
    if not os.path.isdir(path):
        return {"success": False, "message": f"Not a directory: {path}"}

    lines = []
    max_lines = 150

    def _walk(current, depth, prefix):
        if len(lines) >= max_lines:
            return
        try:
            entries = sorted(os.listdir(current))
        except OSError:
            return
        for name in entries:
            if len(lines) >= max_lines:
                lines.append(f"{prefix}... (truncated)")
                return
            full = os.path.join(current, name)
            is_dir = os.path.isdir(full)
            lines.append(f"{prefix}{name}{'/' if is_dir else ''}")
            if is_dir and depth < max_depth:
                _walk(full, depth + 1, prefix + "  ")

    _walk(path, 1, "")
    if not lines:
        return {"success": True, "message": f"{path} is empty."}
    return {"success": True, "message": f"{path}\n" + "\n".join(lines)}


def get_file_info(arg: str) -> dict:
    path = _resolve(arg)
    if not os.path.exists(path):
        return {"success": False, "message": f"Doesn't exist: {path}"}
    try:
        stat = os.stat(path)
    except OSError as exc:
        return {"success": False, "message": f"Couldn't read info for '{path}': {exc}"}

    import datetime
    kind = "folder" if os.path.isdir(path) else "file"
    size = stat.st_size
    modified = datetime.datetime.fromtimestamp(stat.st_mtime).strftime("%Y-%m-%d %H:%M")
    created = datetime.datetime.fromtimestamp(stat.st_ctime).strftime("%Y-%m-%d %H:%M")
    size_str = f"{size} bytes" if size < 1024 else f"{size / 1024:.1f} KB" if size < 1024**2 else f"{size / 1024**2:.1f} MB"
    return {
        "success": True,
        "message": f"{path}: {kind}, {size_str}, created {created}, modified {modified}",
    }


def get_folder_size(arg: str) -> dict:
    path = _resolve(arg) if arg else os.path.expanduser("~")
    if not os.path.isdir(path):
        return {"success": False, "message": f"Not a directory: {path}"}

    total = 0
    file_count = 0
    max_files_scanned = 50000  # safety cap so a huge/networked folder can't hang the agent loop
    for dirpath, _dirnames, filenames in os.walk(path):
        for name in filenames:
            file_count += 1
            if file_count > max_files_scanned:
                break
            try:
                total += os.path.getsize(os.path.join(dirpath, name))
            except OSError:
                continue
        if file_count > max_files_scanned:
            break

    size_str = f"{total / 1024**3:.2f} GB" if total >= 1024**3 else f"{total / 1024**2:.1f} MB"
    suffix = " (stopped early -- very large folder)" if file_count > max_files_scanned else ""
    return {"success": True, "message": f"{path}: {size_str} across {file_count} file(s){suffix}"}


def find_large_files(arg: str) -> dict:
    """arg format: 'root' or 'root|min_size_mb' (default 100 MB)."""
    if "|" in arg:
        root, min_mb_str = (part.strip() for part in arg.split("|", 1))
        try:
            min_mb = float(min_mb_str)
        except ValueError:
            min_mb = 100.0
    else:
        root, min_mb = arg.strip(), 100.0

    root = _resolve(root) if root else os.path.expanduser("~")
    if not os.path.isdir(root):
        return {"success": False, "message": f"Not a directory: {root}"}

    min_bytes = min_mb * 1024 * 1024
    hits = []
    scanned = 0
    for dirpath, _dirnames, filenames in os.walk(root):
        for name in filenames:
            scanned += 1
            if scanned > 50000:
                break
            full = os.path.join(dirpath, name)
            try:
                size = os.path.getsize(full)
            except OSError:
                continue
            if size >= min_bytes:
                hits.append((full, size))
        if scanned > 50000:
            break

    hits.sort(key=lambda t: t[1], reverse=True)
    top = hits[:25]
    if not top:
        return {"success": True, "message": f"No files >= {min_mb:.0f} MB found under {root}."}
    lines = [f"{path} ({size / 1024**2:.1f} MB)" for path, size in top]
    return {"success": True, "message": f"{len(hits)} file(s) >= {min_mb:.0f} MB (showing top {len(top)}): " + " | ".join(lines)}


def find_duplicate_files(arg: str) -> dict:
    """arg = root directory. Groups files by (size, content hash) --
    hashing only happens for files that already share a size, so this
    stays cheap on folders without duplicates. Capped in scan size so a
    huge folder can't hang the agent loop."""
    root = _resolve(arg) if arg else os.path.expanduser("~")
    if not os.path.isdir(root):
        return {"success": False, "message": f"Not a directory: {root}"}

    by_size = defaultdict(list)
    scanned = 0
    for dirpath, _dirnames, filenames in os.walk(root):
        for name in filenames:
            scanned += 1
            if scanned > 20000:
                break
            full = os.path.join(dirpath, name)
            try:
                size = os.path.getsize(full)
            except OSError:
                continue
            if size > 0:
                by_size[size].append(full)
        if scanned > 20000:
            break

    duplicate_groups = []
    hashed_files = 0
    for size, paths in by_size.items():
        if len(paths) < 2 or hashed_files > 4000:
            continue
        by_hash = defaultdict(list)
        for path in paths:
            hashed_files += 1
            try:
                by_hash[_file_hash(path)].append(path)
            except OSError:
                continue
        for group in by_hash.values():
            if len(group) > 1:
                duplicate_groups.append(group)

    if not duplicate_groups:
        return {"success": True, "message": f"No duplicate files found under {root}."}
    lines = [" == ".join(group) for group in duplicate_groups[:15]]
    more = f" (+{len(duplicate_groups) - 15} more groups)" if len(duplicate_groups) > 15 else ""
    return {"success": True, "message": f"{len(duplicate_groups)} duplicate group(s){more}: " + " | ".join(lines)}


def search_file_contents(arg: str) -> dict:
    """arg format: 'query|root' (root optional, defaults to home). Greps
    for `query` (case-insensitive substring) inside text files under root.
    Skips anything that doesn't decode as text, and stops early once it has
    enough hits or has scanned enough files, so this can't hang on a huge
    or binary-heavy tree."""
    if "|" in arg:
        query, root = (part.strip() for part in arg.split("|", 1))
    else:
        query, root = arg.strip(), ""
    if not query:
        return {"success": False, "message": "search_file_contents needs a search query."}

    root = _resolve(root) if root else os.path.expanduser("~")
    if not os.path.isdir(root):
        return {"success": False, "message": f"Not a directory: {root}"}

    query_lower = query.lower()
    hits = []
    scanned = 0
    text_extensions = {".txt", ".md", ".py", ".js", ".ts", ".json", ".csv", ".log", ".html", ".xml", ".yaml", ".yml", ".ini", ".cfg"}
    for dirpath, _dirnames, filenames in os.walk(root):
        for name in filenames:
            if os.path.splitext(name)[1].lower() not in text_extensions:
                continue
            scanned += 1
            if scanned > 3000 or len(hits) >= 30:
                break
            full = os.path.join(dirpath, name)
            try:
                with open(full, "r", encoding="utf-8", errors="ignore") as f:
                    for lineno, line in enumerate(f, start=1):
                        if query_lower in line.lower():
                            hits.append(f"{full}:{lineno}: {line.strip()[:120]}")
                            break
            except OSError:
                continue
        if scanned > 3000 or len(hits) >= 30:
            break

    if not hits:
        return {"success": True, "message": f"No matches for '{query}' found under {root}."}
    return {"success": True, "message": f"{len(hits)} match(es): " + " | ".join(hits)}


def get_recent_files(arg: str) -> dict:
    """arg = root directory (optional, defaults to home). Lists the most
    recently modified files, newest first."""
    root = _resolve(arg) if arg else os.path.expanduser("~")
    if not os.path.isdir(root):
        return {"success": False, "message": f"Not a directory: {root}"}

    entries = []
    scanned = 0
    for dirpath, _dirnames, filenames in os.walk(root):
        for name in filenames:
            scanned += 1
            if scanned > 20000:
                break
            full = os.path.join(dirpath, name)
            try:
                mtime = os.path.getmtime(full)
            except OSError:
                continue
            entries.append((full, mtime))
        if scanned > 20000:
            break

    entries.sort(key=lambda t: t[1], reverse=True)
    top = entries[:20]
    if not top:
        return {"success": True, "message": f"No files found under {root}."}

    import datetime
    lines = [f"{path} ({datetime.datetime.fromtimestamp(mtime).strftime('%Y-%m-%d %H:%M')})" for path, mtime in top]
    return {"success": True, "message": " | ".join(lines)}


def get_file_extension_stats(arg: str) -> dict:
    """arg = root directory (optional, defaults to home). Counts files by
    extension -- a quick way to answer 'what's actually in this folder'
    without listing every file."""
    root = _resolve(arg) if arg else os.path.expanduser("~")
    if not os.path.isdir(root):
        return {"success": False, "message": f"Not a directory: {root}"}

    counts = defaultdict(int)
    scanned = 0
    for dirpath, _dirnames, filenames in os.walk(root):
        for name in filenames:
            scanned += 1
            if scanned > 30000:
                break
            ext = os.path.splitext(name)[1].lower() or "(no extension)"
            counts[ext] += 1
        if scanned > 30000:
            break

    if not counts:
        return {"success": True, "message": f"No files found under {root}."}
    ranked = sorted(counts.items(), key=lambda kv: kv[1], reverse=True)[:20]
    lines = [f"{ext}: {count}" for ext, count in ranked]
    return {"success": True, "message": ", ".join(lines)}


def _file_hash(path: str, algo: str = "sha256") -> str:
    h = hashlib.new(algo)
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1024 * 256), b""):
            h.update(chunk)
    return h.hexdigest()


def calculate_hash(arg: str) -> dict:
    """arg format: 'path' or 'path|algorithm' (default sha256)."""
    if "|" in arg:
        path, algo = (part.strip() for part in arg.split("|", 1))
    else:
        path, algo = arg.strip(), "sha256"
    path = _resolve(path)
    if not os.path.isfile(path):
        return {"success": False, "message": f"Not a file: {path}"}
    try:
        digest = _file_hash(path, algo.lower() or "sha256")
    except (ValueError, OSError) as exc:
        return {"success": False, "message": f"Couldn't hash '{path}': {exc}"}
    return {"success": True, "message": f"{algo.lower()}({path}) = {digest}"}


def compare_files(arg: str) -> dict:
    """arg format: 'path_a|path_b'. Compares by content hash -- exact,
    doesn't need both files loaded into memory at once for a diff."""
    if "|" not in arg:
        return {"success": False, "message": "compare_files needs 'path_a|path_b'."}
    a, b = (_resolve(part.strip()) for part in arg.split("|", 1))
    if not os.path.isfile(a) or not os.path.isfile(b):
        return {"success": False, "message": "Both paths must be existing files."}
    try:
        same = _file_hash(a) == _file_hash(b)
    except OSError as exc:
        return {"success": False, "message": f"Couldn't compare files: {exc}"}
    return {"success": True, "message": f"'{a}' and '{b}' are {'identical' if same else 'different'}."}


def open_file(arg: str) -> dict:
    """Opens a file with its default associated application."""
    path = _resolve(arg)
    if not os.path.isfile(path):
        return {"success": False, "message": f"Not a file: {path}"}
    try:
        os.startfile(path)  # noqa: S606 - Windows-only, intentional
    except OSError as exc:
        return {"success": False, "message": f"Couldn't open '{path}': {exc}"}
    return {"success": True, "message": f"Opened: {path}"}


def open_folder(arg: str) -> dict:
    """Opens a folder in File Explorer."""
    path = _resolve(arg) if arg else os.path.expanduser("~")
    if not os.path.isdir(path):
        return {"success": False, "message": f"Not a folder: {path}"}
    try:
        os.startfile(path)  # noqa: S606 - Windows-only, intentional
    except OSError as exc:
        return {"success": False, "message": f"Couldn't open folder '{path}': {exc}"}
    return {"success": True, "message": f"Opened folder: {path}"}


def reveal_file_in_explorer(arg: str) -> dict:
    """Opens File Explorer with the given file pre-selected/highlighted."""
    path = _resolve(arg)
    if not os.path.exists(path):
        return {"success": False, "message": f"Doesn't exist: {path}"}
    try:
        subprocess.run(["explorer", "/select,", path], check=False)
    except OSError as exc:
        return {"success": False, "message": f"Couldn't open Explorer: {exc}"}
    return {"success": True, "message": f"Revealed in Explorer: {path}"}



# ==========================================================================
# originally troy/tools/archive.py
# ==========================================================================
def _is_tar(path: str) -> bool:
    lower = path.lower()
    return lower.endswith((".tar", ".tar.gz", ".tgz", ".tar.bz2", ".tbz2"))


def create_archive(arg: str) -> dict:
    """arg format: 'archive_path|source1;source2;...'. Archive type is
    inferred from archive_path's extension (.zip, or .tar/.tar.gz/.tar.bz2).
    Refuses to overwrite an existing archive."""
    if "|" not in arg:
        return {"success": False, "message": "create_archive needs 'archive_path|source1;source2;...'."}
    archive_path, sources_text = (part.strip() for part in arg.split("|", 1))
    archive_path = _resolve(archive_path)
    sources = [_resolve(s.strip()) for s in sources_text.split(";") if s.strip()]

    if not sources:
        return {"success": False, "message": "create_archive needs at least one source path."}
    if os.path.exists(archive_path):
        return {"success": False, "message": f"'{archive_path}' already exists -- not overwriting."}
    missing = [s for s in sources if not os.path.exists(s)]
    if missing:
        return {"success": False, "message": f"Source(s) don't exist: {', '.join(missing)}"}

    try:
        os.makedirs(os.path.dirname(archive_path), exist_ok=True)
        if _is_tar(archive_path):
            mode = "w:gz" if archive_path.lower().endswith((".tar.gz", ".tgz")) else \
                   "w:bz2" if archive_path.lower().endswith((".tar.bz2", ".tbz2")) else "w"
            with tarfile.open(archive_path, mode) as tf:
                for src in sources:
                    tf.add(src, arcname=os.path.basename(src))
        else:
            if not archive_path.lower().endswith(".zip"):
                archive_path += ".zip"
            with zipfile.ZipFile(archive_path, "w", zipfile.ZIP_DEFLATED) as zf:
                for src in sources:
                    if os.path.isdir(src):
                        for dirpath, _dirnames, filenames in os.walk(src):
                            for name in filenames:
                                full = os.path.join(dirpath, name)
                                arcname = os.path.join(os.path.basename(src), os.path.relpath(full, src))
                                zf.write(full, arcname)
                    else:
                        zf.write(src, os.path.basename(src))
    except OSError as exc:
        return {"success": False, "message": f"Couldn't create archive: {exc}"}

    return {"success": True, "message": f"Created archive: {archive_path}"}


def _safe_extract_zip(zf: zipfile.ZipFile, dest: str):
    for member in zf.namelist():
        target = os.path.abspath(os.path.join(dest, member))
        if not target.startswith(os.path.abspath(dest) + os.sep) and target != os.path.abspath(dest):
            raise ValueError(f"Archive entry '{member}' would extract outside the destination folder.")
    zf.extractall(dest)


def _safe_extract_tar(tf: tarfile.TarFile, dest: str):
    for member in tf.getmembers():
        target = os.path.abspath(os.path.join(dest, member.name))
        if not target.startswith(os.path.abspath(dest) + os.sep) and target != os.path.abspath(dest):
            raise ValueError(f"Archive entry '{member.name}' would extract outside the destination folder.")
    tf.extractall(dest)


def extract_archive(arg: str) -> dict:
    """arg format: 'archive_path|destination_folder'. Destination must not
    already exist -- prevents silently mixing an extraction into an
    existing unrelated folder."""
    if "|" not in arg:
        return {"success": False, "message": "extract_archive needs 'archive_path|destination_folder'."}
    archive_path, dest = (part.strip() for part in arg.split("|", 1))
    archive_path, dest = _resolve(archive_path), _resolve(dest)

    if not os.path.isfile(archive_path):
        return {"success": False, "message": f"Not a file: {archive_path}"}
    if os.path.exists(dest):
        return {"success": False, "message": f"Destination already exists, not overwriting: {dest}"}

    try:
        os.makedirs(dest)
        if _is_tar(archive_path):
            with tarfile.open(archive_path, "r:*") as tf:
                _safe_extract_tar(tf, dest)
        elif zipfile.is_zipfile(archive_path):
            with zipfile.ZipFile(archive_path, "r") as zf:
                _safe_extract_zip(zf, dest)
        else:
            os.rmdir(dest)
            return {"success": False, "message": f"'{archive_path}' isn't a recognized zip/tar archive."}
    except (OSError, ValueError, tarfile.TarError, zipfile.BadZipFile) as exc:
        return {"success": False, "message": f"Couldn't extract archive: {exc}"}

    return {"success": True, "message": f"Extracted to: {dest}"}


def list_archive(arg: str) -> dict:
    path = _resolve(arg)
    if not os.path.isfile(path):
        return {"success": False, "message": f"Not a file: {path}"}
    try:
        if _is_tar(path):
            with tarfile.open(path, "r:*") as tf:
                names = tf.getnames()
        elif zipfile.is_zipfile(path):
            with zipfile.ZipFile(path, "r") as zf:
                names = zf.namelist()
        else:
            return {"success": False, "message": f"'{path}' isn't a recognized zip/tar archive."}
    except (OSError, tarfile.TarError, zipfile.BadZipFile) as exc:
        return {"success": False, "message": f"Couldn't read archive: {exc}"}

    shown = names[:60]
    more = f" (+{len(names) - 60} more)" if len(names) > 60 else ""
    return {"success": True, "message": f"{len(names)} entries: " + ", ".join(shown) + more}


def add_to_archive(arg: str) -> dict:
    """arg format: 'archive_path|source_path'. ZIP only (tar archives
    aren't safely appendable without rewriting the whole file, which isn't
    worth the complexity here -- recreate with create_archive instead)."""
    if "|" not in arg:
        return {"success": False, "message": "add_to_archive needs 'archive_path|source_path'."}
    archive_path, source = (part.strip() for part in arg.split("|", 1))
    archive_path, source = _resolve(archive_path), _resolve(source)

    if not os.path.isfile(archive_path) or not zipfile.is_zipfile(archive_path):
        return {"success": False, "message": f"Not an existing ZIP archive: {archive_path}"}
    if not os.path.exists(source):
        return {"success": False, "message": f"Source doesn't exist: {source}"}

    try:
        with zipfile.ZipFile(archive_path, "a", zipfile.ZIP_DEFLATED) as zf:
            if os.path.isdir(source):
                for dirpath, _dirnames, filenames in os.walk(source):
                    for name in filenames:
                        full = os.path.join(dirpath, name)
                        arcname = os.path.join(os.path.basename(source), os.path.relpath(full, source))
                        zf.write(full, arcname)
            else:
                zf.write(source, os.path.basename(source))
    except OSError as exc:
        return {"success": False, "message": f"Couldn't add to archive: {exc}"}

    return {"success": True, "message": f"Added '{source}' to {archive_path}"}


def test_archive(arg: str) -> dict:
    """Verifies archive integrity without extracting anything to disk."""
    path = _resolve(arg)
    if not os.path.isfile(path):
        return {"success": False, "message": f"Not a file: {path}"}
    try:
        if _is_tar(path):
            with tarfile.open(path, "r:*") as tf:
                tf.getmembers()  # raises on corruption
        elif zipfile.is_zipfile(path):
            with zipfile.ZipFile(path, "r") as zf:
                bad = zf.testzip()
                if bad:
                    return {"success": True, "message": f"Archive is corrupted -- bad entry: {bad}"}
        else:
            return {"success": False, "message": f"'{path}' isn't a recognized zip/tar archive."}
    except (OSError, tarfile.TarError, zipfile.BadZipFile) as exc:
        return {"success": True, "message": f"Archive is corrupted or unreadable: {exc}"}

    return {"success": True, "message": "Archive is valid."}



# ==========================================================================
# originally troy/tools/process.py
# ==========================================================================
_PROTECTED_NAMES = {
    "system", "system idle process", "registry", "smss.exe", "csrss.exe",
    "wininit.exe", "winlogon.exe", "services.exe", "lsass.exe", "explorer.exe",
    "svchost.exe", "dwm.exe", "fontdrvhost.exe", "sihost.exe", "taskhostw.exe",
    "ctfmon.exe", "python.exe", "pythonw.exe",
}


def list_processes(limit: int = 15) -> dict:
    try:
        import psutil
    except ImportError:
        return {
            "success": False,
            "message": "Process info isn't available -- the 'psutil' package isn't installed (pip install psutil).",
        }

    procs = []
    for p in psutil.process_iter(["pid", "name", "memory_percent"]):
        try:
            info = p.info
            procs.append((info.get("name") or "?", info.get("pid"), info.get("memory_percent") or 0.0))
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            continue

    procs.sort(key=lambda t: t[2], reverse=True)
    top = procs[:limit]
    lines = [f"{name} (pid {pid}, {mem:.1f}% mem)" for name, pid, mem in top]
    return {"success": True, "message": f"Top {len(top)} processes by memory: " + ", ".join(lines)}


def kill_process(name: str) -> dict:
    name = (name or "").strip()
    if not name:
        return {"success": False, "message": "kill_process needs a process name, e.g. 'notepad.exe'."}

    if name.lower() in _PROTECTED_NAMES:
        return {
            "success": False,
            "message": f"Refusing to kill '{name}' -- it's a protected system/host process.",
        }

    try:
        import psutil
    except ImportError:
        return {
            "success": False,
            "message": "Process control isn't available -- the 'psutil' package isn't installed (pip install psutil).",
        }

    matched = []
    for p in psutil.process_iter(["pid", "name"]):
        try:
            if (p.info.get("name") or "").lower() == name.lower():
                matched.append(p)
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            continue

    if not matched:
        return {"success": False, "message": f"No running process named '{name}' was found."}

    killed = 0
    for p in matched:
        try:
            p.terminate()
            killed += 1
        except (psutil.NoSuchProcess, psutil.AccessDenied) as exc:
            return {"success": killed > 0, "message": f"Killed {killed}/{len(matched)} instance(s) of '{name}'; stopped early: {exc}"}

    return {"success": True, "message": f"Terminated {killed} instance(s) of '{name}'."}


# ---------- process introspection & control ----------

def find_process(arg: str) -> dict:
    """arg = substring to match against process names (case-insensitive).
    Unlike is_process_running, returns every match with its pid, useful
    when several instances of the same program might be running."""
    query = (arg or "").strip().lower()
    if not query:
        return {"success": False, "message": "find_process needs a name (or partial name) to search for."}
    try:
        import psutil
    except ImportError:
        return {"success": False, "message": "psutil isn't installed."}

    hits = []
    for p in psutil.process_iter(["pid", "name"]):
        try:
            name = p.info.get("name") or ""
            if query in name.lower():
                hits.append(f"{name} (pid {p.info.get('pid')})")
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            continue
    if not hits:
        return {"success": True, "message": f"No process matching '{query}' found."}
    return {"success": True, "message": f"{len(hits)} match(es): " + ", ".join(hits[:25])}


def is_process_running(arg: str) -> dict:
    name = (arg or "").strip().lower()
    if not name:
        return {"success": False, "message": "is_process_running needs a process name."}
    try:
        import psutil
    except ImportError:
        return {"success": False, "message": "psutil isn't installed."}
    for p in psutil.process_iter(["name"]):
        try:
            if (p.info.get("name") or "").lower() == name:
                return {"success": True, "message": f"'{name}' is running."}
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            continue
    return {"success": True, "message": f"'{name}' is not running."}


def _find_pid(name_or_pid: str):
    import psutil
    name_or_pid = name_or_pid.strip()
    if name_or_pid.isdigit():
        try:
            return psutil.Process(int(name_or_pid))
        except psutil.NoSuchProcess:
            return None
    for p in psutil.process_iter(["name"]):
        try:
            if (p.info.get("name") or "").lower() == name_or_pid.lower():
                return p
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            continue
    return None


def get_process_info(arg: str) -> dict:
    """arg = process name or pid."""
    try:
        import psutil
    except ImportError:
        return {"success": False, "message": "psutil isn't installed."}
    p = _find_pid(arg)
    if p is None:
        return {"success": False, "message": f"No process matching '{arg}' found."}
    try:
        with p.oneshot():
            return {
                "success": True,
                "message": (
                    f"{p.name()} (pid {p.pid}): {p.cpu_percent(interval=0.1):.1f}% CPU, "
                    f"{p.memory_percent():.1f}% mem, status={p.status()}"
                ),
            }
    except (psutil.NoSuchProcess, psutil.AccessDenied) as exc:
        return {"success": False, "message": f"Couldn't read process info: {exc}"}


def get_process_cpu(arg: str) -> dict:
    try:
        import psutil
    except ImportError:
        return {"success": False, "message": "psutil isn't installed."}
    p = _find_pid(arg)
    if p is None:
        return {"success": False, "message": f"No process matching '{arg}' found."}
    try:
        return {"success": True, "message": f"{p.name()} (pid {p.pid}): {p.cpu_percent(interval=0.2):.1f}% CPU"}
    except (psutil.NoSuchProcess, psutil.AccessDenied) as exc:
        return {"success": False, "message": f"Couldn't read CPU usage: {exc}"}


def get_process_memory(arg: str) -> dict:
    try:
        import psutil
    except ImportError:
        return {"success": False, "message": "psutil isn't installed."}
    p = _find_pid(arg)
    if p is None:
        return {"success": False, "message": f"No process matching '{arg}' found."}
    try:
        mem = p.memory_info()
        return {"success": True, "message": f"{p.name()} (pid {p.pid}): {mem.rss / 1024**2:.1f} MB RSS, {p.memory_percent():.1f}% of system RAM"}
    except (psutil.NoSuchProcess, psutil.AccessDenied) as exc:
        return {"success": False, "message": f"Couldn't read memory usage: {exc}"}


def get_process_path(arg: str) -> dict:
    try:
        import psutil
    except ImportError:
        return {"success": False, "message": "psutil isn't installed."}
    p = _find_pid(arg)
    if p is None:
        return {"success": False, "message": f"No process matching '{arg}' found."}
    try:
        return {"success": True, "message": p.exe()}
    except (psutil.NoSuchProcess, psutil.AccessDenied) as exc:
        return {"success": False, "message": f"Couldn't read process path: {exc}"}


def get_process_command_line(arg: str) -> dict:
    try:
        import psutil
    except ImportError:
        return {"success": False, "message": "psutil isn't installed."}
    p = _find_pid(arg)
    if p is None:
        return {"success": False, "message": f"No process matching '{arg}' found."}
    try:
        return {"success": True, "message": " ".join(p.cmdline())}
    except (psutil.NoSuchProcess, psutil.AccessDenied) as exc:
        return {"success": False, "message": f"Couldn't read command line: {exc}"}


def start_process(arg: str) -> dict:
    """arg = an executable name/path, with optional space-separated
    arguments, e.g. 'notepad.exe C:\\notes.txt'. For opening ordinary
    installed applications by common name, open_app is usually a better
    fit -- this is for launching a specific executable path directly."""
    arg = (arg or "").strip()
    if not arg:
        return {"success": False, "message": "start_process needs a command to run."}
    try:
        subprocess.Popen(arg, shell=True)  # noqa: S602 - user-directed launch, same trust level as open_app
    except OSError as exc:
        return {"success": False, "message": f"Couldn't start '{arg}': {exc}"}
    return {"success": True, "message": f"Started: {arg}"}


def open_app_with_arguments(arg: str) -> dict:
    """arg format: 'executable|arguments'. Same underlying mechanism as
    start_process, split into two fields for clarity when arguments
    contain characters that could be ambiguous packed into one string."""
    if "|" in arg:
        exe, args = (part.strip() for part in arg.split("|", 1))
    else:
        exe, args = arg.strip(), ""
    if not exe:
        return {"success": False, "message": "open_app_with_arguments needs an executable."}
    return start_process(f"{exe} {args}".strip())


def open_file_with_app(arg: str) -> dict:
    """arg format: 'app|file_path'."""
    if "|" not in arg:
        return {"success": False, "message": "open_file_with_app needs 'app|file_path'."}
    app, path = (part.strip() for part in arg.split("|", 1))
    if not app or not path:
        return {"success": False, "message": "open_file_with_app needs both an app and a file path."}
    return start_process(f'{app} "{path}"')


def restart_process(arg: str) -> dict:
    """Kills every instance of the named process, then relaunches it once
    via start_process. arg = process name (e.g. 'notepad.exe')."""
    kill_result = kill_process(arg)
    if not kill_result.get("success"):
        return kill_result
    start_result = start_process(arg)
    return {
        "success": start_result.get("success", False),
        "message": f"{kill_result['message']} Then: {start_result['message']}",
    }


def wait_for_process(arg: str) -> dict:
    """arg format: 'process_name|timeout_seconds' (timeout defaults to 20).
    Polls rather than blocking indefinitely -- returns as soon as the
    process appears, or after the timeout, whichever comes first."""
    if "|" in arg:
        name, timeout_str = (part.strip() for part in arg.split("|", 1))
        try:
            timeout = max(1, min(120, float(timeout_str)))
        except ValueError:
            timeout = 20.0
    else:
        name, timeout = arg.strip(), 20.0
    if not name:
        return {"success": False, "message": "wait_for_process needs a process name."}

    try:
        import psutil
    except ImportError:
        return {"success": False, "message": "psutil isn't installed."}

    deadline = time.time() + timeout
    while time.time() < deadline:
        for p in psutil.process_iter(["name"]):
            try:
                if (p.info.get("name") or "").lower() == name.lower():
                    return {"success": True, "message": f"'{name}' appeared after {time.time() - (deadline - timeout):.1f}s."}
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                continue
        time.sleep(0.5)
    return {"success": False, "message": f"'{name}' did not appear within {timeout:.0f}s."}


def wait_for_process_exit(arg: str) -> dict:
    """arg format: 'process_name|timeout_seconds' (timeout defaults to 30)."""
    if "|" in arg:
        name, timeout_str = (part.strip() for part in arg.split("|", 1))
        try:
            timeout = max(1, min(180, float(timeout_str)))
        except ValueError:
            timeout = 30.0
    else:
        name, timeout = arg.strip(), 30.0
    if not name:
        return {"success": False, "message": "wait_for_process_exit needs a process name."}

    try:
        import psutil
    except ImportError:
        return {"success": False, "message": "psutil isn't installed."}

    deadline = time.time() + timeout
    while time.time() < deadline:
        still_running = any(
            (p.info.get("name") or "").lower() == name.lower()
            for p in psutil.process_iter(["name"])
        )
        if not still_running:
            return {"success": True, "message": f"'{name}' has exited."}
        time.sleep(0.5)
    return {"success": False, "message": f"'{name}' was still running after {timeout:.0f}s."}



# ==========================================================================
# originally troy/tools/windows_system.py
# ==========================================================================
def _run(cmd: list, timeout: int = 10):
    return subprocess.run(cmd, capture_output=True, text=True, timeout=timeout, check=False)


# ---------- power actions (all destructive-ish -> gated by requires_confirmation in the registry) ----------

def lock_workstation(_arg: str = "") -> dict:
    """Not confirmation-gated -- locking is instantly reversible with a
    password and is the same as walking away from the PC."""
    if sys.platform != "win32":
        return {"success": False, "message": "lock_workstation is Windows-only."}
    try:
        import ctypes
        ctypes.windll.user32.LockWorkStation()
    except Exception as exc:  # noqa: BLE001
        return {"success": False, "message": f"Couldn't lock the workstation: {exc}"}
    return {"success": True, "message": "Workstation locked."}


def sleep_computer(_arg: str = "") -> dict:
    if sys.platform != "win32":
        return {"success": False, "message": "sleep_computer is Windows-only."}
    try:
        subprocess.run(
            ["rundll32.exe", "powrprof.dll,SetSuspendState", "0", "1", "0"],
            timeout=5, check=False,
        )
    except OSError as exc:
        return {"success": False, "message": f"Couldn't sleep the computer: {exc}"}
    return {"success": True, "message": "Sleep requested."}


def shutdown_computer(arg: str) -> dict:
    """arg (after confirmation): optional delay in seconds, defaults to 30
    so there's a window to cancel_shutdown if this was a mistake."""
    if sys.platform != "win32":
        return {"success": False, "message": "shutdown_computer is Windows-only."}
    try:
        delay = max(0, int(arg.strip())) if arg.strip() else 30
    except ValueError:
        delay = 30
    try:
        _run(["shutdown", "/s", "/t", str(delay)])
    except (OSError, subprocess.SubprocessError) as exc:
        return {"success": False, "message": f"Couldn't schedule shutdown: {exc}"}
    return {"success": True, "message": f"Shutdown scheduled in {delay}s. Use cancel_shutdown to abort."}


def restart_computer(arg: str) -> dict:
    if sys.platform != "win32":
        return {"success": False, "message": "restart_computer is Windows-only."}
    try:
        delay = max(0, int(arg.strip())) if arg.strip() else 30
    except ValueError:
        delay = 30
    try:
        _run(["shutdown", "/r", "/t", str(delay)])
    except (OSError, subprocess.SubprocessError) as exc:
        return {"success": False, "message": f"Couldn't schedule restart: {exc}"}
    return {"success": True, "message": f"Restart scheduled in {delay}s. Use cancel_shutdown to abort."}


def cancel_shutdown(_arg: str = "") -> dict:
    """Not confirmation-gated -- cancelling is the safe direction."""
    if sys.platform != "win32":
        return {"success": False, "message": "cancel_shutdown is Windows-only."}
    try:
        result = _run(["shutdown", "/a"])
    except (OSError, subprocess.SubprocessError) as exc:
        return {"success": False, "message": f"Couldn't cancel shutdown: {exc}"}
    if result.returncode != 0:
        return {"success": True, "message": "No pending shutdown/restart to cancel."}
    return {"success": True, "message": "Pending shutdown/restart cancelled."}


def empty_recycle_bin(_arg: str = "") -> dict:
    if sys.platform != "win32":
        return {"success": False, "message": "empty_recycle_bin is Windows-only."}
    try:
        result = _run(
            ["powershell.exe", "-NoProfile", "-Command", "Clear-RecycleBin -Force -ErrorAction Stop"],
            timeout=30,
        )
    except (OSError, subprocess.SubprocessError) as exc:
        return {"success": False, "message": f"Couldn't empty the Recycle Bin: {exc}"}
    if result.returncode != 0:
        return {"success": False, "message": f"Recycle Bin command failed: {result.stderr.strip()}"}
    return {"success": True, "message": "Recycle Bin emptied."}


# ---------- hardware / OS facts (all read-only, no confirmation needed) ----------

def get_battery_info(_arg: str = "") -> dict:
    try:
        import psutil
    except ImportError:
        return {"success": False, "message": "psutil isn't installed."}
    battery = psutil.sensors_battery()
    if battery is None:
        return {"success": True, "message": "No battery detected (likely a desktop)."}
    state = "charging" if battery.power_plugged else "on battery"
    return {"success": True, "message": f"Battery {battery.percent:.0f}% ({state})."}


def get_cpu_info(_arg: str = "") -> dict:
    try:
        import psutil
    except ImportError:
        return {"success": False, "message": "psutil isn't installed."}
    name = platform.processor() or "Unknown CPU"
    physical = psutil.cpu_count(logical=False) or "?"
    logical = psutil.cpu_count(logical=True) or "?"
    freq = psutil.cpu_freq()
    freq_str = f", {freq.current:.0f} MHz" if freq else ""
    return {"success": True, "message": f"{name} -- {physical} physical / {logical} logical cores{freq_str}."}


def get_memory_info(_arg: str = "") -> dict:
    try:
        import psutil
    except ImportError:
        return {"success": False, "message": "psutil isn't installed."}
    mem = psutil.virtual_memory()
    return {
        "success": True,
        "message": f"RAM: {mem.used / 1024**3:.1f}/{mem.total / 1024**3:.1f} GB used ({mem.percent:.0f}%).",
    }


def get_disk_info(_arg: str = "") -> dict:
    try:
        import psutil
    except ImportError:
        return {"success": False, "message": "psutil isn't installed."}
    lines = []
    for part in psutil.disk_partitions(all=False):
        try:
            usage = psutil.disk_usage(part.mountpoint)
        except OSError:
            continue
        lines.append(f"{part.device} {usage.used / 1024**3:.0f}/{usage.total / 1024**3:.0f} GB ({usage.percent:.0f}%)")
    if not lines:
        return {"success": True, "message": "No disk partitions found."}
    return {"success": True, "message": " | ".join(lines)}


def get_network_info(_arg: str = "") -> dict:
    hostname = socket.gethostname()
    try:
        local_ip = socket.gethostbyname(hostname)
    except OSError:
        local_ip = "unknown"
    return {"success": True, "message": f"Hostname: {hostname}, local IP: {local_ip}."}


def get_ip_address(_arg: str = "") -> dict:
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.settimeout(2)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
    except OSError:
        try:
            ip = socket.gethostbyname(socket.gethostname())
        except OSError:
            return {"success": False, "message": "Couldn't determine a local IP address."}
    return {"success": True, "message": f"Local IP address: {ip}"}


def get_hostname(_arg: str = "") -> dict:
    return {"success": True, "message": socket.gethostname()}


def get_username(_arg: str = "") -> dict:
    return {"success": True, "message": os.environ.get("USERNAME") or os.environ.get("USER") or "unknown"}


def get_windows_version(_arg: str = "") -> dict:
    return {"success": True, "message": f"{platform.system()} {platform.release()} (build {platform.version()})"}


def get_uptime(_arg: str = "") -> dict:
    try:
        import psutil
        import time as _time
        seconds = int(_time.time() - psutil.boot_time())
    except ImportError:
        return {"success": False, "message": "psutil isn't installed."}
    hours, remainder = divmod(seconds, 3600)
    minutes, _ = divmod(remainder, 60)
    return {"success": True, "message": f"Uptime: {hours}h {minutes}m."}


def get_environment_variable(arg: str) -> dict:
    name = (arg or "").strip()
    if not name:
        return {"success": False, "message": "get_environment_variable needs a variable name."}
    value = os.environ.get(name)
    if value is None:
        return {"success": True, "message": f"'{name}' is not set."}
    return {"success": True, "message": f"{name}={value}"}


def set_environment_variable(arg: str) -> dict:
    """arg (after confirmation): 'NAME|value'. Sets it for the current
    process only (and, on Windows, persists it for the user account via
    setx) -- does not touch system-wide/machine-level variables."""
    if "|" not in arg:
        return {"success": False, "message": "set_environment_variable needs 'NAME|value'."}
    name, value = (part.strip() for part in arg.split("|", 1))
    if not name:
        return {"success": False, "message": "set_environment_variable needs a non-empty variable name."}

    os.environ[name] = value
    if sys.platform == "win32":
        try:
            _run(["setx", name, value])
        except (OSError, subprocess.SubprocessError) as exc:
            return {"success": True, "message": f"Set for this session only -- persisting failed: {exc}"}
    return {"success": True, "message": f"Set {name}={value}."}


# ---------- well-known folders ----------

def get_desktop_path(_arg: str = "") -> dict:
    return {"success": True, "message": os.path.join(os.path.expanduser("~"), "Desktop")}


def get_downloads_path(_arg: str = "") -> dict:
    return {"success": True, "message": os.path.join(os.path.expanduser("~"), "Downloads")}


def get_documents_path(_arg: str = "") -> dict:
    return {"success": True, "message": os.path.join(os.path.expanduser("~"), "Documents")}


def get_pictures_path(_arg: str = "") -> dict:
    return {"success": True, "message": os.path.join(os.path.expanduser("~"), "Pictures")}


def get_music_path(_arg: str = "") -> dict:
    return {"success": True, "message": os.path.join(os.path.expanduser("~"), "Music")}


def get_videos_path(_arg: str = "") -> dict:
    return {"success": True, "message": os.path.join(os.path.expanduser("~"), "Videos")}


def open_windows_settings(_arg: str = "") -> dict:
    if sys.platform != "win32":
        return {"success": False, "message": "open_windows_settings is Windows-only."}
    try:
        os.startfile("ms-settings:")  # noqa: S606
    except OSError as exc:
        return {"success": False, "message": f"Couldn't open Settings: {exc}"}
    return {"success": True, "message": "Opened Windows Settings."}


def open_control_panel(_arg: str = "") -> dict:
    if sys.platform != "win32":
        return {"success": False, "message": "open_control_panel is Windows-only."}
    try:
        subprocess.run(["control"], check=False)
    except OSError as exc:
        return {"success": False, "message": f"Couldn't open Control Panel: {exc}"}
    return {"success": True, "message": "Opened Control Panel."}



# ==========================================================================
# originally troy/tools/network.py
# ==========================================================================
_DEFAULT_TIMEOUT = 6
_MAX_DOWNLOAD_BYTES = 200 * 1024 * 1024  # 200 MB safety cap


def ping_host(arg: str) -> dict:
    host = (arg or "").strip()
    if not host:
        return {"success": False, "message": "ping_host needs a hostname or IP."}
    count_flag = "-n" if sys.platform == "win32" else "-c"
    try:
        result = subprocess.run(
            ["ping", count_flag, "3", host], capture_output=True, text=True, timeout=10, check=False,
        )
    except (OSError, subprocess.SubprocessError) as exc:
        return {"success": False, "message": f"Couldn't run ping: {exc}"}
    ok = result.returncode == 0
    tail = "\n".join(result.stdout.strip().splitlines()[-4:])
    return {"success": ok, "message": tail or ("Host unreachable." if not ok else "Ping succeeded.")}


def dns_lookup(arg: str) -> dict:
    host = (arg or "").strip()
    if not host:
        return {"success": False, "message": "dns_lookup needs a hostname."}
    try:
        ip = socket.gethostbyname(host)
    except OSError as exc:
        return {"success": False, "message": f"Couldn't resolve '{host}': {exc}"}
    return {"success": True, "message": f"{host} -> {ip}"}


def resolve_hostname(arg: str) -> dict:
    return dns_lookup(arg)


def check_port(arg: str) -> dict:
    """arg format: 'host|port'."""
    if "|" not in arg:
        return {"success": False, "message": "check_port needs 'host|port'."}
    host, port_str = (part.strip() for part in arg.split("|", 1))
    try:
        port = int(port_str)
    except ValueError:
        return {"success": False, "message": "check_port's port must be an integer."}

    try:
        with socket.create_connection((host, port), timeout=_DEFAULT_TIMEOUT):
            return {"success": True, "message": f"{host}:{port} is open."}
    except OSError as exc:
        return {"success": True, "message": f"{host}:{port} is not reachable ({exc})."}


def get_local_ip(_arg: str = "") -> dict:
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.settimeout(2)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
    except OSError:
        return {"success": False, "message": "Couldn't determine a local IP address."}
    return {"success": True, "message": ip}


def get_public_ip(_arg: str = "") -> dict:
    try:
        resp = requests.get("https://api.ipify.org", timeout=_DEFAULT_TIMEOUT)
        resp.raise_for_status()
    except requests.RequestException as exc:
        return {"success": False, "message": f"Couldn't determine the public IP: {exc}"}
    return {"success": True, "message": resp.text.strip()}


def get_network_adapters(_arg: str = "") -> dict:
    try:
        import psutil
    except ImportError:
        return {"success": False, "message": "psutil isn't installed."}
    addrs = psutil.net_if_addrs()
    lines = []
    for name, entries in addrs.items():
        ipv4 = next((e.address for e in entries if e.family == socket.AF_INET), None)
        if ipv4:
            lines.append(f"{name}: {ipv4}")
    if not lines:
        return {"success": True, "message": "No active network adapters found."}
    return {"success": True, "message": ", ".join(lines)}


def get_wifi_info(_arg: str = "") -> dict:
    if sys.platform != "win32":
        return {"success": False, "message": "get_wifi_info is Windows-only."}
    try:
        result = subprocess.run(
            ["netsh", "wlan", "show", "interfaces"], capture_output=True, text=True, timeout=8, check=False,
        )
    except (OSError, subprocess.SubprocessError) as exc:
        return {"success": False, "message": f"Couldn't query Wi-Fi info: {exc}"}
    if result.returncode != 0 or not result.stdout.strip():
        return {"success": True, "message": "No Wi-Fi adapter or not connected."}
    lines = [l.strip() for l in result.stdout.splitlines() if any(k in l for k in ("SSID", "Signal", "State"))]
    return {"success": True, "message": " | ".join(lines[:6]) if lines else "No Wi-Fi details available."}


def get_wifi_networks(_arg: str = "") -> dict:
    if sys.platform != "win32":
        return {"success": False, "message": "get_wifi_networks is Windows-only."}
    try:
        result = subprocess.run(
            ["netsh", "wlan", "show", "networks"], capture_output=True, text=True, timeout=8, check=False,
        )
    except (OSError, subprocess.SubprocessError) as exc:
        return {"success": False, "message": f"Couldn't scan Wi-Fi networks: {exc}"}
    ssids = [l.split(":", 1)[1].strip() for l in result.stdout.splitlines() if l.strip().startswith("SSID")]
    if not ssids:
        return {"success": True, "message": "No Wi-Fi networks found."}
    return {"success": True, "message": ", ".join(ssids[:25])}


def check_internet_connection(_arg: str = "") -> dict:
    try:
        socket.create_connection(("8.8.8.8", 53), timeout=4)
        return {"success": True, "message": "Internet connection is up."}
    except OSError:
        return {"success": True, "message": "No internet connection detected."}


def get_url_status(arg: str) -> dict:
    url = (arg or "").strip()
    if not url:
        return {"success": False, "message": "get_url_status needs a URL."}
    try:
        resp = requests.head(url, timeout=_DEFAULT_TIMEOUT, allow_redirects=True)
    except requests.RequestException as exc:
        return {"success": False, "message": f"Couldn't reach '{url}': {exc}"}
    return {"success": True, "message": f"{url} -> HTTP {resp.status_code}"}


def get_url_headers(arg: str) -> dict:
    url = (arg or "").strip()
    if not url:
        return {"success": False, "message": "get_url_headers needs a URL."}
    try:
        resp = requests.head(url, timeout=_DEFAULT_TIMEOUT, allow_redirects=True)
    except requests.RequestException as exc:
        return {"success": False, "message": f"Couldn't reach '{url}': {exc}"}
    headers = "; ".join(f"{k}: {v}" for k, v in list(resp.headers.items())[:15])
    return {"success": True, "message": headers or "(no headers returned)"}


def fetch_url(arg: str) -> dict:
    """Fetches a URL's body as text, capped so a huge page doesn't flood
    the model's context. For anything more than reading plain text/HTML,
    the browser tools are the right choice instead."""
    url = (arg or "").strip()
    if not url:
        return {"success": False, "message": "fetch_url needs a URL."}
    try:
        resp = requests.get(url, timeout=_DEFAULT_TIMEOUT)
        resp.raise_for_status()
    except requests.RequestException as exc:
        return {"success": False, "message": f"Couldn't fetch '{url}': {exc}"}
    text = resp.text[:3000]
    suffix = " (truncated)" if len(resp.text) > 3000 else ""
    return {"success": True, "message": text + suffix}


def download_file(arg: str) -> dict:
    """arg format: 'url|destination_path'. Streams to disk with a hard
    byte cap (200 MB) rather than loading the whole response into memory
    first, and refuses to overwrite an existing file, same policy as the
    other file-writing tools."""
    if "|" not in arg:
        return {"success": False, "message": "download_file needs 'url|destination_path'."}
    url, dest = (part.strip() for part in arg.split("|", 1))
    if not url or not dest:
        return {"success": False, "message": "download_file needs both a URL and a destination path."}

    import os
    dest = os.path.abspath(os.path.expanduser(os.path.expandvars(dest)))
    if os.path.exists(dest):
        return {"success": False, "message": f"'{dest}' already exists -- not overwriting."}

    try:
        with requests.get(url, timeout=15, stream=True) as resp:
            resp.raise_for_status()
            os.makedirs(os.path.dirname(dest), exist_ok=True)
            written = 0
            with open(dest, "wb") as f:
                for chunk in resp.iter_content(chunk_size=64 * 1024):
                    written += len(chunk)
                    if written > _MAX_DOWNLOAD_BYTES:
                        f.close()
                        os.remove(dest)
                        return {"success": False, "message": f"Download exceeded the {_MAX_DOWNLOAD_BYTES // 1024**2} MB safety cap and was aborted."}
                    f.write(chunk)
    except requests.RequestException as exc:
        return {"success": False, "message": f"Couldn't download '{url}': {exc}"}
    except OSError as exc:
        return {"success": False, "message": f"Couldn't save to '{dest}': {exc}"}

    return {"success": True, "message": f"Downloaded {written / 1024:.0f} KB to {dest}"}



# ==========================================================================
# originally troy/tools/data_tools.py
# ==========================================================================
def read_json(arg: str) -> dict:
    path = _resolve(arg)
    if not os.path.isfile(path):
        return {"success": False, "message": f"Not a file: {path}"}
    try:
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
    except (OSError, json.JSONDecodeError) as exc:
        return {"success": False, "message": f"Couldn't read JSON from '{path}': {exc}"}
    text = json.dumps(data, indent=2, ensure_ascii=False)
    truncated = text[:3000]
    suffix = " (truncated)" if len(text) > 3000 else ""
    return {"success": True, "message": truncated + suffix}


def write_json(arg: str) -> dict:
    """arg format: 'path|json_text'. Refuses to overwrite an existing
    file, same not-silently-clobbering policy as files.create_file."""
    if "|" not in arg:
        return {"success": False, "message": "write_json needs 'path|json_text'."}
    path, json_text = arg.split("|", 1)
    path = _resolve(path)
    if os.path.exists(path):
        return {"success": False, "message": f"'{path}' already exists -- not overwriting."}
    try:
        data = json.loads(json_text)
    except json.JSONDecodeError as exc:
        return {"success": False, "message": f"Invalid JSON: {exc}"}
    try:
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with open(path, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
    except OSError as exc:
        return {"success": False, "message": f"Couldn't write '{path}': {exc}"}
    return {"success": True, "message": f"Wrote JSON to {path}"}


def validate_json(arg: str) -> dict:
    """arg = raw JSON text (not a path) -- validates without touching disk."""
    try:
        json.loads(arg)
    except json.JSONDecodeError as exc:
        return {"success": True, "message": f"Invalid JSON: {exc}"}
    return {"success": True, "message": "Valid JSON."}


def query_json(arg: str) -> dict:
    """arg format: 'path|dotted.path' e.g. 'config.json|server.port'. Dict
    keys and list indices both work in the dotted path (e.g. 'items.0.name')."""
    if "|" not in arg:
        return {"success": False, "message": "query_json needs 'path|dotted.path'."}
    path, query = (part.strip() for part in arg.split("|", 1))
    path = _resolve(path)
    if not os.path.isfile(path):
        return {"success": False, "message": f"Not a file: {path}"}
    try:
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
    except (OSError, json.JSONDecodeError) as exc:
        return {"success": False, "message": f"Couldn't read JSON from '{path}': {exc}"}

    current = data
    for key in query.split("."):
        if isinstance(current, list):
            try:
                current = current[int(key)]
            except (ValueError, IndexError):
                return {"success": False, "message": f"'{query}' not found (list index '{key}' invalid)."}
        elif isinstance(current, dict):
            if key not in current:
                return {"success": False, "message": f"'{query}' not found (no key '{key}')."}
            current = current[key]
        else:
            return {"success": False, "message": f"'{query}' not found (reached a non-container value early)."}

    text = json.dumps(current, indent=2, ensure_ascii=False) if isinstance(current, (dict, list)) else str(current)
    return {"success": True, "message": text[:2000]}


def merge_json(arg: str) -> dict:
    """arg format: 'path_a|path_b|output_path'. Shallow-merges path_b's
    top-level keys into path_a's, with path_b winning conflicts, and
    writes the result to output_path (which must not already exist)."""
    parts = [p.strip() for p in arg.split("|")]
    if len(parts) != 3:
        return {"success": False, "message": "merge_json needs 'path_a|path_b|output_path'."}
    path_a, path_b, out_path = (_resolve(p) for p in parts)

    for p in (path_a, path_b):
        if not os.path.isfile(p):
            return {"success": False, "message": f"Not a file: {p}"}
    if os.path.exists(out_path):
        return {"success": False, "message": f"'{out_path}' already exists -- not overwriting."}

    try:
        with open(path_a, "r", encoding="utf-8") as f:
            data_a = json.load(f)
        with open(path_b, "r", encoding="utf-8") as f:
            data_b = json.load(f)
    except (OSError, json.JSONDecodeError) as exc:
        return {"success": False, "message": f"Couldn't read input JSON: {exc}"}

    if not isinstance(data_a, dict) or not isinstance(data_b, dict):
        return {"success": False, "message": "merge_json only supports merging two JSON objects (dicts)."}

    merged = {**data_a, **data_b}
    try:
        os.makedirs(os.path.dirname(out_path), exist_ok=True)
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(merged, f, indent=2, ensure_ascii=False)
    except OSError as exc:
        return {"success": False, "message": f"Couldn't write '{out_path}': {exc}"}
    return {"success": True, "message": f"Merged into {out_path}"}


def read_csv(arg: str) -> dict:
    """arg format: 'path' or 'path|max_rows' (default 20)."""
    if "|" in arg:
        path, rows_str = (part.strip() for part in arg.split("|", 1))
        try:
            max_rows = max(1, min(200, int(rows_str)))
        except ValueError:
            max_rows = 20
    else:
        path, max_rows = arg.strip(), 20

    path = _resolve(path)
    if not os.path.isfile(path):
        return {"success": False, "message": f"Not a file: {path}"}
    try:
        with open(path, "r", encoding="utf-8", errors="replace", newline="") as f:
            reader = csv.reader(f)
            rows = []
            for i, row in enumerate(reader):
                if i > max_rows:
                    break
                rows.append(row)
    except OSError as exc:
        return {"success": False, "message": f"Couldn't read '{path}': {exc}"}

    if not rows:
        return {"success": True, "message": f"{path} is empty."}
    header = rows[0]
    body = rows[1:max_rows + 1]
    lines = [", ".join(header)] + [", ".join(r) for r in body]
    suffix = " (truncated)" if len(rows) > max_rows + 1 else ""
    return {"success": True, "message": "\n".join(lines) + suffix}


def write_csv(arg: str) -> dict:
    """arg format: 'path|row1col1,row1col2;row2col1,row2col2;...'. Rows
    separated by ';', columns by ','. Refuses to overwrite an existing
    file. For anything with commas inside field values, build the file
    with create_file instead -- this format is intentionally simple."""
    if "|" not in arg:
        return {"success": False, "message": "write_csv needs 'path|rows'."}
    path, rows_text = arg.split("|", 1)
    path = _resolve(path)
    if os.path.exists(path):
        return {"success": False, "message": f"'{path}' already exists -- not overwriting."}

    rows = [row.split(",") for row in rows_text.split(";") if row.strip()]
    if not rows:
        return {"success": False, "message": "No rows to write."}

    try:
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with open(path, "w", encoding="utf-8", newline="") as f:
            writer = csv.writer(f)
            writer.writerows(rows)
    except OSError as exc:
        return {"success": False, "message": f"Couldn't write '{path}': {exc}"}
    return {"success": True, "message": f"Wrote {len(rows)} row(s) to {path}"}


def search_csv(arg: str) -> dict:
    """arg format: 'path|query'. Returns rows (with header) where any cell
    contains the query substring, case-insensitively."""
    if "|" not in arg:
        return {"success": False, "message": "search_csv needs 'path|query'."}
    path, query = (part.strip() for part in arg.split("|", 1))
    path = _resolve(path)
    if not os.path.isfile(path):
        return {"success": False, "message": f"Not a file: {path}"}
    if not query:
        return {"success": False, "message": "search_csv needs a non-empty query."}

    query_lower = query.lower()
    try:
        with open(path, "r", encoding="utf-8", errors="replace", newline="") as f:
            reader = csv.reader(f)
            rows = list(reader)
    except OSError as exc:
        return {"success": False, "message": f"Couldn't read '{path}': {exc}"}

    if not rows:
        return {"success": True, "message": f"{path} is empty."}
    header, body = rows[0], rows[1:]
    matches = [r for r in body if any(query_lower in cell.lower() for cell in r)]
    if not matches:
        return {"success": True, "message": f"No rows matching '{query}'."}
    lines = [", ".join(header)] + [", ".join(r) for r in matches[:30]]
    suffix = f" (+{len(matches) - 30} more)" if len(matches) > 30 else ""
    return {"success": True, "message": "\n".join(lines) + suffix}


def get_csv_stats(arg: str) -> dict:
    path = _resolve(arg)
    if not os.path.isfile(path):
        return {"success": False, "message": f"Not a file: {path}"}
    try:
        with open(path, "r", encoding="utf-8", errors="replace", newline="") as f:
            reader = csv.reader(f)
            rows = list(reader)
    except OSError as exc:
        return {"success": False, "message": f"Couldn't read '{path}': {exc}"}

    if not rows:
        return {"success": True, "message": f"{path} is empty."}
    header = rows[0]
    data_rows = rows[1:]
    return {
        "success": True,
        "message": f"{len(data_rows)} data row(s), {len(header)} column(s): {', '.join(header)}",
    }



# ==========================================================================
# originally troy/tools/image_tools.py
# ==========================================================================
def _pillow():
    try:
        from PIL import Image
        return Image
    except ImportError:
        return None


def get_image_info(arg: str) -> dict:
    Image = _pillow()
    if Image is None:
        return {"success": False, "message": "Image tools need the 'Pillow' package (pip install Pillow)."}
    path = _resolve(arg)
    if not os.path.isfile(path):
        return {"success": False, "message": f"Not a file: {path}"}
    try:
        with Image.open(path) as img:
            width, height = img.size
            mode, fmt = img.mode, img.format
    except OSError as exc:
        return {"success": False, "message": f"Couldn't read image '{path}': {exc}"}
    size_bytes = os.path.getsize(path)
    return {"success": True, "message": f"{path}: {width}x{height}, {mode}, {fmt}, {size_bytes / 1024:.0f} KB"}


def resize_image(arg: str) -> dict:
    """arg format: 'source|destination|width|height'."""
    Image = _pillow()
    if Image is None:
        return {"success": False, "message": "Image tools need the 'Pillow' package (pip install Pillow)."}
    parts = [p.strip() for p in arg.split("|")]
    if len(parts) != 4:
        return {"success": False, "message": "resize_image needs 'source|destination|width|height'."}
    src, dest, w_str, h_str = parts
    src, dest = _resolve(src), _resolve(dest)
    try:
        width, height = int(w_str), int(h_str)
    except ValueError:
        return {"success": False, "message": "resize_image's width/height must be integers."}
    if not os.path.isfile(src):
        return {"success": False, "message": f"Not a file: {src}"}
    if os.path.exists(dest):
        return {"success": False, "message": f"'{dest}' already exists -- not overwriting."}

    try:
        with Image.open(src) as img:
            resized = img.resize((width, height))
            os.makedirs(os.path.dirname(dest), exist_ok=True)
            resized.save(dest)
    except OSError as exc:
        return {"success": False, "message": f"Couldn't resize image: {exc}"}
    return {"success": True, "message": f"Resized to {width}x{height}: {dest}"}


def crop_image(arg: str) -> dict:
    """arg format: 'source|destination|left|top|right|bottom'."""
    Image = _pillow()
    if Image is None:
        return {"success": False, "message": "Image tools need the 'Pillow' package (pip install Pillow)."}
    parts = [p.strip() for p in arg.split("|")]
    if len(parts) != 6:
        return {"success": False, "message": "crop_image needs 'source|destination|left|top|right|bottom'."}
    src, dest, *box_parts = parts
    src, dest = _resolve(src), _resolve(dest)
    try:
        box = tuple(int(p) for p in box_parts)
    except ValueError:
        return {"success": False, "message": "crop_image's box coordinates must be integers."}
    if not os.path.isfile(src):
        return {"success": False, "message": f"Not a file: {src}"}
    if os.path.exists(dest):
        return {"success": False, "message": f"'{dest}' already exists -- not overwriting."}

    try:
        with Image.open(src) as img:
            cropped = img.crop(box)
            os.makedirs(os.path.dirname(dest), exist_ok=True)
            cropped.save(dest)
    except OSError as exc:
        return {"success": False, "message": f"Couldn't crop image: {exc}"}
    return {"success": True, "message": f"Cropped image saved: {dest}"}


def rotate_image(arg: str) -> dict:
    """arg format: 'source|destination|degrees'."""
    Image = _pillow()
    if Image is None:
        return {"success": False, "message": "Image tools need the 'Pillow' package (pip install Pillow)."}
    parts = [p.strip() for p in arg.split("|")]
    if len(parts) != 3:
        return {"success": False, "message": "rotate_image needs 'source|destination|degrees'."}
    src, dest, deg_str = parts
    src, dest = _resolve(src), _resolve(dest)
    try:
        degrees = float(deg_str)
    except ValueError:
        return {"success": False, "message": "rotate_image's degrees must be a number."}
    if not os.path.isfile(src):
        return {"success": False, "message": f"Not a file: {src}"}
    if os.path.exists(dest):
        return {"success": False, "message": f"'{dest}' already exists -- not overwriting."}

    try:
        with Image.open(src) as img:
            rotated = img.rotate(-degrees, expand=True)
            os.makedirs(os.path.dirname(dest), exist_ok=True)
            rotated.save(dest)
    except OSError as exc:
        return {"success": False, "message": f"Couldn't rotate image: {exc}"}
    return {"success": True, "message": f"Rotated image saved: {dest}"}


def convert_image(arg: str) -> dict:
    """arg format: 'source|destination'. Format is inferred from
    destination's extension (e.g. .png -> .jpg)."""
    Image = _pillow()
    if Image is None:
        return {"success": False, "message": "Image tools need the 'Pillow' package (pip install Pillow)."}
    if "|" not in arg:
        return {"success": False, "message": "convert_image needs 'source|destination'."}
    src, dest = (part.strip() for part in arg.split("|", 1))
    src, dest = _resolve(src), _resolve(dest)
    if not os.path.isfile(src):
        return {"success": False, "message": f"Not a file: {src}"}
    if os.path.exists(dest):
        return {"success": False, "message": f"'{dest}' already exists -- not overwriting."}

    try:
        with Image.open(src) as img:
            if img.mode in ("RGBA", "P") and dest.lower().endswith((".jpg", ".jpeg")):
                img = img.convert("RGB")
            os.makedirs(os.path.dirname(dest), exist_ok=True)
            img.save(dest)
    except OSError as exc:
        return {"success": False, "message": f"Couldn't convert image: {exc}"}
    return {"success": True, "message": f"Converted image saved: {dest}"}


def compress_image(arg: str) -> dict:
    """arg format: 'source|destination|quality' (quality 1-95, default 75).
    Applies to JPEG/WebP; lossless formats like PNG ignore quality and are
    re-saved with optimize=True instead."""
    Image = _pillow()
    if Image is None:
        return {"success": False, "message": "Image tools need the 'Pillow' package (pip install Pillow)."}
    parts = [p.strip() for p in arg.split("|")]
    if len(parts) not in (2, 3):
        return {"success": False, "message": "compress_image needs 'source|destination' or 'source|destination|quality'."}
    src, dest = parts[0], parts[1]
    quality = 75
    if len(parts) == 3:
        try:
            quality = max(1, min(95, int(parts[2])))
        except ValueError:
            pass
    src, dest = _resolve(src), _resolve(dest)
    if not os.path.isfile(src):
        return {"success": False, "message": f"Not a file: {src}"}
    if os.path.exists(dest):
        return {"success": False, "message": f"'{dest}' already exists -- not overwriting."}

    try:
        with Image.open(src) as img:
            os.makedirs(os.path.dirname(dest), exist_ok=True)
            if dest.lower().endswith((".jpg", ".jpeg", ".webp")):
                if img.mode in ("RGBA", "P"):
                    img = img.convert("RGB")
                img.save(dest, quality=quality, optimize=True)
            else:
                img.save(dest, optimize=True)
    except OSError as exc:
        return {"success": False, "message": f"Couldn't compress image: {exc}"}

    before = os.path.getsize(src)
    after = os.path.getsize(dest)
    return {"success": True, "message": f"Compressed {before / 1024:.0f} KB -> {after / 1024:.0f} KB: {dest}"}


def compare_images(arg: str) -> dict:
    """arg format: 'path_a|path_b'. Reports a rough visual difference
    percentage (mean pixel difference over both images resized to a common
    small size) -- not pixel-exact, deliberately cheap and dependency-free
    beyond Pillow."""
    Image = _pillow()
    if Image is None:
        return {"success": False, "message": "Image tools need the 'Pillow' package (pip install Pillow)."}
    if "|" not in arg:
        return {"success": False, "message": "compare_images needs 'path_a|path_b'."}
    a, b = (_resolve(part.strip()) for part in arg.split("|", 1))
    if not os.path.isfile(a) or not os.path.isfile(b):
        return {"success": False, "message": "Both paths must be existing image files."}

    try:
        with Image.open(a) as img_a, Image.open(b) as img_b:
            size = (128, 128)
            pixels_a = list(img_a.convert("RGB").resize(size).getdata())
            pixels_b = list(img_b.convert("RGB").resize(size).getdata())
    except OSError as exc:
        return {"success": False, "message": f"Couldn't compare images: {exc}"}

    total_diff = sum(
        abs(pa[0] - pb[0]) + abs(pa[1] - pb[1]) + abs(pa[2] - pb[2])
        for pa, pb in zip(pixels_a, pixels_b)
    )
    max_diff = len(pixels_a) * 255 * 3
    pct = (total_diff / max_diff) * 100 if max_diff else 0
    return {"success": True, "message": f"Approximate visual difference: {pct:.1f}%"}


def create_thumbnail(arg: str) -> dict:
    """arg format: 'source|destination|max_size' (max_size defaults to 256,
    applies to the longer dimension, aspect ratio preserved)."""
    Image = _pillow()
    if Image is None:
        return {"success": False, "message": "Image tools need the 'Pillow' package (pip install Pillow)."}
    parts = [p.strip() for p in arg.split("|")]
    if len(parts) not in (2, 3):
        return {"success": False, "message": "create_thumbnail needs 'source|destination' or 'source|destination|max_size'."}
    src, dest = parts[0], parts[1]
    max_size = 256
    if len(parts) == 3:
        try:
            max_size = max(16, int(parts[2]))
        except ValueError:
            pass
    src, dest = _resolve(src), _resolve(dest)
    if not os.path.isfile(src):
        return {"success": False, "message": f"Not a file: {src}"}
    if os.path.exists(dest):
        return {"success": False, "message": f"'{dest}' already exists -- not overwriting."}

    try:
        with Image.open(src) as img:
            img.thumbnail((max_size, max_size))
            os.makedirs(os.path.dirname(dest), exist_ok=True)
            img.save(dest)
    except OSError as exc:
        return {"success": False, "message": f"Couldn't create thumbnail: {exc}"}
    return {"success": True, "message": f"Thumbnail saved: {dest}"}



# ==========================================================================
# originally troy/tools/clipboard.py
# ==========================================================================
def read_clipboard() -> dict:
    try:
        import pyperclip
    except ImportError:
        return {
            "success": False,
            "message": "Clipboard access isn't available -- 'pyperclip' is not installed.",
        }

    try:
        text = pyperclip.paste()
    except Exception as exc:  # noqa: BLE001 - clipboard backends fail in varied ways
        return {"success": False, "message": f"Couldn't read the clipboard: {exc}"}

    text = (text or "").strip()
    if not text:
        return {"success": True, "message": "Clipboard is empty."}

    truncated = text[:2000]
    suffix = " (truncated)" if len(text) > 2000 else ""
    return {"success": True, "message": truncated + suffix}


def set_clipboard(text: str) -> dict:
    try:
        import pyperclip
    except ImportError:
        return {
            "success": False,
            "message": "Clipboard access isn't available -- 'pyperclip' is not installed.",
        }

    try:
        pyperclip.copy(text or "")
    except Exception as exc:  # noqa: BLE001
        return {"success": False, "message": f"Couldn't write to the clipboard: {exc}"}

    return {"success": True, "message": f"Copied {len(text or '')} characters to the clipboard."}



# ==========================================================================
# originally troy/tools/weather.py
# ==========================================================================
_GEOCODE_URL = "https://geocoding-api.open-meteo.com/v1/search"
_FORECAST_URL = "https://api.open-meteo.com/v1/forecast"

# WMO weather codes -> short human description.
_WEATHER_CODES = {
    0: "clear sky", 1: "mostly clear", 2: "partly cloudy", 3: "overcast",
    45: "fog", 48: "depositing rime fog",
    51: "light drizzle", 53: "moderate drizzle", 55: "dense drizzle",
    56: "light freezing drizzle", 57: "dense freezing drizzle",
    61: "slight rain", 63: "moderate rain", 65: "heavy rain",
    66: "light freezing rain", 67: "heavy freezing rain",
    71: "slight snow", 73: "moderate snow", 75: "heavy snow", 77: "snow grains",
    80: "slight rain showers", 81: "moderate rain showers", 82: "violent rain showers",
    85: "slight snow showers", 86: "heavy snow showers",
    95: "thunderstorm", 96: "thunderstorm with slight hail", 99: "thunderstorm with heavy hail",
}


def get_weather(place: str) -> dict:
    place = (place or "").strip()
    if not place:
        return {"success": False, "message": "get_weather needs a city/place name."}

    try:
        geo_resp = requests.get(_GEOCODE_URL, params={"name": place, "count": 1}, timeout=8)
        geo = geo_resp.json()
    except requests.RequestException as exc:
        return {"success": False, "message": f"Couldn't reach the geocoding service: {exc}"}
    except ValueError:
        return {"success": False, "message": "Geocoding service returned an unreadable response."}

    results = geo.get("results") or []
    if not results:
        return {"success": False, "message": f"Couldn't find a place matching '{place}'."}

    hit = results[0]
    lat, lon = hit["latitude"], hit["longitude"]
    label = ", ".join(
        part for part in [hit.get("name"), hit.get("admin1"), hit.get("country")] if part
    )

    try:
        forecast_resp = requests.get(
            _FORECAST_URL,
            params={
                "latitude": lat,
                "longitude": lon,
                "current": "temperature_2m,apparent_temperature,relative_humidity_2m,weather_code,wind_speed_10m",
                "temperature_unit": "celsius",
                "wind_speed_unit": "kmh",
            },
            timeout=8,
        )
        forecast = forecast_resp.json()
    except requests.RequestException as exc:
        return {"success": False, "message": f"Couldn't reach the forecast service: {exc}"}
    except ValueError:
        return {"success": False, "message": "Forecast service returned an unreadable response."}

    current = forecast.get("current")
    if not current:
        return {"success": False, "message": f"No current weather data returned for {label}."}

    temp = current.get("temperature_2m")
    feels = current.get("apparent_temperature")
    humidity = current.get("relative_humidity_2m")
    wind = current.get("wind_speed_10m")
    code = current.get("weather_code")
    condition = _WEATHER_CODES.get(code, "unknown conditions")

    message = (
        f"{label}: {condition}, {temp}°C (feels like {feels}°C), "
        f"{humidity}% humidity, wind {wind} km/h."
    )
    return {"success": True, "message": message}


# ==========================================================================
# Free public-API tools: Open-Meteo (forecast/geocoding), Frankfurter
# (currency), Wikipedia, NewsAPI. All plain HTTPS GETs returning JSON,
# read-only and low risk -- no confirmation needed. Only NewsAPI needs a
# key (config.NEWSAPI_KEY); the other three are keyless.
# ==========================================================================
_API_HEADERS = {"User-Agent": "TroyAssistant/1.0 (local desktop assistant)"}
_API_TIMEOUT = 10


def _api_get_json(url: str, params: dict = None, headers: dict = None):
    """GET -> parsed JSON. Raises RuntimeError with a short, user-readable
    reason on any network/HTTP/parse failure so each tool below can just
    wrap it once instead of repeating the same three except clauses."""
    try:
        resp = requests.get(url, params=params, headers={**_API_HEADERS, **(headers or {})}, timeout=_API_TIMEOUT)
    except requests.RequestException as exc:
        raise RuntimeError(f"couldn't reach {url.split('/')[2]}: {exc}") from exc
    resp.encoding = "utf-8"
    if not resp.ok:
        detail = ""
        try:
            body = resp.json()
            detail = body.get("message") or body.get("error") or ""
        except ValueError:
            detail = resp.text[:150]
        raise RuntimeError(f"{resp.status_code} {resp.reason}{': ' + str(detail) if detail else ''}")
    try:
        return resp.json()
    except ValueError as exc:
        raise RuntimeError("service returned an unreadable response") from exc


def _geocode(place: str) -> dict:
    data = _api_get_json(_GEOCODE_URL, {"name": place, "count": 1})
    results = data.get("results") or []
    if not results:
        raise RuntimeError(f"couldn't find a place matching '{place}'")
    return results[0]


def _place_label(hit: dict) -> str:
    return ", ".join(p for p in [hit.get("name"), hit.get("admin1"), hit.get("country")] if p)


# ---- Open-Meteo ----
def geocode_place(place: str) -> dict:
    place = (place or "").strip()
    if not place:
        return {"success": False, "message": "geocode_place needs a place name."}
    try:
        hit = _geocode(place)
    except RuntimeError as exc:
        return {"success": False, "message": f"Geocoding failed: {exc}"}
    return {"success": True, "message": (
        f"{_place_label(hit)}: lat {hit['latitude']}, lon {hit['longitude']}, "
        f"timezone {hit.get('timezone', 'unknown')}, elevation {hit.get('elevation', '?')} m"
        + (f", population {hit['population']:,}" if hit.get("population") else "")
    )}


def get_weather_forecast(arg: str) -> dict:
    parts = split_args(arg)
    place = parts[0].strip() if parts else ""
    if not place:
        return {"success": False, "message": "get_weather_forecast needs '<place>[|<days 1-16, default 3>]'."}
    try:
        days = max(1, min(16, int(parts[1]))) if len(parts) > 1 and parts[1].strip() else 3
    except ValueError:
        return {"success": False, "message": "days must be a whole number between 1 and 16."}
    try:
        hit = _geocode(place)
        data = _api_get_json(_FORECAST_URL, {
            "latitude": hit["latitude"], "longitude": hit["longitude"],
            "daily": "weather_code,temperature_2m_max,temperature_2m_min,precipitation_sum,precipitation_probability_max,wind_speed_10m_max",
            "temperature_unit": "celsius", "wind_speed_unit": "kmh",
            "timezone": "auto", "forecast_days": days,
        })
    except RuntimeError as exc:
        return {"success": False, "message": f"Forecast failed: {exc}"}
    daily = data.get("daily") or {}
    dates = daily.get("time") or []
    if not dates:
        return {"success": False, "message": f"No forecast data returned for {_place_label(hit)}."}
    lines = []
    for i, date in enumerate(dates):
        cond = _WEATHER_CODES.get((daily.get("weather_code") or [None])[i], "unknown conditions")
        rain_prob = (daily.get("precipitation_probability_max") or [None] * len(dates))[i]
        lines.append(
            f"{date}: {cond}, {daily['temperature_2m_min'][i]}-{daily['temperature_2m_max'][i]}°C, "
            f"rain {daily['precipitation_sum'][i]} mm"
            + (f" ({rain_prob}% chance)" if rain_prob is not None else "")
            + f", wind up to {daily['wind_speed_10m_max'][i]} km/h"
        )
    return {"success": True, "message": f"{_place_label(hit)} -- " + " | ".join(lines)}


# ---- Frankfurter (ECB reference exchange rates) ----
_FRANKFURTER_URL = "https://api.frankfurter.dev/v1"


def _currency(code: str) -> str:
    return (code or "").strip().upper()


def convert_currency(arg: str) -> dict:
    parts = split_args(arg)
    if len(parts) < 3:
        return {"success": False, "message": "convert_currency needs '<amount>|<from>|<to>' (e.g. 100|USD|EUR)."}
    try:
        amount = float(parts[0].replace(",", ""))
    except ValueError:
        return {"success": False, "message": f"'{parts[0]}' isn't a valid amount."}
    src, dst = _currency(parts[1]), _currency(parts[2])
    if src == dst:
        return {"success": True, "message": f"{amount:g} {src} = {amount:g} {dst} (same currency)."}
    try:
        data = _api_get_json(f"{_FRANKFURTER_URL}/latest", {"amount": amount, "base": src, "symbols": dst})
    except RuntimeError as exc:
        return {"success": False, "message": f"Currency conversion failed: {exc}"}
    result = (data.get("rates") or {}).get(dst)
    if result is None:
        return {"success": False, "message": f"No {src}->{dst} rate returned (check both are valid ECB currency codes)."}
    return {"success": True, "message": f"{amount:g} {src} = {result:g} {dst} (ECB rate for {data.get('date')})."}


def get_exchange_rates(arg: str) -> dict:
    parts = split_args(arg)
    base = _currency(parts[0]) if parts and parts[0].strip() else "EUR"
    params = {"base": base}
    if len(parts) > 1 and parts[1].strip():
        params["symbols"] = ",".join(_currency(s) for s in parts[1].split(","))
    try:
        data = _api_get_json(f"{_FRANKFURTER_URL}/latest", params)
    except RuntimeError as exc:
        return {"success": False, "message": f"Couldn't fetch rates: {exc}"}
    rates = data.get("rates") or {}
    if not rates:
        return {"success": False, "message": f"No rates returned for base {base}."}
    listing = ", ".join(f"{code} {rate:g}" for code, rate in rates.items())
    return {"success": True, "message": f"1 {base} on {data.get('date')}: {listing}"}


def get_historical_rate(arg: str) -> dict:
    parts = split_args(arg)
    if len(parts) < 3:
        return {"success": False, "message": "get_historical_rate needs '<YYYY-MM-DD>|<from>|<to>'."}
    date, src, dst = parts[0].strip(), _currency(parts[1]), _currency(parts[2])
    try:
        data = _api_get_json(f"{_FRANKFURTER_URL}/{date}", {"base": src, "symbols": dst})
    except RuntimeError as exc:
        return {"success": False, "message": f"Couldn't fetch historical rate: {exc}"}
    rate = (data.get("rates") or {}).get(dst)
    if rate is None:
        return {"success": False, "message": f"No {src}->{dst} rate returned for {date}."}
    return {"success": True, "message": f"1 {src} = {rate:g} {dst} on {data.get('date')} (ECB; nearest prior business day if {date} was a weekend/holiday)."}


def list_currencies(_arg: str = "") -> dict:
    try:
        data = _api_get_json(f"{_FRANKFURTER_URL}/currencies")
    except RuntimeError as exc:
        return {"success": False, "message": f"Couldn't fetch currency list: {exc}"}
    return {"success": True, "message": "; ".join(f"{code}: {name}" for code, name in sorted(data.items()))}


# ---- Wikipedia ----
_WIKI_API = "https://en.wikipedia.org/w/api.php"
_WIKI_SUMMARY = "https://en.wikipedia.org/api/rest_v1/page/summary/"


def wikipedia_search(arg: str) -> dict:
    parts = split_args(arg)
    query = parts[0].strip() if parts else ""
    if not query:
        return {"success": False, "message": "wikipedia_search needs a query."}
    try:
        limit = max(1, min(10, int(parts[1]))) if len(parts) > 1 and parts[1].strip() else 5
    except ValueError:
        limit = 5
    try:
        data = _api_get_json(_WIKI_API, {
            "action": "query", "list": "search", "srsearch": query,
            "srlimit": limit, "format": "json", "srprop": "snippet",
        })
    except RuntimeError as exc:
        return {"success": False, "message": f"Wikipedia search failed: {exc}"}
    hits = (data.get("query") or {}).get("search") or []
    if not hits:
        return {"success": False, "message": f"No Wikipedia results for '{query}'."}
    items = []
    for h in hits:
        snippet = re.sub(r"<[^>]+>", "", h.get("snippet", "")).replace("&quot;", '"').replace("&amp;", "&")
        items.append(f"{h['title']} -- {snippet}")
    return {"success": True, "message": " | ".join(items)}


def wikipedia_summary(arg: str) -> dict:
    """Accepts an exact article title OR loose text -- if the exact title
    doesn't exist it falls back to the top search hit, so 'einstein' or
    'how tall is mount everest' still land on a real article."""
    topic = (arg or "").strip()
    if not topic:
        return {"success": False, "message": "wikipedia_summary needs a topic or article title."}

    def _fetch(title: str):
        return _api_get_json(_WIKI_SUMMARY + quote(title.replace(" ", "_"), safe=""))

    try:
        try:
            page = _fetch(topic)
        except RuntimeError as first_exc:
            if not str(first_exc).startswith("404"):
                raise
            hits = (_api_get_json(_WIKI_API, {
                "action": "query", "list": "search", "srsearch": topic,
                "srlimit": 1, "format": "json",
            }).get("query") or {}).get("search") or []
            if not hits:
                return {"success": False, "message": f"No Wikipedia article found for '{topic}'."}
            page = _fetch(hits[0]["title"])
    except RuntimeError as exc:
        return {"success": False, "message": f"Wikipedia lookup failed: {exc}"}

    extract = (page.get("extract") or "").strip()
    if not extract:
        return {"success": False, "message": f"'{page.get('title', topic)}' has no summary text."}
    if page.get("type") == "disambiguation":
        extract = "(disambiguation page -- try a more specific title) " + extract
    url = ((page.get("content_urls") or {}).get("desktop") or {}).get("page", "")
    return {"success": True, "message": f"{page.get('title')}: {extract[:1500]}" + (f" [{url}]" if url else "")}


# ---- NewsAPI (https://newsapi.org -- needs config.NEWSAPI_KEY) ----
_NEWSAPI_URL = "https://newsapi.org/v2"


def _news_call(endpoint: str, params: dict) -> dict:
    if not config.NEWSAPI_KEY:
        return {"success": False, "message": (
            "NewsAPI isn't configured -- set TROY_NEWSAPI_KEY in .env "
            "(free key at https://newsapi.org/register)."
        )}
    try:
        data = _api_get_json(f"{_NEWSAPI_URL}/{endpoint}", params, headers={"X-Api-Key": config.NEWSAPI_KEY})
    except RuntimeError as exc:
        return {"success": False, "message": f"NewsAPI request failed: {exc}"}
    if data.get("status") != "ok":
        return {"success": False, "message": f"NewsAPI error: {data.get('message', 'unknown error')}"}
    articles = data.get("articles") or []
    if not articles:
        return {"success": False, "message": "NewsAPI returned no articles for that request."}
    lines = []
    for a in articles:
        source = (a.get("source") or {}).get("name") or "unknown source"
        published = (a.get("publishedAt") or "")[:10]
        lines.append(f"{a.get('title')} ({source}, {published}) {a.get('url', '')}")
    return {"success": True, "message": " | ".join(lines)}


def news_top_headlines(arg: str) -> dict:
    """'<country 2-letter, default us>|<category>|<keyword>' -- every part optional."""
    parts = split_args(arg) if arg.strip() else []
    country = (parts[0].strip().lower() if parts and parts[0].strip() else "us")
    params = {"country": country, "pageSize": 5}
    if len(parts) > 1 and parts[1].strip():
        params["category"] = parts[1].strip().lower()
    if len(parts) > 2 and parts[2].strip():
        params["q"] = parts[2].strip()
    return _news_call("top-headlines", params)


def news_search(arg: str) -> dict:
    """'<keywords>[|<language 2-letter, default en>][|<sort: publishedAt|relevancy|popularity>]'."""
    parts = split_args(arg)
    query = parts[0].strip() if parts else ""
    if not query:
        return {"success": False, "message": "news_search needs keywords."}
    params = {
        "q": query, "pageSize": 5,
        "language": parts[1].strip().lower() if len(parts) > 1 and parts[1].strip() else "en",
        "sortBy": parts[2].strip() if len(parts) > 2 and parts[2].strip() else "publishedAt",
    }
    return _news_call("everything", params)


# ==========================================================================
# originally troy/tools/system_info.py
# ==========================================================================
def get_current_time() -> dict:
    now = datetime.now()
    formatted = now.strftime("%A, %B %d %Y, %H:%M:%S")
    return {"success": True, "message": f"Current date/time: {formatted}"}


def get_context_snapshot(_arg: str = "") -> dict:
    """
    CONTEXT AWARENESS: one call that bundles the cheapest structural checks
    (time, active window, how many windows are open, CPU/RAM, and whether
    the web research browser is running and what it's doing) into a single
    observation. This is what Troy should reach for to re-orient itself --
    at the start of a task, after a long gap, after `escalate`, or any time
    it isn't sure what's actually going on right now -- instead of either
    guessing or spending several separate round-trips (get_active_window,
    list_windows, get_system_stats, ...) on facts that are cheap to bundle.
    Every sub-check is independently wrapped so one missing package/API
    never blanks out the whole snapshot -- it just quietly drops that one
    line and returns everything else.
    """
    parts = [f"Time: {datetime.now().strftime('%a %b %d, %H:%M:%S')}"]

    try:
        active = get_active_window()
        if active.get("success"):
            parts.append(active["message"])
    except Exception:  # noqa: BLE001
        pass

    try:
        windows = _enumerate_windows()
        parts.append(f"{len(windows)} window(s) open")
    except Exception:  # noqa: BLE001
        pass

    try:
        import psutil
        cpu = psutil.cpu_percent(interval=0.1)
        mem = psutil.virtual_memory()
        parts.append(f"CPU {cpu:.0f}% / RAM {mem.percent:.0f}%")
    except Exception:  # noqa: BLE001
        pass

    try:
        if browser_worker.is_running():
            def _do():
                pages = browser_worker.list_pages()
                idx = browser_worker.get_active_index()
                return len(pages), (pages[idx].url if pages else "(no tabs)")
            count, active_url = browser_worker.run(_do, timeout=5)
            parts.append(f"Web research browser: {count} tab(s), active tab -> {active_url}")
        else:
            parts.append("Web research browser: not started yet (starts automatically on first web_* call)")
    except Exception:  # noqa: BLE001
        pass

    return {"success": True, "message": " | ".join(parts)}


_CORE_HELP = {
    "speak": "speak:<text> -- says something to the user. Every reply goes through this.",
    "done": "done -- ends the turn. Don't put it right after an info command whose result you still need.",
    "open_app": "open_app:<name> -- opens an application by name (e.g. firefox, notepad, spotify).",
    "open_url": "open_url:<url> -- opens a link in the user's own browser.",
    "search_newtab": "search_newtab:<query> -- searches the web in a new tab of the user's own browser.",
    "click_target": "click_target:<description> -- finds the described thing on screen with the vision model and clicks it.",
    "locate_on_screen": "locate_on_screen:<description> -- returns the pixel coordinates of something on screen without clicking.",
    "type_text": "type_text:<text> -- types text into whatever has focus.",
    "press_key": "press_key:<key> -- e.g. enter, tab, esc.",
    "hotkey": "hotkey:<k1+k2+...> -- e.g. ctrl+c, alt+tab.",
    "escalate": "escalate:<user_request>|<current_task>|<attempted>|<error>|<reason> -- last resort: asks Gemini for help.",
    "remember": "remember:<fact> -- saves a durable fact about the user.",
    "recall": "recall:<query> -- searches saved facts.",
}


def list_tools(arg: str = "") -> dict:
    """list_tools -> the categories; list_tools:<category> -> that category's
    tools with their argument shapes. How a model with a tiny context window
    discovers the ~170 extended tools without them all being in its prompt."""
    groups = by_category()
    category = (arg or "").strip().lower()
    if not category:
        listing = ", ".join(f"{c} ({len(ts)})" for c, ts in groups.items())
        return {"success": True, "message": f"Tool categories: {listing}. Use list_tools:<category> to see one, tool_help:<name> for details."}
    if category not in groups:
        return {"success": False, "message": f"No category '{category}'. Categories: {', '.join(groups)}."}
    lines = []
    for tool in groups[category]:
        args = f":{tool.arg_hint}" if tool.arg_hint else ""
        flags = ("!" if tool.requires_confirmation else "") + ("*" if tool.info else "")
        lines.append(f"{tool.name}{args}{flags}")
    return {"success": True, "message": f"[{category}] " + " | ".join(lines) + "  (! needs approval, * returns info)"}


def tool_help(arg: str = "") -> dict:
    name = (arg or "").strip().split(":")[0].strip()
    if not name:
        return {"success": False, "message": "tool_help needs a tool name, e.g. tool_help:convert_currency."}
    tool = get(name)
    if tool is None:
        if name in _CORE_HELP:
            return {"success": True, "message": _CORE_HELP[name]}
        close = [n for n in _REGISTRY if name in n or n in name][:5]
        return {"success": False, "message": f"No tool named '{name}'." + (f" Did you mean: {', '.join(close)}?" if close else "")}
    args = f":{tool.arg_hint}" if tool.arg_hint else ""
    extra = []
    if tool.requires_confirmation:
        extra.append(f"needs the user's approval (risk={tool.risk_level})")
    if tool.info:
        extra.append("returns information")
    return {"success": True, "message": f"{tool.name}{args} -- {tool.description}" + (f" [{'; '.join(extra)}]" if extra else "")}


def get_media_info() -> dict:
    """
    Returns what's currently playing system-wide (Spotify, browser tab,
    Windows Media Player, etc), via Windows' GlobalSystemMediaTransport-
    ControlsSessionManager. Requires the `winsdk` package -- if it's not
    installed or this isn't Windows, this fails gracefully rather than
    crashing the command loop.
    """
    try:
        import asyncio
        from winsdk.windows.media.control import (
            GlobalSystemMediaTransportControlsSessionManager as SessionManager,
        )
    except ImportError:
        return {
            "success": False,
            "message": "Media info isn't available -- the 'winsdk' package isn't installed "
                       "(pip install winsdk) or this isn't Windows.",
        }

    async def _read():
        manager = await SessionManager.request_async()
        session = manager.get_current_session()
        if session is None:
            return None
        info = await session.try_get_media_properties_async()
        return {
            "title": info.title or "",
            "artist": info.artist or "",
            "app": session.source_app_user_model_id or "",
        }

    try:
        result = asyncio.run(_read())
    except Exception as exc:  # noqa: BLE001 - winrt failures are varied and non-standard
        return {"success": False, "message": f"Couldn't read media info: {exc}"}

    if result is None:
        return {"success": True, "message": "Nothing is currently playing."}

    title = result["title"] or "(untitled)"
    artist = f" by {result['artist']}" if result["artist"] else ""
    app = f" (via {result['app']})" if result["app"] else ""
    return {"success": True, "message": f"Now playing: {title}{artist}{app}"}


def get_system_stats() -> dict:
    """CPU load, RAM usage, and battery status (if present) via psutil.
    Wrapped defensively -- a missing 'psutil' package or a desktop with no
    battery both degrade to a clear partial/failed message rather than a
    crash."""
    try:
        import psutil
    except ImportError:
        return {
            "success": False,
            "message": "System stats aren't available -- the 'psutil' package isn't installed (pip install psutil).",
        }

    cpu_pct = psutil.cpu_percent(interval=0.4)
    mem = psutil.virtual_memory()
    parts = [f"CPU {cpu_pct:.0f}%", f"RAM {mem.percent:.0f}% ({mem.used / 1024**3:.1f}/{mem.total / 1024**3:.1f} GB)"]

    try:
        battery = psutil.sensors_battery()
    except Exception:  # noqa: BLE001 - not every platform implements this
        battery = None
    if battery is not None:
        state = "charging" if battery.power_plugged else "on battery"
        parts.append(f"Battery {battery.percent:.0f}% ({state})")

    return {"success": True, "message": " | ".join(parts)}


def get_storage_info() -> dict:
    """Disk space per drive letter -- a simple, reliable stand-in for 'app
    storage info' that doesn't need admin rights or registry scraping."""
    lines = []
    for letter in string.ascii_uppercase:
        drive = f"{letter}:\\"
        try:
            usage = shutil.disk_usage(drive)
        except (FileNotFoundError, OSError):
            continue
        total_gb = usage.total / (1024 ** 3)
        free_gb = usage.free / (1024 ** 3)
        used_pct = (usage.used / usage.total) * 100 if usage.total else 0
        lines.append(f"{drive} {free_gb:.1f} GB free of {total_gb:.1f} GB ({used_pct:.0f}% used)")

    if not lines:
        return {"success": False, "message": "Couldn't read any drive info."}
    return {"success": True, "message": "Storage: " + " | ".join(lines)}



# ==========================================================================
# originally troy/tools/notifications.py
# ==========================================================================
def _show_balloon(title: str, message: str, icon: str = "Info") -> dict:
    if sys.platform != "win32":
        return {"success": False, "message": "Notifications are Windows-only."}

    title = (title or "Troy").replace('"', "'")
    message = (message or "").replace('"', "'")
    if not message:
        return {"success": False, "message": "A notification needs a message."}

    script = f"""
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
$notify = New-Object System.Windows.Forms.NotifyIcon
$notify.Icon = [System.Drawing.SystemIcons]::{icon}
$notify.BalloonTipTitle = "{title}"
$notify.BalloonTipText = "{message}"
$notify.Visible = $true
$notify.ShowBalloonTip(6000)
Start-Sleep -Seconds 4
$notify.Dispose()
"""
    try:
        subprocess.run(
            ["powershell.exe", "-NoProfile", "-WindowStyle", "Hidden", "-Command", script],
            capture_output=True, text=True, timeout=8, check=False,
        )
    except (OSError, subprocess.SubprocessError, subprocess.TimeoutExpired) as exc:
        return {"success": False, "message": f"Couldn't show notification: {exc}"}

    return {"success": True, "message": f"Shown: {title} -- {message}"}


def show_notification(arg: str) -> dict:
    """arg format: 'title|message' (title optional, defaults to 'Troy')."""
    if "|" in arg:
        title, message = (part.strip() for part in arg.split("|", 1))
    else:
        title, message = "Troy", arg.strip()
    return _show_balloon(title, message, "Info")


def show_task_complete_notification(arg: str) -> dict:
    return _show_balloon("Task complete", arg.strip() or "Troy finished the task.", "Info")


def show_error_notification(arg: str) -> dict:
    return _show_balloon("Troy needs attention", arg.strip() or "Something went wrong.", "Error")


# ==============================================================================
# NEW IN TROYOS STABLE - coordinate targeting (screenshot -> x,y -> click)
# ==============================================================================
# Previously this was a 3-step dance the model had to drive by hand:
#   screenshot  ->  (read the vision description)  ->  click:<x>,<y>
# with the model guessing coordinates from a prose description in between.
# locate_on_screen / click_target fold that into one real call: a screenshot
# is taken, a vision model is asked directly for pixel coordinates of the
# described target (not a description of the scene), and the result is
# returned/clicked immediately. Fewer tool-calling round trips, and the
# coordinates come from the same image that's clicked on, not from the
# model re-deriving them from a sentence.

def _screen_size():
    try:
        return pyautogui.size()
    except Exception:  # noqa: BLE001
        return (1920, 1080)


def _capture_for_locate():
    image = pyautogui.screenshot()
    buffer = io.BytesIO()
    image.save(buffer, format="JPEG", quality=85)
    encoded = base64.b64encode(buffer.getvalue()).decode("utf-8")
    return image, encoded


def locate_on_screen(query: str) -> dict:
    """Screenshot + vision model, asked directly for the pixel coordinates
    of a described on-screen target. Returns {"x": int, "y": int} on
    success instead of just a prose description."""
    query = (query or "").strip()
    if not query:
        return {"success": False, "message": "locate_on_screen needs a description of what to find."}

    image, encoded = _capture_for_locate()
    width, height = image.size
    # "{size}" is filled in with the size of the picture the model actually
    # receives: local models get a smaller one, so the answer is scaled back below.
    prompt = (
        "This screenshot is {size} pixels. Find this on screen: " + repr(query) + ". "
        "Reply with ONLY the pixel coordinates of the center of that element, in the "
        "exact form 'X,Y' (two integers separated by a comma), nothing else. "
        "If it is not visible anywhere on screen, reply with exactly: NOT_FOUND"
    )
    try:
        answer, seen = llm_client.describe_image_ex(encoded, question=prompt, size=(width, height))
        answer = answer.strip()
    except Exception as exc:  # noqa: BLE001
        return {"success": False, "message": f"Couldn't ask the vision model to locate '{query}': {exc}"}

    if "NOT_FOUND" in answer.upper():
        return {"success": False, "message": f"Couldn't find '{query}' on screen."}

    match = re.search(r"(-?\d+)\s*,\s*(-?\d+)", answer)
    if not match:
        return {"success": False, "message": f"Vision model didn't return coordinates for '{query}': {answer[:120]}"}

    x, y = int(match.group(1)), int(match.group(2))
    if seen and seen != (width, height):
        x, y = round(x * width / seen[0]), round(y * height / seen[1])
    x = max(0, min(width - 1, x))
    y = max(0, min(height - 1, y))
    return {"success": True, "message": f"Found '{query}' at ({x}, {y}).", "x": x, "y": y}


def click_target(query: str) -> dict:
    """One command: screenshot -> locate coordinates for `query` -> click
    them with the real mouse. Use this instead of screenshot + click when
    you don't already know the exact pixel position."""
    located = locate_on_screen(query)
    if not located.get("success"):
        return located
    x, y = located["x"], located["y"]
    pyautogui.click(x, y)
    return {"success": True, "message": f"Clicked '{query}' at ({x}, {y})."}


def double_click_target(query: str) -> dict:
    located = locate_on_screen(query)
    if not located.get("success"):
        return located
    x, y = located["x"], located["y"]
    pyautogui.doubleClick(x, y)
    return {"success": True, "message": f"Double-clicked '{query}' at ({x}, {y})."}


# ==============================================================================
# NEW IN TROYOS STABLE - real shell access + one-call system report
# ==============================================================================

def run_shell_command(arg: str) -> dict:
    """Runs a command through the Windows shell and captures its output.
    This is real, general-purpose PC control -- not restricted to a fixed
    command list -- so it is confirmation-gated (see registration below)."""
    command = (arg or "").strip()
    if not command:
        return {"success": False, "message": "run_shell_command needs a command to run."}
    try:
        proc = subprocess.run(
            command, shell=True, capture_output=True, text=True, timeout=30,
        )
    except subprocess.TimeoutExpired:
        return {"success": False, "message": f"Command timed out after 30s: {command}"}
    except Exception as exc:  # noqa: BLE001
        return {"success": False, "message": f"Couldn't run command: {exc}"}
    out = (proc.stdout or "").strip()
    err = (proc.stderr or "").strip()
    combined = out if not err else f"{out}\n[stderr] {err}".strip()
    combined = combined[:4000]
    ok = proc.returncode == 0
    return {"success": ok, "message": combined or f"(no output, exit code {proc.returncode})"}


def get_full_system_report(_arg: str = "") -> dict:
    """One call instead of six: CPU, memory, disk, battery, network, and
    uptime together, for a single 'how's my PC doing' answer."""
    parts = []
    for label, func in (
        ("CPU", get_cpu_info), ("Memory", get_memory_info), ("Disk", get_disk_info),
        ("Battery", get_battery_info), ("Network", get_network_info), ("Uptime", get_uptime),
    ):
        try:
            result = func("")
            parts.append(f"{label}: {result.get('message', '?')}")
        except Exception as exc:  # noqa: BLE001
            parts.append(f"{label}: unavailable ({exc})")
    return {"success": True, "message": " | ".join(parts)}


# ==============================================================================
# WEB RESEARCH TOOLS -- Troy's own invisible browser (not the user's Firefox)
# ==============================================================================
# A real, persistent Chromium instance (troy/browser_worker.py) driven
# through Playwright: reads the actual page (roles, labels, link text),
# clicks real elements by what they say rather than where they happen to
# sit on screen. This is a SEPARATE, headless-by-default browser profile
# that Troy drives for itself -- background research, filling forms,
# reading a page's content -- it is NOT the user's actual Firefox/Chrome
# and nothing that happens here is shown on screen by default. When the
# user asks Troy to "open Firefox"/"open my browser"/"show me the page",
# use open_app/open_url instead (see system_prompt.py's WEB RESEARCH TOOLS
# vs. YOUR BROWSER section) -- reach for these web_* tools only for
# autonomous, invisible information-gathering or multi-step web actions
# where the user doesn't need to watch it happen.

def _web_locate(page, target: str):
    """Tries several Playwright locator strategies, exact match first
    across all of them, then substring match as a fallback across all of
    them -- NOT substring-matching each strategy in turn. The naive
    "try each strategy at exact=False" order picks the wrong element
    surprisingly often: e.g. searching for a "Password" field on a page
    that also has a "Forgot password?" link will substring-match that
    link (as a role="link") before ever trying the actual password input,
    because link-role was checked before label-role. Preferring an exact
    match anywhere beats a substring match anywhere first."""
    target = target.strip()
    selector_candidates = []
    if bool(re.match(r"^[.#\[]", target)) or target.startswith(("text=", "css=", "xpath=")):
        selector_candidates.append(page.locator(target))

    def _role_and_field_candidates(exact: bool):
        return [
            page.get_by_role("textbox", name=target, exact=exact),
            page.get_by_label(target, exact=exact),
            page.get_by_placeholder(target, exact=exact),
            page.get_by_role("button", name=target, exact=exact),
            page.get_by_role("link", name=target, exact=exact),
            page.get_by_text(target, exact=exact),
        ]

    for loc in selector_candidates:
        try:
            if loc.count() > 0:
                return loc.first
        except Exception:  # noqa: BLE001
            continue
    for exact in (True, False):
        for loc in _role_and_field_candidates(exact):
            try:
                if loc.count() > 0:
                    return loc.first
            except Exception:  # noqa: BLE001
                continue
    return None


def web_open(arg: str) -> dict:
    url = (arg or "").strip()
    if not url:
        return {"success": False, "message": "web_open needs a URL."}
    if not re.match(r"^https?://", url):
        url = "https://" + url
    try:
        def _do():
            page = browser_worker.get_active_page()
            page.goto(url, wait_until="domcontentloaded", timeout=20000)
            return page.title()
        title = browser_worker.run(_do, timeout=25)
        return {"success": True, "message": f"Opened {url} -- \"{title}\""}
    except Exception as exc:  # noqa: BLE001
        return {"success": False, "message": f"Couldn't open {url}: {exc}"}


def web_click(arg: str) -> dict:
    target = (arg or "").strip()
    if not target:
        return {"success": False, "message": "web_click needs visible text or a CSS selector."}
    try:
        def _do():
            page = browser_worker.get_active_page()
            loc = _web_locate(page, target)
            if loc is None:
                raise RuntimeError(f"No element matching '{target}' found on the current page.")
            loc.scroll_into_view_if_needed(timeout=5000)
            loc.click(timeout=5000)
            return page.url
        url = browser_worker.run(_do)
        return {"success": True, "message": f"Clicked '{target}'. Now at {url}"}
    except Exception as exc:  # noqa: BLE001
        return {"success": False, "message": f"Couldn't click '{target}': {exc}"}


def web_type(arg: str) -> dict:
    parts = arg.split("|", 1)
    if len(parts) < 2:
        return {"success": False, "message": "web_type needs '<field label or selector>|<text>'."}
    field, text = parts[0].strip(), parts[1]
    if not field:
        return {"success": False, "message": "web_type needs a field to type into."}
    try:
        def _do():
            page = browser_worker.get_active_page()
            loc = _web_locate(page, field)
            if loc is None:
                raise RuntimeError(f"No input matching '{field}' found on the current page.")
            tag = loc.evaluate("el => el.tagName").lower()
            editable = loc.evaluate("el => el.isContentEditable")
            if tag not in ("input", "textarea") and not editable:
                raise RuntimeError(
                    f"'{field}' matched a <{tag}> element, not a text field -- "
                    f"try a more specific label, or the field's exact placeholder text."
                )
            loc.click(timeout=5000)
            loc.fill(text, timeout=5000)
        browser_worker.run(_do)
        return {"success": True, "message": f"Typed into '{field}'."}
    except Exception as exc:  # noqa: BLE001
        return {"success": False, "message": f"Couldn't type into '{field}': {exc}"}


def web_read_page(_arg: str = "") -> dict:
    try:
        def _do():
            page = browser_worker.get_active_page()
            return page.title(), page.url, page.inner_text("body")
        title, url, text = browser_worker.run(_do)
        text = " ".join(text.split())[:2500]
        return {"success": True, "message": f"{title} ({url}): {text}"}
    except Exception as exc:  # noqa: BLE001
        return {"success": False, "message": f"Couldn't read the page: {exc}"}


def web_get_links(_arg: str = "") -> dict:
    try:
        def _do():
            page = browser_worker.get_active_page()
            return page.eval_on_selector_all(
                "a[href]",
                "els => els.map(e => [e.innerText.trim(), e.href]).filter(x => x[0]).slice(0, 40)",
            )
        links = browser_worker.run(_do)
        formatted = " | ".join(f"{t[:50]} -> {h}" for t, h in links)
        return {"success": True, "message": formatted or "No links found on this page."}
    except Exception as exc:  # noqa: BLE001
        return {"success": False, "message": f"Couldn't list links: {exc}"}


def web_press_key(arg: str) -> dict:
    key = (arg or "").strip()
    if not key:
        return {"success": False, "message": "web_press_key needs a key name, e.g. Enter or Tab."}
    try:
        browser_worker.run(lambda: browser_worker.get_active_page().keyboard.press(key))
        return {"success": True, "message": f"Pressed {key}."}
    except Exception as exc:  # noqa: BLE001
        return {"success": False, "message": f"Couldn't press {key}: {exc}"}


def web_scroll(arg: str) -> dict:
    try:
        amount = int(arg) if (arg or "").strip() else 600
    except ValueError:
        amount = 600
    try:
        browser_worker.run(lambda: browser_worker.get_active_page().mouse.wheel(0, amount))
        return {"success": True, "message": f"Scrolled {amount}px."}
    except Exception as exc:  # noqa: BLE001
        return {"success": False, "message": f"Couldn't scroll: {exc}"}


def web_wait_for_text(arg: str) -> dict:
    parts = split_args(arg) if "|" in arg else [arg]
    text = (parts[0] if parts else "").strip()
    try:
        timeout_s = float(parts[1]) if len(parts) > 1 else 10.0
    except ValueError:
        timeout_s = 10.0
    if not text:
        return {"success": False, "message": "web_wait_for_text needs text to wait for."}
    try:
        def _do():
            page = browser_worker.get_active_page()
            page.get_by_text(text, exact=False).first.wait_for(state="visible", timeout=int(timeout_s * 1000))
        browser_worker.run(_do, timeout=timeout_s + 5)
        return {"success": True, "message": f"'{text}' appeared."}
    except Exception as exc:  # noqa: BLE001
        return {"success": False, "message": f"'{text}' didn't appear within {timeout_s}s: {exc}"}


def web_get_url(_arg: str = "") -> dict:
    try:
        url = browser_worker.run(lambda: browser_worker.get_active_page().url)
        return {"success": True, "message": url}
    except Exception as exc:  # noqa: BLE001
        return {"success": False, "message": f"Couldn't get the URL: {exc}"}


def web_go_back(_arg: str = "") -> dict:
    try:
        def _do():
            page = browser_worker.get_active_page()
            page.go_back(timeout=10000)
            return page.url
        url = browser_worker.run(_do)
        return {"success": True, "message": f"Back to {url}"}
    except Exception as exc:  # noqa: BLE001
        return {"success": False, "message": f"Couldn't go back: {exc}"}


def web_reload(_arg: str = "") -> dict:
    try:
        browser_worker.run(lambda: browser_worker.get_active_page().reload(timeout=15000))
        return {"success": True, "message": "Reloaded."}
    except Exception as exc:  # noqa: BLE001
        return {"success": False, "message": f"Couldn't reload: {exc}"}


def web_new_tab(arg: str) -> dict:
    url = (arg or "").strip()
    try:
        def _do():
            page = browser_worker.get_context().new_page()
            browser_worker.add_page(page)
            browser_worker.set_active_index(len(browser_worker.list_pages()) - 1)
            if url:
                target = url if re.match(r"^https?://", url) else "https://" + url
                page.goto(target, wait_until="domcontentloaded", timeout=20000)
            return page.url
        result_url = browser_worker.run(_do, timeout=25)
        return {"success": True, "message": f"New tab opened at {result_url}"}
    except Exception as exc:  # noqa: BLE001
        return {"success": False, "message": f"Couldn't open a new tab: {exc}"}


def web_list_tabs(_arg: str = "") -> dict:
    try:
        def _do():
            pages = browser_worker.list_pages()
            active = browser_worker.get_active_index()
            return [(i, p.url, p.title()) for i, p in enumerate(pages)], active
        tabs, active = browser_worker.run(_do)
        formatted = " | ".join(f"[{i}{'*' if i == active else ''}] {t}: {u}" for i, u, t in tabs)
        return {"success": True, "message": formatted or "No tabs open."}
    except Exception as exc:  # noqa: BLE001
        return {"success": False, "message": f"Couldn't list tabs: {exc}"}


def web_switch_tab(arg: str) -> dict:
    try:
        index = int(arg)
    except (ValueError, TypeError):
        return {"success": False, "message": "web_switch_tab needs a tab index -- see web_list_tabs."}
    try:
        def _do():
            pages = browser_worker.list_pages()
            if not (0 <= index < len(pages)):
                raise RuntimeError(f"No tab at index {index}.")
            browser_worker.set_active_index(index)
            pages[index].bring_to_front()
            return pages[index].url
        url = browser_worker.run(_do)
        return {"success": True, "message": f"Switched to tab {index}: {url}"}
    except Exception as exc:  # noqa: BLE001
        return {"success": False, "message": f"Couldn't switch tabs: {exc}"}


def web_close_tab(arg: str) -> dict:
    arg = (arg or "").strip()
    try:
        def _do():
            index = int(arg) if arg else browser_worker.get_active_index()
            pages = browser_worker.list_pages()
            if not (0 <= index < len(pages)):
                raise RuntimeError(f"No tab at index {index}.")
            if len(pages) == 1:
                raise RuntimeError("Can't close the last remaining tab -- use web_open to navigate it instead.")
            pages[index].close()
            del pages[index]
            browser_worker.set_active_index(max(0, index - 1))
            return index
        closed = browser_worker.run(_do)
        return {"success": True, "message": f"Closed tab {closed}."}
    except Exception as exc:  # noqa: BLE001
        return {"success": False, "message": f"Couldn't close the tab: {exc}"}


def web_screenshot(_arg: str = "") -> dict:
    try:
        image_bytes = browser_worker.run(
            lambda: browser_worker.get_active_page().screenshot(type="jpeg", quality=80), timeout=15,
        )
        encoded = base64.b64encode(image_bytes).decode("utf-8")
        try:
            description = llm_client.describe_image(
                encoded, question="Describe what's visible on this web page screenshot in 2-3 sentences."
            )
        except Exception as exc:  # noqa: BLE001
            description = f"(screenshot taken, but couldn't describe it: {exc})"
        return {"success": True, "message": description}
    except Exception as exc:  # noqa: BLE001
        return {"success": False, "message": f"Couldn't screenshot the page: {exc}"}


# ==============================================================================
# TOOL REGISTRY ENGINE
# ==============================================================================
# A central catalog of every command Troy can run beyond the handful of
# original hand-written ones in dispatcher.py's elif chain: category, risk
# level, whether it needs confirmation, and whether it's an information-
# gathering command. dispatcher.py falls through to run() for anything not
# in its own elif chain.
#
# CONFIRMATION MODEL (see troy/confirmation.py)
# A tool marked requires_confirmation never runs on the calling thread here
# at all -- run() hands it to confirmation.request(), which returns
# immediately with a "pending" result and shows a real prompt in the UI.
# The tool's actual function only ever executes from a genuine button
# click via confirmation.resolve(). The model cannot self-confirm and
# never produces or parses any "confirm" token.

@dataclass
class ToolDefinition:
    name: str
    func: Callable[[str], dict]
    description: str
    category: str
    risk_level: str = "low"
    requires_confirmation: bool = False
    info: bool = False
    arg_hint: str = ""


_REGISTRY: dict = {}


def register(name, func, description, category, risk_level="low",
             requires_confirmation=False, info=False, arg_hint=""):
    if name in _REGISTRY:
        logger.warning("Tool registry: '%s' registered twice -- overwriting.", name)
    _REGISTRY[name] = ToolDefinition(
        name=name, func=func, description=description, category=category,
        risk_level=risk_level, requires_confirmation=requires_confirmation,
        info=info, arg_hint=arg_hint,
    )


def get(name: str):
    return _REGISTRY.get(name)


def all_tools() -> dict:
    return dict(_REGISTRY)


def by_category() -> dict:
    grouped: dict = {}
    for tool in _REGISTRY.values():
        grouped.setdefault(tool.category, []).append(tool)
    for tools in grouped.values():
        tools.sort(key=lambda t: t.name)
    return dict(sorted(grouped.items()))


def info_command_names() -> set:
    return {name for name, tool in _REGISTRY.items() if tool.info}


def run(name: str, arg: str) -> dict:
    """Executes a registered tool by name. Never raises. If the tool
    requires confirmation, this returns immediately with a pending-
    confirmation result and hands off to troy/confirmation.py instead of
    running anything."""
    tool = _REGISTRY.get(name)
    if tool is None:
        return {"success": False, "message": f"Unknown command: {name}"}

    real_arg = arg or ""

    run_ctx = task_context.current()
    if tool.requires_confirmation and run_ctx is not None:
        # Unattended scheduled run: no Approve button can be answered, so only commands the user
        # pre-approved for this exact task (name + argument) run; everything else is refused.
        if not run_ctx.allows(name, real_arg):
            run_ctx.deny(name, real_arg)
            return {"success": False, "message": (
                f"'{name}{(':' + real_arg) if real_arg else ''}' needs the user's approval and wasn't pre-approved for this scheduled task, "
                "so it did not run. Don't try another way around it: report task_result:blocked and say it needs approval.")}
        logger.info("Scheduled task %s: running pre-approved %s %s", run_ctx.task_id, name, real_arg)
    elif tool.requires_confirmation:
        pc = confirmation.request(
            name=name, arg=real_arg, risk_level=tool.risk_level, func=tool.func,
            description=f"{name} {real_arg}".strip(),
        )
        return {
            "success": False,
            "message": (
                f"'{name}' is a {tool.risk_level}-risk action. A confirmation prompt is now "
                f"showing in the app -- it will only run if the user approves it there."
            ),
            "pending_confirmation": True,
            "confirmation_id": pc.id,
        }

    try:
        result = tool.func(real_arg)
    except Exception as exc:  # noqa: BLE001
        logger.warning("Tool '%s' raised an unhandled exception: %s", name, exc)
        return {"success": False, "message": f"'{name}' failed unexpectedly: {exc}"}

    if not isinstance(result, dict) or "success" not in result or "message" not in result:
        return {"success": True, "message": str(result)}
    return result


# ==============================================================================
# TOOL REGISTRATIONS
# ==============================================================================

# ---------- coordinate targeting ----------
register("locate_on_screen", locate_on_screen, "Screenshot + vision model: returns the pixel (x, y) of a described on-screen target.",
          category="vision", info=True, arg_hint="<description>")
register("click_target", click_target, "Screenshot -> locate -> click, in one call. Use when you don't already know exact pixel coordinates.",
          category="vision", arg_hint="<description>")
register("double_click_target", double_click_target, "Screenshot -> locate -> double-click, in one call.",
          category="vision", arg_hint="<description>")

# ---------- shell / full control ----------
register("run_shell_command", run_shell_command, "Runs any shell command and returns its captured output. Real, general PC control.",
          category="system", risk_level="high", requires_confirmation=True, arg_hint="<command>")
register("get_full_system_report", get_full_system_report, "CPU, memory, disk, battery, network, and uptime in one call.",
          category="system", info=True)

# ---------- filesystem ----------
register("delete_file", delete_file, "Moves a file to the Recycle Bin (not a permanent delete).",
          category="filesystem", risk_level="high", requires_confirmation=True, arg_hint="<path>")
register("delete_folder", delete_folder, "Moves a folder (and its contents) to the Recycle Bin.",
          category="filesystem", risk_level="high", requires_confirmation=True, arg_hint="<path>")
register("rename_file", rename_file, "Renames a file in place.", category="filesystem", arg_hint="<path>|<new_name>")
register("create_folder", create_folder, "Creates a new folder.", category="filesystem", arg_hint="<path>")
register("list_folder_tree", list_folder_tree, "Lists a folder's contents recursively, capped in depth and size.",
          category="filesystem", info=True, arg_hint="<path>|<max_depth=2>")
register("get_file_info", get_file_info, "Size, created/modified dates, and type for a file or folder.",
          category="filesystem", info=True, arg_hint="<path>")
register("get_folder_size", get_folder_size, "Total size of a folder's contents.", category="filesystem", info=True, arg_hint="<path>")
register("find_large_files", find_large_files, "Lists files at or above a size threshold under a folder.",
          category="filesystem", info=True, arg_hint="<root>|<min_size_mb=100>")
register("find_duplicate_files", find_duplicate_files, "Finds files with identical content under a folder.",
          category="filesystem", info=True, arg_hint="<root>")
register("search_file_contents", search_file_contents, "Greps for text inside files under a folder.",
          category="filesystem", info=True, arg_hint="<query>|<root>")
register("get_recent_files", get_recent_files, "Most recently modified files under a folder, newest first.",
          category="filesystem", info=True, arg_hint="<root>")
register("get_file_extension_stats", get_file_extension_stats, "Counts files by extension under a folder.",
          category="filesystem", info=True, arg_hint="<root>")
register("calculate_hash", calculate_hash, "Computes a file's content hash.", category="filesystem", info=True, arg_hint="<path>|<algorithm=sha256>")
register("compare_files", compare_files, "Reports whether two files have identical content.",
          category="filesystem", info=True, arg_hint="<path_a>|<path_b>")
register("open_file", open_file, "Opens a file with its default associated application.", category="filesystem", arg_hint="<path>")
register("open_folder", open_folder, "Opens a folder in File Explorer.", category="filesystem", arg_hint="<path>")
register("reveal_file_in_explorer", reveal_file_in_explorer, "Opens File Explorer with a file pre-selected.",
          category="filesystem", arg_hint="<path>")

# ---------- archives ----------
register("create_archive", create_archive, "Creates a .zip or .tar(.gz/.bz2) archive from one or more sources.",
          category="archive", arg_hint="<archive_path>|<src1;src2;...>")
register("extract_archive", extract_archive, "Extracts a zip/tar archive to a new destination folder.",
          category="archive", arg_hint="<archive_path>|<destination>")
register("list_archive", list_archive, "Lists the entries inside a zip/tar archive.", category="archive", info=True, arg_hint="<archive_path>")
register("add_to_archive", add_to_archive, "Adds a file/folder to an existing ZIP archive.", category="archive", arg_hint="<archive_path>|<source>")
register("test_archive", test_archive, "Verifies a zip/tar archive isn't corrupted.", category="archive", info=True, arg_hint="<archive_path>")
register("compress_files", create_archive, "Alias of create_archive.", category="archive", arg_hint="<archive_path>|<src1;src2;...>")

# ---------- Windows system (power/info/paths/env) ----------
register("lock_workstation", lock_workstation, "Locks the Windows workstation.", category="system")
register("sleep_computer", sleep_computer, "Puts the computer to sleep.", category="system", risk_level="medium", requires_confirmation=True)
register("shutdown_computer", shutdown_computer, "Schedules a shutdown (default 30s delay).",
          category="system", risk_level="high", requires_confirmation=True, arg_hint="<delay_seconds=30>")
register("restart_computer", restart_computer, "Schedules a restart (default 30s delay).",
          category="system", risk_level="high", requires_confirmation=True, arg_hint="<delay_seconds=30>")
register("cancel_shutdown", cancel_shutdown, "Cancels a pending shutdown/restart.", category="system")
register("get_battery_info", get_battery_info, "Battery percentage and charging state.", category="system", info=True)
register("get_cpu_info", get_cpu_info, "CPU model and core count.", category="system", info=True)
register("get_memory_info", get_memory_info, "RAM usage.", category="system", info=True)
register("get_disk_info", get_disk_info, "Disk usage per partition.", category="system", info=True)
register("get_network_info", get_network_info, "Hostname and local IP.", category="system", info=True)
register("get_ip_address", get_ip_address, "The machine's local IP address.", category="system", info=True)
register("get_hostname", get_hostname, "The machine's hostname.", category="system", info=True)
register("get_username", get_username, "The current Windows username.", category="system", info=True)
register("get_windows_version", get_windows_version, "Windows OS version/build.", category="system", info=True)
register("get_uptime", get_uptime, "How long the machine has been running.", category="system", info=True)
register("get_environment_variable", get_environment_variable, "Reads an environment variable.",
          category="system", info=True, arg_hint="<name>")
register("set_environment_variable", set_environment_variable, "Sets an environment variable for the user.",
          category="system", risk_level="medium", requires_confirmation=True, arg_hint="<NAME>|<value>")
register("get_desktop_path", get_desktop_path, "The user's Desktop folder path.", category="system", info=True)
register("get_downloads_path", get_downloads_path, "The user's Downloads folder path.", category="system", info=True)
register("get_documents_path", get_documents_path, "The user's Documents folder path.", category="system", info=True)
register("get_pictures_path", get_pictures_path, "The user's Pictures folder path.", category="system", info=True)
register("get_music_path", get_music_path, "The user's Music folder path.", category="system", info=True)
register("get_videos_path", get_videos_path, "The user's Videos folder path.", category="system", info=True)
register("open_windows_settings", open_windows_settings, "Opens the Windows Settings app.", category="system")
register("open_control_panel", open_control_panel, "Opens the classic Control Panel.", category="system")
register("empty_recycle_bin", empty_recycle_bin, "Empties the Recycle Bin.", category="system", risk_level="high", requires_confirmation=True)

# ---------- window management ----------
register("focus_window", focus_window, "Brings a window to the foreground and restores it if minimized.", category="windows", arg_hint="<title_or_process>")
register("restore_window", restore_window, "Restores a minimized window.", category="windows", arg_hint="<title_or_process>")
register("close_window", close_window, "Sends a close request to a specific window.", category="windows", arg_hint="<title_or_process>")
register("get_window_bounds", get_window_bounds, "Position and size of a window.", category="windows", info=True, arg_hint="<title_or_process>")
register("get_window_process", get_window_process, "Which process owns a window.", category="windows", info=True, arg_hint="<title_or_process>")
register("move_window", move_window, "Moves a window to a screen position.", category="windows", arg_hint="<title_or_process>|<x>|<y>")
register("resize_window", resize_window, "Resizes a window.", category="windows", arg_hint="<title_or_process>|<width>|<height>")
register("center_window", center_window, "Centers a window on the primary monitor.", category="windows", arg_hint="<title_or_process>")
register("snap_window_left", snap_window_left, "Snaps a window to the left half of the screen.", category="windows", arg_hint="<title_or_process>")
register("snap_window_right", snap_window_right, "Snaps a window to the right half of the screen.", category="windows", arg_hint="<title_or_process>")
register("snap_window_top", snap_window_top, "Snaps a window to the top half of the screen.", category="windows", arg_hint="<title_or_process>")
register("snap_window_bottom", snap_window_bottom, "Snaps a window to the bottom half of the screen.", category="windows", arg_hint="<title_or_process>")
register("minimize_all_windows", minimize_all_windows, "Minimizes all windows (Show Desktop).", category="windows")
register("restore_all_windows", restore_all_windows, "Restores windows after Show Desktop.", category="windows")
register("get_monitors", get_monitors, "Lists connected monitors and their resolutions.", category="windows", info=True)
register("get_primary_monitor", get_primary_monitor, "Primary monitor resolution.", category="windows", info=True)
register("get_screen_resolution", get_screen_resolution, "Alias of get_primary_monitor.", category="windows", info=True)

# ---------- display / screen geometry ----------
register("take_screenshot_region", take_screenshot_region, "Saves a screenshot of a specific screen region.",
          category="display", info=True, arg_hint="<left>,<top>,<width>,<height>")
register("save_screenshot", save_screenshot, "Saves a full-screen screenshot to a path.", category="display", info=True, arg_hint="<destination_path>")
register("get_screen_size", get_screen_size, "Primary screen resolution.", category="display", info=True)
register("get_cursor_position", get_cursor_position, "Current mouse cursor position.", category="display", info=True)
register("set_cursor_position", set_cursor_position, "Moves the mouse cursor to a position.", category="display", arg_hint="<x>,<y>")
register("get_pixel_color", get_pixel_color, "Reads the RGB color of a specific screen pixel.", category="display", info=True, arg_hint="<x>,<y>")

# ---------- vision / screen understanding ----------
register("find_text_on_screen", find_text_on_screen, "OCRs the screen and reports whether specific text is visible.",
          category="vision", info=True, arg_hint="<query>")
register("compare_screenshots", compare_screenshots, "Approximate visual difference between two saved screenshots.",
          category="vision", info=True, arg_hint="<path_a>|<path_b>")
register("wait_for_screen_change", wait_for_screen_change, "Polls until the screen changes noticeably, or times out.",
          category="vision", info=True, arg_hint="<timeout_seconds=10>")

# ---------- keyboard / mouse ----------
register("double_click", double_click, "Double-clicks at a screen position.", category="input", arg_hint="<x>,<y>")
register("right_click", right_click, "Right-clicks at a screen position.", category="input", arg_hint="<x>,<y>")
register("drag_mouse", drag_mouse, "Drags the mouse from one point to another.", category="input", arg_hint="<x1>,<y1>|<x2>,<y2>")
register("mouse_down", mouse_down, "Presses and holds the left mouse button at a position.", category="input", arg_hint="<x>,<y>")
register("mouse_up", mouse_up, "Releases the left mouse button.", category="input", arg_hint="[<x>,<y>]")
register("press_keys", press_keys, "Presses a sequence of keys one at a time (not simultaneously).", category="input", arg_hint="<key1>,<key2>,...")
register("hold_key", hold_key, "Holds a key down until release_key is called.", category="input", arg_hint="<key>")
register("release_key", release_key, "Releases a key held by hold_key.", category="input", arg_hint="<key>")
register("copy_selected", copy_selected, "Copies the current selection (Ctrl+C).", category="input")
register("cut_selected", cut_selected, "Cuts the current selection (Ctrl+X).", category="input")
register("paste_clipboard", paste_clipboard, "Pastes clipboard content (Ctrl+V).", category="input")
register("select_all", select_all, "Selects all (Ctrl+A).", category="input")
register("undo", undo, "Undo (Ctrl+Z).", category="input")
register("redo", redo, "Redo (Ctrl+Y).", category="input")

# ---------- process / application control ----------
register("find_process", find_process, "Finds running processes matching a partial name.", category="process", info=True, arg_hint="<partial_name>")
register("get_process_info", get_process_info, "CPU/memory/status for a process by name or pid.", category="process", info=True, arg_hint="<name_or_pid>")
register("get_process_cpu", get_process_cpu, "Current CPU usage of a specific process.", category="process", info=True, arg_hint="<name_or_pid>")
register("get_process_memory", get_process_memory, "Current memory usage of a specific process.", category="process", info=True, arg_hint="<name_or_pid>")
register("get_process_path", get_process_path, "Executable path of a running process.", category="process", info=True, arg_hint="<name_or_pid>")
register("get_process_command_line", get_process_command_line, "Full command line of a running process.", category="process", info=True, arg_hint="<name_or_pid>")
register("is_process_running", is_process_running, "Whether a process with this name is currently running.", category="process", info=True, arg_hint="<name>")
register("start_process", start_process, "Launches an executable, optionally with arguments.", category="process", arg_hint="<executable [args...]>")
register("restart_process", restart_process, "Kills every instance of a process, then relaunches it.", category="process", risk_level="medium", arg_hint="<name>")
register("wait_for_process", wait_for_process, "Polls until a process appears, or times out.", category="process", info=True, arg_hint="<name>|<timeout_seconds=20>")
register("wait_for_process_exit", wait_for_process_exit, "Polls until a process exits, or times out.", category="process", info=True, arg_hint="<name>|<timeout_seconds=30>")
register("open_app_with_arguments", open_app_with_arguments, "Opens an app with specific launch arguments.", category="process", arg_hint="<executable>|<arguments>")
register("open_file_with_app", open_file_with_app, "Opens a specific file using a specific application.", category="process", arg_hint="<app>|<file_path>")

# ---------- network ----------
register("ping_host", ping_host, "Pings a host and reports reachability.", category="network", info=True, arg_hint="<host>")
register("dns_lookup", dns_lookup, "Resolves a hostname to an IP address.", category="network", info=True, arg_hint="<hostname>")
register("resolve_hostname", resolve_hostname, "Alias of dns_lookup.", category="network", info=True, arg_hint="<hostname>")
register("check_port", check_port, "Checks whether a TCP port is open on a host.", category="network", info=True, arg_hint="<host>|<port>")
register("get_local_ip", get_local_ip, "The machine's LAN IP address.", category="network", info=True)

def open_in_browser(arg: str) -> dict:
    """'<browser>|<url>': opens a link in a NEW TAB of a specific browser."""
    parts = [x.strip() for x in (arg or "").split("|", 1)]
    if len(parts) != 2 or not parts[1]:
        return {"success": False, "message": "open_in_browser needs '<browser>|<url>', e.g. firefox|https://example.com."}
    from . import app_launcher
    return app_launcher.launch_browser_url(parts[1], parts[0])


register("open_in_browser", open_in_browser, "Opens a link in a new tab of a specific browser (firefox, chrome, edge, brave) instead of the default one.",
          category="network", arg_hint="<browser>|<url>")

# ---------- Troy's own brain: look at, switch and reset the model mid-chat ----------
def _speed_class(model: str) -> str:
    """'fast', 'strong' or '' from the model's name: parameter count (20b vs 120b)
    and well-known size words. A heuristic, but it's only used to pick a sensible
    default for 'switch to a faster/stronger model'."""
    low = model.lower()
    if any(w in low for w in ("flash", "lightning", "mini", "small", "instant", "haiku", "nano", "tiny")):
        return "fast"
    m = re.search(r"(?<![\d.])(\d+(?:\.\d+)?)b(?![a-z])", low)
    if m:
        size = float(m.group(1))
        return "fast" if size <= 32 else "strong" if size >= 70 else ""
    if any(w in low for w in ("super", "pro", "opus", "sonnet", "kimi", "glm-5.3", "large", "ultra")):
        return "strong"
    return ""


def _model_tags(provider_id: str, model: str, vision: bool) -> str:
    tags = [t for t in (_speed_class(model),) if t]
    if provider_id == "lmstudio":
        tags.append("local")
    if vision:
        tags.append("vision")
    return f" [{', '.join(tags)}]" if tags else ""


def _provider_view():
    from . import llm_client, settings_store
    out = []
    for pid, (label, secret) in settings_store.PROVIDERS.items():
        ready = config.LMSTUDIO_ENABLED if secret is None else bool(getattr(config, secret, ""))
        if not ready:
            continue
        text = list(llm_client._models_for(pid, "text"))
        vision = set(llm_client._models_for(pid, "vision"))
        out.append((pid, label, text, vision))
    return out


def current_model(_arg: str = "") -> dict:
    """Which provider/model Troy is thinking with right now."""
    override = config.TEXT_MODEL_OVERRIDE
    prim = config.PRIMARY_PROVIDER
    if override:
        return {"success": True, "message": f"Pinned to {override} (provider order starts with {prim}). Vision: {config.VISION_MODEL_OVERRIDE or 'automatic'}."}
    return {"success": True, "message": f"Automatic: {prim} first, trying its models in order. Vision: {config.VISION_MODEL_OVERRIDE or 'automatic'}."}


def list_models(_arg: str = "") -> dict:
    """The models Troy can switch to (only providers that are set up)."""
    view = _provider_view()
    if not view:
        return {"success": False, "message": "No AI provider is set up."}
    lines = []
    for pid, label, text, vision in view:
        items = " | ".join(f"{m}{_model_tags(pid, m, m in vision)}" for m in text[:14])
        vision_only = [m for m in sorted(vision) if m not in text]
        extra = f" ; vision models: {', '.join(vision_only)}" if vision_only else ""
        lines.append(f"{pid} ({label}){' *current provider*' if pid == config.PRIMARY_PROVIDER else ''}: {items}{extra}")
    return {"success": True, "message": " || ".join(lines) + "  -- switch with set_model:<model> or set_model:<provider>|<model>"}


def _resolve_model(query: str):
    """'fast' | 'strong' | 'local' | 'vision' | a (partial) model name | provider|model -> (provider, model)."""
    from . import llm_client
    query = (query or "").strip()
    provider_hint = ""
    if "|" in query:
        provider_hint, query = [x.strip().lower() for x in query.split("|", 1)]
    view = [v for v in _provider_view() if not provider_hint or v[0] == provider_hint]
    if provider_hint and not view:
        raise ValueError(f"'{provider_hint}' isn't a provider that's set up. Providers: {', '.join(v[0] for v in _provider_view()) or 'none'}.")
    key = query.lower()
    candidates = [(pid, m, m in vision) for pid, _l, text, vision in view for m in text]
    if not candidates:
        raise ValueError("No models available.")
    if key in ("fast", "faster", "quick", "quickest", "fastest"):
        pool = [c for c in candidates if _speed_class(c[1]) == "fast"]
        pool = pool or candidates
        prefer = [c for c in pool if c[0] == config.PRIMARY_PROVIDER] or pool
        return prefer[0][0], prefer[0][1]
    if key in ("strong", "smart", "smartest", "best", "powerful", "stronger"):
        pool = [c for c in candidates if _speed_class(c[1]) == "strong"] or candidates
        prefer = [c for c in pool if c[0] == config.PRIMARY_PROVIDER] or pool
        return prefer[0][0], prefer[0][1]
    if key in ("local", "offline", "private"):
        pool = [c for c in candidates if c[0] == "lmstudio"]
        if not pool:
            raise ValueError("LM Studio isn't enabled, so there's no local model to switch to.")
        return pool[0][0], pool[0][1]
    exact = [c for c in candidates if c[1].lower() == key]
    parts = [c for c in candidates if key and key in c[1].lower()]
    pick = (exact or parts or [None])[0]
    if pick is None:
        import difflib
        names = [c[1].lower() for c in candidates]
        close = difflib.get_close_matches(key, names, n=1, cutoff=0.55)
        if close:
            pick = next(c for c in candidates if c[1].lower() == close[0])
    if pick is None:
        raise ValueError(f"No model matching '{query}'. Use list_models to see the choices.")
    return pick[0], pick[1]


def set_model(arg: str) -> dict:
    """Changes Troy's own model for the rest of this chat (and beyond: it's saved,
    like picking one in the UI). Takes a model name, 'provider|model', or a goal:
    fast, strong, local."""
    from . import confirmation, settings_store
    if not config.ALLOW_MODEL_SWITCH:
        return {"success": False, "message": "Changing my own model is turned off in Settings > Models. Ask the user to switch it or enable it."}
    try:
        pid, model = _resolve_model(arg)
    except ValueError as exc:
        return {"success": False, "message": str(exc)}
    if config.PRIMARY_PROVIDER == pid and config.TEXT_MODEL_OVERRIDE == f"{pid}:{model}":
        return {"success": True, "message": f"Already using {pid} / {model}."}

    def apply(_a=""):
        settings_store.apply_settings({"PRIMARY_PROVIDER": pid, "TEXT_MODEL_OVERRIDE": f"{pid}:{model}"})
        settings_store.notify({"PRIMARY_PROVIDER", "TEXT_MODEL_OVERRIDE"}, "troy")
        return {"success": True, "message": f"Switched my brain to {pid} / {model}. It applies from my next thought."}

    leaving_local = config.PRIMARY_PROVIDER == "lmstudio" and pid != "lmstudio" and config.LMSTUDIO_ENABLED
    if leaving_local:
        # a local model was chosen for privacy: going to the cloud sends the chat off this PC
        confirmation.request("set_model", arg, "medium", apply,
                             f"Switch from your local model to the cloud model {pid} / {model}? Your conversation would be sent to {pid}.")
        return {"success": True, "pending": True, "message": f"Asked the user to approve switching from the local model to the cloud model {pid} / {model}."}
    return apply()


def reset_model(_arg: str = "") -> dict:
    """Back to automatic model choice (the provider order decides)."""
    from . import settings_store
    if not config.ALLOW_MODEL_SWITCH:
        return {"success": False, "message": "Changing my own model is turned off in Settings > Models."}
    settings_store.apply_settings({"TEXT_MODEL_OVERRIDE": ""})
    settings_store.notify({"TEXT_MODEL_OVERRIDE"}, "troy")
    return {"success": True, "message": f"Model choice is automatic again (starting with {config.PRIMARY_PROVIDER})."}


def set_vision_model(arg: str) -> dict:
    """Picks the model used when looking at the screen (must be a vision model)."""
    from . import llm_client, settings_store
    if not config.ALLOW_MODEL_SWITCH:
        return {"success": False, "message": "Changing my own model is turned off in Settings > Models."}
    try:
        pid, model = _resolve_model(arg)
    except ValueError:
        # the text list may not contain a vision-only model: search the vision lists
        key = (arg or "").split("|")[-1].strip().lower()
        found = [(p, m) for p, _l, _t, vis in _provider_view() for m in vis if key and key in m.lower()]
        if not found:
            return {"success": False, "message": f"No vision model matching '{arg}'."}
        pid, model = found[0]
    if model not in llm_client._models_for(pid, "vision"):
        return {"success": False, "message": f"{model} can't see images. Vision models: " + ", ".join(m for _p, _l, _t, vis in _provider_view() for m in vis) + "."}
    settings_store.apply_settings({"VISION_MODEL_OVERRIDE": f"{pid}:{model}"})
    settings_store.notify({"VISION_MODEL_OVERRIDE"}, "troy")
    return {"success": True, "message": f"I'll use {pid} / {model} when I look at the screen."}


register("current_model", current_model, "Which model Troy is thinking with right now.", category="model", info=True)
register("list_models", list_models, "The models Troy can switch to, tagged fast/strong/local/vision.", category="model", info=True)
register("set_model", set_model, "Changes Troy's OWN model mid-chat (name, provider|model, or goal: fast, strong, local). Use only when asked, or when the task clearly needs a faster/stronger/local model. Applies from the next thought.", category="model", arg_hint="<model|provider|model|fast|strong|local>")
register("reset_model", reset_model, "Returns Troy to automatic model choice.", category="model")
register("set_vision_model", set_vision_model, "Chooses the model used when Troy looks at the screen (must support images).", category="model", arg_hint="<model>")

# ---------- searching past conversations ----------
def search_chats(arg: str) -> dict:
    """Finds earlier conversations by title or message text -- how Troy answers
    'what did we talk about regarding X?' or 'find the chat where ...'."""
    from . import sessions
    parts = split_args(arg)
    query = parts[0].strip() if parts else ""
    if not query:
        return {"success": False, "message": "search_chats needs something to look for."}
    found = sessions.search_sessions(query, limit=5, per_chat=2)
    if not found["results"]:
        return {"success": False, "message": f"No past chats mention '{query}'."}
    lines = []
    for r in found["results"]:
        when = r["updated_at"][:10]
        snippets = " / ".join(f"{h['role']}: {h['snippet']}" for h in r["hits"])
        lines.append(f"'{r['title']}' ({when}){' ' + snippets if snippets else ' [title match]'}")
    more = f" (+{found['total_chats'] - len(found['results'])} more chats)" if found["total_chats"] > len(found["results"]) else ""
    return {"success": True, "message": f"{found['total_chats']} chat(s) match: " + " || ".join(lines) + more}


register("search_chats", search_chats, "Searches Troy's saved past conversations (titles and messages) for a word or phrase.",
          category="memory", info=True, arg_hint="<words to find>")

# ---------- YouTube (OAuth 2.0; see troy/youtube.py) ----------
def _yt_call(fn):
    """Runs a youtube.py call, turning its user-readable errors into a tool result."""
    from . import youtube
    try:
        return fn(youtube)
    except youtube.YouTubeError as exc:
        return {"success": False, "message": str(exc)}


def _yt_n(text: str, default: int = 5, cap: int = 25) -> int:
    try:
        return max(1, min(cap, int(str(text).strip())))
    except ValueError:
        return default


def _fmt_videos(videos: list) -> str:
    return " | ".join(f"{i}. {v['title']} -- {v['channel']} ({v['added_at'][:10]}) {v['url']}" for i, v in enumerate(videos, 1))


def youtube_status(_arg: str = "") -> dict:
    def go(yt):
        s = yt.status()
        if not s["configured"]:
            return {"success": False, "message": "YouTube isn't set up: the Google OAuth client id/secret are missing (Settings > Integrations)."}
        if not s["connected"]:
            return {"success": False, "message": "YouTube isn't connected yet. Press Connect YouTube in Settings > Integrations."}
        return {"success": True, "message": f"YouTube is connected as '{s['channel']['title']}'." if s["channel"] else f"YouTube is connected ({s['error'] or 'channel unknown'})."}
    return _yt_call(go)


def youtube_liked(arg: str = "") -> dict:
    n = _yt_n(arg)
    def go(yt):
        videos = yt.liked_videos(n)
        return {"success": True, "message": "Liked videos, newest first: " + _fmt_videos(videos)} if videos else {"success": False, "message": "No liked videos found."}
    return _yt_call(go)


def youtube_playlists(_arg: str = "") -> dict:
    def go(yt):
        lists = yt.my_playlists()
        listing = " | ".join(f"{p['title']} ({p['count']})" for p in lists) or "none"
        return {"success": True, "message": f"Your playlists: {listing}. Also: Liked videos."}
    return _yt_call(go)


def youtube_playlist_items(arg: str) -> dict:
    parts = split_args(arg)
    name = parts[0] if parts else "liked"
    n = _yt_n(parts[1]) if len(parts) > 1 else 5
    def go(yt):
        pid, title = yt.resolve_playlist(name)
        videos = yt.playlist_items(pid, n)
        return {"success": True, "message": f"{title}, newest added first: " + _fmt_videos(videos)} if videos else {"success": False, "message": f"'{title}' is empty."}
    return _yt_call(go)


def youtube_latest(arg: str = "liked") -> dict:
    def go(yt):
        v = yt.latest_in_playlist(arg or "liked")
        return {"success": True, "message": f"Most recently added to '{v['playlist']}': {v['title']} -- {v['channel']} (added {v['added_at'][:10]}) {v['url']}"}
    return _yt_call(go)


def youtube_open_latest(arg: str = "liked") -> dict:
    """Finds the newest video of a playlist (default: Liked videos) and opens it in a new Firefox tab."""
    def go(yt):
        v = yt.latest_in_playlist(arg or "liked")
        opened = yt.open_url(v["url"])
        return {"success": opened["success"], "message": f"{opened['message']} It's '{v['title']}' by {v['channel']} (most recently added to '{v['playlist']}')."}
    return _yt_call(go)


def youtube_search(arg: str) -> dict:
    parts = split_args(arg)
    query = parts[0].strip() if parts else ""
    if not query:
        return {"success": False, "message": "youtube_search needs a query."}
    n = _yt_n(parts[1]) if len(parts) > 1 else 5
    def go(yt):
        videos = yt.search_videos(query, n)
        return {"success": True, "message": "Results: " + _fmt_videos(videos)} if videos else {"success": False, "message": f"No YouTube results for '{query}'."}
    return _yt_call(go)


def youtube_open_video(arg: str) -> dict:
    """A video link or id opens directly; anything else is searched and the top hit opens."""
    arg = (arg or "").strip()
    if not arg:
        return {"success": False, "message": "youtube_open_video needs a link, a video id, or a search."}
    def go(yt):
        vid = yt.parse_video_id(arg)
        if vid:
            return yt.open_url(yt._video_url(vid))
        hits = yt.search_videos(arg, 1)
        if not hits:
            return {"success": False, "message": f"No YouTube results for '{arg}'."}
        opened = yt.open_url(hits[0]["url"])
        return {"success": opened["success"], "message": f"{opened['message']} It's '{hits[0]['title']}' by {hits[0]['channel']}."}
    return _yt_call(go)


def youtube_subscriptions(arg: str = "") -> dict:
    n = _yt_n(arg, 10, 50)
    def go(yt):
        subs = yt.subscriptions(n)
        return {"success": True, "message": "Subscriptions: " + ", ".join(s["title"] for s in subs)} if subs else {"success": False, "message": "No subscriptions found."}
    return _yt_call(go)


def youtube_video_info(arg: str) -> dict:
    def go(yt):
        vid = yt.parse_video_id(arg)
        if not vid:
            return {"success": False, "message": "That doesn't look like a YouTube link or video id."}
        v = yt.video_info(vid)
        return {"success": True, "message": f"{v['title']} -- {v['channel']}, {v['duration']}, {v['views']} views, published {v['published']}. {v['description']} {v['url']}"}
    return _yt_call(go)


register("youtube_status", youtube_status, "Whether YouTube is connected (OAuth) and as which channel.", category="youtube", info=True)
register("youtube_liked", youtube_liked, "Your most recently liked YouTube videos, newest first.", category="youtube", info=True, arg_hint="<count=5>")
register("youtube_playlists", youtube_playlists, "Lists your YouTube playlists.", category="youtube", info=True)
register("youtube_playlist_items", youtube_playlist_items, "Videos of one of your playlists (or 'liked'), newest added first.", category="youtube", info=True, arg_hint="<playlist name>|<count=5>")
register("youtube_latest", youtube_latest, "The most recently added video of a playlist (default: Liked videos); returns its link without opening it.", category="youtube", info=True, arg_hint="<playlist name=liked>")
register("youtube_open_latest", youtube_open_latest, "Opens the most recently added video of a playlist (default: Liked videos) in a new Firefox tab. Use for 'open the last video I liked'.", category="youtube", arg_hint="<playlist name=liked>")
register("youtube_search", youtube_search, "Searches YouTube; returns titles and links.", category="youtube", info=True, arg_hint="<query>|<count=5>")
register("youtube_open_video", youtube_open_video, "Opens a YouTube video (link, id, or a search whose top result is used) in a new Firefox tab.", category="youtube", arg_hint="<link|id|search>")
register("youtube_subscriptions", youtube_subscriptions, "The channels you subscribe to.", category="youtube", info=True, arg_hint="<count=10>")
register("youtube_video_info", youtube_video_info, "Title, channel, length, views and description of a YouTube video.", category="youtube", info=True, arg_hint="<link|id>")

# ---------- public web APIs (Open-Meteo / Frankfurter / Wikipedia / NewsAPI) ----------
register("geocode_place", geocode_place, "Open-Meteo: looks up a place's latitude/longitude/timezone.",
          category="api", info=True, arg_hint="<place>")
register("get_weather_forecast", get_weather_forecast, "Open-Meteo: multi-day forecast (temps, rain, wind) for a place. Use get_weather for just right-now conditions.",
          category="api", info=True, arg_hint="<place>|<days=3>")
register("convert_currency", convert_currency, "Frankfurter (ECB rates): converts an amount between two currencies.",
          category="api", info=True, arg_hint="<amount>|<from>|<to>")
register("get_exchange_rates", get_exchange_rates, "Frankfurter: latest rates for a base currency, optionally filtered to a comma-separated list.",
          category="api", info=True, arg_hint="<base=EUR>|<USD,GBP,...>")
register("get_historical_rate", get_historical_rate, "Frankfurter: the exchange rate on a past date.",
          category="api", info=True, arg_hint="<YYYY-MM-DD>|<from>|<to>")
register("list_currencies", list_currencies, "Frankfurter: every supported currency code and name.",
          category="api", info=True)
register("wikipedia_search", wikipedia_search, "Searches Wikipedia; returns matching article titles with snippets.",
          category="api", info=True, arg_hint="<query>|<max_results=5>")
register("wikipedia_summary", wikipedia_summary, "Wikipedia article summary by title or loose topic text (falls back to the top search hit).",
          category="api", info=True, arg_hint="<topic_or_title>")
register("news_top_headlines", news_top_headlines, "NewsAPI: current top headlines (needs TROY_NEWSAPI_KEY). All parts optional.",
          category="api", info=True, arg_hint="<country=us>|<category>|<keyword>")
register("news_search", news_search, "NewsAPI: searches recent news articles by keyword (needs TROY_NEWSAPI_KEY).",
          category="api", info=True, arg_hint="<keywords>|<language=en>|<sortBy=publishedAt>")
register("get_public_ip", get_public_ip, "The machine's public-facing IP address.", category="network", info=True)
register("get_network_adapters", get_network_adapters, "Active network adapters and their IPs.", category="network", info=True)
register("get_wifi_info", get_wifi_info, "Current Wi-Fi connection details.", category="network", info=True)
register("get_wifi_networks", get_wifi_networks, "Wi-Fi networks visible nearby.", category="network", info=True)
register("check_internet_connection", check_internet_connection, "Whether the internet is currently reachable.", category="network", info=True)
register("download_file", download_file, "Downloads a URL to a local file (200 MB cap).", category="network", arg_hint="<url>|<destination_path>")
register("get_url_status", get_url_status, "HTTP status code for a URL.", category="network", info=True, arg_hint="<url>")
register("fetch_url", fetch_url, "Fetches a URL's text content (capped).", category="network", info=True, arg_hint="<url>")
register("get_url_headers", get_url_headers, "HTTP response headers for a URL.", category="network", info=True, arg_hint="<url>")

# ---------- JSON / CSV data ----------
register("read_json", read_json, "Reads and pretty-prints a JSON file (capped).", category="data", info=True, arg_hint="<path>")
register("write_json", write_json, "Writes JSON text to a new file.", category="data", arg_hint="<path>|<json_text>")
register("query_json", query_json, "Looks up a value in a JSON file by dotted path.", category="data", info=True, arg_hint="<path>|<dotted.path>")
register("merge_json", merge_json, "Shallow-merges two JSON objects into a new file.", category="data", arg_hint="<path_a>|<path_b>|<output_path>")
register("validate_json", validate_json, "Validates raw JSON text.", category="data", info=True, arg_hint="<json_text>")
register("read_csv", read_csv, "Reads the first N rows of a CSV file.", category="data", info=True, arg_hint="<path>|<max_rows=20>")
register("write_csv", write_csv, "Writes rows to a new CSV file.", category="data", arg_hint="<path>|<row1col1,row1col2;row2col1,row2col2>")
register("search_csv", search_csv, "Finds rows in a CSV file containing a search term.", category="data", info=True, arg_hint="<path>|<query>")
register("get_csv_stats", get_csv_stats, "Row/column counts and headers for a CSV file.", category="data", info=True, arg_hint="<path>")

# ---------- images ----------
register("get_image_info", get_image_info, "Dimensions, format, and size of an image.", category="image", info=True, arg_hint="<path>")
register("resize_image", resize_image, "Resizes an image to exact dimensions.", category="image", arg_hint="<source>|<destination>|<width>|<height>")
register("crop_image", crop_image, "Crops an image to a bounding box.", category="image", arg_hint="<source>|<destination>|<left>|<top>|<right>|<bottom>")
register("rotate_image", rotate_image, "Rotates an image by a number of degrees.", category="image", arg_hint="<source>|<destination>|<degrees>")
register("convert_image", convert_image, "Converts an image to a different format.", category="image", arg_hint="<source>|<destination>")
register("compress_image", compress_image, "Re-saves an image at reduced quality/size.", category="image", arg_hint="<source>|<destination>|<quality=75>")
register("compare_images", compare_images, "Approximate visual difference between two images.", category="image", info=True, arg_hint="<path_a>|<path_b>")
register("create_thumbnail", create_thumbnail, "Creates a small thumbnail preserving aspect ratio.", category="image", arg_hint="<source>|<destination>|<max_size=256>")

# ---------- notifications ----------
register("show_notification", show_notification, "Shows a native Windows tray notification.", category="notifications", arg_hint="<title>|<message>")
register("show_task_complete_notification", show_task_complete_notification, "Shows a 'task complete' notification.",
          category="notifications", arg_hint="<message>")
register("show_error_notification", show_error_notification, "Shows an 'attention needed' notification.",
          category="notifications", arg_hint="<message>")

# ---------- web research tools (invisible, Playwright-driven -- NOT the
# user's own browser; see the WEB RESEARCH TOOLS section of system_prompt.py
# for how this is disambiguated from open_app/open_url) ----------
register("web_open", web_open, "Navigates Troy's own background research browser to a URL (launches it on first use).",
          category="web", arg_hint="<url>")
register("web_click", web_click, "Clicks an element on the current research-browser page by its visible text/label or a CSS selector.",
          category="web", arg_hint="<text_or_selector>")
register("web_type", web_type, "Clicks a field by label/placeholder/selector and types text into it.",
          category="web", arg_hint="<field>|<text>")
register("web_read_page", web_read_page, "Returns the page title, URL, and visible text content.",
          category="web", info=True)
register("web_get_links", web_get_links, "Lists visible links (text -> href) on the current page.",
          category="web", info=True)
register("web_press_key", web_press_key, "Presses a keyboard key in the page (e.g. Enter, Tab, Escape).",
          category="web", arg_hint="<key>")
register("web_scroll", web_scroll, "Scrolls the page vertically by a pixel amount.",
          category="web", arg_hint="<pixels=600>")
register("web_wait_for_text", web_wait_for_text, "Waits until specific text becomes visible on the page, or times out.",
          category="web", info=True, arg_hint="<text>|<timeout_seconds=10>")
register("web_get_url", web_get_url, "The current research-browser page's URL.", category="web", info=True)
register("web_go_back", web_go_back, "Research browser's back button.", category="web")
register("web_reload", web_reload, "Reloads the current page.", category="web")
register("web_new_tab", web_new_tab, "Opens a new tab, optionally navigating it to a URL, and makes it active.",
          category="web", arg_hint="[<url>]")
register("web_list_tabs", web_list_tabs, "Lists open tabs with their index, URL, and title.",
          category="web", info=True)
register("web_switch_tab", web_switch_tab, "Makes a specific tab (by index from web_list_tabs) active.",
          category="web", arg_hint="<index>")
register("web_close_tab", web_close_tab, "Closes a tab by index (defaults to the active one).",
          category="web", arg_hint="[<index>]")
register("web_screenshot", web_screenshot, "Screenshots the current page and describes it -- use web_read_page first; this is a fallback for visual-only content.",
          category="web", info=True)

# ---------- desktop UI inspection (real accessibility tree, not vision) ----------
register("inspect_window", ui_automation.inspect_window, "Reads a window's real UI control tree -- actual element types, names, ids, positions, and enabled state. query=\"\" inspects the foreground window.",
          category="desktop", info=True, arg_hint="[<window_title>]")
register("click_element", ui_automation.click_element, "Clicks a real UI element by its accessible name -- reliable for native apps, no pixel guessing.",
          category="desktop", arg_hint="<element>[|<window_title>]")
register("type_into_element", ui_automation.type_into_element, "Sets text on a real UI element by its accessible name (via the accessibility Value pattern where possible).",
          category="desktop", arg_hint="<element>|<text>[|<window_title>]")
register("get_foreground_window_info", ui_automation.get_foreground_window_info, "Name, window class, and exact bounding box of whatever currently has focus.",
          category="desktop", info=True)

# Troy's control over its own app (widget, new chat, settings, power saving): registers its tools on import.
from . import tools_app  # noqa: E402,F401
# Scheduled tasks (schedule_task, list_tasks, ...): registers its tools on import.
from . import tools_tasks  # noqa: E402,F401
# On-demand extra tools (list_extra_tools): registers its tool on import.
from . import extra_tools  # noqa: E402,F401
