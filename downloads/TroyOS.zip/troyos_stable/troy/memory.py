"""
Troy Assistant - Long-Term Memory

An append-only JSON file at troy_memory.json (project root -- see
config.PROJECT_ROOT, this used to be a relative path and could silently
point at the wrong file depending on where Troy was launched from).

Two ways memories reach the model:
  1. PASSIVE: agent.py loads every stored fact once when it starts and
     injects it straight into the system prompt as "things Troy already
     knows about you." This is what actually makes memory feel like it
     works -- Troy doesn't have to guess to go look something up, it
     already has it, the same way you don't "recall" your own name.
  2. ACTIVE: the `remember:<fact>` / `recall:<query>` commands, for facts
     added mid-conversation or explicit searches over a large history.

Recall uses simple keyword/substring overlap, not embeddings -- good
enough for a personal assistant with a few hundred facts, upgradeable to a
vector store later without changing the calling code.
"""

import json
import os
from datetime import datetime

from . import config


def _load():
    if not os.path.exists(config.MEMORY_FILE):
        return []
    with open(config.MEMORY_FILE, "r", encoding="utf-8") as f:
        try:
            return json.load(f)
        except json.JSONDecodeError:
            return []


def _save(entries):
    os.makedirs(os.path.dirname(config.MEMORY_FILE), exist_ok=True)
    with open(config.MEMORY_FILE, "w", encoding="utf-8") as f:
        json.dump(entries, f, indent=2, ensure_ascii=False)


def remember(fact: str) -> str:
    fact = fact.strip()
    if not fact:
        return "Nothing to remember -- empty fact."
    entries = _load()
    entries.append({"timestamp": datetime.now().isoformat(timespec="seconds"), "fact": fact})
    _save(entries)
    return f"Remembered: {fact}"


def _matches(query_words: set, fact_lower: str, fact_words: set) -> int:
    """Returns a match score: keyword overlap, plus credit for substring hits
    that pure word-splitting would miss (e.g. query 'firefox' vs fact
    containing 'Firefox,')."""
    score = len(query_words & fact_words)
    for qw in query_words:
        if len(qw) >= 4 and qw in fact_lower:
            score += 1
    return score


def recall(query: str, limit: int = 5) -> str:
    entries = _load()
    if not entries:
        return "Memory is empty -- nothing has been remembered yet."

    query = query.strip()
    if not query:
        # No query -- just return the most recent facts
        recent = [e["fact"] for e in entries[-limit:]]
        return "Most recent memories: " + " | ".join(recent)

    query_words = set(query.lower().split())
    scored = []
    for entry in entries:
        fact_lower = entry["fact"].lower()
        fact_words = set(fact_lower.split())
        score = _matches(query_words, fact_lower, fact_words)
        if score > 0:
            scored.append((score, entry))

    scored.sort(key=lambda pair: pair[0], reverse=True)
    top = [entry["fact"] for _, entry in scored[:limit]]

    if not top:
        return "No matching memories found."
    return "Relevant memories: " + " | ".join(top)


def all_memories() -> list:
    """Full list of {"timestamp": ..., "fact": ...} dicts, oldest first."""
    return _load()


def recent_memories(limit: int = None) -> list:
    entries = _load()
    if limit is None:
        limit = config.MAX_MEMORIES_IN_CONTEXT
    return entries[-limit:]


def delete_memory(index: int) -> bool:
    """Deletes by position in all_memories() (0 = oldest). Returns True if deleted."""
    entries = _load()
    if 0 <= index < len(entries):
        entries.pop(index)
        _save(entries)
        return True
    return False


def clear_all() -> int:
    """Deletes every stored memory. Returns how many were removed."""
    entries = _load()
    count = len(entries)
    _save([])
    return count
