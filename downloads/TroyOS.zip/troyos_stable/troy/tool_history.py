"""
Native function calling, part 2: the conversation history.

In the text protocol the history is plain role/content messages: Troy's reply is the commands it wrote
(`speak:On it.` / `open_app:firefox` / `done`) and each result comes back as a user message starting
`[OBSERVATION]`. With native calling the history has the API's own shapes:

    {"role": "assistant", "content": "On it.", "tool_calls": [{"id", "type": "function", "function": {"name", "arguments": "<json>"}}]}
    {"role": "tool", "tool_call_id": "<id>", "content": "<result>"}

Three problems this module solves, each of which breaks a request with a 400 if gotten wrong:

  1. PAIRING. Every tool call must be answered by exactly one tool message before the next user/assistant
     message. A stop mid-batch, a crash, or trimming the history can break that. `repair()` fixes any history
     (it is run on every request), so a broken pairing can never reach the API.
  2. SWITCHING. Troy can change its own model mid-chat, and the fallback chain can land on a model without tool
     support. `to_text()` flattens native history into the text protocol; `to_native()` turns old text-protocol
     history (sessions saved before this feature) into plain conversation. Nothing is lost that a model needs.
  3. THE WIRE. Our messages carry a few private keys (fmt, ok, arg, name); `to_wire()` strips them.

Native messages made by Troy are marked "fmt": "n" so a natural-language answer that happens to look like a
command line ("sure: here you go") is never mistaken for a text-protocol reply.
"""
import json
import uuid

from .command_parser import parse_commands

NATIVE = "n"
_PRIVATE = ("fmt", "ok", "arg", "name")


def new_call_id() -> str:
    return "call_" + uuid.uuid4().hex[:12]


def is_native(m: dict) -> bool:
    return m.get("role") == "tool" or bool(m.get("tool_calls")) or m.get("fmt") == NATIVE


def assistant_message(text: str, calls: list) -> dict:
    """`calls`: [{"id", "name", "arguments": <json str>}]. Content is kept as given ("" when there is none)."""
    m = {"role": "assistant", "content": text or "", "fmt": NATIVE}
    if calls:
        m["tool_calls"] = [{"id": c["id"], "type": "function", "function": {"name": c["name"], "arguments": c.get("arguments") or "{}"}} for c in calls]
    return m


def tool_message(call_id: str, name: str, content: str, ok: bool = True, arg: str = "") -> dict:
    return {"role": "tool", "tool_call_id": call_id, "name": name, "content": content, "ok": bool(ok), "arg": arg, "fmt": NATIVE}


# ---------------------------------------------------------------- 1. pairing
def repair(messages: list) -> list:
    """A NEW list in which every assistant tool call is answered by one tool message directly after it, and no tool
    message is left without its call. Missing answers become '(no result: interrupted)'."""
    out: list = []
    pending: dict = {}                    # id -> name, for the assistant message currently being answered

    def flush():
        for cid, (name, arg) in list(pending.items()):
            out.append(tool_message(cid, name, "(no result: the action was interrupted before it finished)", ok=False, arg=arg))
        pending.clear()

    seen_ids: set = set()
    for m in messages:
        role = m.get("role")
        if role == "tool":
            cid = m.get("tool_call_id")
            if cid in pending:
                pending.pop(cid)
                out.append(m)
            continue                     # an orphan tool message: drop it
        flush()
        if role == "assistant" and m.get("tool_calls"):
            m = dict(m)
            fixed = []
            for tc in m["tool_calls"]:
                tc = dict(tc)
                if not tc.get("id") or tc["id"] in seen_ids:
                    tc["id"] = new_call_id()
                seen_ids.add(tc["id"])
                fn = dict(tc.get("function") or {})
                fn["arguments"] = fn.get("arguments") if isinstance(fn.get("arguments"), str) and fn.get("arguments") else "{}"
                tc["function"] = fn
                tc["type"] = "function"
                fixed.append(tc)
                try:
                    arg = json.loads(fn["arguments"])
                    arg = "" if not isinstance(arg, dict) else "|".join(str(v) for v in arg.values())
                except ValueError:
                    arg = ""
                pending[tc["id"]] = (fn.get("name", ""), arg)
            m["tool_calls"] = fixed
        out.append(m)
    flush()
    return out


# ---------------------------------------------------------------- 3. the wire
def to_wire(messages: list, keep_tool_name: bool = False) -> list:
    """What is actually sent to the provider: standard keys only."""
    out = []
    for m in messages:
        w = {k: v for k, v in m.items() if k not in _PRIVATE}
        if keep_tool_name and m.get("role") == "tool" and m.get("name"):
            w["name"] = m["name"]
        if w.get("role") == "assistant" and w.get("tool_calls") and not w.get("content"):
            w.pop("content", None)       # content may be omitted when there are tool calls; an empty string is rejected by some servers
        out.append(w)
    return out


# ---------------------------------------------------------------- 2a. native -> text protocol
def _arg_of(tc: dict) -> str:
    from . import tool_schema
    fn = tc.get("function") or {}
    name = fn.get("name", "")
    try:
        args = json.loads(fn.get("arguments") or "{}")
        return tool_schema.call_to_command(name, args)[1]
    except Exception:  # noqa: BLE001 - history conversion must never fail
        return str(fn.get("arguments") or "")[:200]


def to_text(messages: list) -> list:
    """Native history -> the text protocol. Text-protocol messages pass through unchanged."""
    messages = repair(messages)
    out: list = []
    obs: list = []

    def flush_obs():
        if obs:
            out.append({"role": "user", "content": "\n".join(obs)})
            obs.clear()

    for m in messages:
        if m.get("role") == "tool":
            status = "OK" if m.get("ok", True) else "FAILED"
            obs.append(f"[OBSERVATION] {m.get('name', '')}:{(m.get('arg') or '')[:200]} -> {status} - {m.get('content', '')}")
            continue
        flush_obs()
        if m.get("role") == "assistant" and is_native(m):
            lines = []
            text = (m.get("content") or "").strip()
            if text:
                lines.append("speak:" + " ".join(text.split()))
            for tc in m.get("tool_calls") or []:
                arg = _arg_of(tc)
                lines.append(f"{tc['function']['name']}:{arg}" if arg else tc["function"]["name"])
            if not m.get("tool_calls"):
                lines.append("done")
            out.append({"role": "assistant", "content": "\n".join(lines) or "done"})
        else:
            out.append({k: v for k, v in m.items() if k not in _PRIVATE})
    flush_obs()
    return out


# ---------------------------------------------------------------- 2b. text protocol -> native
def to_native(messages: list) -> list:
    """Old text-protocol history -> plain conversation for a native-calling model: Troy's spoken lines stay,
    the command lines and [OBSERVATION] results (plumbing the model doesn't need to imitate) are dropped.
    Native messages pass through unchanged."""
    out: list = []
    for m in messages:
        role = m.get("role")
        if is_native(m):
            out.append(m)
            continue
        content = m.get("content")
        if role == "assistant" and isinstance(content, str):
            cmds = parse_commands(content)
            if cmds:
                text = " ".join(arg for name, arg in cmds if name == "speak" and arg).strip()
            else:
                text = content.strip()
            if not text:
                continue
            m = {"role": "assistant", "content": text}
        elif role == "user" and isinstance(content, str) and content.lstrip().startswith("[OBSERVATION]"):
            continue
        else:
            m = {k: v for k, v in m.items() if k not in _PRIVATE}
        if out and out[-1].get("role") == m.get("role") and not is_native(out[-1]) and isinstance(m.get("content"), str) \
                and isinstance(out[-1].get("content"), str) and m["role"] in ("user", "assistant"):
            out[-1] = {**out[-1], "content": out[-1]["content"] + "\n" + m["content"]}
        else:
            out.append(m)
    return out
