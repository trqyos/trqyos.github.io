/* Troy phone page. Talks to troy/mobile_server.py:
 *   GET /api/state, SSE /api/stream, POST /api/send|stop|confirm, GET /screen.mjpg
 * Same behaviour as the desktop app, trimmed for a phone: Troy's face, the chat,
 * approvals, and a view-only live screen. */
"use strict";
(() => {
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => Array.from(r.querySelectorAll(s));
const esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
// Browsers refuse (and log an error for) vibration before the first tap, so wait for one.
const buzz = (ms) => { try { if (navigator.vibrate && navigator.userActivation?.hasBeenActive !== false) navigator.vibrate(ms); } catch { /* not supported */ } };

/* ------------------------------------------------------------------ token */
const KEY = "troy.phone.token";
let token = "";
(function readToken() {
  const url = new URL(location.href);
  const t = url.searchParams.get("t");
  if (t) {
    token = t;
    try { localStorage.setItem(KEY, t); } catch { /* private mode */ }
    url.searchParams.delete("t");
    history.replaceState(null, "", url.pathname + url.search + url.hash);   // keep the secret out of the address bar
  } else { try { token = localStorage.getItem(KEY) || ""; } catch { token = ""; } }
})();
const H = () => ({ "Content-Type": "application/json", "X-Troy-Token": token });
async function api(path, body) {
  const r = await fetch(path, body === undefined ? { headers: H() } : { method: "POST", headers: H(), body: JSON.stringify(body) });
  if (r.status === 401) { showPair("That access code isn't valid any more."); throw new Error("unauthorized"); }
  const data = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(data.error || `HTTP ${r.status}`);
  return data;
}

async function rpc(method, params) { return (await api("/api/rpc", { method, params: params || {} })).result; }

/* ---------------------------------------------------- shared clock + local prefs */
let clockOffset = 0;                                 // PC clock minus this phone's clock (ms)
const serverNow = () => Date.now() + clockOffset;
const PREF = "troy.phone.prefs";
const prefs = (() => { try { return JSON.parse(localStorage.getItem(PREF) || "{}"); } catch { return {}; } })();
function setPref(k, v) { prefs[k] = v; try { localStorage.setItem(PREF, JSON.stringify(prefs)); } catch { /* private mode */ } applyPrefs(); }
const isLight = () => prefs.theme === "light" || (prefs.theme !== "dark" && matchMedia("(prefers-color-scheme: light)").matches);
function applyPrefs() {
  document.body.classList.toggle("light", isLight());
  document.body.classList.toggle("calm", !!prefs.calm);
  document.querySelector('meta[name="theme-color"]')?.setAttribute("content", isLight() ? "#e9edfa" : "#070911");
  try { face?.setOptions({ light: isLight() }); VO.face?.setOptions({ light: isLight() }); } catch { /* not mounted yet */ }
}
matchMedia("(prefers-color-scheme: light)").addEventListener?.("change", applyPrefs);

/* ------------------------------------------------------------------ small ui */
function toast(msg, kind = "bad", ms = 3600) {
  const d = document.createElement("div");
  d.className = `toast ${kind === "bad" ? "" : kind}`; d.textContent = msg;
  $("#toasts").append(d); setTimeout(() => d.remove(), ms);
}
function banner(text, bad) {
  const b = $("#banner");
  b.textContent = text || ""; b.classList.toggle("hidden", !text); b.classList.toggle("bad", !!bad);
}

/* ---------------------------------------------------------------- markdown */
function inline(s) {
  const keep = []; const stash = (h) => `\u0000${keep.push(h) - 1}\u0000`;
  s = s.replace(/`([^`\n]+)`/g, (_, c) => stash(`<code>${c}</code>`));
  s = s.replace(/\bhttps?:\/\/[^\s<]*[^\s<.,;:!?)'"\]]/g, (u) => stash(`<a href="${u}" target="_blank" rel="noopener noreferrer">${u}</a>`));
  s = s.replace(/\*\*([^*\n]+)\*\*/g, "<strong>$1</strong>").replace(/(^|[^*\w])\*([^*\n]+)\*(?![\w*])/g, "$1<em>$2</em>");
  return s.replace(/\u0000(\d+)\u0000/g, (_, i) => keep[+i]);
}
function md(text) {
  return String(text ?? "").split("```").map((part, i) => {
    if (i % 2) { const nl = part.indexOf("\n"); const code = nl >= 0 && /^[\w+#.-]*$/.test(part.slice(0, nl).trim()) ? part.slice(nl + 1) : part; return `<pre><code>${esc(code.replace(/\n$/, ""))}</code></pre>`; }
    const out = []; let para = [], list = null;
    const fp = () => { if (para.length) { out.push(`<p>${inline(para.join("<br>"))}</p>`); para = []; } };
    const fl = () => { if (list) { out.push(`<${list.t}>${list.i.map((x) => `<li>${inline(x)}</li>`).join("")}</${list.t}>`); list = null; } };
    for (const line of esc(part).split("\n")) {
      let m;
      if ((m = line.match(/^\s*[-*\u2022]\s+(.*)$/))) { fp(); if (!list || list.t !== "ul") { fl(); list = { t: "ul", i: [] }; } list.i.push(m[1]); }
      else if ((m = line.match(/^\s*\d+[.)]\s+(.*)$/))) { fp(); if (!list || list.t !== "ol") { fl(); list = { t: "ol", i: [] }; } list.i.push(m[1]); }
      else if (!line.trim()) { fp(); fl(); } else { fl(); para.push(line); }
    }
    fp(); fl(); return out.join("");
  }).join("");
}

/* ------------------------------------------------------------------- state */
const S = { wake: { state: "" }, sid: null, title: "", saver: false, state: "starting", detail: "", busy: false, speechUntil: 0, flash: null, lastDesired: "", tab: "chat", es: null, empty: true, info: {} };
const messages = $("#messages");
let typingEl = null;

/* ------------------------------------------------------------------ avatar */
const FACE_LABEL = { idle: "Ready", listening: "Listening", thinking: "Thinking", executing: "Working", speaking: "Speaking", done: "Done", error: "Problem", sleeping: "Asleep", surprised: "Oh!", wink: "Ready", curious: "Ready", proud: "Done" };
let face = null, captionTimer = null;
const FACE_ID = `phone-${Math.random().toString(36).slice(2, 8)}`;
function mountFace() {
  if (typeof NovaFace === "undefined") return;
  try {
    let last = "";
    face = NovaFace.mount($("#face"), { onTint: (r, g, b) => { const v = `${r}, ${g}, ${b}`; if (v !== last) { last = v; document.body.style.setProperty("--tint", v); } } });
    face.onStateChange = (s) => { document.body.dataset.face = s; const c = $("#heroState"); c.dataset.s = s; $("span", c).textContent = FACE_LABEL[s] || s; };
    face.setOptions({ light: isLight(), sleep: true, tracking: false, saver: !!S.saver });
    // same blinks / glances / winks as the PC app and widget (shared clock); pokes + wake-ups are relayed both ways
    face.setSync({ now: serverNow, id: FACE_ID, send: (evt) => rpc("face.relay", evt).catch(() => {}) });
  } catch (e) { console.error(e); }
}
function caption(text) {
  clearTimeout(captionTimer);
  const plain = String(text || "").replace(/```[\s\S]*?```/g, " (code) ").replace(/\n\s*[-*]\s+/g, " \u00B7 ").replace(/[*_`#>]/g, "").replace(/\s+/g, " ").trim();
  const c = $("#caption"); c.textContent = plain.length > 160 ? `${plain.slice(0, 157)}\u2026` : plain; c.classList.toggle("show", !!plain);
  if (plain) captionTimer = setTimeout(() => c.classList.remove("show"), 4200 + plain.length * 45);
}
function flash(state, ms) { if (S.flash && S.flash.state === "error" && S.flash.until > Date.now() && state !== "error") return; S.flash = { state, until: Date.now() + ms }; applyAvatar(); }
function desired() {
  const now = Date.now();
  if (S.flash && S.flash.until > now) return S.flash.state;
  if (S.wake.state === "hearing") return "listening";          // the PC's microphone is hearing you: so does this face
  if (S.speechUntil > now) return "speaking";
  return { thinking: "thinking", executing: "executing", speaking: "speaking", error: "error" }[S.state] || (S.busy ? "thinking" : "idle");
}
function applyAvatar() {
  if (!face) return;
  face.locked = S.busy || S.speechUntil > Date.now();
  const w = desired(); if (w !== S.lastDesired) { S.lastDesired = w; face.setState(w); }
}
const PILL = { starting: "Connecting\u2026", offline: "Offline", idle: "Ready", thinking: "Thinking\u2026", speaking: "Replying\u2026", stopped: "Stopped", error: "Problem" };
function setState(state, detail = "") {
  S.state = state; S.detail = detail;
  const p = $("#pill"); p.dataset.s = state;
  $("span", p).textContent = state === "executing" ? `Running ${detail || "\u2026"}` : (PILL[state] || state);
  if (state === "error") flash("error", 2800);
  updateTyping(); applyAvatar();
}
function setBusy(b) { if (S.busy === b) return; S.busy = b; $("#stopBtn").classList.toggle("hidden", !b); b ? updateTyping() : hideTyping(); applyAvatar(); }

/* ---------------------------------------------------------------- messages */
const near = () => messages.scrollHeight - messages.scrollTop - messages.clientHeight < 90;
const toBottom = () => { messages.scrollTop = messages.scrollHeight; };
function put(node, force) {
  const stick = force || near();
  typingEl ? messages.insertBefore(node, typingEl) : messages.append(node);
  if (stick) toBottom();
  updateCompact();
}
function clearEmpty() { if (S.empty) { messages.innerHTML = ""; S.empty = false; typingEl = null; } }
function addMsg(role, text, opt = {}) {
  clearEmpty();
  const el = document.createElement("div");
  el.className = `msg ${role}${opt.error ? " error" : ""}`;
  if (opt.quiet) el.style.animation = "none";
  el.innerHTML = role === "user" ? esc(text) : md(text);
  if (opt.src) el.insertAdjacentHTML("beforeend", `<small>via ${esc(opt.src)}</small>`);
  put(el, role === "user");
}
function addStep(e, opt = {}) {
  clearEmpty();
  const last = typingEl ? typingEl.previousElementSibling : messages.lastElementChild;
  let g = last && last.classList.contains("steps") ? last : null;
  if (!g) {
    g = document.createElement("div"); g.className = "steps"; g._n = 0; g._f = 0; g._names = [];
    g.innerHTML = '<details><summary><svg viewBox="0 0 24 24"><path d="M13 2 3 14h9l-1 8 10-12h-9z"/></svg><span></span></summary><div class="list"></div></details>';
    if (opt.quiet) g.style.animation = "none";
    put(g);
  }
  const arg = String(e.arg || "").replace(/\s+/g, " ").trim();
  const row = document.createElement("div"); row.className = `step ${e.success ? "ok" : "fail"}`;
  row.innerHTML = `<b>${esc(e.name)}</b>${arg ? ` <span class="a">${esc(arg.length > 70 ? arg.slice(0, 70) + "\u2026" : arg)}</span>` : ""}<div class="r">${esc(e.message || "")}</div>`;
  $(".list", g).append(row);
  g._n++; if (!e.success) g._f++; if (!g._names.includes(e.name)) g._names.push(e.name);
  $("span", g).innerHTML = `${g._n} action${g._n > 1 ? "s" : ""}: ${esc(g._names.slice(0, 3).join(", "))}${g._names.length > 3 ? "\u2026" : ""} \u00B7 ${g._f ? `<span class="bad">${g._f} failed</span>` : '<span class="ok">ok</span>'}`;
}
function addTaskNote(e, opt = {}) {
  clearEmpty();
  const el = document.createElement("div");
  el.className = `msg task-note${e.ok === false ? " bad" : ""}`;
  if (opt.quiet) el.style.animation = "none";
  el.innerHTML = `<svg><use href="#i-${e.ok === false ? "alert" : "tasks"}"/></svg><div>${esc(e.text || "")}</div>`;
  put(el);
}
function showTyping(label) {
  if (!typingEl) { typingEl = document.createElement("div"); typingEl.className = "typing"; typingEl.innerHTML = '<span><i></i><i></i><i></i></span><span class="tl"></span>'; clearEmpty(); const s = near(); messages.append(typingEl); if (s) toBottom(); }
  $(".tl", typingEl).textContent = label;
}
function hideTyping() { typingEl?.remove(); typingEl = null; }
function updateTyping() { if (S.busy) showTyping(S.state === "executing" ? `Running ${S.detail}\u2026` : S.state === "speaking" ? "Replying\u2026" : "Thinking\u2026"); }

const SUGGEST = ["What's on my screen?", "Open my last liked YouTube video", "How's my PC doing?", "Volume down"];
function renderEmpty() {
  S.empty = true; typingEl = null;
  const name = S.info.user_name;
  messages.innerHTML = `<div class="empty"><h2>${name ? `Hi ${esc(name)}` : "Hi"} \u{1F44B}</h2><p>Ask Troy to do something on your PC.</p><div class="chips">${SUGGEST.map((s) => `<button class="chip" data-s="${esc(s)}">${esc(s)}</button>`).join("")}</div></div>`;
  updateCompact();
}
function renderHistory(entries) {
  messages.innerHTML = ""; S.empty = false; typingEl = null;
  if (!entries.length) { renderEmpty(); return; }
  for (const e of entries) {
    if (e.role === "tool") addStep(e, { quiet: true });
    else if (e.role === "task") addTaskNote(e, { quiet: true });
    else addMsg(e.role === "user" ? "user" : "assistant", e.text || "", { quiet: true, error: /^\(Troy couldn't reach|^\u26A0/.test(e.text || "") });
  }
  toBottom();
}
messages.addEventListener("click", (e) => { const c = e.target.closest(".chip"); if (c) send(c.dataset.s); });

/* The mascot shrinks once there is a conversation to read, or while typing. */
function updateCompact() {
  const hero = $("#hero"), count = messages.children.length;
  hero.classList.toggle("compact", S.manualCompact ?? (!S.empty && count > 2));
}
$("#hero").addEventListener("click", (e) => { if (e.target.closest("canvas") && !$("#hero").classList.contains("compact")) return; S.manualCompact = !$("#hero").classList.contains("compact"); updateCompact(); });
$("#hero").addEventListener("dblclick", () => { S.manualCompact = undefined; updateCompact(); });

/* --------------------------------------------------------------- approvals */
function confCard(p) {
  if (document.getElementById(`conf-${p.id}`)) return;
  const d = document.createElement("div"); d.className = "conf"; d.id = `conf-${p.id}`;
  d.innerHTML = `<b><svg viewBox="0 0 24 24"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>Troy needs your OK</b><code>${esc(p.name)}${p.arg ? ":" + esc(p.arg) : ""}</code><p>${esc(p.description || "")}</p>
    <div class="row"><button class="btn pri" data-ok="1">Approve</button><button class="btn" data-ok="0">Deny</button></div>`;
  d.addEventListener("click", async (e) => {
    const b = e.target.closest("[data-ok]"); if (!b) return;
    d.remove();
    try { await api("/api/confirm", { id: p.id, approved: b.dataset.ok === "1" }); } catch (err) { toast(err.message); }
  });
  $("#confs").append(d); flash("surprised", 900); buzz([60, 40, 60]); caption("I need your OK for something.");
}

/* ------------------------------------------------------------------ sending */
async function send(text) {
  text = String(text ?? $("#inp").value).trim(); if (!text) return;
  $("#inp").value = ""; autosize();
  addMsg("user", text); setBusy(true);
  try { await api("/api/send", { text }); }
  catch (e) { toast(e.message); if (!S.busy) return; setBusy(false); }
}
function autosize() { const i = $("#inp"); i.style.height = "auto"; i.style.height = Math.min(i.scrollHeight, 130) + "px"; i.style.overflowY = i.scrollHeight > 130 ? "auto" : "hidden"; }
$("#composer").addEventListener("submit", (e) => { e.preventDefault(); send(); });
$("#inp").addEventListener("input", autosize);
$("#inp").addEventListener("focus", () => { S.manualCompact = true; updateCompact(); setTimeout(toBottom, 250); });
$("#inp").addEventListener("blur", () => { S.manualCompact = undefined; updateCompact(); });
$("#stopBtn").addEventListener("click", () => api("/api/stop", {}).then(() => toast("Stopping\u2026", "info", 1400)).catch((e) => toast(e.message)));

/* Voice input: only where the browser offers it (it needs HTTPS or localhost). */
(function voice() {
  const R = window.SpeechRecognition || window.webkitSpeechRecognition;
  if (!R || !window.isSecureContext) return;
  const btn = $("#micBtn"); btn.classList.remove("hidden");
  let rec = null;
  btn.addEventListener("click", () => {
    if (rec) { rec.stop(); return; }
    rec = new R(); rec.lang = navigator.language || "en-US"; rec.interimResults = true; rec.continuous = false;
    rec.onstart = () => { btn.classList.add("hot"); flash("listening", 8000); };
    rec.onresult = (e) => { $("#inp").value = Array.from(e.results).map((r) => r[0].transcript).join(" "); autosize(); };
    rec.onend = () => { btn.classList.remove("hot"); S.flash = null; applyAvatar(); const had = $("#inp").value.trim(); rec = null; if (had) send(); };
    rec.onerror = (e) => { toast(e.error === "not-allowed" ? "Allow the microphone to use voice input." : `Voice input: ${e.error}`); };
    try { rec.start(); } catch { rec = null; }
  });
})();

/* ============================ full voice mode =============================
 * The phone becomes Troy's ears and mouth: getUserMedia -> a client-side
 * port of troy/audio_in.py's Endpointer (so the phone decides when you've
 * finished talking, without streaming audio constantly) -> 16 kHz PCM16
 * POSTed per utterance. Troy's replies arrive over the SSE stream as
 * {"type":"voice","action":"speak"} events and are spoken with the phone's
 * own speechSynthesis, or fetched as audio when the PC is set to use its
 * chosen voice. Talking over Troy barges in and stops it. */
const VO = { on: false, muted: false, speaker: "phone", face: null, lastFace: "", stream: null, ctx: null, proc: null,
  ep: null, down: null, playing: false, queue: [], levelAt: 0, busyUtterance: false };
const V_LABEL = { listening: "Listening\u2026", hearing: "Listening\u2026", transcribing: "Heard you\u2026", thinking: "Thinking\u2026",
  executing: "Working\u2026", speaking: "Speaking\u2026", muted: "Muted", off: "Off" };
const V_FACE = { listening: "listening", hearing: "listening", transcribing: "thinking", thinking: "thinking",
  executing: "executing", speaking: "speaking", muted: "sleeping", off: "idle" };
const RING_LEN = 351.9;

/* --- a faithful port of troy/audio_in.py's Endpointer, same tuning ------- */
class MicEndpointer {
  constructor(rate = 16000) {
    this.frame = Math.floor(rate * 0.03);          // 30 ms frames
    this.startFrames = 5;                          // speech must last ~150 ms
    this.endFrames = Math.max(1, Math.round(0.7 / 0.03));   // ~700 ms of quiet ends it
    this.prerollFrames = 10;                       // keep ~300 ms before speech
    this.minSamples = Math.floor(rate * 0.4);
    this.maxSamples = Math.floor(rate * 15);
    this.margin = 2.6; this.absMin = 220; this.floor = 120;
    this.calibFrames = 12; this.seen = 0;
    this.sensitivity = 1;                          // raised while Troy is talking
    this.reset();
  }
  reset() { this.buf = new Int16Array(0); this.pre = []; this.speech = []; this.voiced = 0; this.quiet = 0; this.inSpeech = false; }
  get threshold() { return Math.max(this.absMin, this.floor * this.margin) * this.sensitivity; }
  feed(chunk) {                                    // chunk: Int16Array
    const all = new Int16Array(this.buf.length + chunk.length);
    all.set(this.buf); all.set(chunk, this.buf.length);
    const n = Math.floor(all.length / this.frame);
    const events = [];
    for (let i = 0; i < n; i++) {
      const fr = all.subarray(i * this.frame, (i + 1) * this.frame);
      let sum = 0;
      for (let k = 0; k < fr.length; k++) sum += fr[k] * fr[k];
      const level = Math.sqrt(sum / fr.length);
      events.push(["level", level]);
      if (this.seen < this.calibFrames) { this.seen++; this.floor = 0.55 * this.floor + 0.45 * level; continue; }
      const voiced = level > this.threshold;
      if (!this.inSpeech) {
        if (!voiced) { this.floor = 0.96 * this.floor + 0.04 * level; this.voiced = 0; this.pre.push(fr); if (this.pre.length > this.prerollFrames + this.startFrames) this.pre.shift(); continue; }
        this.voiced++; this.pre.push(fr);
        if (this.voiced >= this.startFrames) { this.inSpeech = true; this.speech = this.pre.slice(-(this.prerollFrames + this.voiced)); this.quiet = 0; events.push(["start"]); }
      } else {
        this.speech.push(fr);
        this.quiet = voiced ? 0 : this.quiet + 1;
        let total = 0; for (const f of this.speech) total += f.length;
        if (this.quiet >= this.endFrames || total >= this.maxSamples) {
          let audio = new Int16Array(total);
          let o = 0; for (const f of this.speech) { audio.set(f, o); o += f.length; }
          const keep = audio.length - this.quiet * this.frame;
          const cut = Math.max(this.minSamples, keep + this.frame * 3);
          audio = audio.slice(0, cut);
          events.push(audio.length >= this.minSamples ? ["end", audio] : ["discard"]);
          this.speech = []; this.pre = []; this.voiced = 0; this.quiet = 0; this.inSpeech = false;
        }
      }
    }
    this.buf = all.slice(n * this.frame);
    return events;
  }
}

/* linear downsampler to 16 kHz, carrying the remainder between blocks */
function makeDownsampler(srcRate, dstRate = 16000) {
  let acc = new Float32Array(0);
  const need = srcRate / dstRate;
  return (block) => {
    const all = new Float32Array(acc.length + block.length);
    all.set(acc); all.set(block, acc.length);
    const nOut = Math.floor((all.length - 1) / need);
    if (nOut <= 0) { acc = all; return new Int16Array(0); }
    const out = new Int16Array(nOut);
    for (let k = 0; k < nOut; k++) {
      const x = k * need, i = Math.floor(x), f = x - i;
      const s = all[i] * (1 - f) + all[i + 1] * f;
      out[k] = Math.max(-32768, Math.min(32767, Math.round(s * 32768)));
    }
    acc = all.slice(Math.floor(nOut * need));
    return out;
  };
}

function setVoiceState(state) {
  const el = $("#vState");
  el.dataset.s = state;
  el.textContent = V_LABEL[state] || state;
  const want = V_FACE[state] || "idle";
  if (VO.face && want !== VO.lastFace) { VO.lastFace = want; VO.face.setState(want); }
}
function addTranscript(who, text, opt = {}) {
  const t = $("#vTranscript");
  const el = document.createElement("p");
  el.className = who;
  el.textContent = text;
  if (opt.pc) el.insertAdjacentText("afterbegin", "(PC) ");
  t.append(el);
  while (t.children.length > 40) t.firstElementChild.remove();
  t.scrollTop = t.scrollHeight;
}
function setRing(level) {
  const now = performance.now();
  if (now - VO.levelAt < 90) return;
  VO.levelAt = now;
  const pct = Math.min(1, Math.sqrt(level / 240000));   // perceptual-ish curve
  $("#ringArc").style.strokeDashoffset = String(RING_LEN * (1 - pct));
}

function mountVoiceFace() {
  if (VO.face || typeof NovaFace === "undefined") return;
  try { VO.face = NovaFace.mount($("#voiceFace"), { onTint: (r, g, b) => { const v = `${r},${g},${b}`; if (v !== VO._tint) { VO._tint = v; $("#voiceOverlay").style.setProperty("--tint-rgb", v); } } }); } catch (e) { console.error(e); }
}

/* ------------------------------------------------------------- speaking */
function playingChanged(on) {
  VO.playing = on;
  if (VO.ep) VO.ep.sensitivity = on ? 4 : 1;      // barge-in needs a clearly louder voice
  api("/api/voice/event", { speaking: on }).catch(() => {});
  if (VO.on) setVoiceState(on ? "speaking" : "listening");
}
function clearSpeakQueue() {
  VO.queue = [];
  try { window.speechSynthesis?.cancel(); } catch { /* not supported */ }
  if (VO._audioEl) { VO._audioEl.pause(); VO._audioEl._killed = true; VO._audioEl = null; }
  if (VO.playing) playingChanged(false);
}
function speakNext() {
  if (VO.playing || !VO.queue.length) return;
  const ev = VO.queue.shift();
  playingChanged(true);
  const done = () => { if (!VO._audioEl) playingChanged(false); speakNext(); };
  if (VO.speaker === "troy" && ev.audio) {
    const a = new Audio(`${ev.audio}?t=${encodeURIComponent(token)}`);
    VO._audioEl = a;
    a.onended = () => { if (VO._audioEl === a) VO._audioEl = null; playingChanged(false); speakNext(); };
    a.onerror = () => { if (VO._audioEl === a) VO._audioEl = null; playingChanged(false); speakNext(); };
    a.play().catch(() => { if (VO._audioEl === a) VO._audioEl = null; playingChanged(false); speakNext(); });
  } else if (window.speechSynthesis) {
    const u = new SpeechSynthesisUtterance(ev.text);
    u.rate = 1.03;
    u.onend = done; u.onerror = done;
    try { window.speechSynthesis.speak(u); } catch { done(); }
    if (!window.speechSynthesis.speaking) setTimeout(() => { if (!window.speechSynthesis.speaking && VO.playing) done(); }, 1200);
  } else playingChanged(false);
}
function queueSpeak(ev) {
  if (!ev || !ev.text) return;
  VO.queue.push(ev);
  if (VO.queue.length > 12) VO.queue.splice(0, VO.queue.length - 12);
  speakNext();
}

/* ------------------------------------------------------------ utterances */
async function sendUtterance(pcm) {
  VO.busyUtterance = true;
  try {
    const r = await fetch("/api/voice/utterance?rate=16000", {
      method: "POST", headers: { "Content-Type": "application/octet-stream", "X-Troy-Token": token },
      body: new Uint8Array(pcm.buffer, pcm.byteOffset, pcm.byteLength),
    });
    if (r.status === 401) { showPair("That access code isn't valid any more."); return; }
    const d = await r.json().catch(() => ({}));
    if (!r.ok) { if (d.error) toast(d.error, "bad", 6000); return; }
    if (d.action === "ignored") { return; }
    if (d.action === "end") { addTranscript("you", d.text || ""); endVoice("goodbye"); return; }
    if (d.action === "stop") { addTranscript("you", d.text || ""); clearSpeakQueue(); return; }
    addTranscript("you", d.text || "");
    setVoiceState("thinking");
  } catch (e) {
    toast("Couldn't reach the PC: " + (e.message || e), "bad", 5000);
  } finally {
    VO.busyUtterance = false;
  }
}

function onAudioFrames(float32) {
  if (!VO.on || VO.muted) return;
  const pcm = VO.down(float32);
  if (!pcm.length) return;
  for (const [kind, val] of VO.ep.feed(pcm)) {
    if (kind === "level") { setRing(val); continue; }
    if (kind === "start") {
      if (VO.playing) { clearSpeakQueue(); api("/api/voice/interrupt", {}).catch(() => {}); }   // barge-in
      setVoiceState("hearing");
    } else if (kind === "end") {
      if (VO.busyUtterance) continue;          // previous one still uploading: drop overlap
      setVoiceState("transcribing");
      sendUtterance(val);
    }
  }
}

/* --------------------------------------------------------------- session */
function showSecurePanel() {
  $("#voiceOverlay").classList.remove("hidden");
  $("#vSecure").classList.remove("hidden");
  $("#vTranscript").classList.add("hidden");
  $(".v-face").classList.add("hidden");
  $("#vState").classList.add("hidden");
  let url = S.voiceInfo?.https || "";
  if (!url && location.protocol === "http:") {
    const port = (parseInt(location.port, 10) || 80) + 1;
    url = `https://${location.hostname}${port !== 443 ? ":" + port : ""}/?t=${encodeURIComponent(token)}`;
  }
  const a = $("#vSecureLink");
  if (url) { a.href = url; a.classList.remove("hidden"); } else a.classList.add("hidden");
  mountVoiceFace();
}

async function startVoice() {
  if (VO.on) return;
  if (!window.isSecureContext) { showSecurePanel(); return; }
  if (S.voiceInfo && S.voiceInfo.enabled === false) { toast("Phone voice is turned off on the PC (Troy \u203a Settings \u203a Phone).", "info", 5000); return; }
  let r;
  try { r = await api("/api/voice/start", {}); } catch (e) { toast(e.message, "bad", 6000); return; }
  VO.speaker = r.speaker || "phone";
  let stream;
  try {
    stream = await navigator.mediaDevices.getUserMedia({ audio: { echoCancellation: true, noiseSuppression: true, autoGainControl: true }, video: false });
  } catch (e) {
    toast(e && e.name === "NotAllowedError" ? "Allow the microphone to use voice mode." : `Microphone: ${(e && (e.message || e.name)) || "unavailable"}`, "bad", 6000);
    api("/api/voice/stop", {}).catch(() => {});
    return;
  }
  VO.on = true; VO.muted = false; VO.stream = stream;
  VO.queue = []; VO.playing = false; VO.busyUtterance = false;
  VO.ep = new MicEndpointer(16000);
  VO.down = makeDownsampler(48000);
  try {
    VO.ctx = new (window.AudioContext || window.webkitAudioContext)();
    VO.down = makeDownsampler(VO.ctx.sampleRate);
    const src = VO.ctx.createMediaStreamSource(stream);
    VO.proc = VO.ctx.createScriptProcessor(4096, 1, 1);
    VO.proc.onaudioprocess = (e) => onAudioFrames(e.inputBuffer.getChannelData(0));
    const sink = VO.ctx.createGain(); sink.gain.value = 0;
    src.connect(VO.proc); VO.proc.connect(sink); sink.connect(VO.ctx.destination);
  } catch (e) {
    toast("Audio engine unavailable: " + (e.message || e), "bad", 6000);
    endVoice("error");
    return;
  }
  $("#voiceOverlay").classList.remove("hidden");
  $("#vSecure").classList.add("hidden");
  $("#vTranscript").classList.remove("hidden");
  $(".v-face").classList.remove("hidden");
  $("#vState").classList.remove("hidden");
  $("#vTranscript").innerHTML = "";
  $("#voiceBtn").classList.add("on");
  mountVoiceFace();
  setVoiceState("listening");
  try { window.speechSynthesis?.getVoices(); } catch { /* prime voices where supported */ }
  if (VO.speaker === "troy") addTranscript("troy", `(speaking in Troy's voice from the PC)`);
  buzz(20);
  wake(true);
}

async function endVoice(reason = "user") {
  const was = VO.on;
  VO.on = false;
  $("#voiceBtn").classList.remove("on");
  $("#voiceOverlay").classList.add("hidden");
  clearSpeakQueue();
  try { VO.proc && (VO.proc.onaudioprocess = null); } catch { /* already gone */ }
  try { VO.ctx && VO.ctx.close(); } catch { /* already gone */ }
  VO.proc = null; VO.ctx = null;
  try { VO.stream && VO.stream.getTracks().forEach((t) => t.stop()); } catch { /* already stopped */ }
  VO.stream = null; VO.ep = null; VO.down = null;
  $("#ringArc").style.strokeDashoffset = String(RING_LEN);
  if (was) api("/api/voice/stop", {}).catch(() => {});
  if (reason === "goodbye") toast("Voice mode ended \u2014 say the word to start again.", "info", 2600);
}

$("#voiceBtn").addEventListener("click", () => { if (!VO.on) startVoice(); else endVoice(); });
$("#vEndBtn").addEventListener("click", () => endVoice());
$("#vMuteBtn").addEventListener("click", () => {
  VO.muted = !VO.muted;
  $("#vMuteBtn").classList.toggle("muted", VO.muted);
  $("#vMuteBtn").title = VO.muted ? "Unmute the microphone" : "Mute the microphone";
  if (VO.ep) VO.ep.reset();
  if (VO.on) setVoiceState(VO.muted ? "muted" : "listening");
});
$("#vStopBtn").addEventListener("click", () => {
  clearSpeakQueue();
  api("/api/voice/interrupt", {}).catch(() => {});
  setVoiceState("listening");
});
document.addEventListener("visibilitychange", () => { if (document.hidden && VO.on && VO.ep) VO.ep.reset(); });

/* ------------------------------------------------------------------ events */
function onEvent(ev) {
  switch (ev.type) {
    case "message":
      if (ev.kind === "user") { addMsg("user", ev.text, { src: "PC" }); setBusy(true); }
      else { addMsg("assistant", ev.text, { error: /^\(Troy couldn't reach|^\u26A0/.test(ev.text || "") }); caption(ev.text); S.speechUntil = Date.now() + clamp(String(ev.text).length * 60, 1400, 14000); buzz(25); applyAvatar(); }
      break;
    case "tool": addStep(ev); break;
    case "status": if (ev.status) setState(ev.status.state || "idle", ev.status.detail || ""); break;
    case "voice":
      /* voice-mode events from the PC: state, transcripts, sentences to say */
      if (ev.action === "state") { if (VO.on && !VO.muted && ev.state !== "off") setVoiceState(ev.state); }
      else if (ev.action === "transcript") { if (VO.on && ev.source === "pc") addTranscript("you", ev.text, { pc: true }); }
      else if (ev.action === "speak") { if (VO.on) queueSpeak(ev); }
      else if (ev.action === "listener") { S.wake.state = ev.state; applyAvatar(); }
      else if (ev.action === "level") { if (!VO.on) pcLevel(ev.level); }
      break;
    case "turn":
      if (ev.state === "started") setBusy(true);
      else if (!ev.pending) { setBusy(false); if (S.state !== "error") flash("done", 1400); setTimeout(() => { if (!S.busy && (S.state === "error" || S.state === "stopped")) setState("idle"); }, 3000); }
      break;
    case "event": onPcEvent(ev.event, ev.data || {}); break;
    case "confirmation": ev.action === "request" ? confCard(ev) : document.getElementById(`conf-${ev.id}`)?.remove(); break;
    default: break;
  }
}

/* The PC's mic level drives this face and its glow exactly like the widget's. */
let lvlTimer = null;
function pcLevel(raw) {
  const pct = Math.min(1, Math.sqrt(Math.max(0, Number(raw) || 0) / 240000));
  face?.setLevel(pct); document.body.style.setProperty("--lvl", pct.toFixed(3));
  clearTimeout(lvlTimer); lvlTimer = setTimeout(() => document.body.style.setProperty("--lvl", "0"), 450);
}
/* events mirrored from the PC app (see ipc_host._MIRROR_TO_PHONE) */
function onPcEvent(name, d) {
  if (name === "face.event") { if (d.origin !== FACE_ID) face?.applyRemote(d); }
  else if (name === "power.state") { S.saver = !!d.active; face?.setOptions({ saver: S.saver }); }
  else if (name === "session.changed") {
    if (d.action === "created" && d.id) S.sid = d.id;
    if ((d.action === "loaded" && d.id && d.id !== S.sid) || d.action === "reset" || (d.action === "deleted" && d.was_current)) { S.sid = d.action === "loaded" ? d.id : null; S.title = d.title || ""; reloadChat(); }
  }
  P.listeners.forEach((fn) => { try { fn(name, d); } catch (e) { console.error(e); } });
}
async function reloadChat() { try { const st = await api("/api/state"); S.sid = st.status?.session_id || null; renderHistory(st.history || []); updateTitle(); } catch { /* the stream will explain */ } }
function updateTitle() { $("#chatTitle").textContent = S.sid ? (S.title || "Chat") : "New chat"; }

async function hydrate() {
  const t0 = Date.now();
  const st = await api("/api/state");
  if (st.now) clockOffset = st.now + (Date.now() - t0) / 2 - Date.now();
  S.sid = st.status?.session_id || null; if (!S.sid) S.title = "";
  S.info = st.info || {};
  S.screenEnabled = st.screen?.enabled !== false;
  S.voiceInfo = st.voice || {};
  renderHistory(st.history || []);
  (st.confirmations || []).forEach(confCard);
  setBusy(!!st.status?.busy);
  setState(st.status?.state?.state || (typeof st.status?.state === "string" ? st.status.state : "idle"), st.status?.state?.detail || "");
  banner(""); updateTitle(); P.listeners.forEach((fn) => { try { fn("hydrated", st); } catch { /* ignore */ } });
}

function connect() {
  S.es?.close();
  const es = new EventSource(`/api/stream?t=${encodeURIComponent(token)}`);
  S.es = es;
  es.onopen = () => { banner(""); hydrate().catch(() => {}); };
  es.onmessage = (m) => { try { onEvent(JSON.parse(m.data)); } catch { /* keepalive or junk */ } };
  es.onerror = () => { if (es.readyState === EventSource.CLOSED) { setState("offline"); banner("Can't reach Troy. Is the PC on and Troy running?", true); setTimeout(connect, 4000); } else { setState("starting"); banner("Reconnecting\u2026"); } };
}

/* ------------------------------------------------------------- live screen */
const V = { preset: "balanced", monitor: 1, paused: false, scale: 1, x: 0, y: 0, active: false };
const img = $("#screenImg"), viewer = $("#viewer"), stage = $("#stage");
function screenSrc() { return `/screen.mjpg?t=${encodeURIComponent(token)}&preset=${V.preset}&monitor=${V.monitor}&_=${Date.now()}`; }
function startScreen() {
  if (!S.screenEnabled) { $("#screenMsg").textContent = "Screen sharing is turned off on the PC (Troy > Settings > Phone)."; return; }
  if (V.paused) return;
  $("#screenMsg").textContent = "Connecting to the screen\u2026"; $("#liveBadge").classList.add("hidden");
  img.src = screenSrc(); V.active = true; wake(true);
}
function stopScreen() { img.removeAttribute("src"); V.active = false; $("#liveBadge").classList.add("hidden"); wake(false); }
img.addEventListener("load", () => { $("#screenMsg").textContent = ""; $("#liveBadge").classList.remove("hidden"); });
img.addEventListener("error", async () => {
  if (!V.active) return;
  $("#liveBadge").classList.add("hidden");
  let why = "The screen stream stopped.";
  try { const r = await fetch(`/api/screen/info?t=${encodeURIComponent(token)}`); const d = await r.json(); if (d.enabled === false) why = "Screen sharing is turned off on the PC."; } catch { why = "Can't reach the PC."; }
  $("#screenMsg").innerHTML = `${esc(why)}<br><br><button class="btn" id="retryScreen" style="pointer-events:auto">Try again</button>`;
  $("#retryScreen")?.addEventListener("click", startScreen);
});
let wl = null;
async function wake(on) { try { if (on && navigator.wakeLock && !wl) wl = await navigator.wakeLock.request("screen"); else if (!on && wl) { wl.release(); wl = null; } } catch { wl = null; } }

$$("#qual button").forEach((b) => b.addEventListener("click", () => { V.preset = b.dataset.preset; $$("#qual button").forEach((x) => x.classList.toggle("on", x === b)); if (!V.paused) startScreen(); }));
$("#monitorSel").addEventListener("change", (e) => { V.monitor = +e.target.value; if (!V.paused) startScreen(); });
$("#pauseBtn").addEventListener("click", () => {
  V.paused = !V.paused;
  $("#pauseBtn").innerHTML = V.paused ? '<svg viewBox="0 0 24 24"><path d="m6 4 14 8-14 8z"/></svg>' : '<svg viewBox="0 0 24 24"><path d="M8 5v14M16 5v14"/></svg>';
  if (V.paused) { stopScreen(); $("#screenMsg").textContent = "Paused"; } else startScreen();
});
$("#shotBtn").addEventListener("click", async () => {
  try {
    const r = await fetch(`/api/screen/shot?t=${encodeURIComponent(token)}&w=1600&q=80&monitor=${V.monitor}`);
    if (!r.ok) throw new Error((await r.json().catch(() => ({}))).error || "Couldn't capture");
    const a = document.createElement("a"); a.href = URL.createObjectURL(await r.blob()); a.download = `troy-screen-${Date.now()}.jpg`; document.body.append(a); a.click(); a.remove(); toast("Saved", "ok", 1400);
  } catch (e) { toast(e.message); }
});
$("#fsBtn").addEventListener("click", async () => {
  const on = !viewer.classList.contains("fs");
  viewer.classList.toggle("fs", on); document.body.classList.toggle("fs-open", on);
  try { if (on) { await viewer.requestFullscreen?.(); await screen.orientation?.lock?.("landscape"); } else { if (document.fullscreenElement) await document.exitFullscreen(); screen.orientation?.unlock?.(); } } catch { /* the CSS fallback still fills the screen */ }
});
document.addEventListener("fullscreenchange", () => { if (!document.fullscreenElement && viewer.classList.contains("fs")) { viewer.classList.remove("fs"); document.body.classList.remove("fs-open"); } });

/* pinch to zoom, drag to pan, double tap to reset; controls fade while idle */
let idleTimer = null;
function poke() { viewer.classList.remove("idle"); clearTimeout(idleTimer); idleTimer = setTimeout(() => viewer.classList.add("idle"), 3500); }
function applyTransform() { img.style.transform = `translate(${V.x}px,${V.y}px) scale(${V.scale})`; }
function limitPan() {
  const r = stage.getBoundingClientRect(), w = img.clientWidth * V.scale, h = img.clientHeight * V.scale;
  const ox = (r.width - img.clientWidth) / 2, oy = (r.height - img.clientHeight) / 2;
  V.x = clamp(V.x, Math.min(0, r.width - w - ox), -ox + Math.max(0, 0)); V.y = clamp(V.y, Math.min(0, r.height - h - oy), -oy + Math.max(0, 0));
  if (V.scale <= 1) { V.x = 0; V.y = 0; }
}
const pts = new Map(); let pinch = null, lastTap = 0;
stage.addEventListener("pointerdown", (e) => { stage.setPointerCapture(e.pointerId); pts.set(e.pointerId, { x: e.clientX, y: e.clientY }); poke(); if (pts.size === 2) { const [a, b] = [...pts.values()]; pinch = { d: Math.hypot(a.x - b.x, a.y - b.y), s: V.scale }; } });
stage.addEventListener("pointermove", (e) => {
  const p = pts.get(e.pointerId); if (!p) return;
  if (pts.size === 2 && pinch) { pts.set(e.pointerId, { x: e.clientX, y: e.clientY }); const [a, b] = [...pts.values()]; V.scale = clamp(pinch.s * Math.hypot(a.x - b.x, a.y - b.y) / pinch.d, 1, 6); limitPan(); applyTransform(); return; }
  if (V.scale > 1) { V.x += e.clientX - p.x; V.y += e.clientY - p.y; limitPan(); applyTransform(); }
  pts.set(e.pointerId, { x: e.clientX, y: e.clientY });
});
const up = (e) => { pts.delete(e.pointerId); if (pts.size < 2) pinch = null; };
stage.addEventListener("pointerup", (e) => { up(e); const now = Date.now(); if (now - lastTap < 300) { V.scale = 1; V.x = V.y = 0; applyTransform(); } lastTap = now; });
stage.addEventListener("pointercancel", up);
stage.addEventListener("wheel", (e) => { e.preventDefault(); V.scale = clamp(V.scale * (e.deltaY < 0 ? 1.15 : 0.87), 1, 6); limitPan(); applyTransform(); poke(); }, { passive: false });

async function loadMonitors() {
  try {
    const d = await api("/api/screen/info");
    const sel = $("#monitorSel"), mons = (d.monitors || []).filter((m) => m.index > 0);
    sel.classList.toggle("hidden", mons.length < 2);
    sel.innerHTML = mons.map((m, i) => `<option value="${m.index}">Screen ${i + 1} \u00B7 ${m.width}\u00D7${m.height}</option>`).join("");
    if (mons.length && !mons.some((m) => m.index === V.monitor)) V.monitor = mons[0].index;
  } catch { /* the stream will explain */ }
}

/* -------------------------------------------------------------------- tabs */
const TABS = ["chat", "chats", "tasks", "screen", "settings"];
let lensX = null;
function moveLens(animate) {
  const btn = $(`#tabs button[data-tab="${S.tab}"]`), lens = $("#lens"), dock = $("#tabs");
  if (!btn || !dock.offsetWidth) return;
  const w = btn.offsetWidth, x = btn.offsetLeft;
  lens.style.width = `${w}px`;
  if (animate && lensX !== null && lens.animate && !prefs.calm) {
    lens.animate([{ transform: `translateX(${lensX}px) scale(1)` }, { transform: `translateX(${(lensX + x) / 2}px) scale(1.32, .9)`, offset: .45 }, { transform: `translateX(${x}px) scale(1)` }], { duration: 520, easing: "cubic-bezier(.34,1.3,.5,1)" });
  }
  lens.style.transform = `translateX(${x}px)`; lensX = x;
}
function setTab(t) {
  if (!TABS.includes(t)) return;
  const was = S.tab; S.tab = t;
  $$("#tabs button").forEach((b) => b.classList.toggle("on", b.dataset.tab === t));
  TABS.forEach((n) => $(`#tab-${n}`).classList.toggle("on", n === t));
  moveLens(was !== t); if (was !== t) buzz(8);
  if (t === "screen") { loadMonitors(); startScreen(); poke(); } else stopScreen();     // closing the tab ends the stream
  if (t === "chat") setTimeout(toBottom, 60);
  P.listeners.forEach((fn) => { try { fn("tab", { tab: t }); } catch (e) { console.error(e); } });
}
$$("#tabs button").forEach((b) => b.addEventListener("click", () => setTab(b.dataset.tab)));
addEventListener("resize", () => moveLens(false));
document.addEventListener("visibilitychange", () => { if (document.hidden) { if (S.tab === "screen") stopScreen(); } else if (S.tab === "screen" && !V.paused) startScreen(); });
/* the dock slides away while the keyboard is up */
$("#inp").addEventListener("focus", () => document.body.classList.add("kb"));
$("#inp").addEventListener("blur", () => document.body.classList.remove("kb"));
/* touch ripple on every button */
document.addEventListener("pointerdown", (e) => {
  const b = e.target.closest?.("button, .item.tap, .row.tap"); if (!b || prefs.calm) return;
  const r = b.getBoundingClientRect(), d = Math.max(r.width, r.height) * 2, i = document.createElement("i");
  i.className = "rip"; i.style.cssText = `width:${d}px;height:${d}px;left:${e.clientX - r.left - d / 2}px;top:${e.clientY - r.top - d / 2}px`;
  b.append(i); setTimeout(() => i.remove(), 650);
}, { passive: true });

/* new chat + title */
async function newChat() {
  if (S.busy) { toast("Troy is busy \u2014 stop the current task first.", "info"); return; }
  try { await rpc("session.reset"); } catch (e) { toast(e.message); return; }
  S.sid = null; S.title = ""; S.manualCompact = undefined; renderEmpty(); updateTitle(); setTab("chat"); $("#inp").focus();
}
$("#newChatBtn").addEventListener("click", newChat);
$("#chatTitleBtn").addEventListener("click", () => setTab("chats"));

/* ---------------------------------------------------------------- pairing */
function showPair(msg) { $("#app").classList.add("hidden"); $("#pair").classList.remove("hidden"); $("#pairErr").textContent = msg || ""; S.es?.close(); }
$("#pairBtn").addEventListener("click", () => {
  const raw = $("#pairIn").value.trim(); let t = raw;
  try { t = new URL(raw).searchParams.get("t") || raw; } catch { /* a bare code */ }
  if (!t) { $("#pairErr").textContent = "Paste the link or code from Troy's settings."; return; }
  token = t; try { localStorage.setItem(KEY, t); } catch { /* ignore */ }
  start();
});

async function start() {
  if (!token) { showPair(""); return; }
  try {
    await hydrate();
    I18N.sync(rpc);                                  // follow the language chosen on the PC (reloads once if it differs)
    $("#pair").classList.add("hidden"); $("#app").classList.remove("hidden");
    connect();
    if (!face) { mountFace(); }
  } catch (e) {
    if (e.message !== "unauthorized") { $("#pair").classList.add("hidden"); $("#app").classList.remove("hidden"); if (!face) mountFace(); setState("offline"); banner("Can't reach Troy. Is the PC on and Troy running?", true); setTimeout(start, 4000); }
  }
}
applyPrefs();
const P = window.TroyPhone = { api, rpc, toast, esc, md, buzz, S, prefs, setPref, setTab, newChat, listeners: [], serverNow,
  isLight, reloadChat, updateTitle, showPair, sheet: null };
setInterval(applyAvatar, 250);
setInterval(() => api("/api/state").then((st) => { if (st.now) clockOffset = st.now - Date.now(); }).catch(() => {}), 60000);   // keep the shared clock honest
start();
requestAnimationFrame(() => moveLens(false));
window.__troyPhone = { send, onEvent, setTab, get state() { return S; }, voice: { get vo() { return VO; }, start: startVoice, end: endVoice, speak: queueSpeak, endpointer: MicEndpointer, downsample: makeDownsampler, setState: setVoiceState, secure: showSecurePanel } };      // handy for tests and debugging
})();
