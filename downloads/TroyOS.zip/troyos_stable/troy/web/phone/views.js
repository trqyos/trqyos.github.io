/* Troy phone page: the Chats, Tasks and Settings screens, plus the bottom sheet they share.
 * They talk to the PC app through POST /api/rpc (an allow-list of the PC app's own methods), and
 * stay current through the events the PC mirrors to the phone (task.*, session.changed, settings.changed ...). */
"use strict";
(() => {
const P = window.TroyPhone;
if (!P) return;
const { rpc, esc, toast, S } = P;
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => Array.from(r.querySelectorAll(s));
const ic = (n) => `<svg><use href="#i-${n}"/></svg>`;
const msg = (e) => String(e?.message || e || "Something went wrong.");
const debounce = (fn, ms) => { let t; return (...a) => { clearTimeout(t); t = setTimeout(() => fn(...a), ms); }; };
const pad = (n) => String(n).padStart(2, "0");

function ago(iso) {
  const t = Date.parse(iso); if (!t) return "";
  const m = Math.round((Date.now() - t) / 60000);
  if (m < 1) return "just now"; if (m < 60) return `${m} min ago`;
  const h = Math.round(m / 60); if (h < 24) return `${h} h ago`;
  const d = Math.round(h / 24); if (d < 7) return `${d} day${d > 1 ? "s" : ""} ago`;
  return new Date(t).toLocaleDateString(undefined, { month: "short", day: "numeric" });
}
function when(iso) { const d = new Date(iso); return `${d.toLocaleDateString(undefined, { weekday: "short", month: "short", day: "numeric" })} ${pad(d.getHours())}:${pad(d.getMinutes())}`; }
function inn(iso) {
  const s = Math.round((Date.parse(iso) - Date.now()) / 1000); if (!isFinite(s)) return "";
  if (s < 0) return "due"; if (s < 90) return "in under 2 min"; const m = Math.round(s / 60); if (m < 90) return `in ${m} min`;
  const h = Math.round(m / 60); if (h < 36) return `in ${h} h`; return `in ${Math.round(h / 24)} days`;
}

/* ================================================================ bottom sheet */
const wrap = $("#sheetWrap"), body = $("#sheetBody");
let sheetClose = null;
function closeSheet() {
  if (wrap.classList.contains("hidden")) return;
  wrap.classList.add("closing");
  setTimeout(() => { wrap.classList.add("hidden"); wrap.classList.remove("closing"); body.innerHTML = ""; document.body.classList.remove("kb"); sheetClose?.(); sheetClose = null; }, 280);
}
function openSheet(html, onReady, onClose) {
  body.innerHTML = html; sheetClose = onClose || null;
  wrap.classList.remove("closing", "hidden"); $("#sheet").scrollTop = 0;
  if (onReady) onReady(body);
  return body;
}
$("#sheetScrim").addEventListener("click", closeSheet);
P.sheet = { open: openSheet, close: closeSheet };
const menuSheet = (title, items) => {
  const el = openSheet(`<h3>${esc(title)}</h3><div class="menu">${items.map((it, i) => `<button class="btn ${it.cls || ""}" data-i="${i}">${ic(it.icon)}${esc(it.text)}</button>`).join("")}</div>`);
  el.addEventListener("click", (e) => { const b = e.target.closest("[data-i]"); if (!b) return; closeSheet(); items[+b.dataset.i].run(); });
};
const confirmSheet = (title, text, okText, run) => {
  const el = openSheet(`<h3>${esc(title)}</h3><p class="sub">${esc(text)}</p><div class="actions"><button class="btn" data-a="no">Cancel</button><button class="btn pri" data-a="ok">${esc(okText)}</button></div>`);
  el.addEventListener("click", (e) => { const a = e.target.closest("[data-a]")?.dataset.a; if (!a) return; closeSheet(); if (a === "ok") run(); });
};
const pickSheet = (title, options, current, pick, sub = "") => {
  const el = openSheet(`<h3>${esc(title)}</h3>${sub ? `<p class="sub">${esc(sub)}</p>` : ""}<div class="menu">${options.map((o, i) => `<button class="opt ${o.id === current ? "on" : ""}" data-i="${i}"><span>${esc(o.label)}</span>${o.id === current ? ic("check") : ""}</button>`).join("")}</div>`);
  el.addEventListener("click", (e) => { const b = e.target.closest("[data-i]"); if (!b) return; closeSheet(); pick(options[+b.dataset.i].id); });
};
const textSheet = (title, sub, value, placeholder, save) => {
  const el = openSheet(`<h3>${esc(title)}</h3><p class="sub">${esc(sub)}</p><input id="tsIn" type="text" value="${esc(value)}" placeholder="${esc(placeholder)}" maxlength="80"><div class="actions"><button class="btn" data-a="no">Cancel</button><button class="btn pri" data-a="ok">Save</button></div>`);
  setTimeout(() => $("#tsIn", el)?.focus(), 350);
  const go = () => { const v = $("#tsIn", el).value.trim(); closeSheet(); save(v); };
  el.addEventListener("click", (e) => { const a = e.target.closest("[data-a]")?.dataset.a; if (a === "no") closeSheet(); else if (a === "ok") go(); });
  $("#tsIn", el).addEventListener("keydown", (e) => { if (e.key === "Enter") go(); });
};

/* ===================================================================== chats */
const C = { list: [], q: "", results: null };
const chatList = $("#chatList");
async function loadChats() {
  try { C.list = (await rpc("session.list")).sessions || []; } catch (e) { chatList.innerHTML = `<div class="empty-note">${esc(msg(e))}</div>`; return; }
  const cur = C.list.find((s) => s.id === S.sid); if (cur) { S.title = cur.title; P.updateTitle(); }
  renderChats();
}
function chatItem(s, i, extra = "") {
  return `<div class="item tap pop ${s.id === S.sid ? "cur" : ""}" data-id="${esc(s.id)}" style="--i:${Math.min(i, 10)}">
    <div class="t"><span class="n">${esc(s.title || "Untitled")}</span><button class="round sm more" data-more aria-label="More">${ic("pencil")}</button></div>
    <div class="m"><span>${esc(ago(s.updated_at))}</span>${s.task_count ? `<span>${ic("tasks")}${s.task_count} task${s.task_count > 1 ? "s" : ""}</span>` : ""}${s.id === S.sid ? '<span class="badge pri">Open</span>' : ""}</div>${extra}</div>`;
}
function renderChats() {
  if (C.results) {
    chatList.innerHTML = C.results.length ? C.results.map((r, i) => chatItem(r, i, (r.hits || []).slice(0, 2).map((h) => `<div class="snip">${esc(h.snippet)}</div>`).join(""))).join("") : '<div class="empty-note">No chats match.</div>';
  } else chatList.innerHTML = C.list.length ? C.list.map((s, i) => chatItem(s, i)).join("") : '<div class="empty-note">No chats yet. Say something to Troy to start one.</div>';
}
async function openChat(id) {
  if (S.busy) { toast("Troy is busy \u2014 stop the current task first.", "info"); return; }
  try {
    const r = await rpc("session.load", { id });
    S.sid = id; S.title = r.title || "Chat"; S.manualCompact = undefined;
    await P.reloadChat(); P.setTab("chat");
  } catch (e) { toast(msg(e)); }
}
function chatMenu(id) {
  const s = C.list.find((x) => x.id === id) || C.results?.find((x) => x.id === id); if (!s) return;
  menuSheet(s.title || "Chat", [
    { icon: "pencil", text: "Rename", run: () => textSheet("Rename chat", "Shown in your chat list on every device.", s.title || "", "Chat name", async (v) => { if (!v) return; try { await rpc("session.rename", { id, title: v }); if (id === S.sid) { S.title = v; P.updateTitle(); } loadChats(); } catch (e) { toast(msg(e)); } }) },
    { icon: "trash", text: "Delete", cls: "bad", run: () => confirmSheet("Delete this chat?", "Its messages are removed for good.", "Delete", async () => { try { await rpc("session.delete", { id }); if (id === S.sid) { S.sid = null; S.title = ""; P.reloadChat(); } loadChats(); } catch (e) { toast(msg(e)); } }) },
  ]);
}
chatList.addEventListener("click", (e) => {
  const it = e.target.closest(".item"); if (!it) return;
  if (e.target.closest("[data-more]")) chatMenu(it.dataset.id); else openChat(it.dataset.id);
});
$("#chatsNew").addEventListener("click", () => P.newChat());
const runSearch = debounce(async () => {
  const q = C.q.trim();
  if (!q) { C.results = null; renderChats(); return; }
  try { C.results = ((await rpc("session.search", { query: q, limit: 30 })).results) || []; } catch { C.results = []; }
  renderChats();
}, 280);
$("#chatQ").addEventListener("input", (e) => { C.q = e.target.value; runSearch(); });

/* ===================================================================== tasks */
const STATUS = { scheduled: ["Scheduled", "pri"], running: ["Running now", "run"], retrying: ["Retrying", "warn"], paused: ["Paused", ""], completed: ["Done", "ok"], failed: ["Failed", "bad"], cancelled: ["Cancelled", ""], missed: ["Missed", "warn"] };
const FINISHED = ["completed", "failed", "cancelled", "missed"];
const isDone = (t) => FINISHED.includes(t.status);
const K = { tasks: [], info: {}, filter: "active", open: {}, step: {} };
const taskList = $("#taskList");

async function loadTasks() {
  try { const r = await rpc("tasks.list"); K.tasks = r.tasks || []; K.info = r; } catch (e) { taskList.innerHTML = `<div class="empty-note">${esc(msg(e))}</div>`; return; }
  renderTasks();
}
function upsert(t) {
  const i = K.tasks.findIndex((x) => x.id === t.id), keep = i >= 0 ? K.tasks[i] : {};
  const merged = { chat_exists: keep.chat_exists, chat_title: keep.chat_title, ...t };
  if (i >= 0) K.tasks[i] = merged; else K.tasks.unshift(merged);
  if (t.status !== "running") delete K.step[t.id];
  renderTasks();
}
function taskCard(t, i) {
  const [label, tone] = STATUS[t.status] || [t.status, ""], done = isDone(t), running = t.status === "running";
  let last = "";
  if (running && K.step[t.id]) last = `<div class="last"><b>Now:</b> ${esc(K.step[t.id])}</div>`;
  else if (t.last_outcome === "success") last = `<div class="last ok"><b>Last run: done.</b> ${esc(t.last_summary || "")}</div>`;
  else if (t.last_outcome === "missed") last = `<div class="last warn"><b>Missed.</b> ${esc(t.last_summary || "")}</div>`;
  else if (t.last_outcome) last = `<div class="last bad"><b>Last run ${t.last_outcome === "stopped" ? "stopped" : "failed"}.</b> ${esc(t.last_error || t.last_summary || "")}</div>`;
  const need = (t.needs_approval || []).length ? `<div class="approval"><span>${ic("shield")}Needs your approval to run unattended: ${t.needs_approval.map((c) => `<code>${esc(c)}</code>`).join(" ")}</span><button class="btn sm pri" data-a="approve">Approve and run now</button></div>` : "";
  const b = (a, icon, text, cls = "") => `<button class="btn sm ${cls}" data-a="${a}">${ic(icon)}${text}</button>`;
  const acts = running ? b("stop", "stop", "Stop", "bad") : [b("run", "play", done ? "Run again" : "Run now"),
    t.status === "paused" ? b("resume", "play", "Resume") : (!done ? b("pause", "pause", "Pause") : ""), b("edit", "pencil", done ? "Reschedule" : "Edit"),
    done ? b("delete", "trash", "Delete", "bad") : b("cancel", "x", "Cancel", "bad"), b("log", "log", K.open[t.id] ? "Hide log" : "Log")].join("");
  return `<div class="item pop ${running ? "running" : ""}" data-task="${esc(t.id)}" style="--i:${Math.min(i, 10)}">
    <div class="t"><span class="n">${esc(t.title)}</span><span class="badge ${tone}">${label}</span></div>
    <div class="m"><span>${ic("clock")}${esc(t.schedule_text || "")}</span>${t.next_run ? `<span>${esc(when(t.next_run))} \u00B7 ${esc(inn(t.next_run))}</span>` : ""}${(running || t.status === "retrying") && t.run ? `<span>Attempt ${t.run.attempt} of ${1 + t.effective_max_retries}</span>` : ""}</div>
    <div class="prompt">${esc(t.prompt)}</div>${last}${need}<div class="acts">${acts}</div>${K.open[t.id] ? '<div class="tlog">Loading\u2026</div>' : ""}</div>`;
}
function renderTasks() {
  const active = K.tasks.filter((t) => !isDone(t)), badge = $("#tasksBadge");
  badge.textContent = String(active.length); badge.classList.toggle("hidden", !active.length);
  $("#taskOff").classList.toggle("hidden", K.info.enabled !== false);
  $("#taskClear").classList.toggle("hidden", !K.tasks.some(isDone));
  $$("#taskFilter button").forEach((x) => x.classList.toggle("on", x.dataset.v === K.filter));
  const list = K.tasks.filter((t) => K.filter === "all" || (K.filter === "active") === !isDone(t));
  taskList.innerHTML = list.length ? list.map(taskCard).join("") : `<div class="empty-note">${K.tasks.length ? "Nothing here." : "No tasks yet. Tell Troy \u201Cput the PC to sleep at 10 PM\u201D, or press New task."}</div>`;
  for (const id of Object.keys(K.open)) if (K.open[id]) fillLog(id);
}
async function fillLog(id) {
  const box = $(`[data-task="${id}"] .tlog`); if (!box) return;
  try { const { entries } = await rpc("tasks.logs", { id, limit: 40 }); box.textContent = entries.length ? entries.map((e) => `${String(e.ts).slice(5, 16).replace("T", " ")}  ${e.event}: ${e.message}`).join("\n") : "No log entries yet."; box.scrollTop = box.scrollHeight; }
  catch (e) { box.textContent = msg(e); }
}
async function act(id, a) {
  const run = async (m, p) => { try { const r = await rpc(m, { id, ...(p || {}) }); if (r.task) upsert(r.task); return r; } catch (e) { toast(msg(e)); } };
  if (a === "run") run("tasks.run_now"); else if (a === "pause") run("tasks.pause"); else if (a === "resume") run("tasks.resume");
  else if (a === "approve") run("tasks.approve"); else if (a === "stop") { P.api("/api/stop", {}).catch(() => {}); }
  else if (a === "log") { K.open[id] = !K.open[id]; renderTasks(); }
  else if (a === "edit") taskForm(K.tasks.find((t) => t.id === id));
  else if (a === "cancel") confirmSheet("Cancel this task?", "It won't run again unless you reschedule it.", "Cancel task", () => run("tasks.cancel"));
  else if (a === "delete") confirmSheet("Delete this task?", "It disappears from the list.", "Delete", async () => { try { await rpc("tasks.delete", { id }); K.tasks = K.tasks.filter((t) => t.id !== id); renderTasks(); } catch (e) { toast(msg(e)); } });
}
taskList.addEventListener("click", (e) => { const b = e.target.closest("[data-a]"), it = e.target.closest("[data-task]"); if (b && it) act(it.dataset.task, b.dataset.a); });
$("#taskFilter").addEventListener("click", (e) => { const b = e.target.closest("button"); if (b) { K.filter = b.dataset.v; renderTasks(); } });
$("#taskClear").addEventListener("click", () => confirmSheet("Clear finished tasks?", "Done, failed, missed and cancelled tasks are removed.", "Clear", async () => { try { await rpc("tasks.clear_finished"); loadTasks(); } catch (e) { toast(msg(e)); } }));
$("#taskNew").addEventListener("click", () => taskForm(null));

function taskForm(task) {
  const editing = !!task, d = K.info.defaults || {};
  const el = openSheet(`<h3>${editing ? "Edit task" : "New task"}</h3><p class="sub">${editing ? "Change what Troy does or when." : "Troy does this at the time you give, with nobody watching."}</p>
    <label>Name<small>Optional: shown in the list.</small><input id="tfTitle" type="text" maxlength="60" value="${esc(task?.title || "")}" placeholder="e.g. Sleep the PC"></label>
    <label>When<small>\u201Cin 30 minutes\u201D, \u201Ctomorrow at 9am\u201D, \u201Cevery Monday at 22:00\u201D</small><input id="tfWhen" type="text" placeholder="${editing ? `Now: ${esc(task.schedule_text)} (empty = keep)` : "every day at 22:00"}" autocapitalize="off"></label>
    <div id="tfPv" class="pv"></div>
    <label>What Troy should do<small>A short instruction, as if telling a person.</small><textarea id="tfPrompt" rows="3" placeholder="Put the computer to sleep.">${esc(task?.prompt || "")}</textarea></label>
    ${editing ? "" : `<label>Allow without asking<small>Commands that normally need approval, separated by \u201C;\u201D (e.g. sleep_computer).</small><input id="tfApprove" type="text" placeholder="sleep_computer" autocapitalize="off"></label>`}
    <div class="two"><label>Retries<small>Default ${d.max_retries ?? 2}</small><input id="tfRetries" type="number" min="0" max="10" value="${task?.max_retries ?? ""}" placeholder="default"></label>
    <label>Seconds apart<small>Default ${d.retry_delay ?? 30}</small><input id="tfDelay" type="number" min="5" max="3600" value="${task?.retry_delay ?? ""}" placeholder="default"></label></div>
    <div id="tfErr" class="pv bad"></div><div class="actions"><button class="btn" data-a="no">Cancel</button><button class="btn pri" data-a="ok">${editing ? "Save" : "Create task"}</button></div>`);
  const f = (id) => $(`#${id}`, el), err = (t) => { f("tfErr").textContent = t || ""; };
  const preview = debounce(async () => {
    const w = f("tfWhen").value.trim(), pv = f("tfPv"); pv.className = "pv"; if (!w) { pv.textContent = ""; return; }
    try { const r = await rpc("tasks.preview", { when: w }); pv.classList.toggle("bad", !r.ok); pv.textContent = r.ok ? `${r.text} \u2014 next: ${r.next.slice(0, 2).map(when).join(", ")}` : r.error; } catch { pv.textContent = ""; }
  }, 350);
  f("tfWhen").addEventListener("input", preview);
  el.addEventListener("click", async (e) => {
    const a = e.target.closest("[data-a]")?.dataset.a; if (!a) return;
    if (a === "no") { closeSheet(); return; }
    const prompt = f("tfPrompt").value.trim(), whenV = f("tfWhen").value.trim();
    if (!prompt) return err("Tell Troy what to do."); if (!editing && !whenV) return err("Say when it should run.");
    try {
      const p = { title: f("tfTitle").value.trim(), prompt };
      if (editing) { p.id = task.id; if (whenV) p.when = whenV; const r = f("tfRetries").value, dl = f("tfDelay").value; p.max_retries = r; p.retry_delay = dl; if (r === "" && dl === "") p.default_retries = true; }
      else { p.when = whenV; p.approve = f("tfApprove").value.trim(); }
      const r = await rpc(editing ? "tasks.modify" : "tasks.create", p);
      closeSheet(); if (r.task) upsert(r.task); P.buzz(15);
    } catch (x) { err(msg(x)); }
  });
}

/* ================================================================== settings */
const T = { values: {}, secrets: {}, providers: [], memories: [], version: "" };
const POWER = [{ id: "auto", label: "Automatic (on battery)" }, { id: "on", label: "Always save power" }, { id: "off", label: "Never" }];
const NAMES = { auto: "Automatic", on: "Always on", off: "Off", phone: "This phone", troy: "Troy's voice (PC)", light: "Light", dark: "Dark", en: "English", tr: "Türkçe" };
async function loadSettings() {
  try {
    const [s, p, m] = await Promise.all([rpc("settings.get"), rpc("provider.list").catch(() => ({ providers: [], overrides: {} })), rpc("memory.list").catch(() => ({ memories: [] }))]);
    T.values = s.values || {}; T.version = s.version_label || s.version || ""; T.providers = p.providers || []; T.overrides = p.overrides || {}; T.memories = m.memories || [];
  } catch (e) { $("#setBody").innerHTML = `<div class="empty-note">${esc(msg(e))}</div>`; return; }
  renderSettings();
}
const swRow = (icon, title, sub, key) => `<div class="row tap" data-sw="${key}"><span class="ic">${ic(icon)}</span><div class="tx"><b>${title}</b><small>${sub}</small></div><i class="sw ${T.values[key] ? "on" : ""}"></i></div>`;
const navRow = (icon, title, sub, val, id) => `<div class="row tap" data-nav="${id}"><span class="ic">${ic(icon)}</span><div class="tx"><b>${title}</b>${sub ? `<small>${sub}</small>` : ""}</div><span class="val">${esc(val || "")}</span>${ic("chev")}</div>`;
function renderSettings() {
  const v = T.values, prim = T.providers.find((p) => p.primary), ov = T.overrides?.text || "";
  const model = ov ? ov.split(":").slice(1).join(":") || ov : "Automatic";
  const theme = P.prefs.theme || "auto";
  $("#setBody").innerHTML = `
  <div class="group pop" style="--i:0"><h3>You</h3><div class="box">${navRow("user", "Your name", "What Troy calls you", v.USER_NAME || "Not set", "name")}
    ${navRow("chat", "Language", "Troy's windows, widget and this page", v.UI_LANGUAGE === "auto" ? "Automatic" : NAMES[v.UI_LANGUAGE || "en"], "language")}</div></div>
  <div class="group pop" style="--i:1"><h3>Brain</h3><div class="box">
    ${navRow("brain", "Provider", "Where Troy thinks", prim?.label || v.PRIMARY_PROVIDER, "provider")}
    ${navRow("bolt", "Model", "Text model", model, "model")}
    ${swRow("bolt", "Fast replies", "Shorter, quicker answers", "LLM_FAST")}
    ${swRow("brain", "Troy may switch models", "Lets Troy pick a stronger or faster one", "ALLOW_MODEL_SWITCH")}</div></div>
  <div class="group pop" style="--i:2"><h3>Voice</h3><div class="box">
    ${swRow("speaker", "Speak replies on the PC", "Through the PC's speakers", "VOICE_OUTPUT_ENABLED")}
    ${swRow("speaker", "Talk over Troy to interrupt", "Barge-in", "VOICE_BARGE_IN")}
    ${swRow("chat", "Spoken style", "Replies written to be heard", "VOICE_SPOKEN_STYLE")}
    ${navRow("speaker", "Phone voice", "Whose voice you hear in voice mode", NAMES[v.VOICE_PHONE_SPEAKER] || v.VOICE_PHONE_SPEAKER, "speaker")}</div></div>
  <div class="group pop" style="--i:3"><h3>PC</h3><div class="box">
    ${navRow("battery", "Power saving", "Calmer animation, fewer updates", NAMES[v.POWER_SAVING] || v.POWER_SAVING, "power")}
    ${swRow("tasks", "Scheduled tasks", "Let Troy run tasks on time", "TASKS_ENABLED")}
    ${navRow("brain", "Memory", "Things Troy remembers", `${T.memories.length}`, "memory")}</div></div>
  <div class="group pop" style="--i:4"><h3>This phone</h3><div class="box">
    ${navRow("moon", "Appearance", "Only on this phone", NAMES[theme] || "Automatic", "theme")}
    <div class="row tap" data-calm><span class="ic">${ic("bolt")}</span><div class="tx"><b>Calm animations</b><small>Stops the drifting glass and ripples</small></div><i class="sw ${P.prefs.calm ? "on" : ""}"></i></div>
    ${navRow("link", "Disconnect", "Forget this PC on this phone", "", "disconnect")}</div></div>
  <p class="hint">Troy ${esc(T.version)} \u00B7 API keys and phone access are changed on the PC.</p>`;
}
async function save(changes) {
  try { await rpc("settings.update", { changes }); Object.assign(T.values, changes); } catch (e) { toast(msg(e)); }
  renderSettings();
}
const setBody = $("#setBody");
setBody.addEventListener("click", async (e) => {
  const sw = e.target.closest("[data-sw]"), nav = e.target.closest("[data-nav]");
  if (e.target.closest("[data-calm]")) { P.setPref("calm", !P.prefs.calm); renderSettings(); return; }
  if (sw) { const k = sw.dataset.sw; $(".sw", sw).classList.toggle("on"); P.buzz(8); save({ [k]: !T.values[k] }); return; }
  if (!nav) return;
  const id = nav.dataset.nav, v = T.values;
  if (id === "name") textSheet("Your name", "What Troy calls you.", v.USER_NAME || "", "Your name", (x) => save({ USER_NAME: x }));
  else if (id === "language") pickSheet("Language", [{ id: "en", label: "English" }, { id: "tr", label: "Türkçe" }, { id: "auto", label: "Automatic (system language)" }], v.UI_LANGUAGE || "en", async (lang) => { await save({ UI_LANGUAGE: lang }); I18N.sync(rpc); });
  else if (id === "provider") pickSheet("Provider", T.providers.filter((p) => p.configured).map((p) => ({ id: p.id, label: p.label })), v.PRIMARY_PROVIDER, async (pid) => { try { await rpc("provider.set_primary", { provider: pid }); v.PRIMARY_PROVIDER = pid; await loadSettings(); } catch (x) { toast(msg(x)); } }, "Only providers with a key on the PC are listed.");
  else if (id === "model") {
    const prim = T.providers.find((p) => p.id === v.PRIMARY_PROVIDER), models = (prim?.models?.text || []);
    const cur = T.overrides?.text || "";
    pickSheet("Text model", [{ id: "", label: "Automatic" }, ...models.map((m) => ({ id: m, label: m }))], cur ? cur.split(":").slice(1).join(":") : "", async (m) => { try { await rpc("model.set", { kind: "text", provider: m ? prim.id : "", model: m }); await loadSettings(); } catch (x) { toast(msg(x)); } }, `Models from ${prim?.label || "the provider"}.`);
  } else if (id === "speaker") pickSheet("Phone voice", [{ id: "phone", label: "This phone's own voice" }, { id: "troy", label: "Troy's voice from the PC" }], v.VOICE_PHONE_SPEAKER, (x) => save({ VOICE_PHONE_SPEAKER: x }));
  else if (id === "power") pickSheet("Power saving", POWER, v.POWER_SAVING, (x) => save({ POWER_SAVING: x }), "Applies to the PC app, the widget and this page.");
  else if (id === "theme") pickSheet("Appearance", [{ id: "auto", label: "Automatic" }, { id: "dark", label: "Dark" }, { id: "light", label: "Light" }], P.prefs.theme || "auto", (x) => { P.setPref("theme", x); renderSettings(); });
  else if (id === "memory") memorySheet();
  else if (id === "disconnect") confirmSheet("Disconnect this phone?", "You'll need the link from the PC to connect again.", "Disconnect", () => { try { localStorage.removeItem("troy.phone.token"); } catch { /* ignore */ } location.reload(); });
});
function memorySheet() {
  const draw = () => {
    const el = openSheet(`<h3>Memory</h3><p class="sub">Facts Troy keeps about you.</p><div class="menu">${T.memories.length ? T.memories.map((m, i) => `<div class="opt"><span>${esc(m.fact)}</span><button class="round sm" data-del="${i}" aria-label="Forget">${ic("trash")}</button></div>`).join("") : '<div class="empty-note">Nothing yet.</div>'}</div>
      <label>Add a fact<input id="memIn" type="text" placeholder="I like jazz" maxlength="200"></label><div class="actions"><button class="btn pri" data-a="add">Remember</button><button class="btn" data-a="done">Done</button></div>`);
    el.addEventListener("click", async (e) => {
      const del = e.target.closest("[data-del]"), a = e.target.closest("[data-a]")?.dataset.a;
      try {
        if (del) { await rpc("memory.delete", { index: +del.dataset.del }); T.memories.splice(+del.dataset.del, 1); draw(); }
        else if (a === "add") { const f = $("#memIn", el).value.trim(); if (f) { await rpc("memory.add", { fact: f }); T.memories = (await rpc("memory.list")).memories || []; draw(); } }
        else if (a === "done") { closeSheet(); renderSettings(); }
      } catch (x) { toast(msg(x)); }
    });
  };
  draw();
}

/* ============================================================ wiring + live */
P.listeners.push((name, d) => {
  if (name === "tab") { if (d.tab === "chats") loadChats(); else if (d.tab === "tasks") loadTasks(); else if (d.tab === "settings") loadSettings(); }
  else if (name === "hydrated") { loadTasks(); loadChats(); }
  else if (name === "task.changed") { if (d.task) upsert(d.task); }
  else if (name === "task.deleted") { K.tasks = K.tasks.filter((t) => t.id !== d.id); renderTasks(); }
  else if (name === "task.step") { K.step[d.id] = `${d.name}${d.arg ? `: ${String(d.arg).slice(0, 60)}` : ""} ${d.success ? "\u2713" : "\u2717"}`; renderTasks(); }
  else if (name === "task.started") { if (d.task) { K.step[d.task.id] = "starting\u2026"; upsert(d.task); } toast(`Running task: ${d.task?.title || ""}`, "info", 2600); }
  else if (name === "task.retrying") toast(`Task \u201C${d.task?.title}\u201D failed, trying again soon.`, "info", 5000);
  else if (name === "task.finished") { toast(d.text || "Task finished", d.ok ? "ok" : "bad", 7000); if (d.task) upsert(d.task); }
  else if (name === "session.changed") { if (S.tab === "chats" || d.action === "created") loadChats(); else if (d.action === "renamed" || d.action === "deleted") loadChats(); }
  else if (name === "settings.changed" || name === "model.changed") { if (name === "settings.changed") I18N.sync(rpc); if (S.tab === "settings") loadSettings(); }
  else if (name === "power.state") { T.values.POWER_SAVING = T.values.POWER_SAVING; }
});
})();
