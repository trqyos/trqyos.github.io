"""
Persistent, validated runtime settings.

Everything the Settings screen (and Troy itself, via the model-switching
tools) can change lives here: a typed allow-list, range/enum validation,
live application onto `config`, and a small JSON file so changes survive a
restart without editing .env. API keys are accepted but write-only.

Kept separate from troy/ipc_host.py so that tools_all.py (Troy changing its
own model mid-chat) can use exactly the same code path as the UI.
"""

import json
import os

from . import config, llm_client

SETTINGS_FILE = os.path.join(config.PROJECT_ROOT, "troy_settings.json")
# key -> type. Everything here is applied to `config` immediately AND saved
# to troy_settings.json so it survives restarts (no .env editing needed).
SETTINGS = {
    "USER_NAME": str, "PRIMARY_PROVIDER": str,
    "TEXT_MODEL_OVERRIDE": str, "VISION_MODEL_OVERRIDE": str,
    "ESCALATION_ENABLED": bool, "LMSTUDIO_ENABLED": bool,
    "VOICE_INPUT_ENABLED": bool, "VOICE_OUTPUT_ENABLED": bool,
    "POWER_SAVING": str, "WAKE_WORD": str, "STT_ENGINE": str,
    "TTS_RATE": int, "TTS_VOICE_ID": str,
    "MAX_STEPS_PER_TURN": int, "BROWSER_HEADLESS": bool,
    # speed / context size
    "PROMPT_MODE": str, "CONTEXT_BUDGET_TOKENS": int, "LLM_MAX_OUTPUT_TOKENS": int, "LLM_FAST": bool,
    "LMSTUDIO_CONTEXT_TOKENS": int, "LMSTUDIO_TEXT_MODEL": str, "LMSTUDIO_VISION_MODEL": str,
    # apps, phone, integrations
    "TTS_ENGINE": str, "EDGE_VOICE": str, "PIPER_MODEL": str, "VOICE_CONVERSATION_IDLE_SECONDS": int, "VOICE_BARGE_IN": bool,
    "VOICE_INPUT_DEVICE": str, "VOICE_SPOKEN_STYLE": bool, "STT_LANGUAGE": str, "MOBILE_VOICE_ENABLED": bool,
    "VOICE_PHONE_SPEAKER": str, "MOBILE_HTTPS_ENABLED": bool, "WAKE_WORD_FOLLOWUP_SECONDS": float,
    "ALLOW_MODEL_SWITCH": bool, "APP_LAUNCH_MODE": str, "MOBILE_SCREEN_ENABLED": bool, "MOBILE_SCREEN_MAX_FPS": int,
    "YOUTUBE_CLIENT_ID": str, "YOUTUBE_BROWSER": str,
    # scheduled tasks + on-demand extra tools
    "TASKS_ENABLED": bool, "TASK_MAX_RETRIES": int, "TASK_RETRY_DELAY_SECONDS": int, "TASK_MISSED_GRACE_MINUTES": int,
    "EXTRA_TOOLS_ENABLED": bool, "TOOL_CALLING": str,
}
SECRETS = ("GROQ_API_KEY", "OPENROUTER_API_KEY", "GEMINI_API_KEY", "NVIDIA_API_KEY", "NEWSAPI_KEY", "YOUTUBE_CLIENT_SECRET")
RESTART_REQUIRED = {"BROWSER_HEADLESS"}
PROVIDERS = {  # id -> (label, secret key name or None)
    "groq": ("Groq", "GROQ_API_KEY"), "openrouter": ("OpenRouter", "OPENROUTER_API_KEY"),
    "gemini": ("Google Gemini", "GEMINI_API_KEY"), "nvidia": ("NVIDIA NIM", "NVIDIA_API_KEY"),
    "lmstudio": ("LM Studio (local)", None),
}


_listeners = []


def on_change(callback):
    """callback(changed_keys: set, source: str) -- how the UI hears about changes made by Troy itself."""
    _listeners.append(callback)


def notify(keys, source="user"):
    for cb in list(_listeners):
        try:
            cb(set(keys), source)
        except Exception:  # noqa: BLE001 - a listener must never break a settings change
            pass


def read_saved() -> dict:
    try:
        with open(SETTINGS_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError):
        return {}


def validate(key, value):
    """Range/enum checks so a bad value is rejected up front instead of
    being saved and then breaking something at the next startup."""
    if key == "PRIMARY_PROVIDER" and value not in PROVIDERS:
        raise ValueError(f"PRIMARY_PROVIDER must be one of: {', '.join(PROVIDERS)}.")
    if key == "STT_ENGINE" and value not in ("google", "whisper"):
        raise ValueError("STT_ENGINE must be 'google' or 'whisper'.")
    enums = {"PROMPT_MODE": ("auto", "compact", "tiny", "detailed"), "TOOL_CALLING": ("auto", "native", "text"), "APP_LAUNCH_MODE": ("auto", "direct", "start_menu"),
             "YOUTUBE_BROWSER": ("firefox", "chrome", "edge", "brave", "default"),
             "TTS_ENGINE": ("auto", "sapi", "edge", "piper"), "POWER_SAVING": ("off", "auto", "on"), "VOICE_PHONE_SPEAKER": ("phone", "troy")}
    if key in enums and value not in enums[key]:
        raise ValueError(f"{key} must be one of: {', '.join(enums[key])}.")
    ranges = {"CONTEXT_BUDGET_TOKENS": (1000, 60000), "LLM_MAX_OUTPUT_TOKENS": (128, 8000),
              "LMSTUDIO_CONTEXT_TOKENS": (1024, 262144), "MOBILE_SCREEN_MAX_FPS": (1, 30),
              "VOICE_CONVERSATION_IDLE_SECONDS": (5, 300), "WAKE_WORD_FOLLOWUP_SECONDS": (2, 60),
              "TASK_MAX_RETRIES": (0, 10), "TASK_RETRY_DELAY_SECONDS": (5, 3600), "TASK_MISSED_GRACE_MINUTES": (1, 1440)}
    if key in ranges and not ranges[key][0] <= value <= ranges[key][1]:
        raise ValueError(f"{key} must be between {ranges[key][0]} and {ranges[key][1]}.")
    if key == "TTS_RATE" and not 50 <= value <= 400:
        raise ValueError("TTS_RATE must be between 50 and 400.")
    if key == "MAX_STEPS_PER_TURN" and not 1 <= value <= 100:
        raise ValueError("MAX_STEPS_PER_TURN must be between 1 and 100.")
    if key in ("TEXT_MODEL_OVERRIDE", "VISION_MODEL_OVERRIDE") and value:
        provider, _, model = value.partition(":")
        if provider not in PROVIDERS or not model:
            raise ValueError(f"{key} must look like 'provider:model' (or be empty for automatic).")


def _coerce(kind, value):
    if kind is bool:
        return value if isinstance(value, bool) else str(value).strip().lower() in ("1", "true", "yes", "on")
    return kind(value) if kind is not str else str(value).strip()


def apply_settings(changes: dict, persist: bool = True) -> dict:
    """Validates + applies + (optionally) saves. All-or-nothing: a bad key
    or value raises before anything is changed."""
    staged = {}
    for key, value in changes.items():
        if key in SETTINGS:
            try:
                staged[key] = _coerce(SETTINGS[key], value)
            except (TypeError, ValueError):
                raise ValueError(f"Invalid value for {key}: {value!r}") from None
            validate(key, staged[key])
        elif key in SECRETS:
            staged[key] = str(value).strip()
        else:
            raise ValueError(f"Unknown or read-only setting: {key}")
    for key, value in staged.items():
        setattr(config, key, value)
    if staged.keys() & {"LMSTUDIO_ENABLED", "LMSTUDIO_TEXT_MODEL", "LMSTUDIO_VISION_MODEL", "LMSTUDIO_CONTEXT_TOKENS"}:
        llm_client._LM.update(at=0.0)           # re-discover on next use
    if staged.keys() & {"PRIMARY_PROVIDER", "TEXT_MODEL_OVERRIDE", "VISION_MODEL_OVERRIDE"}:
        llm_client.clear_cooldowns()           # a deliberate change deserves a fresh try
    if "POWER_SAVING" in staged:
        from . import power
        power.changed()
    if persist and staged:
        saved = read_saved()
        saved.update(staged)
        with open(SETTINGS_FILE, "w", encoding="utf-8") as f:
            json.dump(saved, f, indent=2)
    return staged


