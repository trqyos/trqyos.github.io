"""
Power saving.

POWER_SAVING = off | auto | on  (Settings > Power, or Troy's set_power_saving tool).
`auto` follows the battery: Electron reports it through the `power.report` IPC
method (the backend can't see it reliably on every OS), and this module turns
that into one boolean, `active()`, that everything consults:

* the UI (via the `power.state` event): pauses decorative animation, drops the
  frosted-glass blur, caps the avatar's frame rate
* backend loops that would otherwise spin: the live mic-level stream and the
  phone screen-share frame rate
"""

from . import config, ui_bridge

MODES = ("off", "auto", "on")
SAVER_PHONE_FPS = 4
SAVER_LEVEL_INTERVAL = 0.25     # seconds between voice.level events (normally 0.1)

_on_battery = None              # None until Electron has reported
_last = None


def mode() -> str:
    m = str(getattr(config, "POWER_SAVING", "auto")).lower()
    return m if m in MODES else "auto"


def active() -> bool:
    m = mode()
    return m == "on" or (m == "auto" and bool(_on_battery))


def status() -> dict:
    return {"mode": mode(), "on_battery": _on_battery, "active": active()}


def _announce():
    global _last
    s = status()
    if s != _last:
        _last = s
        ui_bridge.emit("power.state", s)


def changed():
    """The mode setting was edited."""
    _announce()


def report_battery(on_battery) -> dict:
    global _on_battery
    _on_battery = None if on_battery is None else bool(on_battery)
    _announce()
    return status()


def phone_fps(requested: int) -> int:
    return min(int(requested), SAVER_PHONE_FPS) if active() else int(requested)


def level_interval() -> float:
    return SAVER_LEVEL_INTERVAL if active() else 0.1
