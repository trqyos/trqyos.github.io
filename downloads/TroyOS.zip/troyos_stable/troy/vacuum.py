"""
Xiaomi Robot Vacuum S20+ (xiaomi.vacuum.b108gl): what the robot can do, and how to ask it safely.

Layers (so each is testable on its own):
    miot_client.py   the encrypted LAN protocol (knows nothing about vacuums)
    vacuum.py        THIS FILE: the S20+ property/action table + commands that check the robot really did something
    tools_vacuum.py  the model-facing tools (thin wrappers around the functions here)

Every address below comes from the published MIoT spec of xiaomi.vacuum.b108gl as quoted in the openHAB / Home Assistant
/ homebridge-miot threads and the roquerodrigo/ha-xiaomi-vacuum integration (see docs/VACUUM.md for sources). The S20+
numbers DIFFER from the X20 Max the HA integration documents in detail (e.g. status is 2/1 here, 2/2 there), so nothing
is borrowed from that table.

Two lessons from real S20+ owners drive the design:
  * the robot answers `code: 0` to payloads it silently ignores, so an acknowledgement proves nothing. Commands here
    re-read the robot's state and report what actually happened;
  * a room-clean command has been reported working in three different encodings on different stacks. "auto" tries them
    in turn, accepts one only if the robot really enters room-cleaning, stops a robot that started a whole-home clean
    by mistake, and remembers the encoding that worked.
"""

import json
import re
import threading
import time
import unicodedata

from . import config, miot_client
from .logger import logger

MODEL = "xiaomi.vacuum.b108gl"

# ---- property addresses (siid, piid) ----
STATUS, FAULT, SWEEP_MOP, SWEEP_TYPE, AREA, CLEAN_TIME, PASSES, SUCTION, WATER = (2, 1), (2, 2), (2, 3), (2, 4), (2, 5), (2, 6), (2, 7), (2, 8), (2, 9)
BATTERY, CHARGING = (3, 1), (3, 2)
VOLUME = (4, 2)
MOP_ATTACHED, FIRMWARE, STATUS_EXTRA, ROOM_INFO = (6, 1), (6, 2), (6, 9), (6, 10)
# consumables: (label, life-% property). The spec names three brush services alike; this order (8 main, 9 side, 11 mop)
# follows the spec's service order and a PR that told them apart by their Chinese labels. Filter is explicitly 10.
CONSUMABLES = (("main brush", (8, 2)), ("side brush", (9, 2)), ("filter", (10, 2)), ("mop pad", (11, 2)))

# ---- actions (siid, aiid) ----
A_START, A_STOP, A_PAUSE = (2, 1), (2, 2), (2, 6)
A_ROOMS = (2, 13)            # start-vacuum-room-sweep, input piid 13 (vacuum-room-ids)
A_RESUME = (6, 1)            # vacuum-extend: continue-sweep
A_LOCATE = (6, 6)            # vacuum-extend: find-vacuum
A_DOCK = (3, 1)              # battery: start-charge
ROOM_IN_PIID = 13

STATUS_TEXT = {1: "idle", 2: "charging on the dock", 3: "charging interrupted", 4: "cleaning", 5: "paused", 6: "returning to the dock",
               7: "in remote-control mode", 8: "fully charged on the dock", 9: "building a map", 10: "updating its firmware"}
SWEEP_TYPE_TEXT = {1: "whole home", 4: "an area", 5: "mapping", 6: "going to charge", 7: "remote control", 8: "selected rooms", 9: "custom clean"}
CLEANING, PAUSED, IDLE, CHARGING_S, DOCKED, RETURNING = 4, 5, 1, 2, 8, 6
ROOM_SWEEP = 8

MODES = {1: "sweep (vacuum only)", 2: "mop only", 3: "sweep and mop together", 4: "sweep first, then mop"}
SUCTION_LEVELS = {1: "silent", 2: "standard", 3: "strong", 4: "max"}
WATER_LEVELS = {0: "off", 1: "low", 2: "medium", 3: "high"}

# Words people (and models) use, English and Turkish, folded (see fold()).
_MODE_WORDS = {1: ("sweep", "vacuum", "sweep only", "vacuum only", "dry", "supur", "sadece supur", "kuru"),
               2: ("mop", "mop only", "mopping", "paspas", "sadece paspas", "sulu"),
               3: ("sweep mop", "sweep and mop", "vacuum and mop", "both", "sweep+mop", "mop and sweep", "supur ve paspas", "ikisi", "hem supur hem paspas"),
               4: ("sweep then mop", "sweep before mop", "sweep before mopping", "sweep first then mop", "vacuum then mop", "once supur sonra paspas", "supur sonra paspas")}
_SUCTION_WORDS = {1: ("silent", "quiet", "low", "whisper", "sessiz", "dusuk"), 2: ("standard", "basic", "normal", "medium", "orta", "standart"),
                  3: ("strong", "high", "guclu", "yuksek"), 4: ("max", "maximum", "full", "full speed", "turbo", "maksimum", "tam", "en yuksek")}
_WATER_WORDS = {0: ("off", "none", "dry", "kapali", "yok"), 1: ("low", "little", "dusuk", "az"), 2: ("medium", "mid", "normal", "orta"), 3: ("high", "max", "lots", "yuksek", "cok")}
ROOM_ENCODINGS = ("json_tagged", "json", "csv", "csv_tagged")

# Tests replace these to run without waiting.
_sleep = time.sleep
_now = time.monotonic


# ============================================================================ small helpers
def fold(text) -> str:
    """Lower-case, accent-free, Turkish-aware form used for matching ('Mutfak', 'MUTFAK', 'Çocuk Odası' -> 'cocuk odasi')."""
    s = str(text or "").replace("İ", "i").replace("I", "i").replace("ı", "i").lower()
    s = "".join(c for c in unicodedata.normalize("NFKD", s) if not unicodedata.combining(c))
    return re.sub(r"[^a-z0-9+]+", " ", s).strip()


def _choice(value, words: dict, names: dict, label: str):
    """'3', 'strong', 'Güçlü' -> 3. Raises ValueError listing the valid options."""
    v = fold(value)
    if v.lstrip("-").isdigit() and int(v) in words:
        return int(v)
    for key, aliases in words.items():
        if v in aliases:
            return key
    raise ValueError(f"'{value}' isn't a valid {label}. Options: " + ", ".join(n.split(" (")[0] for n in names.values()) + ".")


def _num(value, default=None):
    """'80', '80%', ' 2 ' -> float; anything else -> default."""
    m = re.fullmatch(r"\s*(-?\d+(?:\.\d+)?)\s*%?\s*", str(value))
    return float(m.group(1)) if m else default


def parse_rooms(raw) -> list:
    """The room-info property -> [{id, name, fan, water, mode, passes, on}]. Accepts the table form the robot reports
    ({"room_attrs": [[header...], [row...]]}) and the object form used when writing ({"room_attrs": [{...}]})."""
    if not raw:
        return []
    try:
        data = json.loads(raw) if isinstance(raw, str) else raw
    except ValueError:
        return []
    attrs = data.get("room_attrs") if isinstance(data, dict) else None
    if not attrs:
        return []
    rows = []
    if isinstance(attrs[0], list):
        header = [str(h) for h in attrs[0]]
        rows = [dict(zip(header, r)) for r in attrs[1:] if isinstance(r, list)]
    else:
        rows = [r for r in attrs if isinstance(r, dict)]
    out = []
    for r in rows:
        try:
            out.append({"id": int(r["id"]), "name": str(r.get("room_name") or f"Room {r['id']}"), "fan": r.get("fan_level"),
                        "water": r.get("water_level"), "mode": r.get("clean_mode"), "passes": r.get("clean_times"), "on": bool(r.get("on"))})
        except (KeyError, TypeError, ValueError):
            continue
    return out


def encode_rooms(ids, encoding: str) -> list:
    """The `in` list of start-vacuum-room-sweep for the given room ids."""
    csv = ",".join(str(i) for i in ids)
    as_json = json.dumps({"room": list(ids)}, separators=(",", ":"))
    return {"json_tagged": [{"piid": ROOM_IN_PIID, "value": as_json}], "json": [as_json],
            "csv": [csv], "csv_tagged": [{"piid": ROOM_IN_PIID, "value": csv}]}[encoding]


def split_names(text) -> list:
    return [p.strip() for p in re.split(r"[,;\n|]+|\s+(?:and|ve|&)\s+", str(text or ""), flags=re.IGNORECASE) if p.strip()]


def match_rooms(wanted: list, rooms: list):
    """-> (ids, problems). A name matches exactly, then by prefix, then by substring (after folding); a numeric id works too."""
    ids, problems = [], []
    for w in wanted:
        fw = fold(w)
        hits = [r for r in rooms if fold(r["name"]) == fw] or [r for r in rooms if fold(r["name"]).startswith(fw)] \
            or [r for r in rooms if fw and fw in fold(r["name"])]
        if not hits and fw.isdigit():
            hits = [r for r in rooms if r["id"] == int(fw)]
        if len(hits) == 1:
            if hits[0]["id"] not in ids:
                ids.append(hits[0]["id"])
        elif hits:
            problems.append(f"'{w}' matches several rooms ({', '.join(r['name'] for r in hits)}); be more specific")
        else:
            problems.append(f"no room called '{w}'")
    return ids, problems


# ============================================================================ the controller
class VacuumError(Exception):
    """A problem worded for the user (never a stack trace)."""


_lock = threading.RLock()
_client_cache = {"key": None, "client": None}
_client_factory = None          # tests inject a fake: callable(host, token, timeout) -> client


def configured() -> bool:
    return bool(config.VACUUM_HOST and config.VACUUM_TOKEN)


def _client():
    if not config.VACUUM_ENABLED:
        raise VacuumError("The robot vacuum integration is turned off. Turn it on in Settings > Integrations > Robot vacuum.")
    if not configured():
        raise VacuumError("The robot vacuum isn't set up yet: it needs its IP address and device token (Settings > Integrations > Robot vacuum; "
                          "docs/VACUUM.md explains how to get the token).")
    key = (config.VACUUM_HOST, config.VACUUM_TOKEN, config.VACUUM_TIMEOUT_SECONDS)
    if _client_cache["key"] != key:
        try:
            factory = _client_factory or (lambda h, t, to: miot_client.MiotClient(h, t, timeout=to))
            _client_cache.update(key=key, client=factory(*key))
        except ValueError as exc:
            raise VacuumError(str(exc)) from None
    return _client_cache["client"]


def _friendly(exc: Exception) -> str:
    if isinstance(exc, VacuumError):
        return str(exc)
    if isinstance(exc, miot_client.MiotTokenError):
        return str(exc)
    if isinstance(exc, miot_client.MiotConnectionError):
        return str(exc)
    if isinstance(exc, miot_client.MiotAckTimeout):
        return "The robot didn't answer in time. It may be busy, asleep far from the dock, or off Wi-Fi."
    if isinstance(exc, miot_client.MiotDeviceError):
        return f"The robot refused that ({exc})."
    if isinstance(exc, ValueError):
        return str(exc)
    return f"Unexpected problem talking to the robot: {exc}"


def guarded(fn):
    """Decorator: a command never raises; it returns {'success', 'message'} in plain words."""
    def wrapper(*args, **kwargs):
        try:
            with _lock:
                return fn(*args, **kwargs)
        except (VacuumError, miot_client.MiotError, ValueError) as exc:
            return {"success": False, "message": _friendly(exc)}
        except Exception as exc:  # noqa: BLE001
            logger.warning("Vacuum command %s failed unexpectedly: %s", fn.__name__, exc)
            return {"success": False, "message": _friendly(exc)}
    wrapper.__name__ = fn.__name__
    wrapper.__doc__ = fn.__doc__
    return wrapper


def _read(props: dict) -> dict:
    """{'name': (siid, piid)} -> {'name': value} (properties the robot doesn't answer are absent)."""
    got = _client().get_properties(list(props.values()))
    return {name: got[addr] for name, addr in props.items() if addr in got}


def read_state() -> dict:
    return _read({"status": STATUS, "fault": FAULT, "mode": SWEEP_MOP, "sweep_type": SWEEP_TYPE, "area": AREA, "time": CLEAN_TIME, "passes": PASSES,
                  "suction": SUCTION, "water": WATER, "battery": BATTERY, "charging": CHARGING, "mop": MOP_ATTACHED, "extra": STATUS_EXTRA})


def _act(addr, args=()):
    """Runs an action. A missing ack is not a failure: the robot often executes it anyway, and callers verify the state."""
    try:
        _client().action(addr[0], addr[1], args)
        return True
    except miot_client.MiotAckTimeout:
        return False


def _wait(predicate, timeout=8.0, interval=1.0):
    """Polls the robot's status until predicate(state) is true. -> (matched, last_state)."""
    end, last = _now() + timeout, {}
    while True:
        try:
            last = _read({"status": STATUS, "sweep_type": SWEEP_TYPE, "fault": FAULT})
        except miot_client.MiotError:
            last = {}
        if last and predicate(last):
            return True, last
        if _now() >= end:
            return False, last
        _sleep(interval)


def _say_status(state: dict) -> str:
    s = state.get("status")
    return STATUS_TEXT.get(s, f"in status {s}") if s is not None else "in an unknown state"


def _fault_note(state: dict) -> str:
    f = state.get("fault")
    return f" It reports fault code {f} (look at the robot or the Xiaomi Home app)." if f else ""


# ============================================================================ read-only
@guarded
def status() -> dict:
    st = read_state()
    if not st:
        return {"success": False, "message": "The robot answered, but gave no status. Is it the S20+ (xiaomi.vacuum.b108gl)? Run: python -m troy.vacuum_cli info"}
    bits = [f"The robot is {_say_status(st)}"]
    if st.get("status") == CLEANING and st.get("sweep_type") in SWEEP_TYPE_TEXT:
        bits[0] += f" ({SWEEP_TYPE_TEXT[st['sweep_type']]})"
    if st.get("extra") == 1:
        bits[0] += " (in sleep mode)"
    elif st.get("extra") == 2:
        bits[0] += " (relocating itself on the map)"
    if "battery" in st:
        bits.append(f"battery {st['battery']}%" + (" and charging" if st.get("charging") == 1 else ""))
    if st.get("area") or st.get("time"):
        bits.append(f"last/current clean: {st.get('area', 0) / 100:.1f} m² in {round(st.get('time', 0) / 60)} min")
    settings = []
    if st.get("mode") in MODES:
        settings.append(f"mode {MODES[st['mode']]}")
    if st.get("suction") in SUCTION_LEVELS:
        settings.append(f"suction {SUCTION_LEVELS[st['suction']]}")
    if st.get("water") in WATER_LEVELS:
        settings.append(f"mop water {WATER_LEVELS[st['water']]}")
    if st.get("passes"):
        settings.append(f"{st['passes']} pass{'es' if st['passes'] > 1 else ''}")
    if settings:
        bits.append("settings: " + ", ".join(settings))
    if st.get("mop") is False:
        bits.append("no mop pad attached")
    return {"success": True, "message": "; ".join(bits) + "." + _fault_note(st)}


@guarded
def rooms() -> dict:
    got = _client().get_properties([ROOM_INFO]).get(ROOM_INFO)
    lst = parse_rooms(got)
    if not lst:
        return {"success": False, "message": "The robot reports no rooms. Rooms appear after it has built a map and you've split it into rooms in the Xiaomi Home app."}
    lines = []
    for r in lst:
        cfg = [f"mode {MODES.get(r['mode'], r['mode'])}", f"suction {SUCTION_LEVELS.get(r['fan'], r['fan'])}", f"water {WATER_LEVELS.get(r['water'], r['water'])}"]
        lines.append(f"{r['name']} (id {r['id']}; {', '.join(cfg)}{'' if r['on'] else '; not selected'})")
    return {"success": True, "message": f"{len(lst)} rooms: " + "; ".join(lines) + ". Each room is cleaned with the settings saved for it in the Xiaomi Home app."}


@guarded
def consumables() -> dict:
    got = _client().get_properties([a for _, a in CONSUMABLES])
    parts = [f"{label} {got[addr]}%" for label, addr in CONSUMABLES if addr in got]
    if not parts:
        return {"success": False, "message": "The robot didn't report its consumables."}
    low = [label for label, addr in CONSUMABLES if got.get(addr, 100) <= 10]
    return {"success": True, "message": "Life left: " + ", ".join(parts) + "." + (f" Replace soon: {', '.join(low)}." if low else "")}


@guarded
def test() -> dict:
    """Connection check for the Settings screen / CLI: proves host + token and the model."""
    info = _client().info()
    model = info.get("model", "?")
    note = "" if model == MODEL else f" This integration was written for {MODEL}; other models may not behave."
    st = read_state()
    return {"success": True, "message": f"Connected to {model} (firmware {info.get('fw_ver', '?')}); it is {_say_status(st)}, battery {st.get('battery', '?')}%." + note,
            "model": model, "firmware": info.get("fw_ver"), "battery": st.get("battery"), "state": _say_status(st)}


# ============================================================================ commands
@guarded
def start(mode=None) -> dict:
    st = read_state()
    s = st.get("status")
    if s == CLEANING:
        return {"success": True, "message": f"The robot is already cleaning ({SWEEP_TYPE_TEXT.get(st.get('sweep_type'), 'in progress')})."}
    if s == 10:
        return {"success": False, "message": "The robot is updating its firmware; try again in a few minutes."}
    if s == PAUSED and not mode:
        return _resume()
    if mode:
        err = _apply_mode(_choice(mode, _MODE_WORDS, MODES, "cleaning mode"), st)
        if err:
            return {"success": False, "message": err}
    sent = _act(A_START)
    ok, now = _wait(lambda x: x.get("status") == CLEANING, 10)
    if ok:
        return {"success": True, "message": "Started cleaning the whole home." + ("" if sent else " (The robot didn't acknowledge, but it is cleaning.)")}
    return {"success": False, "message": f"I sent the start command but the robot is {_say_status(now)}, not cleaning.{_fault_note(now)} "
                                         "Common reasons: it is stuck, the battery is very low, or the water tank / dust bin needs attention."}


def _apply_mode(value: int, st: dict):
    """Sets sweep/mop mode; returns an error string or None. A mop mode without a mop pad is silently reverted by the robot."""
    if value in (2, 3, 4) and st.get("mop") is False:
        return "A mopping mode needs the mop pad attached, and the robot reports none. Attach it, or choose sweep only."
    _client().set_property(SWEEP_MOP[0], SWEEP_MOP[1], value)
    return None


@guarded
def clean_rooms(names) -> dict:
    wanted = names if isinstance(names, list) else split_names(names)
    if not wanted:
        return {"success": False, "message": "Say which rooms to clean, e.g. 'kitchen, hallway'. See vacuum_rooms for the names."}
    lst = parse_rooms(_client().get_properties([ROOM_INFO]).get(ROOM_INFO))
    if not lst:
        return {"success": False, "message": "The robot reports no rooms, so it can't clean one. Split the map into rooms in the Xiaomi Home app first."}
    ids, problems = match_rooms(wanted, lst)
    if problems:
        return {"success": False, "message": "I couldn't pick the rooms: " + "; ".join(problems) + ". Rooms: " + ", ".join(r["name"] for r in lst) + "."}
    names_txt = ", ".join(next(r["name"] for r in lst if r["id"] == i) for i in ids)

    st = read_state()
    if st.get("status") == 10:
        return {"success": False, "message": "The robot is updating its firmware; try again in a few minutes."}
    if st.get("status") in (CLEANING, PAUSED):        # switch to the new rooms: stop what it is doing first
        _act(A_STOP)
        _wait(lambda x: x.get("status") not in (CLEANING, PAUSED), 6)

    pref = config.VACUUM_ROOM_ENCODING
    order = [pref] if pref in ROOM_ENCODINGS else list(ROOM_ENCODINGS)
    tried = []
    for enc in order:
        tried.append(enc)
        _act(A_ROOMS, encode_rooms(ids, enc))
        verdict = _confirm_room_clean()
        if verdict == "rooms":
            if pref == "auto":
                _remember_encoding(enc)
            return {"success": True, "message": f"Cleaning {names_txt} now."}
        if verdict == "global":
            _act(A_STOP)
            _act(A_DOCK)
            return {"success": False, "message": f"The robot started a whole-home clean instead of {names_txt} (encoding '{enc}'), so I stopped it and sent it back to the dock. "
                                                 "Tell me and I'll try another way, or start the room clean in the Xiaomi Home app."}
    return {"success": False, "message": f"I sent the room command ({', '.join(tried)}) but the robot never started cleaning {names_txt}. "
                                         "S20+ room commands are the least consistent part of its protocol; start that room in the Xiaomi Home app, "
                                         "and see docs/VACUUM.md (Troubleshooting) to help pin down the right encoding."}


def _confirm_room_clean(timeout=7.0) -> str:
    """'rooms' (robot is cleaning selected rooms), 'global' (cleaning, but not rooms), or 'none'. Needs two agreeing reads."""
    end, seen = _now() + timeout, []
    while _now() < end:
        _sleep(1.0)
        try:
            s = _read({"status": STATUS, "sweep_type": SWEEP_TYPE})
        except miot_client.MiotError:
            continue
        if s.get("status") == CLEANING:
            seen.append("rooms" if s.get("sweep_type") == ROOM_SWEEP else "global")
            if len(seen) >= 2 and seen[-1] == seen[-2]:
                return seen[-1]
        else:
            seen.clear()
    return "none"


def _remember_encoding(enc: str):
    try:
        from . import settings_store
        settings_store.apply_settings({"VACUUM_ROOM_ENCODING": enc})
        logger.info("Vacuum: room-clean encoding '%s' worked and is now remembered.", enc)
    except Exception as exc:  # noqa: BLE001 - remembering is a nicety
        logger.warning("Vacuum: couldn't remember the room encoding: %s", exc)


@guarded
def pause() -> dict:
    s = read_state().get("status")
    if s != CLEANING:
        return {"success": False, "message": f"Nothing to pause: the robot is {_say_status({'status': s})}."}
    _act(A_PAUSE)
    ok, now = _wait(lambda x: x.get("status") == PAUSED, 6)
    return {"success": ok, "message": "Paused." if ok else f"I sent pause but the robot is {_say_status(now)}."}


def _resume() -> dict:
    s = read_state().get("status")
    if s == CLEANING:
        return {"success": True, "message": "The robot is already cleaning."}
    if s != PAUSED:
        return {"success": False, "message": f"Nothing to resume: the robot is {_say_status({'status': s})}. Use vacuum_start to begin a clean."}
    _act(A_RESUME)
    ok, now = _wait(lambda x: x.get("status") == CLEANING, 8)
    return {"success": ok, "message": "Resumed cleaning." if ok else f"I sent resume but the robot is {_say_status(now)}."}


resume = guarded(_resume)


@guarded
def stop() -> dict:
    s = read_state().get("status")
    if s not in (CLEANING, PAUSED, RETURNING):
        return {"success": True, "message": f"Nothing to stop: the robot is {_say_status({'status': s})}."}
    _act(A_STOP)
    ok, now = _wait(lambda x: x.get("status") not in (CLEANING, RETURNING), 6)
    return {"success": ok, "message": "Stopped. The robot stays where it is; say 'send it home' to dock it." if ok else f"I sent stop but the robot is {_say_status(now)}."}


@guarded
def dock() -> dict:
    s = read_state().get("status")
    if s in (CHARGING_S, DOCKED):
        return {"success": True, "message": f"The robot is already on its dock ({_say_status({'status': s})})."}
    if s == RETURNING:
        return {"success": True, "message": "The robot is already on its way back to the dock."}
    _act(A_DOCK)
    ok, now = _wait(lambda x: x.get("status") in (RETURNING, CHARGING_S, DOCKED), 8)
    return {"success": ok, "message": "Sending the robot back to the dock." if ok else f"I sent the dock command but the robot is {_say_status(now)}.{_fault_note(now)}"}


@guarded
def locate() -> dict:
    sent = _act(A_LOCATE)
    return {"success": True, "message": "The robot is announcing where it is." + ("" if sent else " (No acknowledgement, but it usually still plays the sound.)")}


SETTING_NAMES = ("suction", "mop_water", "mode", "passes", "volume")


@guarded
def set_option(option, value) -> dict:
    opt = fold(option).replace(" ", "_")
    c = _client()
    if opt in ("suction", "power", "fan", "fan_speed"):
        v = _choice(value, _SUCTION_WORDS, SUCTION_LEVELS, "suction level")
        c.set_property(*SUCTION, v)
        return {"success": True, "message": f"Suction set to {SUCTION_LEVELS[v]}."}
    if opt in ("mop_water", "water", "water_level", "mop"):
        v = _choice(value, _WATER_WORDS, WATER_LEVELS, "mop water level")
        c.set_property(*WATER, v)
        return {"success": True, "message": f"Mop water set to {WATER_LEVELS[v]}."}
    if opt in ("mode", "clean_mode", "cleaning_mode"):
        v = _choice(value, _MODE_WORDS, MODES, "cleaning mode")
        err = _apply_mode(v, read_state())
        if err:
            return {"success": False, "message": err}
        back = c.get_properties([SWEEP_MOP]).get(SWEEP_MOP)
        if back is not None and back != v:
            return {"success": False, "message": f"The robot reverted the mode to {MODES.get(back, back)}. A mopping mode needs the mop pad and water tank fitted."}
        return {"success": True, "message": f"Cleaning mode set to {MODES[v]}."}
    if opt in ("passes", "times", "clean_times", "repeat"):
        v = _num(value, -1)
        if v not in (1, 2):
            return {"success": False, "message": "Passes can be 1 or 2."}
        c.set_property(*PASSES, int(v))
        return {"success": True, "message": f"The robot will clean {int(v)} time{'s' if v > 1 else ''} over."}
    if opt in ("volume", "voice_volume"):
        v = _num(value, -1)
        if not 0 <= v <= 100:
            return {"success": False, "message": "Volume is 0 to 100."}
        c.set_property(*VOLUME, int(v))
        return {"success": True, "message": f"Robot voice volume set to {int(v)}%."}
    return {"success": False, "message": f"Unknown setting '{option}'. Settings: {', '.join(SETTING_NAMES)}."}
