"""
Command line for setting up and debugging the robot vacuum, without starting Troy:

    python -m troy.vacuum_cli discover                 find miIO devices on this LAN (their IP + device id)
    python -m troy.vacuum_cli test [--host IP --token T]     does the IP + token work? what model is it?
    python -m troy.vacuum_cli status | rooms | consumables | start | pause | resume | stop | dock | locate
    python -m troy.vacuum_cli clean "kitchen, hall"
    python -m troy.vacuum_cli set suction strong
    python -m troy.vacuum_cli get 2 1 [3 1 ...]        raw property read (siid piid pairs)
    python -m troy.vacuum_cli call 2 13 '{"piid":13,"value":"{\\"room\\":[4]}"}'   raw action (advanced)

Host and token come from --host/--token, else TROY_VACUUM_HOST / TROY_VACUUM_TOKEN (.env), else the values saved by the
Settings screen. The raw commands are for diagnosing a model that behaves differently; they bypass the safety checks.
"""

import argparse
import json
import socket
import struct
import sys
import time

from . import config, miot_client, vacuum


def _load(args):
    try:                                        # values saved from the Settings screen
        from . import settings_store
        saved = settings_store.read_saved()
        for key in ("VACUUM_HOST", "VACUUM_TOKEN", "VACUUM_ROOM_ENCODING"):
            if saved.get(key):
                setattr(config, key, saved[key])
    except Exception:  # noqa: BLE001
        pass
    if args.host:
        config.VACUUM_HOST = args.host
    if args.token:
        config.VACUUM_TOKEN = args.token
    config.VACUUM_ENABLED = True                # the CLI is explicit use: ignore the on/off switch


def discover(timeout=3.0) -> list:
    """Broadcasts the miIO hello; every device on the LAN answers with its id. -> [(ip, did_decimal)]."""
    found = {}
    with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:
        s.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
        s.settimeout(0.5)
        end = time.monotonic() + timeout
        s.sendto(miot_client.HELLO, ("255.255.255.255", miot_client.PORT))
        while time.monotonic() < end:
            try:
                data, addr = s.recvfrom(1024)
            except OSError:
                s.sendto(miot_client.HELLO, ("255.255.255.255", miot_client.PORT))
                continue
            if len(data) >= 16 and struct.unpack(">H", data[:2])[0] == miot_client.MAGIC:
                found[addr[0]] = int.from_bytes(data[8:12], "big")
    return sorted(found.items())


def _print(result):
    print(("OK   " if result.get("success") else "FAIL ") + result.get("message", ""))
    return 0 if result.get("success") else 1


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(prog="python -m troy.vacuum_cli", description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("command")
    ap.add_argument("rest", nargs="*")
    ap.add_argument("--host")
    ap.add_argument("--token")
    args = ap.parse_args(argv)
    cmd = args.command.lower()

    if cmd == "discover":
        devices = discover()
        if not devices:
            print("No miIO devices answered. Is this PC on the same Wi-Fi/LAN as the robot (not a guest network)? Some routers block broadcasts: then read the robot's IP in your router's device list.")
            return 1
        for ip, did in devices:
            print(f"{ip:<16} device id {did}   (the 'did' in the Xiaomi Home app / token tools)")
        print("\nThe robot is the one whose device id matches the app. Next: python -m troy.vacuum_cli test --host <ip> --token <token>")
        return 0

    _load(args)
    simple = {"status": vacuum.status, "rooms": vacuum.rooms, "consumables": vacuum.consumables, "test": vacuum.test, "start": vacuum.start,
              "pause": vacuum.pause, "resume": vacuum.resume, "stop": vacuum.stop, "dock": vacuum.dock, "locate": vacuum.locate}
    if cmd in simple:
        return _print(simple[cmd]())
    if cmd == "clean":
        return _print(vacuum.clean_rooms(" ".join(args.rest)))
    if cmd == "set" and len(args.rest) >= 2:
        return _print(vacuum.set_option(args.rest[0], " ".join(args.rest[1:])))
    if cmd == "info":
        try:
            print(json.dumps(vacuum._client().info(), indent=2))
            return 0
        except (vacuum.VacuumError, miot_client.MiotError) as exc:
            print("FAIL", vacuum._friendly(exc))
            return 1
    try:
        if cmd == "get" and len(args.rest) >= 2 and len(args.rest) % 2 == 0:
            pairs = [(int(args.rest[i]), int(args.rest[i + 1])) for i in range(0, len(args.rest), 2)]
            got = vacuum._client().get_properties(pairs)
            for p in pairs:
                print(f"{p[0]}.{p[1]} = " + (repr(got[p]) if p in got else "(not available)"))
            return 0
        if cmd == "call" and len(args.rest) >= 2:
            inputs = [json.loads(a) for a in args.rest[2:]]
            print(json.dumps(vacuum._client().action(int(args.rest[0]), int(args.rest[1]), inputs)))
            return 0
    except (vacuum.VacuumError, miot_client.MiotError, ValueError) as exc:
        print("FAIL", vacuum._friendly(exc))
        return 1
    ap.print_help()
    return 2


if __name__ == "__main__":
    sys.exit(main())
