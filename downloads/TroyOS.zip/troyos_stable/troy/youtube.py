"""
YouTube Data API v3 with OAuth 2.0 -- "open the last video on my liked videos".

How the example request works:
  1. channels.list(mine=true)  -> the channel's relatedPlaylists (likes = "LL")
     or playlists.list(mine=true) -> a playlist by name
  2. playlistItems.list(playlistId=...) -> the items; the newest by the date it
     was ADDED to the playlist is the "last video"
  3. https://www.youtube.com/watch?v=<VIDEO_ID>
  4. opened in a new Firefox tab (troy/app_launcher.py)

Sign-in is the standard OAuth 2.0 flow for desktop apps: the user's browser
opens Google's consent page, Google redirects to a one-shot server on
127.0.0.1 (random port), and the code is exchanged using PKCE. No Google
client library is needed -- everything is plain HTTPS through `requests`.
Tokens live in troy_youtube_token.json; the access token is refreshed
automatically. Requested scope: youtube.readonly (view only).

Setup (once): Google Cloud Console -> enable "YouTube Data API v3" -> OAuth
consent screen (add yourself as a test user) -> Credentials -> OAuth client ID
of type "Desktop app" -> paste the client id and secret into Settings.
"""

import base64
import difflib
import hashlib
import json
import os
import re
import secrets
import threading
import time
from http.server import BaseHTTPRequestHandler, HTTPServer
from urllib.parse import parse_qs, urlencode, urlparse

import requests

from . import app_launcher, config
from .logger import logger

SCOPE = "https://www.googleapis.com/auth/youtube.readonly"
AUTH_URL = "https://accounts.google.com/o/oauth2/v2/auth"
TOKEN_URL = "https://oauth2.googleapis.com/token"
REVOKE_URL = "https://oauth2.googleapis.com/revoke"
API = "https://www.googleapis.com/youtube/v3"
TIMEOUT = 12
MAX_PAGES = 20                      # 20 x 50 = 1000 playlist items
AUTH_WINDOW_SECONDS = 300

_lock = threading.RLock()
_pending = None                     # the sign-in currently waiting for Google's redirect
_listeners = []                     # callables(event: str, data: dict)


class YouTubeError(Exception):
    """A problem worth showing to the user as-is."""


def on_event(callback):
    _listeners.append(callback)


def _emit(event: str, data: dict):
    for cb in list(_listeners):
        try:
            cb(event, data)
        except Exception:  # noqa: BLE001 - a listener must never break sign-in
            logger.debug("youtube listener failed", exc_info=True)


# ------------------------------------------------------------------ tokens
def configured() -> bool:
    return bool(config.YOUTUBE_CLIENT_ID and config.YOUTUBE_CLIENT_SECRET)


def _read_token() -> dict:
    try:
        with open(config.YOUTUBE_TOKEN_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError):
        return {}


def _write_token(data: dict):
    with open(config.YOUTUBE_TOKEN_FILE, "w", encoding="utf-8") as f:
        json.dump(data, f)
    try:
        os.chmod(config.YOUTUBE_TOKEN_FILE, 0o600)
    except OSError:
        pass


def _store_token_response(payload: dict, previous: dict = None) -> dict:
    token = dict(previous or {})
    token["access_token"] = payload["access_token"]
    token["expires_at"] = time.time() + int(payload.get("expires_in", 3600))
    if payload.get("refresh_token"):
        token["refresh_token"] = payload["refresh_token"]       # Google only sends it on first consent
    token["scope"] = payload.get("scope", token.get("scope", SCOPE))
    _write_token(token)
    return token


def _token_request(data: dict) -> dict:
    data = {**data, "client_id": config.YOUTUBE_CLIENT_ID, "client_secret": config.YOUTUBE_CLIENT_SECRET}
    try:
        resp = requests.post(TOKEN_URL, data=data, timeout=TIMEOUT)
    except requests.RequestException as exc:
        raise YouTubeError(f"Couldn't reach Google to sign in: {exc}") from exc
    try:
        payload = resp.json()
    except ValueError:
        payload = {}
    if not resp.ok or "access_token" not in payload:
        reason = payload.get("error_description") or payload.get("error") or f"HTTP {resp.status_code}"
        raise YouTubeError(f"Google refused the sign-in: {reason}")
    return payload


def access_token() -> str:
    """A valid access token, refreshing it if it expires within a minute."""
    with _lock:
        token = _read_token()
        if not token.get("access_token"):
            raise YouTubeError("YouTube isn't connected. Open Settings > Integrations and press Connect YouTube.")
        if token.get("expires_at", 0) - time.time() > 60:
            return token["access_token"]
        if not token.get("refresh_token"):
            raise YouTubeError("The YouTube sign-in expired. Reconnect it in Settings > Integrations.")
        if not configured():
            raise YouTubeError("The YouTube client id/secret are missing. Add them in Settings > Integrations.")
        try:
            payload = _token_request({"grant_type": "refresh_token", "refresh_token": token["refresh_token"]})
        except YouTubeError as exc:
            if "invalid_grant" in str(exc):
                raise YouTubeError("Google revoked the YouTube sign-in. Reconnect it in Settings > Integrations.") from exc
            raise
        return _store_token_response(payload, token)["access_token"]


def connected() -> bool:
    t = _read_token()
    return bool(t.get("access_token") or t.get("refresh_token"))


# ------------------------------------------------------------------ sign-in
def _pkce_pair():
    verifier = base64.urlsafe_b64encode(secrets.token_bytes(48)).rstrip(b"=").decode()
    challenge = base64.urlsafe_b64encode(hashlib.sha256(verifier.encode()).digest()).rstrip(b"=").decode()
    return verifier, challenge


def build_auth_url(redirect_uri: str, state: str, challenge: str) -> str:
    return AUTH_URL + "?" + urlencode({
        "client_id": config.YOUTUBE_CLIENT_ID, "redirect_uri": redirect_uri, "response_type": "code",
        "scope": SCOPE, "state": state, "code_challenge": challenge, "code_challenge_method": "S256",
        "access_type": "offline", "prompt": "consent", "include_granted_scopes": "true",
    })


_PAGE = """<!doctype html><meta charset="utf-8"><title>Troy</title>
<body style="font:16px system-ui;background:#0b0e17;color:#eaf0fb;display:grid;place-items:center;height:100vh;margin:0">
<div style="text-align:center;max-width:420px;padding:24px"><div style="font-size:42px">%s</div><h2>%s</h2><p style="opacity:.7">%s</p></div></body>"""


def _exchange_code(code: str, redirect_uri: str, verifier: str) -> dict:
    payload = _token_request({"grant_type": "authorization_code", "code": code, "redirect_uri": redirect_uri, "code_verifier": verifier})
    with _lock:
        token = _store_token_response(payload, {})
    return token


def _finish(ok: bool, message: str):
    global _pending
    with _lock:
        pending, _pending = _pending, None
    if pending and pending.get("server"):
        threading.Thread(target=pending["server"].shutdown, daemon=True).start()
    if ok:
        info = {}
        try:
            info = channel_info()
        except YouTubeError as exc:
            logger.warning("Signed in but couldn't read the channel: %s", exc)
        _emit("youtube.connected", {"channel": info})
    else:
        _emit("youtube.error", {"message": message})


def handle_callback(params: dict) -> tuple:
    """Processes Google's redirect. params: {code?, state?, error?}. -> (ok, message)"""
    with _lock:
        pending = _pending
    if not pending:
        return False, "No YouTube sign-in is in progress."
    if params.get("state") != pending["state"]:
        return False, "That sign-in link didn't match the one Troy started. Please try again."
    if params.get("error"):
        message = "Sign-in was cancelled." if params["error"] == "access_denied" else f"Google said: {params['error']}"
        _finish(False, message)
        return False, message
    if not params.get("code"):
        return False, "The redirect didn't include a sign-in code."
    try:
        _exchange_code(params["code"], pending["redirect_uri"], pending["verifier"])
    except YouTubeError as exc:
        _finish(False, str(exc))
        return False, str(exc)
    _finish(True, "")
    return True, "Troy is connected to YouTube."


class _Callback(BaseHTTPRequestHandler):
    def log_message(self, *a):  # noqa: D401 - silence the default access log
        pass

    def do_GET(self):  # noqa: N802
        url = urlparse(self.path)
        if url.path != "/callback":
            self.send_response(404); self.end_headers(); return
        params = {k: v[0] for k, v in parse_qs(url.query).items()}
        ok, message = handle_callback(params)
        body = (_PAGE % ("\u2705" if ok else "\u26A0\uFE0F", "Troy is connected" if ok else "Couldn't connect", "You can close this tab and go back to Troy." if ok else message)).encode()
        self.send_response(200)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)


def begin_auth(open_browser: bool = True) -> dict:
    """Starts sign-in: returns {"auth_url", "port"} and opens the consent page
    in the user's browser. Success/failure arrives via on_event listeners
    ("youtube.connected" / "youtube.error") when Google redirects back."""
    global _pending
    if not configured():
        raise YouTubeError("Add your Google OAuth client id and secret first (Settings > Integrations).")
    cancel_auth()
    server = HTTPServer(("127.0.0.1", 0), _Callback)
    port = server.server_address[1]
    verifier, challenge = _pkce_pair()
    state = secrets.token_urlsafe(24)
    redirect_uri = f"http://127.0.0.1:{port}/callback"
    with _lock:
        _pending = {"state": state, "verifier": verifier, "redirect_uri": redirect_uri, "server": server, "started": time.time()}
    threading.Thread(target=server.serve_forever, daemon=True, name="troy-youtube-oauth").start()

    def _timeout():
        with _lock:
            still = _pending is not None and _pending["state"] == state
        if still:
            _finish(False, "Sign-in timed out. Press Connect YouTube to try again.")
    timer = threading.Timer(AUTH_WINDOW_SECONDS, _timeout)
    timer.daemon = True
    timer.start()

    url = build_auth_url(redirect_uri, state, challenge)
    if open_browser:
        app_launcher.launch_browser_url(url, config.YOUTUBE_BROWSER)
    return {"auth_url": url, "port": port}


def complete_from_url(redirect_url: str) -> tuple:
    """Fallback if the loopback page couldn't load (some firewalls/VPNs block
    it): the user pastes the full address from the browser's address bar."""
    q = parse_qs(urlparse(redirect_url.strip()).query)
    return handle_callback({k: v[0] for k, v in q.items()})


def cancel_auth():
    global _pending
    with _lock:
        pending, _pending = _pending, None
    if pending and pending.get("server"):
        threading.Thread(target=pending["server"].shutdown, daemon=True).start()


def signing_in() -> bool:
    return _pending is not None


def disconnect() -> bool:
    token = _read_token()
    for key in ("refresh_token", "access_token"):
        if token.get(key):
            try:
                requests.post(REVOKE_URL, params={"token": token[key]}, timeout=6)
            except requests.RequestException:
                pass
            break
    try:
        os.remove(config.YOUTUBE_TOKEN_FILE)
    except OSError:
        pass
    _emit("youtube.disconnected", {})
    return True


# --------------------------------------------------------------------- API
def _api(path: str, params: dict = None) -> dict:
    token = access_token()
    for attempt in (1, 2):
        try:
            resp = requests.get(f"{API}/{path}", params=params or {}, headers={"Authorization": f"Bearer {token}"}, timeout=TIMEOUT)
        except requests.RequestException as exc:
            raise YouTubeError(f"Couldn't reach YouTube: {exc}") from exc
        if resp.status_code == 401 and attempt == 1:
            with _lock:                                   # force a refresh and retry once
                t = _read_token(); t["expires_at"] = 0; _write_token(t)
            token = access_token()
            continue
        break
    if resp.ok:
        return resp.json()
    try:
        err = resp.json().get("error", {})
        reason = (err.get("errors") or [{}])[0].get("reason", "")
        message = err.get("message", "")
    except ValueError:
        reason, message = "", resp.text[:120]
    if reason in ("quotaExceeded", "dailyLimitExceeded", "rateLimitExceeded"):
        raise YouTubeError("The YouTube API's daily quota is used up. It resets at midnight Pacific time.")
    if reason in ("accessNotConfigured", "SERVICE_DISABLED") or "has not been used" in message:
        raise YouTubeError("The YouTube Data API v3 isn't enabled for your Google Cloud project. Enable it in the Cloud Console, then retry.")
    if resp.status_code in (401, 403):
        raise YouTubeError(f"YouTube refused the request ({reason or resp.status_code}). Try reconnecting in Settings > Integrations.")
    if resp.status_code == 404 or reason == "playlistNotFound":
        raise YouTubeError("YouTube couldn't find that playlist.")
    raise YouTubeError(f"YouTube error {resp.status_code}: {message or reason}")


def channel_info() -> dict:
    data = _api("channels", {"part": "snippet,contentDetails", "mine": "true"})
    items = data.get("items") or []
    if not items:
        raise YouTubeError("This Google account has no YouTube channel.")
    ch = items[0]
    snip = ch.get("snippet", {})
    return {
        "id": ch["id"], "title": snip.get("title", ""),
        "thumbnail": ((snip.get("thumbnails") or {}).get("default") or {}).get("url", ""),
        "playlists": ch.get("contentDetails", {}).get("relatedPlaylists", {}),
    }


def status() -> dict:
    info = {"configured": configured(), "connected": connected(), "signing_in": signing_in(), "channel": None, "error": ""}
    if info["connected"]:
        try:
            ch = channel_info()
            info["channel"] = {k: ch[k] for k in ("id", "title", "thumbnail")}
        except YouTubeError as exc:
            info["error"] = str(exc)
    return info


def _video_url(video_id: str) -> str:
    return f"https://www.youtube.com/watch?v={video_id}"


def _item_to_video(item: dict) -> dict:
    sn = item.get("snippet", {})
    vid = (sn.get("resourceId") or {}).get("videoId") or item.get("contentDetails", {}).get("videoId", "")
    return {
        "video_id": vid, "title": sn.get("title", ""), "channel": sn.get("videoOwnerChannelTitle") or sn.get("channelTitle", ""),
        "added_at": sn.get("publishedAt", ""), "url": _video_url(vid) if vid else "",
        "unavailable": sn.get("title") in ("Private video", "Deleted video") or not vid,
    }


def playlist_items(playlist_id: str, limit: int = 5, newest_first_by_date: bool = True) -> list:
    """Items of a playlist, newest ADDED first. Walks the pages (up to
    MAX_PAGES) because a normal playlist is ordered by position, not by date."""
    videos, page, pages = [], None, 0
    while pages < MAX_PAGES:
        params = {"part": "snippet,contentDetails", "playlistId": playlist_id, "maxResults": 50}
        if page:
            params["pageToken"] = page
        data = _api("playlistItems", params)
        videos += [v for v in map(_item_to_video, data.get("items", [])) if not v["unavailable"]]
        page, pages = data.get("nextPageToken"), pages + 1
        # the liked-videos playlist is already newest-first, so the first page is enough
        if not page or (playlist_id == "LL" and len(videos) >= limit):
            break
    if newest_first_by_date:
        videos.sort(key=lambda v: v["added_at"], reverse=True)
    return videos[:limit]


def my_playlists() -> list:
    out, page = [], None
    for _ in range(MAX_PAGES):
        params = {"part": "snippet,contentDetails", "mine": "true", "maxResults": 50}
        if page:
            params["pageToken"] = page
        data = _api("playlists", params)
        for p in data.get("items", []):
            out.append({"id": p["id"], "title": p["snippet"].get("title", ""), "count": p.get("contentDetails", {}).get("itemCount", 0)})
        page = data.get("nextPageToken")
        if not page:
            break
    return out


_LIKED = {"liked", "likes", "liked videos", "my liked videos", "my likes", "ll", "favorites", "favourites"}
_PLAYLIST_ID = re.compile(r"^(PL|UU|LL|FL|OL|RD)[A-Za-z0-9_-]{2,}$")


def resolve_playlist(name: str) -> tuple:
    """-> (playlist_id, display name) for 'liked videos', a playlist title (fuzzy) or an id."""
    n = (name or "").strip()
    if not n or n.lower() in _LIKED:
        return "LL", "Liked videos"
    if n.lower() in ("watch later", "wl"):
        raise YouTubeError("YouTube doesn't let apps read the Watch Later list (an API restriction since 2016). Add the videos to a normal playlist, or use Liked videos.")
    if n.lower() == "uploads":
        return channel_info()["playlists"].get("uploads", ""), "Your uploads"
    if _PLAYLIST_ID.match(n) and len(n) > 12:
        return n, n
    lists = my_playlists()
    titles = {p["title"].casefold(): p for p in lists}
    key = n.casefold()
    hit = titles.get(key)
    if not hit:
        starts = [t for t in titles if t.startswith(key)] or [t for t in titles if key in t]
        if starts:
            hit = titles[sorted(starts, key=len)[0]]
    if not hit:
        close = difflib.get_close_matches(key, list(titles), n=1, cutoff=0.6)
        hit = titles[close[0]] if close else None
    if not hit:
        have = ", ".join(p["title"] for p in lists[:10]) or "none"
        raise YouTubeError(f"No playlist named '{n}'. Your playlists: {have}.")
    return hit["id"], hit["title"]


def latest_in_playlist(name: str = "liked") -> dict:
    playlist_id, title = resolve_playlist(name)
    items = playlist_items(playlist_id, limit=1)
    if not items:
        raise YouTubeError(f"'{title}' has no videos I can read.")
    return {**items[0], "playlist": title}


def liked_videos(limit: int = 5) -> list:
    return playlist_items("LL", limit=limit)


def search_videos(query: str, limit: int = 5) -> list:
    data = _api("search", {"part": "snippet", "q": query, "type": "video", "maxResults": max(1, min(limit, 15))})
    out = []
    for it in data.get("items", []):
        vid = (it.get("id") or {}).get("videoId")
        if vid:
            out.append({"video_id": vid, "title": it["snippet"].get("title", ""), "channel": it["snippet"].get("channelTitle", ""),
                        "added_at": it["snippet"].get("publishedAt", ""), "url": _video_url(vid)})
    return out


def subscriptions(limit: int = 10) -> list:
    data = _api("subscriptions", {"part": "snippet", "mine": "true", "maxResults": max(1, min(limit, 50)), "order": "relevance"})
    return [{"title": s["snippet"].get("title", ""), "channel_id": (s["snippet"].get("resourceId") or {}).get("channelId", "")} for s in data.get("items", [])]


_VIDEO_ID = re.compile(r"(?:v=|youtu\.be/|shorts/|embed/)([A-Za-z0-9_-]{11})")


def parse_video_id(text: str):
    text = (text or "").strip()
    m = _VIDEO_ID.search(text)
    if m:
        return m.group(1)
    return text if re.fullmatch(r"[A-Za-z0-9_-]{11}", text) else None


def _iso_duration(iso: str) -> str:
    m = re.fullmatch(r"PT(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)S)?", iso or "")
    if not m:
        return ""
    h, mi, s = (int(x or 0) for x in m.groups())
    return f"{h}:{mi:02d}:{s:02d}" if h else f"{mi}:{s:02d}"


def video_info(video_id: str) -> dict:
    data = _api("videos", {"part": "snippet,contentDetails,statistics", "id": video_id})
    items = data.get("items") or []
    if not items:
        raise YouTubeError("YouTube has no video with that id (or it's private).")
    v = items[0]
    return {
        "video_id": video_id, "url": _video_url(video_id), "title": v["snippet"].get("title", ""),
        "channel": v["snippet"].get("channelTitle", ""), "published": v["snippet"].get("publishedAt", "")[:10],
        "duration": _iso_duration(v["contentDetails"].get("duration", "")), "views": v.get("statistics", {}).get("viewCount", ""),
        "description": " ".join(v["snippet"].get("description", "").split())[:300],
    }


def open_url(url: str) -> dict:
    return app_launcher.launch_browser_url(url, config.YOUTUBE_BROWSER)
