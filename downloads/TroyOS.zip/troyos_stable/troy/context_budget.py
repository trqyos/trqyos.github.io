"""
Keeps every LLM request inside a token budget.

Why this exists: Groq's free tier rejects requests over ~8000 tokens per
minute ("413 Payload Too Large"), a local model in LM Studio often has a
4096-token window, and every extra token costs latency on every provider.
So before a request leaves the app the messages are fitted to a budget:

  1. the fixed system messages at the top (prompt, memory, live context) are
     always kept -- the memory one is shortened if it alone is too big;
  2. every other message is capped in length (tool output is the usual culprit);
  3. the OLDEST conversation messages are dropped until it fits, leaving a
     one-line note so the model knows earlier turns were omitted.

Nothing here mutates the caller's list: the full history stays on disk and in
the UI, only what is sent to the model is trimmed. Token counts are estimated
(characters / 3.6) -- close enough for budgeting, and it needs no tokenizer.
"""

CHARS_PER_TOKEN = 3.6
_MESSAGE_OVERHEAD = 4
OMITTED_NOTE = "(Earlier conversation omitted to save space.)"
# An extra-tool list (troy/extra_tools.py) must reach the model whole or not at all: a list cut in the
# middle would look complete and invite guessing. It builds itself to fit the budget, so it's exempt
# from the per-message cap (it can still be dropped with the oldest messages, never half-shown).
EXTRA_LIST_MARKER = "[EXTRA-TOOLS-LIST]"
EXTRA_LIST_CAP_CHARS = 6500


def estimate_tokens(text) -> int:
    if not text:
        return 0
    if isinstance(text, list):                       # multimodal content parts
        total = 0
        for part in text:
            if part.get("type") == "text":
                total += estimate_tokens(part.get("text", ""))
            else:
                total += 700                          # a downscaled image costs a few hundred tokens
        return total
    return int(len(str(text)) / CHARS_PER_TOKEN) + 1


def message_tokens(message: dict) -> int:
    n = estimate_tokens(message.get("content")) + _MESSAGE_OVERHEAD
    for tc in message.get("tool_calls") or []:          # native function calls: the name and JSON arguments are sent too
        fn = tc.get("function") or {}
        n += estimate_tokens(fn.get("name", "")) + estimate_tokens(fn.get("arguments", "")) + 4
    return n


def tools_tokens(tools) -> int:
    """Estimated size of a `tools` list (JSON schemas) -- it counts against the request just like messages do."""
    if not tools:
        return 0
    import json
    return estimate_tokens(json.dumps(tools, separators=(",", ":")))


def total_tokens(messages: list) -> int:
    return sum(message_tokens(m) for m in messages)


def _shorten(text: str, max_chars: int) -> str:
    if len(text) <= max_chars:
        return text
    keep_head = int(max_chars * 0.7)
    keep_tail = max_chars - keep_head
    cut = len(text) - max_chars
    return f"{text[:keep_head]} ...[{cut} characters trimmed]... {text[-keep_tail:]}"


def fit_messages(messages: list, budget_tokens: int, message_cap_chars: int = 1800, fixed_head: int = 3) -> list:
    """Returns a NEW list that fits `budget_tokens` (estimated)."""
    budget_tokens = max(400, int(budget_tokens))
    head_count = 0
    while head_count < min(fixed_head, len(messages)) and messages[head_count].get("role") == "system":
        head_count += 1
    head = [dict(m) for m in messages[:head_count]]
    tail = []
    for m in messages[head_count:]:
        m = dict(m)
        if isinstance(m.get("content"), str):
            cap = max(message_cap_chars, EXTRA_LIST_CAP_CHARS) if EXTRA_LIST_MARKER in m["content"] else message_cap_chars
            m["content"] = _shorten(m["content"], cap)
        tail.append(m)

    def size():
        return total_tokens(head) + total_tokens(tail)

    # 1) shrink the memory/context system messages if the head alone is too large
    for i in range(len(head) - 1, 0, -1):
        if total_tokens(head) <= budget_tokens * 0.6:
            break
        head[i]["content"] = _shorten(head[i]["content"], 1200)

    # 2) drop the oldest conversation, always keeping the latest message
    dropped = False
    while size() > budget_tokens and len(tail) > 1:
        tail.pop(0)
        dropped = True
    # a conversation should start with the user's side, not a dangling reply (or a tool result whose call was dropped)
    while dropped and len(tail) > 1 and tail[0].get("role") in ("assistant", "tool"):
        tail.pop(0)
    if dropped:
        tail.insert(0, {"role": "user", "content": OMITTED_NOTE})

    # 3) last resort: the single remaining message is itself enormous
    if size() > budget_tokens and tail:
        room = max(300, int((budget_tokens - total_tokens(head)) * CHARS_PER_TOKEN))
        if isinstance(tail[-1].get("content"), str):
            tail[-1]["content"] = _shorten(tail[-1]["content"], room)
    return head + tail
