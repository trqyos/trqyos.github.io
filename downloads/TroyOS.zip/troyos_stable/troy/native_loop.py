"""
Native function calling, part 3: the agent loop.

`NativeLoopMixin` is mixed into TroyAgent. For every step of a request it:

  1. builds the request: native system prompt + memory + live context + the conversation, trimmed to the
     provider's budget, with every tool call paired with its result (tool_history.repair);
  2. sends it with the Toolbox's JSON schemas as the API's `tools` field (llm_client.chat_tools);
  3. speaks the model's plain text (the narration before a tool call is spoken the moment the first call starts
     to arrive, not after the whole reply), then runs each tool call: arguments are decoded and checked against the
     tool's schema (tool_schema), turned into the SAME (name, arg) pair a text command would give, and handed to
     dispatcher.execute -- so approvals, scheduled-task grants, stop control and every tool behave exactly as before;
  4. returns each result as a `tool` message and asks again, until the model answers without calling a tool.

There is no `speak` or `done` here: the model's text is what Troy says, and ending the turn is simply answering
without a tool call.

Fallback: if no available model accepts tool calls (llm_client.NoNativeTools), the loop returns "fallback" and the
agent finishes the request with the text protocol -- the history is flattened for that, so nothing is lost.
"""
import difflib
import json

from . import config, context_budget, dispatcher, llm_client, stop_control, system_prompt, task_context, tool_history, tool_schema
from .llm_client import LLMError, NoNativeTools, StoppedByUser
from .logger import logger

_NO_REPLY_NUDGE = ("[SYSTEM] You haven't told the user the outcome. Reply with one short sentence saying what you did, "
                   "or what went wrong. Don't call more tools unless something is still unfinished.")


class NativeLoopMixin:
    # ------------------------------------------------------------------ decisions
    def _use_native(self) -> bool:
        return config.TOOL_CALLING in ("auto", "native")

    def _native_tiny(self) -> bool:
        return self._prompt_mode() == "tiny"

    def _start_native_request(self, user_text: str = ""):
        """Per-request setup: the prompt flavour and the tools the model can see."""
        self._native_active = self._use_native()
        if self._native_active:
            self._toolbox = tool_schema.Toolbox(user_text, tiny=self._native_tiny(), scheduled_run=task_context.current() is not None)
        else:
            self._toolbox = None

    # ------------------------------------------------------------------ building one request
    def _native_wire(self, label: str, tools_tokens: int) -> list:
        budget, cap = llm_client.budget_for(label)
        body = tool_history.to_native(self.messages[3:])
        fitted = context_budget.fit_messages(list(self.messages[:3]) + body, max(400, budget - tools_tokens), message_cap_chars=cap)
        fitted = tool_history.repair(fitted)           # trimming can separate a call from its result
        return tool_history.to_wire(fitted, keep_tool_name=(label == "gemini"))

    def _native_call(self, early: dict):
        tools = self._toolbox.schemas()
        t_tokens = context_budget.tools_tokens(tools)

        def on_text(text):
            early["text"] = text
            if text == "":
                early["fired"] = False

        def on_tool_start():
            # the first tool call has begun, so the sentence before it ("On it.") is complete: say it now
            text = (early["text"] or "").strip()
            if text and not early["fired"]:
                early["fired"] = True
                early["spoken"] = text
                self.on_state("speaking")
                self.on_speak(text)

        return llm_client.chat_tools(lambda label: self._native_wire(label, t_tokens), tools,
                                     stop_check=stop_control.stop_controller.is_stopped, on_text=on_text, on_tool_start=on_tool_start)

    # ------------------------------------------------------------------ running one tool call
    def _not_a_tool(self, name: str) -> dict:
        close = difflib.get_close_matches(name, tool_schema.all_names(), n=3, cutoff=0.6)
        hint = f" Did you mean: {', '.join(close)}?" if close else ""
        return {"success": False, "message": (f"There is no tool named '{name}'.{hint} Call find_tools to search the tools that exist; "
                                              "if none can do what the user asked, tell them plainly that you can't. Never invent a tool.")}

    def _run_tool_call(self, call: dict) -> tuple:
        """-> (arg_string, result_dict) for one model tool call. Never raises."""
        name, raw = call["name"], call.get("arguments") or ""
        try:
            args = json.loads(raw) if raw.strip() else {}
        except ValueError:
            return "", {"success": False, "message": f"The arguments for {name} weren't valid JSON ({raw[:80]!r}). Call it again with a JSON object of its parameters."}
        try:
            if name == tool_schema.FIND_TOOLS:
                query = str(args.get("query", "")) if isinstance(args, dict) else ""
                return query, tool_schema.find_tools(self._toolbox, query)
            if name in ("speak", "done"):                         # a model that fell back to the old habit: honour it harmlessly
                text = str(args.get("text", "")) if isinstance(args, dict) else ""
                if name == "speak" and text:
                    self.on_state("speaking")
                    self.on_speak(text)
                return text, {"success": True, "message": "ok"}
            if not self._toolbox.has(name):
                if tool_schema.schema_for(name) is None:
                    return "", self._not_a_tool(name)
                self._toolbox.load([name])                        # exists, just wasn't loaded: load it, and make the model use its schema
                return "", {"success": False, "message": f"'{name}' wasn't loaded yet, so it did NOT run. It is loaded now: call it again with its parameters."}
            name, arg = tool_schema.call_to_command(name, args)
        except tool_schema.ToolArgError as exc:
            return "", {"success": False, "message": f"{exc} Fix the arguments and call {name} again."}
        return arg, dispatcher.execute(name, arg)

    def _result_content(self, result: dict) -> str:
        message = str(result.get("message", "")).replace("Now end with done.", "Nothing more to do.")      # `done` is a text-protocol word
        if len(message) > config.OBSERVATION_MAX_CHARS and not result.get("full"):
            message = message[:config.OBSERVATION_MAX_CHARS] + f" ...[{len(message) - config.OBSERVATION_MAX_CHARS} more characters not shown]"
        if not result.get("success", False) and not result.get("pending_confirmation"):
            return "FAILED - " + message
        return message

    # ------------------------------------------------------------------ the loop
    def _run_native_loop(self) -> str:
        """-> "done" when the request is finished (for any reason), or "fallback" to continue with the text protocol."""
        self._brain_seen = (config.PRIMARY_PROVIDER, config.TEXT_MODEL_OVERRIDE)
        nudged = False
        try:
            for step_index in range(config.MAX_STEPS_PER_TURN):
                if (config.PRIMARY_PROVIDER, config.TEXT_MODEL_OVERRIDE) != self._brain_seen:
                    self._brain_seen = (config.PRIMARY_PROVIDER, config.TEXT_MODEL_OVERRIDE)
                    self.refresh_system_prompt()
                if stop_control.stop_controller.is_stopped():
                    self._handle_stop()
                    return "done"

                self.on_state("thinking")
                early = {"text": "", "fired": False, "spoken": ""}
                try:
                    reply = self._native_call(early)
                except StoppedByUser:
                    self.messages.pop()
                    self._handle_stop()
                    return "done"
                except NoNativeTools as exc:
                    if config.TOOL_CALLING == "auto":
                        logger.info("No model accepts native tool calls (%s); using the text protocol for this request.", str(exc).splitlines()[0])
                        return "fallback"
                    self.messages.pop()
                    self.on_state("error", str(exc))
                    self.on_speak(f"(Native tool calling is forced on, but no model accepts it.)\n{exc}")
                    return "done"
                except LLMError as exc:
                    self.messages.pop()
                    logger.error("LLM call failed: %s", exc)
                    self.on_state("error", str(exc))
                    self.on_speak(f"(Troy couldn't reach any model right now.)\n{exc}")
                    return "done"

                text = (reply.text or "").strip()
                calls = reply.tool_calls
                self.messages.append(tool_history.assistant_message(text, calls))

                if not calls:
                    if not text:
                        if self._has_tool_results_this_request() and not nudged:
                            nudged = True
                            self.messages.append({"role": "user", "content": _NO_REPLY_NUDGE})
                            continue
                        text = "(The model sent an empty reply.)"
                    self.on_state("speaking")
                    self.on_speak(text)
                    return "done"

                if text and not (early["fired"] and early["spoken"] == text):
                    self.on_state("speaking")
                    self.on_speak(text)

                stopped = False
                all_pending = True
                for n, call in enumerate(calls):
                    if stop_control.stop_controller.is_stopped():
                        stopped = True
                        for rest in calls[n:]:
                            self.messages.append(tool_history.tool_message(rest["id"], rest["name"], "Skipped: stopped by the user.", ok=False))
                        break
                    self.on_state("executing", call["name"])
                    arg, result = self._run_tool_call(call)
                    success = result.get("success", False)
                    logger.info("Tool %s(%s) -> %s - %s", call["name"], arg, "OK" if success else "FAILED", result.get("message", ""))
                    self.on_tool_result(call["name"], arg, success, result.get("ui_message") or result.get("message", ""))
                    if not result.get("pending_confirmation"):
                        all_pending = False
                    self.messages.append(tool_history.tool_message(call["id"], call["name"], self._result_content(result), ok=success, arg=arg))
                if stopped:
                    self._handle_stop()
                    return "done"

                if all_pending and text:
                    return "done"       # it already told the user what needs approving; nothing left to say until they answer
                if any(c["name"] == "task_result" for c in calls) and task_context.current() is not None and task_context.current().reported:
                    return "done"       # a scheduled run has reported its outcome: that is its last act

                steps_left = config.MAX_STEPS_PER_TURN - step_index - 1
                if 0 < steps_left <= 3:
                    self.messages.append({"role": "user", "content": (
                        f"[SYSTEM] Heads up: {steps_left} step(s) left in this turn before the step limit -- wrap up soon: verify the result if you "
                        "haven't, then report the outcome (or the honest blocker). Don't start a new multi-step sub-task now.")})

            self.on_speak("(Reached the step limit for this turn.)")
            return "done"
        finally:
            self.on_state("idle")

    def _has_tool_results_this_request(self) -> bool:
        for m in reversed(self.messages[3:]):
            if m.get("role") == "tool":
                return True
            if m.get("role") == "user" and not str(m.get("content", "")).startswith("[SYSTEM]"):
                return False
        return False

    # ------------------------------------------------------------------ falling back
    def _switch_to_text(self):
        """Continue this request with the text protocol: flatten the history and rebuild the prompt."""
        self._native_active = False
        self._toolbox = None
        self.messages[3:] = tool_history.to_text(self.messages[3:])
        self.refresh_system_prompt()
        self.refresh_situational_context()
