"""
TROYOS STABLE - Confirmation State

Risky actions (deleting something, shutting down the PC, emptying the
Recycle Bin, ...) used to be gated by asking the model to resend the same
command with a "CONFIRM|" prefix once the user had said yes *in chat text*.
That put a safety-critical decision inside model-generated text -- which
is exactly the kind of thing a bad turn, a misread reply, or a crafted
prompt could get wrong.

Confirmation now lives here, as plain application state, not prompt text:
  1. A risky tool call creates a PendingConfirmation and returns
     immediately WITHOUT running -- the model is simply told a
     confirmation prompt is now showing.
  2. The UI shows a real Confirm / Cancel control for it.
  3. The tool only ever actually runs when resolve() is called from that
     real button click. The model is never asked to reissue anything and
     never sees or produces a "confirm" token of any kind.
"""

import itertools
import threading
from dataclasses import dataclass
from typing import Callable, Optional

from . import task_context

_lock = threading.Lock()
_id_counter = itertools.count(1)


@dataclass
class PendingConfirmation:
    id: int
    name: str
    arg: str
    risk_level: str
    description: str
    func: Callable[[str], dict]


_pending: dict[int, PendingConfirmation] = {}
_listener: Optional[Callable[[PendingConfirmation], None]] = None


def set_listener(callback: Optional[Callable[[PendingConfirmation], None]]) -> None:
    """The UI calls this once at startup with a function to invoke whenever
    a new confirmation is created, so it can display a real prompt. Safe to
    call from any thread; the callback itself is responsible for hopping
    back to the UI thread if needed (e.g. via a Qt signal's .emit)."""
    global _listener
    _listener = callback


class UnattendedRefusal(RuntimeError):
    """A scheduled run asked for an Approve prompt. Nobody is there to click it (and the answer would
    land in the wrong chat), so it is refused; pre-approve the command for the task instead."""


def request(name: str, arg: str, risk_level: str, func: Callable[[str], dict], description: str) -> PendingConfirmation:
    if task_context.current() is not None:
        raise UnattendedRefusal(
            f"'{name}' needs the user's approval, which can't be asked during an unattended scheduled run. "
            "It only runs if it was pre-approved for this task.")
    with _lock:
        pc = PendingConfirmation(
            id=next(_id_counter), name=name, arg=arg,
            risk_level=risk_level, description=description, func=func,
        )
        _pending[pc.id] = pc
    if _listener is not None:
        try:
            _listener(pc)
        except Exception:  # noqa: BLE001 - a broken UI hook must never break the pending action
            pass
    return pc


def resolve(confirmation_id: int, approved: bool) -> dict:
    """Runs (or discards) a pending action. Only ever called from a real
    user gesture in the app -- never from parsed model output."""
    with _lock:
        pc = _pending.pop(confirmation_id, None)
    if pc is None:
        return {"success": False, "message": "That confirmation is no longer pending."}
    if not approved:
        return {"success": True, "message": f"Cancelled: {pc.name} {pc.arg}".strip(), "name": pc.name, "arg": pc.arg}
    try:
        result = pc.func(pc.arg)
    except Exception as exc:  # noqa: BLE001
        result = {"success": False, "message": f"'{pc.name}' failed: {exc}"}
    result = dict(result) if isinstance(result, dict) else {"success": True, "message": str(result)}
    result.setdefault("success", True)
    result.setdefault("message", "")
    result["name"] = pc.name
    result["arg"] = pc.arg
    return result


def list_pending() -> list:
    with _lock:
        return list(_pending.values())


def cancel_all() -> None:
    with _lock:
        _pending.clear()
