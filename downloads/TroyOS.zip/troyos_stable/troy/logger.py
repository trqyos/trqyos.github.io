"""
Troy Assistant - Log System

One rotating log file per day under troy_logs/, plus everything still goes
to stderr for whoever's watching the terminal Troy was launched from.
Every other module imports `logger` from here instead of calling
`logging.getLogger` itself, so the setup (handlers, formatting, rotation)
lives in exactly one place.

What gets logged (see call sites in agent.py, dispatcher.py, llm_client.py,
escalation.py):
  - every user turn and which source it came from (typed)
  - every command Troy runs, its argument, and whether it succeeded
  - every LLM call attempt, including provider/model fallbacks
  - escalations to Gemini and their outcome
  - force-stop events
  - uncaught errors, with tracebacks

Log lines are plain text, one event per line, so `troy_logs/troy.log` is
readable by just opening it -- no log viewer required, though `tail()`
below is also what the Electron frontend's logs panel calls over IPC
(see troy/ipc_host.py, channel "logs:get").
"""

import logging
import logging.handlers
import os

from . import config

os.makedirs(config.LOGS_DIR, exist_ok=True)
_LOG_FILE = os.path.join(config.LOGS_DIR, "troy.log")

logger = logging.getLogger("troy")
logger.setLevel(getattr(logging, config.LOG_LEVEL, logging.INFO))

if not logger.handlers:  # guard against duplicate handlers on module re-import
    _formatter = logging.Formatter(
        "%(asctime)s [%(levelname)s] %(name)s: %(message)s", datefmt="%Y-%m-%d %H:%M:%S"
    )

    _file_handler = logging.handlers.TimedRotatingFileHandler(
        _LOG_FILE, when="midnight", backupCount=14, encoding="utf-8"
    )
    _file_handler.setFormatter(_formatter)
    logger.addHandler(_file_handler)

    _console_handler = logging.StreamHandler()
    # Defensive second layer behind main.py's stream reconfigure: if this
    # module is ever imported from some other entry point that didn't
    # force UTF-8 first (tests, a future CLI, ...), make sure the console
    # handler's stream can't raise "'charmap' codec can't encode
    # character ..." on a non-ASCII log line -- a crash inside logging
    # itself is the worst place for this to happen, since it would take
    # down whatever was merely trying to LOG something.
    _stream = getattr(_console_handler, "stream", None)
    if _stream is not None and hasattr(_stream, "reconfigure"):
        try:
            _stream.reconfigure(encoding="utf-8", errors="replace")
        except Exception:  # noqa: BLE001 - never let logging setup itself fail
            pass
    _console_handler.setFormatter(_formatter)
    logger.addHandler(_console_handler)

    logger.propagate = False


def tail(max_chars: int = 20000) -> str:
    """Returns the end of today's log file as text, for the UI's log viewer.
    Reads only the last `max_chars` characters so a huge log file can't
    freeze the UI thread."""
    if not os.path.exists(_LOG_FILE):
        return "(no log file yet)"
    try:
        size = os.path.getsize(_LOG_FILE)
        with open(_LOG_FILE, "r", encoding="utf-8", errors="replace") as f:
            if size > max_chars:
                f.seek(size - max_chars)
                f.readline()  # drop a possibly-truncated first line
            return f.read()
    except OSError as exc:
        return f"(couldn't read log file: {exc})"


def log_file_path() -> str:
    return _LOG_FILE
