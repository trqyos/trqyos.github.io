"""
Troy Assistant - Stop Control

A single, process-wide "please stop" flag that lets the UI interrupt Troy
mid-turn -- including while a response is still streaming in from the LLM,
not just between commands. Deliberately dead simple (one threading.Event)
because it only needs to answer one question from a lot of different
places: "should I abandon what I'm doing right now?"

How it's wired in:
  - llm_client.chat() polls is_stopped() between streamed chunks and raises
    StoppedByUser the moment it sees the flag -- this is what makes the
    force-stop button interrupt generation itself, not just the aftermath.
  - agent.py checks is_stopped() before each step of the observe/react loop
    and before executing each parsed command, so a batch of commands
    already in flight doesn't keep running after the button is pressed.
  - dispatcher.execute() checks it too, as a last line of defence for
    anything else that calls into the dispatcher directly.
  - MainWindow's Force Stop button calls request_stop(); TroyAgent clears
    the flag again at the start of the next turn so a stale stop doesn't
    silently block all future input.
"""

import threading


class StopController:
    def __init__(self):
        self._event = threading.Event()

    def request_stop(self):
        """Called by the UI's Force Stop button. Safe to call from any thread."""
        self._event.set()

    def clear(self):
        """Called at the start of every new turn so stopping one turn doesn't
        permanently disable the assistant."""
        self._event.clear()

    def is_stopped(self) -> bool:
        return self._event.is_set()


# Process-wide singleton -- there's only ever one active turn at a time
# (see MainWindow's turn queue), so one shared flag is all that's needed.
stop_controller = StopController()
