"""
TROYOS STABLE - Wake-word voice listener

Continuous, hands-free voice control: a background thread listens to the
microphone the whole time it's enabled, with no button to press. It:

  1. Watches for speech starting (an adaptive energy gate against the
     room's own background noise level -- see config.VAD_ENERGY_MULTIPLIER
     -- not a heavyweight VAD model or extra native dependency: just
     RMS amplitude, which is enough once a wake word/transcript is the
     real filter downstream anyway).
  2. Captures until speech stops (config.VAD_SILENCE_HANGOVER_SECONDS of
     trailing quiet ends the utterance -- this is the "detects when
     speech ends quickly" knob).
  3. Transcribes the utterance (troy/voice.py -- either STT engine).
  4. If the wake word (config.WAKE_WORD, default "troy") is in it,
     whatever comes after it in the SAME breath is sent immediately as a
     command ("Troy, open Chrome" -> "open Chrome", sent right away). If
     only the wake word was said, a short follow-up window opens
     (config.WAKE_WORD_FOLLOWUP_SECONDS) where the NEXT utterance is sent
     as-is, with no need to repeat "Troy" -- an actual back-and-forth
     exchange, not one wake word per sentence. Utterances that don't
     contain the wake word and aren't inside a follow-up window are
     ignored -- ambient conversation, a TV, etc. never gets sent anywhere.

Threading: on_command/on_state_change are called from this module's own
background thread, never the Qt GUI thread. main_window.py is responsible
for marshalling them (same pattern as the mobile bridge, hotkey, and
confirmation listener: wrap them in a Qt signal's .emit).
"""

import queue
import re
import threading
import time

from . import audio_in, config, speech_text, voice
from .logger import logger

_thread = None
_stop_event = threading.Event()
_state = "idle"  # idle | hearing | thinking | awake
_awake_until = 0.0
_on_command = None
_on_state_change = None
# Hooks used by full voice mode (troy/voice_mode.py). All optional.
_hooks = {"on_level": None, "is_speaking": None, "on_barge_in": None, "on_transcript": None,
          "on_interrupt": None, "on_conversation_end": None}
_conversation = False
_conversation_until = 0.0
_paused = False


def set_paused(paused: bool):
    """Mute the microphone (the loop keeps running but ignores everything)."""
    global _paused
    _paused = bool(paused)


def is_paused() -> bool:
    return _paused


def set_hooks(**hooks):
    """on_level(rms) ~30x/s | is_speaking() -> bool (Troy is talking) | on_barge_in() |
    on_transcript(text) | on_interrupt() ("stop") | on_conversation_end(reason)."""
    _hooks.update({k: v for k, v in hooks.items() if k in _hooks})


def set_conversation(enabled: bool):
    """Conversation mode: every utterance is a command (no wake word needed)
    until the room has been quiet for VOICE_CONVERSATION_IDLE_SECONDS or the
    user says 'goodbye'. This is what makes it hands-free."""
    global _conversation, _conversation_until
    _conversation = bool(enabled)
    _conversation_until = time.monotonic() + config.VOICE_CONVERSATION_IDLE_SECONDS if enabled else 0.0


def in_conversation() -> bool:
    return _conversation


def extend_conversation():
    """Called when Troy finishes speaking: the follow-up window starts from now, not from when the user last spoke."""
    global _conversation_until
    if _conversation:
        _conversation_until = time.monotonic() + config.VOICE_CONVERSATION_IDLE_SECONDS


def _hook(name, *args):
    fn = _hooks.get(name)
    if fn:
        try:
            return fn(*args)
        except Exception:  # noqa: BLE001 - a broken hook must never kill the listener
            logger.debug("wake_listener hook %s failed", name, exc_info=True)
    return None


def set_callbacks(on_command, on_state_change=None):
    """on_command(text: str) is called once per recognized, wake-word-
    gated command -- the caller should treat this exactly like a typed
    message (append it, send it) since it's already been decided this is
    really a command, not background noise."""
    global _on_command, _on_state_change
    _on_command = on_command
    _on_state_change = on_state_change


def start() -> bool:
    """Starts the background listener (idempotent). Returns False (and
    logs why) instead of raising if sounddevice/the mic isn't available.
    This has to be broad, not just ImportError: sounddevice raises OSError
    at import time if its native PortAudio library is missing/broken,
    which is exactly the kind of environment problem that must degrade to
    a log message, not take the whole app down with it at startup."""
    global _thread
    if _thread is not None and _thread.is_alive():
        return True
    try:
        import sounddevice  # noqa: F401
    except Exception as exc:  # noqa: BLE001
        logger.warning("Voice input unavailable (%s). Check 'sounddevice' is installed and a mic/audio driver is present.", exc)
        return False

    _stop_event.clear()
    _thread = threading.Thread(target=_loop, daemon=True, name="troy-wake-listener")
    _thread.start()
    return True


def stop():
    _stop_event.set()


def is_running() -> bool:
    return _thread is not None and _thread.is_alive()


def get_state() -> str:
    return _state


def _set_state(state: str):
    global _state
    if state == _state:
        return
    _state = state
    if _on_state_change:
        try:
            _on_state_change(state)
        except Exception:  # noqa: BLE001 - a broken UI hook must never kill the listener
            pass


def _split_wake_word(transcript: str, wake_word: str):
    """Returns (triggered, command). `command` is the text after the wake
    word (may be empty, meaning "wake word only -- open a follow-up
    window and wait for the real command"). Matches the wake word as a
    whole word, case-insensitively, anywhere in the utterance, so "hey
    Troy" and "Troy, ..." both work."""
    if not wake_word:
        return True, transcript.strip()  # no wake word configured -- treat everything as a command
    pattern = re.compile(r"\b" + re.escape(wake_word) + r"\b", re.IGNORECASE)
    match = pattern.search(transcript)
    if not match:
        return False, ""
    remainder = transcript[match.end():].strip(" ,.!?-")
    return True, remainder


def _pick_input_device(sd):
    """Index of the microphone whose name contains VOICE_INPUT_DEVICE, else None (system default)."""
    want = (config.VOICE_INPUT_DEVICE or "").lower()
    if not want:
        return None
    try:
        for i, d in enumerate(sd.query_devices()):
            if d.get("max_input_channels", 0) > 0 and want in d.get("name", "").lower():
                return i
    except Exception:  # noqa: BLE001
        pass
    logger.warning("Microphone '%s' not found; using the system default.", config.VOICE_INPUT_DEVICE)
    return None


def _loop():
    global _conversation, _conversation_until
    try:
        import sounddevice as sd
    except Exception as exc:  # noqa: BLE001
        logger.warning("Wake listener couldn't start: %s", exc)
        return

    samplerate = 16000
    frame_samples = int(samplerate * 30 / 1000)
    audio_q: "queue.Queue" = queue.Queue()

    def _callback(indata, frames, time_info, status):
        audio_q.put(indata[:, 0].copy())

    try:
        stream = sd.InputStream(samplerate=samplerate, channels=1, dtype="int16", blocksize=frame_samples,
                                callback=_callback, device=_pick_input_device(sd))
        stream.start()
    except Exception as exc:  # noqa: BLE001
        logger.warning("Wake listener couldn't open the microphone: %s", exc)
        _set_state("idle")
        return

    logger.info("Wake listener started -- say '%s' to talk to Troy.", config.WAKE_WORD or "(any speech)")
    _set_state("idle")
    ep = audio_in.Endpointer(rate=samplerate, end_silence_ms=int(config.VAD_SILENCE_HANGOVER_SECONDS * 1000),
                             max_seconds=config.VAD_MAX_UTTERANCE_SECONDS)
    barge_started = False
    try:
        while not _stop_event.is_set():
            try:
                frame = audio_q.get(timeout=0.5)
            except queue.Empty:
                _expire(); continue

            if _paused:
                ep.reset(); barge_started = False
                continue
            speaking = bool(_hook("is_speaking"))
            # While Troy talks the mic hears Troy: either ignore it, or (barge-in)
            # only react to a voice clearly louder than the speaker's output.
            if speaking and not config.VOICE_BARGE_IN:
                ep.reset(); barge_started = False
                continue
            ep.sensitivity = 4.0 if speaking else 1.0

            for event in ep.feed(frame):
                kind = event[0]
                if kind == "level":
                    _hook("on_level", event[1])
                elif kind == "start":
                    if speaking:
                        barge_started = True
                        _hook("on_barge_in")                     # cut Troy off, then capture what you're saying
                    _set_state("hearing")
                elif kind == "end":
                    barge_started = False
                    _finish_utterance(event[1], samplerate)
                elif kind == "discard":
                    barge_started = False
                    _set_state("awake" if (time.monotonic() < _awake_until or _conversation) else "idle")
            _expire()
    finally:
        stream.stop()
        stream.close()
        _set_state("idle")


def _expire():
    """Follow-up windows running out: wake-word window and conversation mode."""
    global _conversation, _conversation_until
    now = time.monotonic()
    if _conversation and not _hook("is_speaking") and _state in ("awake", "idle") and now > _conversation_until:
        _conversation = False
        _set_state("idle")
        _hook("on_conversation_end", "timeout")
    elif _state == "awake" and not _conversation and now > _awake_until:
        _set_state("idle")


def _calibrate(audio_q, seconds: float = 1.0) -> float:
    """Samples ~1s of ambient audio at startup to seed the noise floor, so
    the very first utterance doesn't rely on a guessed default."""
    import numpy as np
    levels = []
    deadline = time.monotonic() + seconds
    while time.monotonic() < deadline:
        try:
            frame = audio_q.get(timeout=0.2)
        except queue.Empty:
            continue
        levels.append(_rms(frame))
    return max(50.0, float(np.mean(levels)) if levels else 50.0)


def _rms(frame) -> float:
    import numpy as np
    return float(np.sqrt(np.mean(frame.astype(np.float64) ** 2)))


def _finish_utterance(frames, samplerate):
    import numpy as np
    global _awake_until, _conversation

    was_awake = time.monotonic() < _awake_until or _conversation
    _set_state("thinking")
    audio = np.concatenate(frames) if isinstance(frames, (list, tuple)) else frames
    text = voice.transcribe(audio, samplerate)

    if not text or speech_text.looks_like_noise(text):
        _set_state("awake" if was_awake else "idle")
        return
    _hook("on_transcript", text)

    if _conversation:
        # hands-free: everything is for Troy (a wake word, if said, is just ignored)
        _, remainder = _split_wake_word(text, config.WAKE_WORD)
        text = remainder or text
        if speech_text.is_end_phrase(text):
            _conversation = False
            _set_state("idle")
            _hook("on_conversation_end", "goodbye")
            return
        if speech_text.is_stop_phrase(text):
            _hook("on_interrupt")
            _set_state("awake")
            return
        _dispatch(text)
        return

    if was_awake:
        # already in a follow-up conversation window -- this utterance
        # IS the command, no wake word needed again
        if speech_text.is_stop_phrase(text):
            _hook("on_interrupt"); _set_state("awake"); return
        _dispatch(text)
        return

    triggered, remainder = _split_wake_word(text, config.WAKE_WORD)
    if not triggered:
        logger.debug("Wake listener heard (ignored, no wake word): %s", text)
        _set_state("idle")
        return

    if remainder:
        if speech_text.is_stop_phrase(remainder):
            _hook("on_interrupt"); _set_state("idle"); return
        _dispatch(remainder)
    else:
        # wake word only ("Troy", "Hey Troy") -- open the follow-up window
        # and wait for the actual command next, no need to say it again
        _awake_until = time.monotonic() + config.WAKE_WORD_FOLLOWUP_SECONDS
        _set_state("awake")


def _dispatch(text: str):
    global _awake_until, _conversation_until
    _awake_until = time.monotonic() + config.WAKE_WORD_FOLLOWUP_SECONDS
    if _conversation:
        _conversation_until = time.monotonic() + config.VOICE_CONVERSATION_IDLE_SECONDS
    if _on_command:
        try:
            _on_command(text)
        except Exception:  # noqa: BLE001 - a broken UI hook must never kill the listener
            pass
    _set_state("awake")
