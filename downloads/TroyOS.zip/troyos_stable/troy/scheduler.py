"""
Troy's task scheduler.

Runs on its own thread, completely separate from the conversation loop. While
nothing is due it just sleeps (waking at most every 30 s to notice a clock change
or a wake-up from sleep); the model is never polled and is only called -- through
the injected `executor` -- at the moment a task is actually due.

Lifecycle of a task (field `status`)
    scheduled   waiting for `next_run`
    running     the executor is working on it right now
    retrying    the last attempt failed; the next attempt is at `next_run`
    paused      kept, but not scheduled until resumed
    completed   a one-time task that succeeded
    failed      a one-time task that failed for good (retries used up, or it can't succeed)
    cancelled   cancelled by the user
    missed      a one-time task whose moment passed while Troy/the PC was off
Recurring tasks go back to `scheduled` after every run (`last_outcome` says how it went).

Everything is saved to troy_tasks.json on every change (atomic replace) and every
event is appended to troy_task_runs.jsonl, so a restart resumes exactly where it was:
a run that was interrupted continues as a retry and is told which of its actions had
already succeeded, so those are not repeated.

The scheduler knows nothing about models, UI or tools. The host gives it:
    executor(task, run) -> Outcome      does one attempt (see troy/task_runner.py)
    on_event(name, payload)             changed | started | retrying | finished | missed
    context_provider() -> dict          {"session_id", "message_index"} of the chat creating a task
    stop_current()                      aborts the running attempt (cancel / user stop)
"""

import json
import os
import threading
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timedelta

from . import config, schedule_spec
from .logger import logger
from .schedule_spec import ScheduleError

MAX_TASKS = 200
MAX_WAIT_SECONDS = 30.0
PENDING = ("scheduled", "retrying")
DONE_STATES = ("completed", "failed", "cancelled", "missed")


@dataclass
class Outcome:
    """How one attempt went. status: done | retry | blocked | stopped."""
    status: str
    summary: str = ""
    error: str = ""
    needs_approval: list = field(default_factory=list)   # risky commands refused for lack of pre-approval
    used_tools: dict = field(default_factory=dict)       # extra tools this run used: name -> usage line


class RunState:
    """What the executor is told about the attempt it is running, and how it reports progress."""

    def __init__(self, scheduler, task_id, attempt, max_attempts, done_actions, last_error, manual):
        self._scheduler = scheduler
        self.task_id = task_id
        self.attempt = attempt
        self.max_attempts = max_attempts
        self.done_actions = list(done_actions)     # actions that already succeeded in this run (earlier attempts)
        self.last_error = last_error
        self.manual = manual

    def record_action(self, name, arg, message):
        self._scheduler._record_action(self.task_id, name, arg, message)

    def log(self, message, level="info", event="note"):
        self._scheduler._log(self.task_id, event, message, level=level)


def _iso(dt):
    return dt.replace(microsecond=0).isoformat() if dt else None


def _parse(value):
    return datetime.fromisoformat(value) if value else None


class Scheduler:
    def __init__(self, executor=None, on_event=None, clock=None, context_provider=None,
                 stop_current=None, tasks_file=None, log_file=None):
        self.executor = executor
        self.on_event = on_event or (lambda name, payload: None)
        self._clock = clock or datetime.now
        self.context_provider = context_provider or (lambda: {})
        self.stop_current = stop_current or (lambda: None)
        self._tasks_file, self._log_file = tasks_file, log_file
        self._cond = threading.Condition(threading.RLock())
        self._tasks: dict = {}
        self._loaded = False
        self._running_id = None
        self._stop = False
        self._thread = None
        self._log_writes = 0

    # ------------------------------------------------------------ paths + storage
    def _tasks_path(self):
        return self._tasks_file or config.TASKS_FILE

    def _log_path(self):
        return self._log_file or config.TASK_LOG_FILE

    def _ensure_loaded(self):
        if self._loaded:
            return
        with self._cond:
            if self._loaded:
                return
            self._loaded = True
            path = self._tasks_path()
            try:
                with open(path, "r", encoding="utf-8") as f:
                    data = json.load(f)
                for t in data.get("tasks", []):
                    if isinstance(t, dict) and t.get("id") and isinstance(t.get("schedule"), dict):
                        self._tasks[t["id"]] = t
            except FileNotFoundError:
                pass
            except (OSError, ValueError) as exc:
                bad = f"{path}.corrupt-{datetime.now():%Y%m%d%H%M%S}"
                logger.error("Task file unreadable (%s); keeping it as %s and starting empty.", exc, bad)
                try:
                    os.replace(path, bad)
                except OSError:
                    pass

    def _save(self):
        path = self._tasks_path()
        tmp = f"{path}.tmp"
        try:
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump({"version": 1, "tasks": list(self._tasks.values())}, f, indent=2, ensure_ascii=False)
            os.replace(tmp, path)
        except OSError as exc:
            logger.error("Couldn't save scheduled tasks: %s", exc)

    def _log(self, task_id, event, message, level="info", **extra):
        entry = {"ts": _iso(self._clock()), "task_id": task_id, "event": event, "level": level, "message": str(message)[:600], **extra}
        try:
            with self._cond:
                with open(self._log_path(), "a", encoding="utf-8") as f:
                    f.write(json.dumps(entry, ensure_ascii=False) + "\n")
                self._log_writes += 1
                if self._log_writes % 200 == 0:
                    self._trim_log()
        except OSError as exc:
            logger.warning("Couldn't write the task log: %s", exc)
        (logger.warning if level in ("warning", "error") else logger.info)("Task %s: %s %s", task_id, event, message)

    def _trim_log(self, keep=2000, limit=4000):
        try:
            with open(self._log_path(), "r", encoding="utf-8") as f:
                lines = f.readlines()
            if len(lines) > limit:
                with open(self._log_path(), "w", encoding="utf-8") as f:
                    f.writelines(lines[-keep:])
        except OSError:
            pass

    def logs(self, task_id=None, limit=100) -> list:
        """The newest `limit` log entries (oldest first), optionally for one task."""
        out = []
        try:
            with open(self._log_path(), "r", encoding="utf-8") as f:
                for line in f:
                    try:
                        e = json.loads(line)
                    except ValueError:
                        continue
                    if task_id is None or e.get("task_id") == task_id:
                        out.append(e)
        except OSError:
            return []
        return out[-max(1, int(limit)):]

    def _emit(self, name, payload):
        try:
            self.on_event(name, payload)
        except Exception as exc:  # noqa: BLE001 - a UI hook must never break the scheduler
            logger.warning("Task event hook failed: %s", exc)

    # ------------------------------------------------------------ views
    def _view(self, t) -> dict:
        v = json.loads(json.dumps(t))
        try:
            v["schedule_text"] = schedule_spec.describe(t["schedule"])
        except Exception:  # noqa: BLE001
            v["schedule_text"] = "Unknown schedule"
        v["recurring"] = schedule_spec.is_recurring(t["schedule"])
        v["effective_max_retries"] = self._max_retries(t)
        v["effective_retry_delay"] = self._retry_delay(t)
        return v

    def get(self, task_id):
        self._ensure_loaded()
        with self._cond:
            t = self._tasks.get(task_id)
            return self._view(t) if t else None

    def list(self) -> list:
        """Every task, active first (soonest next), then finished ones (newest first)."""
        self._ensure_loaded()
        with self._cond:
            tasks = [self._view(t) for t in self._tasks.values()]
        active = sorted([t for t in tasks if t["status"] not in DONE_STATES], key=lambda t: (t.get("next_run") or "9999", t["created_at"]))
        finished = sorted([t for t in tasks if t["status"] in DONE_STATES], key=lambda t: t.get("updated_at") or "", reverse=True)
        return active + finished

    def resolve(self, ref: str) -> dict:
        """Finds a task from an id, an id prefix or (part of) its title. Raises LookupError with a helpful message."""
        self._ensure_loaded()
        ref = (ref or "").strip()
        with self._cond:
            tasks = list(self._tasks.values())
            if not ref:
                raise LookupError("Which task? Give its id or title (see list_tasks).")
            exact = [t for t in tasks if t["id"] == ref]
            if exact:
                return exact[0]
            for test in (lambda t: t["id"].startswith(ref.lower()),
                         lambda t: t["title"].lower() == ref.lower(),
                         lambda t: ref.lower() in t["title"].lower()):
                found = [t for t in tasks if test(t)]
                if len(found) == 1:
                    return found[0]
                if len(found) > 1:
                    raise LookupError(f"'{ref}' matches {len(found)} tasks: " + "; ".join(f"{t['id']} ({t['title']})" for t in found[:6]) + ". Use the id.")
            raise LookupError(f"No task matches '{ref}'." + (" Tasks: " + "; ".join(f"{t['id']} ({t['title']})" for t in tasks[:8]) if tasks else " There are no tasks."))

    # ------------------------------------------------------------ settings helpers
    @staticmethod
    def _max_retries(t):
        return int(t["max_retries"]) if t.get("max_retries") is not None else int(config.TASK_MAX_RETRIES)

    @staticmethod
    def _retry_delay(t):
        return int(t["retry_delay"]) if t.get("retry_delay") is not None else int(config.TASK_RETRY_DELAY_SECONDS)

    @staticmethod
    def _grace():
        return timedelta(minutes=max(1, int(config.TASK_MISSED_GRACE_MINUTES)))

    # ------------------------------------------------------------ creating / changing
    @staticmethod
    def _make_title(prompt, title):
        title = " ".join((title or "").split())
        if not title:
            title = " ".join(prompt.split())
        return title[:60] + ("\u2026" if len(title) > 60 else "")

    def _spec_for(self, when, now):
        if isinstance(when, dict):
            return schedule_spec.validate(when, now)
        return schedule_spec.parse_when(str(when or ""), now)

    def add(self, prompt, when, title="", session_id=None, message_index=None, grants=(), max_retries=None, retry_delay=None) -> dict:
        self._ensure_loaded()
        prompt = " ".join(str(prompt or "").split())
        if not prompt:
            raise ValueError("The task needs an instruction (what Troy should do when it's time).")
        if len(prompt) > 2000:
            raise ValueError("The task instruction is too long (2000 characters at most).")
        now = self._clock().replace(microsecond=0)
        spec = self._spec_for(when, now)
        first = schedule_spec.next_run(spec, now)
        if first is None:
            raise ScheduleError("That time has already passed.")
        ctx = {}
        try:
            ctx = self.context_provider() or {}
        except Exception:  # noqa: BLE001
            pass
        with self._cond:
            if sum(1 for t in self._tasks.values() if t["status"] not in DONE_STATES) >= MAX_TASKS:
                raise ValueError(f"There are already {MAX_TASKS} active tasks; cancel some first.")
            task = {
                "id": uuid.uuid4().hex[:8], "title": self._make_title(prompt, title), "prompt": prompt,
                "schedule": spec, "status": "scheduled", "created_at": _iso(now), "updated_at": _iso(now),
                "next_run": _iso(first), "last_run": None, "last_outcome": None, "last_summary": "", "last_error": "",
                "run_count": 0, "fail_count": 0,
                "session_id": session_id if session_id is not None else ctx.get("session_id"),
                "message_index": message_index if message_index is not None else ctx.get("message_index"),
                "max_retries": max_retries, "retry_delay": retry_delay,
                "grants": sorted({g.strip() for g in grants if g and g.strip()}), "needs_approval": [],
                "known_tools": {}, "run": None, "manual": False,
            }
            self._tasks[task["id"]] = task
            self._save()
            self._log(task["id"], "created", f"{task['title']} -- {schedule_spec.describe(spec)}; first run {_iso(first)}")
            self._cond.notify_all()
            view = self._view(task)
        self._emit("changed", {"task": view})
        return view

    def modify(self, task_id, *, title=None, prompt=None, when=None, max_retries=None, retry_delay=None, clear_retries=False) -> dict:
        self._ensure_loaded()
        with self._cond:
            t = self._tasks.get(task_id)
            if t is None:
                raise LookupError(f"No task with id {task_id}.")
            if t["status"] == "running":
                raise ValueError("That task is running right now; change it when it has finished.")
            now = self._clock().replace(microsecond=0)
            changes = []
            if when is not None:
                spec = self._spec_for(when, now)
                first = schedule_spec.next_run(spec, now)
                if first is None:
                    raise ScheduleError("That time has already passed.")
                t["schedule"], t["next_run"] = spec, _iso(first)
                if t["status"] != "paused":
                    t["status"] = "scheduled"
                t["run"], t["manual"] = None, False
                changes.append(f"schedule -> {schedule_spec.describe(spec)}")
            if prompt is not None:
                clean = " ".join(str(prompt).split())
                if not clean:
                    raise ValueError("The instruction can't be empty.")
                if len(clean) > 2000:
                    raise ValueError("The task instruction is too long (2000 characters at most).")
                if clean != t["prompt"]:
                    t["prompt"] = clean
                    if t["grants"]:
                        changes.append("approvals cleared (the instruction changed)")
                    t["grants"], t["known_tools"], t["needs_approval"] = [], {}, []
                    changes.append("instruction changed")
            if title is not None:
                t["title"] = self._make_title(t["prompt"], title)
                changes.append("title changed")
            if max_retries is not None or clear_retries:
                t["max_retries"] = None if clear_retries else max(0, min(10, int(max_retries)))
                changes.append(f"retries -> {t['max_retries'] if t['max_retries'] is not None else 'default'}")
            if retry_delay is not None:
                t["retry_delay"] = max(5, min(3600, int(retry_delay)))
                changes.append(f"retry delay -> {t['retry_delay']}s")
            t["updated_at"] = _iso(now)
            self._save()
            self._log(task_id, "modified", "; ".join(changes) or "no change")
            self._cond.notify_all()
            view = self._view(t)
        self._emit("changed", {"task": view})
        return view

    def pause(self, task_id) -> dict:
        return self._set_status(task_id, "paused", allowed=("scheduled", "retrying"), event="paused", message="Paused.")

    def resume(self, task_id) -> dict:
        self._ensure_loaded()
        with self._cond:
            t = self._tasks.get(task_id)
            if t is None:
                raise LookupError(f"No task with id {task_id}.")
            if t["status"] != "paused":
                raise ValueError("That task isn't paused.")
            now = self._clock().replace(microsecond=0)
            nxt = schedule_spec.next_run(t["schedule"], now)
            if nxt is None:
                t["status"], t["next_run"], t["last_outcome"] = "missed", None, "missed"
                msg = "Resumed, but its time has already passed."
            else:
                t["status"], t["next_run"] = "scheduled", _iso(nxt)
                msg = f"Resumed; next run {_iso(nxt)}."
            t["updated_at"] = _iso(now)
            self._save()
            self._log(task_id, "resumed", msg)
            self._cond.notify_all()
            view = self._view(t)
        self._emit("changed", {"task": view})
        return view

    def cancel(self, task_id) -> dict:
        self._ensure_loaded()
        with self._cond:
            t = self._tasks.get(task_id)
            if t is None:
                raise LookupError(f"No task with id {task_id}.")
            if t["status"] in ("cancelled", "completed"):
                raise ValueError(f"That task is already {t['status']}.")
            was_running = t["status"] == "running"
            t["status"], t["next_run"], t["manual"] = "cancelled", None, False
            t["updated_at"] = _iso(self._clock())
            self._save()
            self._log(task_id, "cancelled", "Cancelled by the user." + (" Stopping the run in progress." if was_running else ""))
            self._cond.notify_all()
            view = self._view(t)
        if was_running:
            try:
                self.stop_current()
            except Exception:  # noqa: BLE001
                pass
        self._emit("changed", {"task": view})
        return view

    def delete(self, task_id) -> bool:
        self._ensure_loaded()
        with self._cond:
            t = self._tasks.get(task_id)
            if t is None:
                return False
            if t["status"] == "running":
                raise ValueError("That task is running right now; cancel it first.")
            del self._tasks[task_id]
            self._save()
            self._log(task_id, "deleted", t["title"])
        self._emit("deleted", {"id": task_id})
        return True

    def clear_finished(self) -> int:
        self._ensure_loaded()
        with self._cond:
            ids = [i for i, t in self._tasks.items() if t["status"] in DONE_STATES]
            for i in ids:
                del self._tasks[i]
            if ids:
                self._save()
        for i in ids:
            self._emit("deleted", {"id": i})
        return len(ids)

    def _set_status(self, task_id, status, allowed, event, message):
        self._ensure_loaded()
        with self._cond:
            t = self._tasks.get(task_id)
            if t is None:
                raise LookupError(f"No task with id {task_id}.")
            if t["status"] not in allowed:
                raise ValueError(f"A {t['status']} task can't be {status}.")
            t["status"], t["next_run"] = status, None
            t["updated_at"] = _iso(self._clock())
            self._save()
            self._log(task_id, event, message)
            view = self._view(t)
        self._emit("changed", {"task": view})
        return view

    def grant(self, task_id, commands) -> dict:
        """Records the user's approval for exact commands to run unattended in this task."""
        self._ensure_loaded()
        with self._cond:
            t = self._tasks.get(task_id)
            if t is None:
                raise LookupError(f"No task with id {task_id}.")
            new = {c.strip() for c in commands if c and c.strip()}
            t["grants"] = sorted(set(t["grants"]) | new)
            t["needs_approval"] = [c for c in t["needs_approval"] if c not in t["grants"]]
            t["updated_at"] = _iso(self._clock())
            self._save()
            self._log(task_id, "approved", "The user approved running unattended: " + ", ".join(sorted(new)))
            view = self._view(t)
        self._emit("changed", {"task": view})
        return view

    def run_now(self, task_id) -> dict:
        """Runs the task as soon as nothing else is running (even a finished or paused one)."""
        self._ensure_loaded()
        with self._cond:
            t = self._tasks.get(task_id)
            if t is None:
                raise LookupError(f"No task with id {task_id}.")
            if t["status"] == "running":
                raise ValueError("That task is already running.")
            now = self._clock().replace(microsecond=0)
            if t["status"] in PENDING and schedule_spec.is_recurring(t["schedule"]) and not t.get("manual"):
                t["saved_next"] = t["next_run"]
            t["status"], t["next_run"], t["manual"] = "scheduled", _iso(now), True
            t["run"], t["updated_at"] = None, _iso(now)
            self._save()
            self._log(task_id, "run_now", "Run requested by the user.")
            self._cond.notify_all()
            view = self._view(t)
        self._emit("changed", {"task": view})
        return view

    # ------------------------------------------------------------ the loop
    def start(self):
        self._ensure_loaded()
        old = self._thread
        if old and old.is_alive() and self._stop:         # stop() was just called: let that thread finish first
            old.join(2)
        with self._cond:
            if self._thread and self._thread.is_alive() and not self._stop:
                return
            self._stop = False
            self._recover_locked()
            self._thread = threading.Thread(target=self._loop, daemon=True, name="troy-scheduler")
            self._thread.start()

    def stop(self):
        with self._cond:
            self._stop = True
            self._cond.notify_all()

    def is_running(self) -> bool:
        return bool(self._thread and self._thread.is_alive() and not self._stop)

    def _recover_locked(self):
        """After a restart: a run that was cut off continues as a retry (keeping what it already did)."""
        now = self._clock().replace(microsecond=0)
        changed = False
        for t in self._tasks.values():
            if t["status"] != "running":
                continue
            changed = True
            run = t.get("run") or {"attempt": 1, "done_actions": []}
            self._log(t["id"], "interrupted", f"Troy stopped while attempt {run.get('attempt', 1)} was running.", level="warning")
            if run.get("attempt", 1) <= self._max_retries(t):
                run["attempt"] = run.get("attempt", 1) + 1
                run["last_error"] = "The previous attempt was interrupted when Troy shut down."
                t["run"], t["status"], t["next_run"] = run, "retrying", _iso(now)
            else:
                self._finalize_locked(t, Outcome("blocked", error="Interrupted by a shutdown and out of retries."), now)
        if changed:
            self._save()

    def _loop(self):
        while True:
            with self._cond:
                if self._stop:
                    return
                picked = self._pick_due_locked(self._clock())
                if picked is None:
                    self._cond.wait(self._wait_seconds_locked(self._clock()))
                    continue
            threading.Thread(target=self._execute, args=(picked,), daemon=True, name=f"troy-task-{picked}").start()

    def _wait_seconds_locked(self, now) -> float:
        nxt = [_parse(t["next_run"]) for t in self._tasks.values() if t["status"] in PENDING and t.get("next_run")]
        if not nxt or self._running_id:
            return MAX_WAIT_SECONDS
        return max(0.2, min(MAX_WAIT_SECONDS, (min(nxt) - now).total_seconds()))

    def _pick_due_locked(self, now):
        """Starts the earliest due task (marking it running) and returns its id; None if nothing is due or one is already running."""
        if self._running_id or self.executor is None:
            return None
        due = sorted((t for t in self._tasks.values() if t["status"] in PENDING and t.get("next_run") and _parse(t["next_run"]) <= now),
                     key=lambda t: t["next_run"])
        for t in due:
            late = now - _parse(t["next_run"])
            if t["status"] == "scheduled" and not t.get("manual") and late > self._grace():
                self._mark_missed_locked(t, now, late)
                continue
            self._start_locked(t, now)
            return t["id"]
        return None

    def _start_locked(self, t, now):
        run = t.get("run")
        fresh = t["status"] == "scheduled" or not run
        if fresh:
            run = {"id": uuid.uuid4().hex[:6], "attempt": 1, "done_actions": [], "last_error": "", "started_at": _iso(now)}
        t["run"], t["status"], self._running_id = run, "running", t["id"]
        t["last_run"], t["updated_at"] = _iso(now), _iso(now)
        self._save()
        self._log(t["id"], "started", f"Attempt {run['attempt']} of {1 + self._max_retries(t)}" + (" (manual run)" if t.get("manual") else ""))
        self._emit("started", {"task": self._view(t)})
        self._emit("changed", {"task": self._view(t)})

    def _mark_missed_locked(self, t, now, late):
        minutes = int(late.total_seconds() // 60)
        msg = f"Was due {minutes} min ago while Troy or the PC was off; not run (the grace period is {int(self._grace().total_seconds() // 60)} min)."
        t["last_outcome"], t["last_summary"], t["updated_at"] = "missed", msg, _iso(now)
        if schedule_spec.is_recurring(t["schedule"]):
            nxt = schedule_spec.next_run(t["schedule"], now)
            t["next_run"] = _iso(nxt)
            t["status"] = "scheduled" if nxt else "missed"
        else:
            t["status"], t["next_run"] = "missed", None
        self._save()
        self._log(t["id"], "missed", msg, level="warning")
        view = self._view(t)
        self._emit("missed", {"task": view})
        self._emit("changed", {"task": view})

    def tick(self, now=None):
        """One synchronous pass (used by tests and the 'run now' fast path): runs a due task inline and returns its id."""
        self._ensure_loaded()
        with self._cond:
            picked = self._pick_due_locked(now or self._clock())
        if picked:
            self._execute(picked)
        return picked

    # ------------------------------------------------------------ running one attempt
    def _record_action(self, task_id, name, arg, message):
        with self._cond:
            t = self._tasks.get(task_id)
            if not t or not t.get("run"):
                return
            t["run"]["done_actions"].append({"name": name, "arg": str(arg)[:200], "message": str(message)[:200]})
            self._save()
        self._log(task_id, "action", f"{name}{(':' + str(arg)[:80]) if arg else ''} -> OK")

    def _execute(self, task_id):
        with self._cond:
            t = self._tasks.get(task_id)
            if t is None:
                self._running_id = None
                return
            run = t["run"]
            snapshot = self._view(t)
            state = RunState(self, task_id, run["attempt"], 1 + self._max_retries(t), run["done_actions"], run.get("last_error", ""), bool(t.get("manual")))
        try:
            outcome = self.executor(snapshot, state)
            if not isinstance(outcome, Outcome):
                raise TypeError("the task executor returned no outcome")
        except Exception as exc:  # noqa: BLE001 - an executor crash is a failed attempt, not a dead scheduler
            logger.exception("Task executor crashed")
            outcome = Outcome("retry", error=f"The run crashed: {exc}")
        self._finish(task_id, outcome)

    def _finish(self, task_id, outcome):
        events = []
        with self._cond:
            t = self._tasks.get(task_id)
            self._running_id = None
            if t is not None:
                events = self._finalize_locked(t, outcome, self._clock().replace(microsecond=0))
                self._save()
            self._cond.notify_all()
        for name, payload in events:
            self._emit(name, payload)

    def _finalize_locked(self, t, outcome, now) -> list:
        """Applies an attempt's outcome: success, retry or final failure. Returns the events to emit."""
        run = t.get("run") or {"attempt": 1, "done_actions": []}
        attempt, retries = run.get("attempt", 1), self._max_retries(t)
        recurring = schedule_spec.is_recurring(t["schedule"])
        manual, saved_next = bool(t.get("manual")), t.pop("saved_next", None)
        t["updated_at"] = _iso(now)
        events = []

        if t["status"] == "cancelled":                 # cancelled while it ran: stay cancelled
            t["run"], t["manual"] = None, False
            self._log(t["id"], "stopped", "The run ended after the task was cancelled.")
            return [("changed", {"task": self._view(t)})]

        def next_after():
            if manual and saved_next and _parse(saved_next) > now:
                return _parse(saved_next)
            return schedule_spec.next_run(t["schedule"], now) if recurring else None

        if outcome.status == "done":
            t["run_count"] += 1
            t["last_outcome"], t["last_summary"], t["last_error"] = "success", outcome.summary, ""
            t["needs_approval"], t["manual"], t["run"] = [], False, None
            t["known_tools"].update(outcome.used_tools or {})
            nxt = next_after()
            t["status"], t["next_run"] = ("scheduled", _iso(nxt)) if nxt else ("completed", None)
            self._log(t["id"], "success", outcome.summary or "Done.")
            events.append(("finished", {"task": self._view(t), "ok": True, "summary": outcome.summary, "attempts": attempt}))
        elif outcome.status == "retry" and attempt <= retries:
            delay = self._retry_delay(t)
            run["attempt"], run["last_error"] = attempt + 1, outcome.error or outcome.summary or "The attempt failed."
            t["run"], t["status"], t["next_run"] = run, "retrying", _iso(now + timedelta(seconds=delay))
            t["last_error"] = run["last_error"]
            self._log(t["id"], "retry", f"Attempt {attempt} failed: {run['last_error']} Trying again in {delay}s (attempt {attempt + 1} of {1 + retries}).", level="warning")
            events.append(("retrying", {"task": self._view(t), "error": run["last_error"], "attempt": attempt}))
        else:
            reason = outcome.error or outcome.summary or "The task could not be completed."
            if outcome.status == "retry":
                reason += f" (gave up after {attempt} attempt{'s' if attempt != 1 else ''})"
            kind = {"stopped": "stopped", "blocked": "failed"}.get(outcome.status, "failed")
            t["run_count"] += 1
            t["fail_count"] += 1
            t["last_outcome"], t["last_summary"], t["last_error"] = kind, outcome.summary or reason, reason
            t["needs_approval"] = list(outcome.needs_approval or [])
            t["manual"], t["run"] = False, None
            nxt = next_after()
            t["status"], t["next_run"] = ("scheduled", _iso(nxt)) if nxt else ("failed", None)
            self._log(t["id"], "failed", reason, level="error")
            events.append(("finished", {"task": self._view(t), "ok": False, "summary": outcome.summary or reason, "error": reason, "attempts": attempt}))
        events.append(("changed", {"task": self._view(t)}))
        return events


# ---------------------------------------------------------------- the process-wide instance
_instance = None


def install(instance):
    """The host installs its Scheduler here so the task tools (troy/tools_tasks.py) can reach it."""
    global _instance
    _instance = instance


def get():
    return _instance
