"""
Turning text into something worth saying out loud, and spoken text into intent.

Replies are written for a screen: markdown, bullet lists, links, file paths,
emoji. Read aloud by a speech engine those are noise ("asterisk asterisk
bold asterisk asterisk", a 90-character URL spelled out). clean_for_speech()
rewrites a reply the way a person would say it; split_sentences() lets the
speech engine start on the first sentence while later ones are still being
prepared; the phrase helpers decide whether what the user said was a command
to Troy, "stop talking", or "we're done".
"""

import re

_EMOJI = re.compile("[\U0001F000-\U0001FAFF\u2600-\u27BF\uFE0F\u200D\u2B50\u2B06\u2194-\u21AA\u231A-\u23FF]+")
_URL = re.compile(r"https?://[^\s)>\]]+", re.IGNORECASE)
_WIN_PATH = re.compile(r"\b[A-Za-z]:\\(?:[^\s\\/:*?\"<>|]+\\)*([^\s\\/:*?\"<>|]*)")
_ABBREV = ("mr", "mrs", "ms", "dr", "prof", "sr", "jr", "st", "vs", "etc", "e.g", "i.e", "approx", "no", "inc", "ltd")


def _domain(url: str) -> str:
    m = re.match(r"https?://(?:www\.)?([^/\s?#]+)", url, re.IGNORECASE)
    return m.group(1) if m else "a link"


def clean_for_speech(text: str, keep_code_note: bool = True) -> str:
    """Markdown/links/paths/emoji -> plain, speakable sentences."""
    if not text:
        return ""
    s = str(text)
    s = re.sub(r"```.*?```", " I've put the code on screen. " if keep_code_note else " ", s, flags=re.DOTALL)
    s = re.sub(r"`([^`\n]*)`", r"\1", s)
    s = re.sub(r"\[([^\]\n]+)\]\((https?://[^)\s]+)\)", r"\1", s)               # [text](url) -> text
    s = _URL.sub(lambda m: _domain(m.group(0)), s)                              # bare URL -> its domain
    s = _WIN_PATH.sub(lambda m: m.group(1) or "that folder", s)                  # C:\a\b\file.txt -> file.txt
    s = re.sub(r"^\s{0,3}#{1,6}\s*", "", s, flags=re.MULTILINE)                  # headings
    s = re.sub(r"^\s*>\s?", "", s, flags=re.MULTILINE)                          # quotes
    s = re.sub(r"^\s*[-*\u2022]\s+", "", s, flags=re.MULTILINE)                  # bullets
    s = re.sub(r"^\s*\d+[.)]\s+", "", s, flags=re.MULTILINE)                     # numbered items
    s = re.sub(r"(\*\*|__)(.+?)\1", r"\2", s)
    s = re.sub(r"(?<![\w*])[*_]([^*_\n]+)[*_](?![\w*])", r"\1", s)
    s = re.sub(r"[|~^]+", " ", s)
    s = _EMOJI.sub("", s)
    s = s.replace("&", " and ").replace("%", " percent").replace("\u00B0C", " degrees Celsius").replace("\u00B0F", " degrees Fahrenheit")
    s = re.sub(r"(?<=\d)\s*-\s*(?=\d)", " to ", s)                               # 9-17 -> 9 to 17
    # list items run together as separate sentences instead of one breathless line
    s = re.sub(r"\n+", ". ", s)
    s = re.sub(r"\s*\.\s*(\.\s*)+", ". ", s)
    s = re.sub(r"\.\s*([,;:!?])", r"\1", s)
    s = re.sub(r"\s+", " ", s).strip()
    return s


def split_sentences(text: str, max_chars: int = 240) -> list:
    """Sentences, never splitting on 'Dr.' / 'e.g.' / decimals; very long ones
    are cut at a comma or space so synthesis stays quick."""
    text = (text or "").strip()
    if not text:
        return []
    parts, buf = [], ""
    tokens = re.split(r"(?<=[.!?])\s+", text)
    for tok in tokens:
        buf = f"{buf} {tok}".strip() if buf else tok
        last = buf.rstrip(".!?").split(" ")[-1].lower().rstrip(".")
        if buf[-1:] in ".!?" and last not in _ABBREV and not re.fullmatch(r"[A-Za-z]", last):
            parts.append(buf); buf = ""
    if buf:
        parts.append(buf)
    out = []
    for p in parts:
        while len(p) > max_chars:
            cut = max(p.rfind(", ", 0, max_chars), p.rfind(" ", 0, max_chars))
            cut = cut if cut > 40 else max_chars
            out.append(p[:cut + 1].strip()); p = p[cut + 1:].strip()
        if p:
            out.append(p)
    return out


def _norm(text: str) -> str:
    return re.sub(r"[^a-z0-9' ]+", " ", (text or "").lower()).strip()


_END = (
    "stop listening", "end voice mode", "exit voice mode", "stop voice mode", "leave voice mode", "voice mode off",
    "that's all", "thats all", "that is all", "that's it", "thats it", "goodbye", "good bye", "bye troy", "bye bye",
    "go to sleep", "we're done", "were done", "i'm done", "im done", "thanks troy that's all", "that will be all",
)
_STOP = ("stop", "stop it", "stop talking", "cancel", "cancel that", "never mind", "nevermind", "be quiet", "quiet", "shut up",
         "enough", "that's enough", "thats enough", "hold on", "wait", "stop that", "abort", "silence")


def is_end_phrase(text: str) -> bool:
    """'goodbye', 'that's all', 'stop listening'... -- the user is leaving voice mode."""
    n = _norm(text)
    if not n or len(n.split()) > 8:
        return False
    return any(n == p or n.endswith(" " + p) or n.startswith(p + " ") or n == "thanks " + p for p in _END)


def is_stop_phrase(text: str) -> bool:
    """A short interruption: stop talking / cancel what you're doing."""
    n = _norm(text)
    n = re.sub(r"^((hey|ok|okay|please)\s+)*(troy\b[ ,]*)?", "", n).strip()
    n = re.sub(r"\s+please$", "", n).strip()
    if not n or len(n.split()) > 4:
        return False
    return n in _STOP


def looks_like_noise(text: str) -> bool:
    """Speech-to-text hallucinations on silence/noise ('you', 'thank you for watching', lone punctuation)."""
    n = _norm(text)
    if len(n) < 2:
        return True
    return n in {"you", "uh", "um", "hmm", "mm", "ah", "oh", "thank you for watching", "thanks for watching", "bye", "the", "i"}
