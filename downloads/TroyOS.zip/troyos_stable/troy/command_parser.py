"""
Troy Assistant - Command Parser

Parses Troy's raw LLM output into a list of (command_name, arg_string) tuples.
Troy is instructed to only output lines like:
    command_name
    command_name:argument

This parser is intentionally forgiving: it strips markdown fences/bullets,
ignores blank lines, and silently skips lines that don't look like a command
instead of crashing, so a slightly-misbehaving LLM doesn't break the whole loop.
"""

import re

# command names: lowercase letters and underscores only
_COMMAND_LINE_RE = re.compile(r"^\s*([a-z_]+)\s*(?::(.*))?\s*$")
# Defense in depth: llm_client already strips <think> blocks, but if a
# reasoning model ever slips one through anyway, don't let its scratchpad
# text get misread as command lines (or dumped verbatim as "speech" by the
# raw-text fallback in agent.py).
_THINK_BLOCK_RE = re.compile(r"<think>.*?</think>", re.IGNORECASE | re.DOTALL)
# Small/free models routinely forget the newline before `done` and glue it
# onto the end of the previous line instead -- e.g. `speak:Hey there. done`
# arrives as ONE line, so the whole thing (including " done") becomes the
# `speak` argument, and " done" ends up literally spoken/displayed. This
# matches a standalone trailing "done" (optional punctuation before it,
# preceded by at least one other character) and splits it back out into
# its own command.
_TRAILING_DONE_RE = re.compile(r"^(.*\S)\s+done[.!?]*\s*$", re.IGNORECASE)


def parse_commands(raw_text: str):
    """
    Returns a list of (command_name: str, arg: str) tuples, in order.
    `arg` is "" if the command had no argument.
    """
    commands = []
    if not raw_text:
        return commands

    # Strip common LLM formatting mistakes: reasoning blocks, code fences
    cleaned = _THINK_BLOCK_RE.sub("", raw_text)
    cleaned = cleaned.replace("```", "")

    for line in cleaned.splitlines():
        line = line.strip().lstrip("-*").strip()
        if not line:
            continue
        match = _COMMAND_LINE_RE.match(line)
        if not match:
            continue
        name, arg = match.group(1), match.group(2)
        commands.append((name, (arg or "").strip()))

    return _split_glued_done(commands)


def _split_glued_done(commands: list) -> list:
    fixed = []
    for name, arg in commands:
        if name != "done" and arg:
            match = _TRAILING_DONE_RE.match(arg)
            if match:
                fixed.append((name, match.group(1).strip()))
                fixed.append(("done", ""))
                continue
        fixed.append((name, arg))
    return fixed


def split_args(arg: str):
    """Splits a pipe-separated argument string into a list: 'a|b|c' -> ['a', 'b', 'c']"""
    if not arg:
        return []
    return [part.strip() for part in arg.split("|")]
