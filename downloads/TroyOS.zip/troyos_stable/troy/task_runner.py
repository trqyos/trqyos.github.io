"""
Carrying out one scheduled-task attempt.

The scheduler decides WHEN; this decides HOW. It uses the same TroyAgent and the same
tools as a normal chat turn -- nothing is re-implemented -- but in a fresh, isolated
conversation (so a task never reads from or writes into whatever chat is open) built
from the task's stored instruction:

    [SCHEDULED TASK] ... Task / Instruction / Attempt n of m
    ALREADY DONE in this run -- do not repeat ...      (from earlier attempts)
    Previous attempt failed: ... change something concrete   (when retrying)
    task_result:<done|retry|blocked>|<summary>         (how the model reports the outcome)

The outcome is taken from the model's own task_result report when there is one;
otherwise it is derived from what actually happened (see _derive).

Unattended means no Approve buttons: risky commands run only if they were
pre-approved for this task (troy/task_context.py); anything else is refused and
comes back as `needs_approval`.
"""

import threading
from datetime import datetime

from . import task_context
from .scheduler import Outcome

_STEP_LIMIT_NOTE = "(Reached the step limit"


def build_prompt(task: dict, run) -> str:
    """The single message the model is given for this attempt."""
    when = task.get("schedule_text") or ""
    lines = [
        "[SCHEDULED TASK -- an automatic run of something the user scheduled earlier. The user is not watching and cannot answer questions.]",
        f"Task: {task['title']}",
        f"Instruction: {task['prompt']}",
        f"Schedule: {when}. Now: {datetime.now().strftime('%a %b %d %Y %H:%M')}. Attempt {run.attempt} of {run.max_attempts}.",
    ]
    if run.done_actions:
        lines.append("ALREADY DONE in this run -- these succeeded earlier, do NOT do them again:")
        lines += [f"- {a['name']}{(':' + a['arg']) if a.get('arg') else ''} -> {a.get('message', 'OK')}" for a in run.done_actions[-12:]]
    if run.last_error:
        lines.append(f"The previous attempt failed: {run.last_error} Look at what actually went wrong and change something concrete instead of repeating the same step.")
    known = task.get("known_tools") or {}
    if known:
        lines.append("Extra tools this task has used before (exact usage): " + "; ".join(known.values())[:700])
    lines.append(
        "RULES: do exactly what the instruction says, nothing more. Never ask the user anything. Commands marked as needing approval only run if the user "
        "pre-approved them for this task; if one is refused, stop and report blocked. Do not schedule new tasks. "
        "Finish with task_result:<done|retry|blocked>|<one short sentence for the user>, then done. "
        "done = the instruction is fully carried out. retry = it failed in a way trying again may fix (app not ready, network down). "
        "blocked = it can't be done (missing permission, file, app or tool) so retrying won't help."
    )
    return "\n".join(lines)


class TaskRunner:
    """`agent_factory(on_speak=, on_state=, on_tool_result=)` makes a fresh agent; `turn_lock` is the host's
    lock that keeps a task from running at the same time as a chat turn (both drive the same PC)."""

    def __init__(self, agent_factory, turn_lock=None, on_state=None, on_step=None, info_names=frozenset(), restore_model=None):
        self.agent_factory = agent_factory
        self.turn_lock = turn_lock or threading.Lock()
        self.on_state = on_state or (lambda state, detail="": None)
        self.on_step = on_step or (lambda task_id, name, arg, ok, message: None)
        self.info_names = set(info_names)
        self.restore_model = restore_model      # callable(snapshot) / snapshot callable pair from the host (optional)

    def execute(self, task: dict, run) -> Outcome:
        ctx = task_context.RunContext(task["id"], grants=task.get("grants", []), attempt=run.attempt)
        results, spoken, states = [], [], []

        def on_tool(name, arg, ok, message):
            results.append({"name": name, "arg": arg, "ok": bool(ok), "message": str(message)})
            self.on_step(task["id"], name, arg, ok, str(message))
            if ok and name not in self.info_names and name not in ("task_result",):
                run.record_action(name, arg, str(message)[:200])

        def on_state(state, detail=""):
            states.append((state, detail))
            self.on_state(state, detail)

        agent = self.agent_factory(on_speak=lambda text: spoken.append(str(text)), on_state=on_state, on_tool_result=on_tool)
        prompt = build_prompt(task, run)
        snapshot = self.restore_model[0]() if self.restore_model else None
        try:
            with self.turn_lock:
                run.log(f"Running attempt {run.attempt}.", event="attempt")
                with task_context.activate(ctx):
                    agent.handle_user_input(prompt, source="task")
        except Exception as exc:  # noqa: BLE001
            return Outcome("retry", error=f"The agent crashed: {exc}", used_tools=_used(agent))
        finally:
            if snapshot is not None:
                try:
                    self.restore_model[1](snapshot)      # a task may have switched models: back to the user's choice
                except Exception:  # noqa: BLE001
                    pass
        return self._derive(ctx, results, spoken, states, agent)

    def _derive(self, ctx, results, spoken, states, agent) -> Outcome:
        used = _used(agent)
        last_state = next((s for s in reversed(states) if s[0] in ("stopped", "error")), None)
        if last_state and last_state[0] == "stopped":
            return Outcome("stopped", summary="Stopped before it finished.", error="Stopped by the user.", used_tools=used)
        if ctx.denied:
            cmds = ", ".join(ctx.denied)
            return Outcome("blocked", summary=f"Needs your approval to run unattended: {cmds}.",
                           error=f"Not pre-approved for unattended runs: {cmds}.", needs_approval=list(ctx.denied), used_tools=used)
        if ctx.reported:
            status, summary = ctx.reported
            return Outcome(status, summary=summary, error=summary, used_tools=used)
        if last_state and last_state[0] == "error":
            return Outcome("retry", error=(last_state[1] or "The model couldn't be reached.")[:300], used_tools=used)
        if any(s.startswith(_STEP_LIMIT_NOTE) for s in spoken):
            return Outcome("retry", error="Ran out of steps before finishing.", used_tools=used)

        # The model didn't report: judge by what happened.
        actions = [r for r in results if r["name"] not in self.info_names and r["name"] != "task_result"]
        if actions:
            if actions[-1]["ok"]:
                return Outcome("done", summary=(spoken[-1] if spoken else "Done."), used_tools=used)
            return Outcome("retry", error=f"{actions[-1]['name']} failed: {actions[-1]['message'][:200]}", used_tools=used)
        if spoken:       # an information-only task ("tell me the CPU load"): the answer is the result
            return Outcome("done", summary=spoken[-1], used_tools=used)
        return Outcome("retry", error="The run ended without doing or reporting anything.", used_tools=used)


def _used(agent) -> dict:
    try:
        return dict(agent.extra_tools_used())
    except Exception:  # noqa: BLE001 - the agent may be a test double
        return {}
