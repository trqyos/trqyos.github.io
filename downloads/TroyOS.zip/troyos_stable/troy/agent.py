"""
Troy Assistant - Core Agent Loop

For each user turn:
  1. Send the conversation + system prompt to the LLM.
  2. Parse the response into a list of commands.
  3. Execute each command in order:
       - `speak` commands are spoken/printed to the user immediately.
       - other commands run and their result becomes an [OBSERVATION].
       - `done` ends the turn.
  4. If the turn wasn't ended with `done`, loop back to step 1 so Troy can
     react to the observations it just received -- this is what gives Troy
     "vision through system feedback": it sees the outcome of its own
     actions before deciding what to do next.
  5. Stop after MAX_STEPS_PER_TURN loops as a safety net against runaway loops.

Force-stop: at the top of every step and before every individual command,
the loop checks stop_control.stop_controller. If it's set, the turn ends
immediately -- this is on top of llm_client.chat() itself aborting
mid-stream, so a press of the UI's Force Stop button interrupts Troy
whether it's currently generating text or already executing commands.
"""

from . import config, dispatcher, extra_tools, llm_client, memory, stop_control, tool_history, tools_all
from .command_parser import parse_commands
from .native_loop import NativeLoopMixin
from .dispatcher import INFO_COMMANDS
from .llm_client import LLMError, StoppedByUser
from .logger import logger
from . import system_prompt


class TroyAgent(NativeLoopMixin):
    def __init__(self, on_speak=print, on_state=None, on_tool_result=None):
        """
        on_speak: callback invoked with (text: str) whenever Troy wants to talk.
                  Defaults to `print`.
        on_state: optional callback invoked with (state: str, detail: str) as Troy
                  moves through "thinking" -> "executing" -> "speaking" -> "idle"
                  (or "error"/"stopped"). Drives UI status indicators. Purely
                  cosmetic -- safe to leave as None for headless/console use.
        on_tool_result: optional callback invoked with (name: str, arg: str,
                  success: bool, message: str) after every non-speak/non-done
                  command finishes. Drives the UI's tool-call labels so tool
                  use is visible, not just narrated in speech.
        """
        self.on_speak = on_speak
        self.on_state = on_state or (lambda state, detail="": None)
        self.on_tool_result = on_tool_result or (lambda name, arg, success, message: None)
        self.voice_style = False            # True while the user is talking to Troy by voice
        self.voice_forced = False           # set by voice mode so typed turns during it are spoken-style too
        self._native_active = False         # True while a request runs with native function calling (see native_loop.py)
        self._toolbox = None
        self._prompt_mode_in_use = self._prompt_mode()
        self._extra = extra_tools.begin(lambda: self.messages)   # what the model has been shown / has used in this request
        self._extra_used_last = {}
        self.messages = [
            {"role": "system", "content": system_prompt.build_system_prompt(self._prompt_mode_in_use)},
            self._build_memory_message(),
            self._build_context_message(),
        ]

    # ------------------------------------------------------------------
    # Prompt size. A 9k-token prompt made every reply slow, tripped Groq's
    # 8000-token-per-minute cap, and could not fit a local model's window.
    # ------------------------------------------------------------------
    def _prompt_mode(self) -> str:
        mode = config.PROMPT_MODE
        if mode in ("compact", "tiny", "detailed"):
            return mode
        # auto: a small local context window needs the tiny prompt
        if config.PRIMARY_PROVIDER == "lmstudio" and config.LMSTUDIO_ENABLED:
            try:
                if llm_client.lmstudio_context() <= 6144:
                    return "tiny"
            except Exception:  # noqa: BLE001 - never block a turn on discovery
                return "tiny"
        return "compact"

    def refresh_system_prompt(self):
        """Rebuilt each turn (cheap) so a changed name, provider or prompt
        setting applies immediately, without restarting the app."""
        mode = self._prompt_mode()
        self._prompt_mode_in_use = mode
        if self._native_active:
            content = system_prompt.build_native_prompt(tiny=(mode == "tiny"))
        else:
            content = system_prompt.build_system_prompt(mode)
        self.messages[0] = {"role": "system", "content": content}

    def _build_memory_message(self) -> dict:
        """
        This is what actually makes memory 'work': instead of hoping the model
        proactively calls `recall`, every stored fact is handed to it up front
        as part of the system context, the same way you don't have to
        consciously "recall" your own name. Rebuilt fresh each turn so facts
        added mid-conversation (or via the memory endpoints) show up
        immediately without needing a restart.
        """
        entries = memory.recent_memories()
        if not entries:
            facts_text = "(nothing remembered yet)"
        else:
            facts_text = "\n".join(f"- {e['fact']}" for e in entries)
        return {
            "role": "system",
            "content": (
                "Long-term memory: things you already know about the user from "
                "past sessions, oldest first.\n" + facts_text
            ),
        }

    def _build_context_message(self, user_text: str = "") -> dict:
        """
        CONTEXT AWARENESS: a live situational snapshot (time, active window,
        open-window count, CPU/RAM, web-research-browser state), rebuilt
        fresh at the start of every turn so Troy is never reasoning from a
        stale or nonexistent picture of "what's actually happening right
        now". This is the exact same data get_context returns on demand
        (see tools_all.get_context_snapshot) -- handing it over automatically
        here means Troy doesn't need to spend a round-trip on it just to
        get oriented at the start of an ordinary turn. Wrapped defensively:
        a snapshot failure must never block the turn from starting.
        """
        try:
            snapshot = tools_all.get_context_snapshot()
            detail = snapshot.get("message", "(unavailable)")
        except Exception as exc:  # noqa: BLE001 - must never block a turn from starting
            logger.warning("Situational context snapshot failed: %s", exc)
            detail = "(unavailable)"
        content = "Situational context (live, refreshed every turn): " + detail
        hint = ""
        if not self._native_active:        # native mode loads the matching tools themselves (tool_schema.Toolbox)
            try:
                hint = system_prompt.relevant_tools_hint(user_text, limit=4 if self._prompt_mode_in_use == "tiny" else 5)
            except Exception:  # noqa: BLE001 - hints are a nicety
                hint = ""
        if hint:
            content += "\nLikely relevant tools (exact usage):\n" + hint
        if self.voice_style and config.VOICE_SPOKEN_STYLE and self._native_active:
            content += ("\nVOICE: the user is talking to you by voice and everything you say is read aloud. Keep each reply to one or two short, "
                        "natural sentences: no lists, markdown, links or file paths; say numbers the way a person would; do the work first, then "
                        "summarise. A quick acknowledgement like \"On it.\" before a long task is good.")
        elif self.voice_style and config.VOICE_SPOKEN_STYLE:
            content += ("\nVOICE: the user is talking to you by voice and every speak: line is read aloud. Keep each speak: to one or two short, "
                        "natural sentences: no lists, markdown, links or file paths; say numbers the way a person would; do the work first, then "
                        "summarise. A quick acknowledgement like speak:On it. before a long task is good.")
        return {"role": "system", "content": content}

    def refresh_memory_context(self):
        """Call after memory changes outside a normal turn (e.g. the
        memory endpoints adding/deleting/clearing facts directly) so the
        next turn sees it."""
        self.messages[1] = self._build_memory_message()

    def refresh_situational_context(self, user_text: str = ""):
        """Rebuilds the live situational-context message. Called
        automatically at the top of every turn (with the user's message, so
        the tools it mentions can be described in full); also safe to call on
        demand (e.g. a frontend's "refresh context" action) between turns."""
        self.messages[2] = self._build_context_message(user_text)

    def load_history(self, history: list):
        """Restores a previous session's conversation. `history` is whatever
        export_history() returned earlier -- everything after the three
        fixed system messages. Memory and situational context are both
        refreshed at the same time since either may have changed since
        this session was last active."""
        self.refresh_memory_context()
        self.refresh_situational_context()
        self.messages = self.messages[:3] + list(history)

    def export_history(self) -> list:
        """Everything except the three fixed system messages (system
        prompt, memory context, situational context) -- these are rebuilt
        fresh on load, only the actual conversation needs to be persisted
        per-session."""
        return self.messages[3:]

    def handle_user_input(self, user_text: str, source: str = "typed"):
        """
        source: "typed" for text the user typed directly.
        """
        stop_control.stop_controller.clear()  # a stop from a previous turn must not carry over
        self.voice_style = bool(self.voice_forced or str(source).startswith(("voice", "phone")))
        self._extra = extra_tools.begin(lambda: self.messages)   # a new request: nothing extra shown yet
        self._begin_request(user_text)
        self.refresh_system_prompt()
        self.refresh_memory_context()
        self.refresh_situational_context(user_text)
        self.messages.append({"role": "user", "content": user_text})
        logger.info("User turn (%s): %s", source, user_text)
        self._run_step_loop()

    def resume_with_observation(self, observation_text: str):
        """
        Continues the conversation with a system-generated observation
        instead of something the user typed -- used when a pending
        confirmation (troy/confirmation.py) resolves. That happens on its
        own timeline, outside any normal turn (the model already ended its
        turn with `done` when it issued the risky command), so this is
        the resumption path back into the same step loop: the result is
        appended exactly like a normal [OBSERVATION] and Troy gets to
        react to it -- report success, try a follow-up, whatever's next.
        Does NOT clear stop_control (a stop should still apply) and does
        NOT refresh memory/context (those are per-turn, and this isn't a
        new turn from the user's point of view).
        """
        self._begin_request("")
        if self._native_active:
            # the [OBSERVATION] form belongs to the text protocol (and is dropped from native history): say it as a system note
            observation_text = "[SYSTEM] Result of the action the user approved: " + observation_text.replace("[OBSERVATION] ", "", 1)
        self.refresh_system_prompt()
        self.messages.append({"role": "user", "content": observation_text})
        logger.info("Resuming after external event: %s", observation_text)
        self._run_step_loop()

    def _begin_request(self, user_text: str):
        """Chooses native function calling or the text protocol for this request and gets the history into that form."""
        self._start_native_request(user_text)
        if not self._native_active and any(tool_history.is_native(m) for m in self.messages[3:]):
            self.messages[3:] = tool_history.to_text(self.messages[3:])      # the model was switched to one without tool calling

    def _early_speak(self, early: dict, text: str):
        """Speaks the opening `speak:` lines of a reply AS THEY STREAM IN, instead
        of after the whole reply has arrived: with "speak:On it." as the first
        line, Troy starts talking about a second sooner. Only complete lines
        before the first non-speak command are used, so nothing is ever said
        that the full parse wouldn't also have said; the main loop then skips
        the lines already spoken."""
        if text == "":                                    # a new attempt (another model): start over
            early["pos"], early["blocked"] = 0, False
            return
        if early["blocked"] or "<think" in text.lower():
            early["blocked"] = True
            return
        while True:
            nl = text.find("\n", early["pos"])
            if nl < 0:
                return
            line = text[early["pos"]:nl].strip()
            early["pos"] = nl + 1
            if not line:
                continue
            if line.lower().startswith("speak:"):
                spoken = line[6:].strip()
                if spoken and spoken not in early["spoken"]:
                    self.on_state("speaking")
                    self.on_speak(spoken)
                    early["spoken"].append(spoken)
            else:
                early["blocked"] = True
                return

    def _prune_history(self, keep: int = 60):
        """Bounds memory use: only the newest `keep` conversation messages are
        retained (the model never saw more than a token-budget's worth anyway)."""
        if len(self.messages) > 3 + keep:
            self.messages = self.messages[:3] + self.messages[-keep:]
            while len(self.messages) > 4 and self.messages[3].get("role") != "user":
                del self.messages[3]

    def note_event(self, text: str):
        """Adds a system note to the conversation (a scheduled task reporting back) so a follow-up like
        "did that work?" has the answer. Only call between turns."""
        self.messages.append({"role": "user", "content": f"[SYSTEM] {text}"})

    def extra_tools_used(self) -> dict:
        """Extra tools (not in the prompt) the last request actually used: name -> usage line."""
        return dict(self._extra_used_last)

    def _run_step_loop(self):
        try:
            if self._native_active:
                with extra_tools.activate(None):        # the gate / list_extra_tools machinery belongs to the text protocol
                    outcome = self._run_native_loop()
                if outcome == "fallback":
                    self._switch_to_text()
                    with extra_tools.activate(self._extra):
                        self._run_step_loop_inner()
            else:
                with extra_tools.activate(self._extra):
                    self._run_step_loop_inner()
        finally:
            # Request over: forget the extra-tool lists it was shown, keeping only the usage of what it used.
            self._extra_used_last = dict(self._extra.used)
            try:
                extra_tools.collapse(self.messages, self._extra)
            except Exception as exc:  # noqa: BLE001 - tidying history must never break a turn
                logger.warning("Couldn't trim the extra tool list: %s", exc)
            self._extra.revealed.clear()
            self._extra.used.clear()
            self._prune_history()

    def _run_step_loop_inner(self):
        self._brain_seen = (config.PRIMARY_PROVIDER, config.TEXT_MODEL_OVERRIDE)

        try:
            for step_index in range(config.MAX_STEPS_PER_TURN):
                if (config.PRIMARY_PROVIDER, config.TEXT_MODEL_OVERRIDE) != self._brain_seen:
                    self._brain_seen = (config.PRIMARY_PROVIDER, config.TEXT_MODEL_OVERRIDE)
                    self.refresh_system_prompt()          # Troy switched models mid-turn: size the prompt to the new one
                if stop_control.stop_controller.is_stopped():
                    self._handle_stop()
                    return

                self.on_state("thinking")
                early = {"pos": 0, "spoken": [], "blocked": False}
                try:
                    raw_response = llm_client.chat(
                        self.messages, stop_check=stop_control.stop_controller.is_stopped,
                        on_text=lambda text, early=early: self._early_speak(early, text),
                    )
                except StoppedByUser:
                    self.messages.pop()  # drop the user turn so it isn't silently retried later
                    self._handle_stop()
                    return
                except LLMError as exc:
                    # Don't crash the whole assistant over an API/model problem --
                    # surface it, drop the failed user turn so it isn't retried
                    # forever, and let the user try again.
                    self.messages.pop()
                    logger.error("LLM call failed: %s", exc)
                    self.on_state("error", str(exc))
                    self.on_speak(f"(Troy couldn't reach any model right now.)\n{exc}")
                    return

                self.messages.append({"role": "assistant", "content": raw_response})

                commands = parse_commands(raw_response)
                if not commands:
                    # LLM didn't follow the command format -- treat raw text as speech
                    # rather than silently dropping it.
                    self.on_state("speaking")
                    self.on_speak(raw_response.strip())
                    return

                observations = []
                done_requested = False
                saw_info_command = False
                stopped_mid_batch = False

                for name, arg in commands:
                    if stop_control.stop_controller.is_stopped():
                        stopped_mid_batch = True
                        break

                    if name == "speak" and early["spoken"] and arg.strip() == early["spoken"][0]:
                        early["spoken"].pop(0)           # already said while the reply was still streaming
                        continue

                    if name == "speak":
                        self.on_state("speaking")
                    elif name != "done":
                        self.on_state("executing", name)

                    result = dispatcher.execute(name, arg)

                    if result.get("is_speech"):
                        self.on_speak(result["message"])
                        continue

                    if result.get("is_done"):
                        done_requested = True
                        continue

                    success = result.get("success", False)
                    message = result.get("message", "")
                    logger.info("Command %s:%s -> %s - %s", name, arg, "OK" if success else "FAILED", message)
                    self.on_tool_result(name, arg, success, result.get("ui_message") or message)   # the UI gets a short line for long lists

                    status = "OK" if success else "FAILED"
                    message = str(message)
                    if len(message) > config.OBSERVATION_MAX_CHARS and not result.get("full"):
                        message = message[:config.OBSERVATION_MAX_CHARS] + f" ...[{len(message) - config.OBSERVATION_MAX_CHARS} more characters not shown]"
                    observations.append(f"[OBSERVATION] {name}:{arg[:200]} -> {status} - {message}")
                    if name in INFO_COMMANDS or result.get("needs_followup"):
                        saw_info_command = True

                if stopped_mid_batch:
                    if observations:
                        observations.append("[OBSERVATION] Remaining commands in this batch were skipped -- stopped by user.")
                        self.messages.append({"role": "user", "content": "\n".join(observations)})
                    self._handle_stop()
                    return

                # THE FIX: models routinely bundle `done` in the same
                # response as an information-gathering command like
                # `screenshot` or `list_dir` (their prompt says "always end
                # with done", so they do -- out of habit, before they've
                # actually seen the result). Honoring `done` here would
                # throw away the observation the WHOLE POINT of that
                # command was to get: the screenshot would be taken, sent
                # to the vision model, described -- and then silently
                # discarded, with Troy never reacting to what it saw.
                # So: if this batch produced an info-command observation,
                # that `done` is treated as premature and ignored -- the
                # observation goes back to the model for one more round so
                # it can actually act on what it just learned. `done` is
                # still honored immediately for ordinary action commands
                # (open_app, click, type_text, ...), where the model isn't
                # waiting to see anything and an extra round trip would
                # just be needless latency.
                if done_requested and not (observations and saw_info_command):
                    return

                # FEEDBACK: direct, first-person signal about the turn's own
                # progress (distinct from anything the user said), so the
                # model can react to running low on steps instead of being
                # silently cut off by the step limit below with no warning.
                steps_left = config.MAX_STEPS_PER_TURN - step_index - 1
                if 0 < steps_left <= 3:
                    observations.append(
                        f"[SYSTEM] Heads up: {steps_left} step(s) left in this turn "
                        "before the step limit -- wrap up soon: verify the result if "
                        "you haven't, then speak: the outcome (or the honest blocker) "
                        "and done. Don't start a new multi-step sub-task now."
                    )

                if observations:
                    self.messages.append({"role": "user", "content": "\n".join(observations)})
                else:
                    # No observations and no `done` -- avoid looping forever on nothing
                    return

            self.on_speak("(Reached the step limit for this turn.)")
        finally:
            self.on_state("idle")

    def _handle_stop(self):
        logger.info("Turn stopped by user (force stop).")
        self.on_state("stopped")
        self.on_speak("(Stopped.)")
