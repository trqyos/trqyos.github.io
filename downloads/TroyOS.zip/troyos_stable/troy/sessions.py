"""
Troy Assistant - Sessions

Each session is one saved conversation: what Troy actually remembers of the
exchange (agent_history, fed back to the LLM) plus what the UI displays
(display_log, the chat-bubble transcript). Stored as one JSON file per
session under troy_sessions/. Deliberately simple -- flat files, no
database -- this is a single-user local assistant, not a multi-tenant app.
"""

import json
import os
import threading
from datetime import datetime

from . import config

# Read-modify-write helpers below (link_task, append_entries) can be called from a task
# thread while the chat autosaves; one lock keeps those writes from interleaving.
_lock = threading.RLock()


def _path(session_id: str) -> str:
    return os.path.join(config.SESSIONS_DIR, f"{session_id}.json")


def _ensure_dir():
    os.makedirs(config.SESSIONS_DIR, exist_ok=True)


def _read(session_id: str):
    path = _path(session_id)
    if not os.path.exists(path):
        return None
    with open(path, "r", encoding="utf-8") as f:
        try:
            return json.load(f)
        except json.JSONDecodeError:
            return None


def _write(session_id: str, data: dict):
    _ensure_dir()
    with open(_path(session_id), "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)


def create_session(title: str = None) -> str:
    _ensure_dir()
    session_id = datetime.now().strftime("%Y%m%d%H%M%S%f")
    now = datetime.now().isoformat(timespec="seconds")
    data = {
        "id": session_id,
        "title": title or f"Session {datetime.now().strftime('%b %d, %H:%M')}",
        "created_at": now,
        "updated_at": now,
        "agent_history": [],
        "display_log": [],
    }
    _write(session_id, data)
    return session_id


def save_session(session_id: str, title: str, agent_history: list, display_log: list):
    with _lock:
        data = _read(session_id) or {"id": session_id, "created_at": datetime.now().isoformat(timespec="seconds")}
        data["title"] = title
        data["agent_history"] = agent_history
        data["display_log"] = display_log
        data["updated_at"] = datetime.now().isoformat(timespec="seconds")
        _write(session_id, data)


def link_task(session_id: str, task_id: str) -> bool:
    """Remembers that this chat created a scheduled task (the sidebar marks such chats with a task icon).
    Other fields -- including this one -- survive save_session, which only touches what it owns."""
    if not session_id:
        return False
    with _lock:
        data = _read(session_id)
        if data is None:
            return False
        ids = data.setdefault("task_ids", [])
        if task_id not in ids:
            ids.append(task_id)
            _write(session_id, data)
        return True


def append_entries(session_id: str, display_entry: dict = None, agent_message: dict = None) -> bool:
    """Adds a note to a saved chat that is NOT the one currently open (e.g. a task reporting back):
    one entry for what the person reads, one for what the model remembers."""
    with _lock:
        data = _read(session_id)
        if data is None:
            return False
        if display_entry:
            data.setdefault("display_log", []).append(display_entry)
        if agent_message:
            data.setdefault("agent_history", []).append(agent_message)
        data["updated_at"] = datetime.now().isoformat(timespec="seconds")
        _write(session_id, data)
        return True


def exists(session_id: str) -> bool:
    return bool(session_id) and os.path.exists(_path(session_id))


def load_session(session_id: str):
    """Returns the full session dict, or None if it doesn't exist (e.g. was deleted)."""
    return _read(session_id)


def list_sessions() -> list:
    """Returns [{"id", "title", "updated_at", "has_tasks", "task_count"}, ...], most recently updated first."""
    _ensure_dir()
    sessions = []
    for filename in os.listdir(config.SESSIONS_DIR):
        if not filename.endswith(".json"):
            continue
        data = _read(filename[:-5])
        if data:
            sessions.append({
                "id": data.get("id", filename[:-5]),
                "title": data.get("title", "Untitled"),
                "updated_at": data.get("updated_at", ""),
                "has_tasks": bool(data.get("task_ids")),
                "task_count": len(data.get("task_ids") or []),
            })
    sessions.sort(key=lambda s: s["updated_at"], reverse=True)
    return sessions


def rename_session(session_id: str, new_title: str) -> bool:
    data = _read(session_id)
    if not data:
        return False
    data["title"] = new_title
    _write(session_id, data)
    return True


def delete_session(session_id: str) -> bool:
    path = _path(session_id)
    if os.path.exists(path):
        os.remove(path)
        return True
    return False


def most_recent_session_id():
    sessions = list_sessions()
    return sessions[0]["id"] if sessions else None


# ---------------------------------------------------------------- search
import unicodedata

_search_cache = {}      # session id -> (file mtime, searchable entries)


def _fold(text: str) -> str:
    """Case- and accent-insensitive form: 'Caf\u00e9' matches 'cafe'."""
    return "".join(c for c in unicodedata.normalize("NFKD", str(text).casefold()) if not unicodedata.combining(c))


def _entries_for(session_id: str, data: dict):
    path = _path(session_id)
    try:
        st = os.stat(path)
        mtime, size = st.st_mtime_ns, st.st_size
    except OSError:
        return []
    cached = _search_cache.get(session_id)
    if cached and cached[0] == mtime and cached[1] == size:
        return cached[2]
    entries = []
    for index, e in enumerate(data.get("display_log", [])):
        role = e.get("role")
        if role in ("user", "assistant"):
            text = e.get("text", "")
        elif role == "tool":
            text = f"{e.get('name', '')} {e.get('arg', '')} {e.get('message', '')}"
        else:
            continue
        if text.strip():
            entries.append((index, role, text, _fold(text)))
    _search_cache[session_id] = (mtime, size, entries)
    return entries


def _snippet(text: str, start: int, length: int, radius: int = 60):
    a, b = max(0, start - radius), min(len(text), start + length + radius)
    flat = text[a:b].replace("\n", " ")
    lead = start - a
    return ("\u2026" if a else "") + flat + ("\u2026" if b < len(text) else ""), lead + (1 if a else 0), length


def search_sessions(query: str, limit: int = 30, per_chat: int = 3) -> dict:
    """Finds chats whose TITLE or MESSAGES contain every word of `query`.

    Returns {"results": [{id, title, updated_at, title_match, hit_count,
    hits: [{index, role, snippet, start, length}]}], "total_chats": n}.
    `index` is the message's position in that chat's display_log, which is
    what lets a UI open the chat and scroll straight to it. Title matches come
    first, then chats with the most message hits, then the most recent."""
    words = [w for w in _fold(query).split() if w]
    if not words:
        return {"results": [], "total_chats": 0}
    _ensure_dir()
    results = []
    for filename in os.listdir(config.SESSIONS_DIR):
        if not filename.endswith(".json"):
            continue
        sid = filename[:-5]
        data = _read(sid)
        if not data:
            continue
        title = data.get("title", "Untitled")
        folded_title = _fold(title)
        title_match = all(w in folded_title for w in words)
        hits, count = [], 0
        for index, role, text, folded in _entries_for(sid, data):
            if all(w in folded for w in words):
                count += 1
                if len(hits) < per_chat:
                    pos = min((folded.find(w) for w in words if folded.find(w) >= 0), default=0)
                    snip, start, length = _snippet(text, pos, len(words[0]))
                    hits.append({"index": index, "role": role, "snippet": snip, "start": start, "length": length})
        if title_match or count:
            results.append({"id": data.get("id", sid), "title": title, "updated_at": data.get("updated_at", ""),
                            "title_match": title_match, "hit_count": count, "hits": hits})
    results.sort(key=lambda r: (not r["title_match"], -r["hit_count"], ""), reverse=False)
    results.sort(key=lambda r: r["updated_at"], reverse=True)
    results.sort(key=lambda r: (not r["title_match"], -r["hit_count"]))
    return {"results": results[:limit], "total_chats": len(results)}
