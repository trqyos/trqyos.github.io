"""
A self-signed TLS certificate for the phone page.

Browsers only allow getUserMedia (the phone's microphone) on a "secure
context": https://, or http://localhost. The real phone page is served over
plain Wi-Fi http, so Troy also serves the exact same page over https on
MOBILE_UI_PORT + 1 -- using the certificate generated here.

The first time it's needed, a key + cert pair is written next to the project
root (troy_key.pem / troy_cert.pem) and reused forever after. SANs cover
localhost, the machine's hostname and its LAN IP, so no "name mismatch"
warnings for the ways the phone can reach the PC. The browser will still show
a "not trusted" warning once (it IS self-signed) -- that's the one-tap
"proceed anyway" price of no certificate authority, and Tailscale HTTPS (a
real LetsEncrypt cert, see troy/remote.py) is there when you want zero
warnings.

Everything degrades: no `cryptography` package -> (None, None) and a clear
log line, and the https server simply doesn't start; the http page keeps
working (just without the microphone).
"""

import datetime
import ipaddress
import os
import socket
import ssl

from . import config
from .logger import logger

CERT_FILE = os.path.join(config.PROJECT_ROOT, "troy_cert.pem")
KEY_FILE = os.path.join(config.PROJECT_ROOT, "troy_key.pem")
YEARS = 10


def _subject_alt_names(lan_ip: str) -> list:
    """x509 GeneralName objects (NOT strings): localhost, the hostname, the
    LAN IP and 127.0.0.1 -- every way the phone can reach this PC."""
    from cryptography import x509
    names = [x509.DNSName("localhost"), x509.DNSName(socket.gethostname() or "localhost")]
    try:
        names.append(x509.IPAddress(ipaddress.ip_address((lan_ip or "").strip())))
    except ValueError:                                  # no / bad LAN IP -- the DNS names still work
        pass
    names.append(x509.IPAddress(ipaddress.ip_address("127.0.0.1")))
    return names


def generate(cert_path: str, key_path: str, lan_ip: str) -> None:
    """Makes one self-signed cert covering localhost, the hostname and the LAN IP."""
    from cryptography import x509
    from cryptography.hazmat.primitives import hashes, serialization
    from cryptography.hazmat.primitives.asymmetric import rsa
    from cryptography.x509.oid import NameOID

    key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
    subject = x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, "TroyOS phone page")])
    now = datetime.datetime.now(datetime.timezone.utc)
    builder = (x509.CertificateBuilder()
               .subject_name(subject).issuer_name(subject)
               .public_key(key.public_key())
               .serial_number(x509.random_serial_number())
               .not_valid_before(now - datetime.timedelta(days=1))
               .not_valid_after(now + datetime.timedelta(days=365 * YEARS))
               .add_extension(x509.SubjectAlternativeName(_subject_alt_names(lan_ip)), critical=False))
    cert = builder.sign(key, hashes.SHA256())
    with open(key_path, "wb") as f:
        f.write(key.private_bytes(serialization.Encoding.PEM, serialization.PrivateFormat.TraditionalOpenSSL,
                                  serialization.NoEncryption()))
    os.chmod(key_path, 0o600)
    with open(cert_path, "wb") as f:
        f.write(cert.public_bytes(serialization.Encoding.PEM))
    logger.info("Generated a self-signed certificate for the phone page (%s).", cert_path)


def ensure_pair(lan_ip: str = None) -> tuple:
    """-> (cert_path, key_path), generating on first use; (None, None) when the
    `cryptography` package isn't installed or the pair can't be created."""
    from . import mobile_server
    lan_ip = lan_ip or mobile_server.lan_ip()
    try:
        if not (os.path.exists(CERT_FILE) and os.path.exists(KEY_FILE)):
            generate(CERT_FILE, KEY_FILE, lan_ip)
        return CERT_FILE, KEY_FILE
    except ImportError:
        logger.warning("HTTPS for the phone needs the 'cryptography' package: pip install cryptography "
                       "(the phone page stays http-only; the microphone then needs Tailscale HTTPS).")
    except Exception as exc:  # noqa: BLE001 - no cert must never stop the http page
        logger.warning("Couldn't create the phone HTTPS certificate: %s", exc)
    return None, None


def ssl_context(lan_ip: str = None) -> ssl.SSLContext:
    """A ready server-side TLS context, or None when unavailable."""
    cert, key = ensure_pair(lan_ip)
    if not cert:
        return None
    try:
        ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
        ctx.load_cert_chain(cert, key)
        return ctx
    except Exception as exc:  # noqa: BLE001
        logger.warning("Couldn't load the phone HTTPS certificate: %s", exc)
        return None
