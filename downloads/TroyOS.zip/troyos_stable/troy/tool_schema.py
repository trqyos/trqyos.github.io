"""
Native function calling, part 1: tool definitions.

Troy's tools were written for a text protocol: every tool takes ONE string (`name:arg|arg|arg`).
Native function calling needs, for each tool, a JSON schema (named, typed parameters) that goes
to the model in the API's `tools` field, and the model answers with structured arguments instead
of text that has to be parsed.

This module is the bridge. It does NOT re-implement any tool:

    schema_for(name)          -> {"type": "function", "function": {name, description, parameters}}
    coerce_args(name, args)   -> validated {param: str} dict, or a ToolArgError the model can read
    to_arg_string(name, args) -> the exact `a|b|c` string the existing tool function already takes

So every safety layer (confirmation, scheduled-task grants, stop control, the dispatcher) keeps
working unchanged: a native call is turned into the same (name, arg) pair a text call would give.

Where the schemas come from:
  1. BUILTINS -- the commands the dispatcher handles itself (open_app, click, ...), written by hand.
  2. OVERRIDES -- registry tools whose arg_hint is too odd to derive (enums, "x,y" pairs, lists).
  3. everything else -- derived from `arg_hint`: `<a>|<b>[|<c>]` -> params a, b (required), c (optional);
     `<name=default>` -> optional; `<x>,<y>` -> two params joined with a comma.
A test checks that EVERY registered tool produces a valid schema, so a new tool can't silently
ship without one.
"""
import re
from dataclasses import dataclass, field

from . import tools_all

# Tools that exist only for the text protocol; native mode replaces them (find_tools / the schema itself).
TEXT_ONLY = frozenset({"speak", "done", "list_extra_tools", "list_tools", "tool_help"})

FIND_TOOLS = "find_tools"


class ToolArgError(ValueError):
    """The model's arguments don't fit the tool. The message is written for the model to read and fix."""


@dataclass
class Param:
    name: str
    type: str = "string"            # string | integer | number | boolean
    desc: str = ""
    required: bool = True
    enum: tuple = ()
    default: str = ""


@dataclass
class Spec:
    name: str
    description: str
    params: list = field(default_factory=list)
    template: str = ""              # how to join params into the legacy arg string, e.g. "{x},{y}"; "" = join with "|"
    approval: bool = False
    info: bool = False


def P(name, desc="", type="string", required=True, enum=(), default=""):
    return Param(name, type, desc, required, tuple(enum), default)


# ---------------------------------------------------------------- hand-written: built-in commands
# (these never went through the registry: dispatcher.execute handles them directly)
_B = {}


def _b(name, description, *params, template="", info=False):
    _B[name] = Spec(name, description, list(params), template, False, info)


_b("open_app", "Opens an application by name on the user's PC (visible, the user's own).", P("name", "app name, e.g. firefox, notepad, spotify"))
_b("close_active_window", "Closes the focused window (Alt+F4).")
_b("minimize_window", "Minimizes the focused window.")
_b("maximize_window", "Maximizes the focused window.")
_b("switch_window", "Opens the Alt+Tab window switcher.")
_b("open_url", "Opens a URL in the user's own browser.", P("url"))
_b("search_newtab", "Searches the web in a new tab of the user's own browser.", P("query"))
_b("type_text", "Types text into whatever has keyboard focus.", P("text"))
_b("press_key", "Presses one key (enter, tab, esc, f5, ...).", P("key"))
_b("hotkey", "Presses a key combination, keys joined with +.", P("keys", "e.g. ctrl+c or alt+tab"))
_b("click", "Clicks at screen pixel coordinates.", P("x", type="integer"), P("y", type="integer"), template="{x},{y}")
_b("move_mouse", "Moves the pointer to screen pixel coordinates.", P("x", type="integer"), P("y", type="integer"), template="{x},{y}")
_b("scroll", "Scrolls the mouse wheel; positive = up, negative = down.", P("amount", type="integer"))
_b("click_target", "Finds something on screen from a description (screenshot + vision) and clicks it.", P("description", "what to click, e.g. 'the blue Save button'"))
_b("locate_on_screen", "Returns the pixel position of something on screen, from a description.", P("description"), info=True)
_b("screenshot", "Takes a screenshot and describes what is on screen.", info=True)
_b("read_screen_text", "Reads the text visible on screen (OCR).", info=True)
_b("get_active_window", "Title and process of the focused window.", info=True)
_b("list_windows", "Lists open windows.", info=True)
_b("window_exists", "Is a window with this title open?", P("query", "part of the window title"), info=True)
_b("get_context", "Live snapshot: time, active window, CPU/RAM.", info=True)
_b("get_time", "Current date and time.", info=True)
_b("get_system_stats", "CPU, RAM and battery usage.", info=True)
_b("get_storage_info", "Disk space.", info=True)
_b("get_media_info", "What media is playing right now.", info=True)
_b("list_processes", "Lists running processes.", info=True)
_b("kill_process", "Ends a process by name (the user sees an approval card first if it is risky).", P("name"))
_b("get_weather", "Current weather for a place.", P("place"), info=True)
_b("create_file", "Creates (or overwrites) a text file.", P("path"), P("content", required=False))
_b("move_file", "Moves a file or folder.", P("source"), P("destination"))
_b("copy_file", "Copies a file or folder.", P("source"), P("destination"))
_b("read_file", "Reads a text file.", P("path"), info=True)
_b("find_files", "Finds files by name pattern under a folder.", P("pattern"), P("root", "folder to search; default: the user's home", required=False), info=True)
_b("list_dir", "Lists a folder's contents.", P("path"), info=True)
_b("get_clipboard", "Reads the clipboard text.", info=True)
_b("set_clipboard", "Puts text on the clipboard.", P("text"))
_b("play_audio", "Toggles media play/pause.")
_b("pause_audio", "Toggles media play/pause.")
_b("volume_up", "Raises the system volume.")
_b("volume_down", "Lowers the system volume.")
_b("volume_mute", "Mutes or unmutes the system volume.")
_b("wait", "Waits a number of seconds.", P("seconds", type="number"))
_b("remember", "Stores a lasting fact about the user or their preferences.", P("fact"))
_b("recall", "Searches what Troy remembers.", P("query", required=False), info=True)
_b("escalate", "Last resort: asks a bigger model for help when stuck.", P("request"), P("task", required=False),
   P("tried", required=False), P("error", required=False), P("reason", required=False))

# Explicit schemas for registry tools whose arg_hint can't be derived reliably.
_O = {}


def _o(name, *params, template="", description=""):
    _O[name] = (list(params), template, description)


_o("schedule_task", P("when", "natural language: 'in 30 minutes', 'tomorrow at 9am', 'every Monday and Friday at 22:00', 'October 25 2026 at 14:30'"),
   P("instruction", "a short imperative for your future self, e.g. 'Put the computer to sleep.'"), P("title", required=False),
   P("approve", "commands that need approval to run unattended, separated by ';' (e.g. sleep_computer)", required=False),
   description="Schedules something for later or on a repeat. The user sees an approval card for any commands listed in 'approve'.")
_o("set_model", P("model", "a model name, 'provider|model', or fast / strong / local"))
_o("set_power_saving", P("mode", enum=("off", "auto", "on")))
_o("task_result", P("status", enum=("done", "retry", "blocked")), P("summary", "one short sentence for the user"))
_o("set_appearance", P("setting", enum=("theme", "accent", "layout")), P("value"))
_o("set_widget_option", P("option", enum=("onTop", "autoCollapse", "hotkey")), P("value"))
_o("open_view", P("view", "chat, memory, tools, logs or settings"), P("pane", required=False))
_o("vacuum_set", P("setting", "which setting to change", enum=("suction", "mop_water", "mode", "passes", "volume")),
   P("value", "suction: silent|standard|strong|max; mop_water: off|low|medium|high; mode: sweep|mop|sweep_mop|sweep_then_mop; passes: 1|2; volume: 0-100"))
_o("vacuum_start", P("mode", "optional: sweep, mop, sweep_mop or sweep_then_mop", required=False))
_o("vacuum_clean_rooms", P("rooms", "room names separated by commas, exactly as vacuum_rooms lists them"))
_o("double_click", P("x", type="integer"), P("y", type="integer"), template="{x},{y}")
_o("right_click", P("x", type="integer"), P("y", type="integer"), template="{x},{y}")
_o("mouse_down", P("x", type="integer", required=False), P("y", type="integer", required=False), template="{x},{y}")
_o("mouse_up", P("x", type="integer", required=False), P("y", type="integer", required=False), template="{x},{y}")
_o("set_cursor_position", P("x", type="integer"), P("y", type="integer"), template="{x},{y}")
_o("get_pixel_color", P("x", type="integer"), P("y", type="integer"), template="{x},{y}")
_o("drag_mouse", P("x1", type="integer"), P("y1", type="integer"), P("x2", type="integer"), P("y2", type="integer"), template="{x1},{y1}|{x2},{y2}")
_o("take_screenshot_region", P("left", type="integer"), P("top", type="integer"), P("width", type="integer"), P("height", type="integer"),
   template="{left},{top},{width},{height}")
_o("press_keys", P("keys", "keys separated by commas, pressed in order, e.g. ctrl,c"))
_o("create_archive", P("archive_path"), P("sources", "files/folders to include, separated by ;"))
_o("compress_files", P("archive_path"), P("sources", "files/folders to include, separated by ;"))
_o("start_process", P("command", "executable and its arguments, as one string"))
_o("youtube_open_video", P("video", "a link, a video id, or words to search for"))
_o("youtube_video_info", P("video", "a link or a video id"))
_o("write_csv", P("path"), P("rows", "rows separated by ;, cells by commas"))
_o("get_exchange_rates", P("base", "currency code, default EUR", required=False), P("symbols", "comma-separated codes, e.g. USD,GBP", required=False))
_o("news_top_headlines", P("country", "two-letter code, default us", required=False), P("category", required=False), P("keyword", required=False))
_o("list_tasks", P("filter", "active, finished, or a word", required=False))
_o("list_settings", P("filter", required=False))
_o("inspect_window", P("window_title", required=False))
_o("convert_currency", P("amount", type="number"), P("from_currency", "e.g. USD"), P("to_currency", "e.g. EUR"))
_o("get_historical_rate", P("date", "YYYY-MM-DD"), P("from_currency"), P("to_currency"))

_NUMERIC = {"x", "y", "count", "width", "height", "left", "top", "right", "bottom", "port", "degrees", "quality", "pixels", "index",
            "max_depth", "max_rows", "max_results", "max_size", "min_size_mb", "timeout_seconds", "delay_seconds", "days", "seconds"}


# ---------------------------------------------------------------- deriving a spec from arg_hint
def _split_top(text: str, sep: str) -> list:
    """Splits on `sep` outside <...> and [...]."""
    out, depth, cur = [], 0, ""
    for ch in text:
        if ch in "<[":
            depth += 1
        elif ch in ">]":
            depth = max(0, depth - 1)
        if ch == sep and depth == 0:
            out.append(cur)
            cur = ""
        else:
            cur += ch
    out.append(cur)
    return out


def _ident(text: str, used: set) -> str:
    base = re.sub(r"[^a-z0-9]+", "_", text.lower()).strip("_") or "value"
    if base[0].isdigit():
        base = "p_" + base
    base = base[:32]
    name, n = base, 2
    while name in used:
        name, n = f"{base}_{n}", n + 1
    used.add(name)
    return name


def _derive_params(hint: str) -> tuple:
    """-> (params, template). Never raises: an unparseable hint becomes one string parameter."""
    hint = (hint or "").strip()
    if not hint:
        return [], ""
    hint = hint.replace("[|", "|[")          # "<a>[|<b>]" means "<a>, then an optional <b>"
    used: set = set()
    params, pieces = [], []
    for seg in _split_top(hint, "|"):
        seg = seg.strip()
        if not seg:
            continue
        optional = seg.startswith("[")
        inner = seg.strip("[]").strip()
        # every <...> group in the segment is one parameter ("<x>,<y>" is two, joined by the comma that separates them)
        groups = re.findall(r"<([^<>]*)>", inner)
        if not groups:                       # "[ nosymbols]" or other free text
            groups = [inner]
        seg_names = []
        for g in groups:
            default = ""
            alts = [a.strip() for a in g.split("|")] if "|" in g else []
            if "=" in g:
                g, default = g.split("=", 1)
                default = default.strip()
            label = g.strip()
            desc = ""
            if alts:
                label = alts[0]
                desc = "one of: " + ", ".join(alts)
            elif len(label.split()) > 1:
                desc = label
            name = _ident(label, used)
            ptype = "string"
            if name in _NUMERIC:
                ptype = "number" if name.endswith("seconds") else "integer"
            elif re.fullmatch(r"-?\d+(\.\d+)?", default or ""):
                ptype = "number" if "." in default else "integer"
            if default:
                desc = (desc + " " if desc else "") + f"(default {default})"
            params.append(Param(name, ptype, desc, required=not optional and not default, default=default))
            seg_names.append(name)
        pieces.append(",".join("{" + n + "}" for n in seg_names))
    tpl = "|".join(pieces)
    return params, tpl


def _short(text: str, limit: int = 200) -> str:
    text = " ".join((text or "").split())
    return text if len(text) <= limit else text[:limit - 1].rstrip() + "…"


def spec_for(name: str):
    """The Spec for a tool name (builtin, override or derived), or None if no such tool exists."""
    if name in _B:
        return _B[name]
    t = tools_all.get(name)
    if t is None:
        return None
    if name in _O:
        params, tpl, desc = _O[name]
        return Spec(name, desc or t.description, [Param(**vars(p)) for p in params], tpl, t.requires_confirmation, t.info)
    params, tpl = _derive_params(t.arg_hint)
    return Spec(name, t.description, params, tpl, t.requires_confirmation, t.info)


def find_tools_spec() -> Spec:
    return Spec(FIND_TOOLS, "Searches ALL of Troy's tools (files, system, network, web research, desktop automation, windows, images, YouTube, "
                "web APIs, to-dos, notes, ...) by words or category and loads the matching ones so you can call them next. "
                "Use it when none of your current tools fits the request.",
                [P("query", "what you need, e.g. 'resize image' or 'battery' or a category name")], info=True)


def all_names() -> list:
    names = set(_B) | set(tools_all.all_tools())
    return sorted(n for n in names if n not in TEXT_ONLY)


# ---------------------------------------------------------------- JSON schema
def _param_json(p: Param) -> dict:
    d = {"type": p.type}
    if p.enum:
        d["enum"] = list(p.enum)
    if p.desc:
        d["description"] = p.desc
    return d


def schema_from_spec(spec: Spec) -> dict:
    desc = _short(spec.description)
    flags = []
    if spec.approval:
        flags.append("needs the user's approval (they see an Approve button; don't retry)")
    if spec.info:
        flags.append("returns information")
    if flags:
        desc += " [" + "; ".join(flags) + "]"
    props = {p.name: _param_json(p) for p in spec.params}
    params = {"type": "object", "properties": props}
    required = [p.name for p in spec.params if p.required]
    if required:
        params["required"] = required
    return {"type": "function", "function": {"name": spec.name, "description": desc, "parameters": params}}


def schema_for(name: str):
    spec = find_tools_spec() if name == FIND_TOOLS else spec_for(name)
    return schema_from_spec(spec) if spec else None


def schemas_for(names) -> list:
    out, seen = [], set()
    for n in names:
        if n in seen:
            continue
        seen.add(n)
        s = schema_for(n)
        if s:
            out.append(s)
    return out


# ---------------------------------------------------------------- model arguments -> validated strings -> legacy arg
def _as_text(p: Param, value) -> str:
    """One model-supplied value -> the text the legacy tool expects. Numbers may arrive as 5, 5.0 or "5"."""
    if value is None:
        return ""
    if isinstance(value, bool):
        if p.type in ("integer", "number"):
            raise ToolArgError(f"'{p.name}' must be a number, not true/false.")
        return "true" if value else "false"
    if isinstance(value, (int, float)):
        if p.type == "integer" and float(value) != int(value):
            raise ToolArgError(f"'{p.name}' must be a whole number, got {value}.")
        return str(int(value)) if float(value) == int(value) else str(value)
    if isinstance(value, str):
        if p.type in ("integer", "number"):
            text = value.strip()
            if not text:
                return ""
            try:
                number = float(text)
            except ValueError:
                raise ToolArgError(f"'{p.name}' must be {'a whole number' if p.type == 'integer' else 'a number'}, got '{value}'.") from None
            if p.type == "integer" and number != int(number):
                raise ToolArgError(f"'{p.name}' must be a whole number, got '{value}'.")
            return str(int(number)) if number == int(number) else str(number)
        return value.strip()
    raise ToolArgError(f"'{p.name}' must be a single {p.type} value, not {type(value).__name__}.")


def coerce_args(name: str, args) -> dict:
    """Checks `args` (the decoded JSON the model sent) against the tool's parameters. -> {param: str}."""
    spec = find_tools_spec() if name == FIND_TOOLS else spec_for(name)
    if spec is None:
        raise ToolArgError(f"There is no tool named '{name}'.")
    if args is None:
        args = {}
    if not isinstance(args, dict):
        raise ToolArgError("Arguments must be a JSON object like {\"param\": value}.")
    known = {p.name: p for p in spec.params}
    unknown = [k for k in args if k not in known]
    if unknown:
        raise ToolArgError(f"Unknown parameter(s) {', '.join(repr(k) for k in unknown)} for {name}. "
                           f"Parameters: {', '.join(known) or '(none)'}.")
    out = {}
    for p in spec.params:
        v = args.get(p.name)
        text = "" if v is None else _as_text(p, v)
        if text == "" and p.required:
            raise ToolArgError(f"Missing required parameter '{p.name}' for {name}" + (f" ({p.desc})." if p.desc else "."))
        if p.enum and text and text not in p.enum:
            low = {e.lower(): e for e in p.enum}
            if text.lower() in low:
                text = low[text.lower()]
            else:
                raise ToolArgError(f"'{p.name}' must be one of: {', '.join(p.enum)} (got '{text}').")
        out[p.name] = text
    return out


def to_arg_string(name: str, values: dict) -> str:
    """The legacy `a|b|c` string for already-coerced values (see coerce_args)."""
    spec = find_tools_spec() if name == FIND_TOOLS else spec_for(name)
    if spec is None:
        return ""
    params = spec.params
    if not params:
        return ""
    if len(params) == 1 and not spec.template:
        return values.get(params[0].name, "")
    template = spec.template or "|".join("{" + p.name + "}" for p in params)
    # fields that contain the separator would be split apart by the tool: refuse instead of corrupting the call
    sep_fields = [p.name for p in params[:-1] if "|" in values.get(p.name, "")]
    if sep_fields and "|" in template:
        raise ToolArgError(f"The character '|' can't be used inside '{sep_fields[0]}' for {name} (it separates the parameters). Rephrase without it.")
    text = template.format(**{p.name: values.get(p.name, "") for p in params})
    # drop empty optional tail pieces: "a|b||" -> "a|b", "5,5" stays, "," -> ""
    if "|" in template:
        parts = text.split("|")
        while len(parts) > 1 and parts[-1].strip() == "":
            parts.pop()
        text = "|".join(parts)
    if text.strip(",| ") == "":
        return ""
    return text


def call_to_command(name: str, args) -> tuple:
    """(name, arg_string) for a model's tool call, or raises ToolArgError."""
    values = coerce_args(name, args)
    return name, to_arg_string(name, values)


# ---------------------------------------------------------------- which tools does the model get to see?
# Always loaded. Kept small on purpose: every schema costs ~60 tokens on every request (Groq's free tier allows ~8000
# tokens per minute). Everything else is loaded when it matches what the user asked, or via find_tools.
CORE_TINY = ("open_app", "open_url", "search_newtab", "type_text", "press_key", "hotkey", "click_target", "screenshot", "read_screen_text",
             "get_active_window", "get_time", "get_system_stats", "read_file", "remember", "recall", FIND_TOOLS)

CORE = CORE_TINY + ("click", "scroll", "close_active_window", "switch_window", "list_windows", "get_weather", "create_file", "list_dir",
                    "find_files", "get_clipboard", "set_clipboard", "schedule_task")


def core_names(tiny: bool = False) -> list:
    names = CORE_TINY if tiny else CORE
    return [n for n in names if n == FIND_TOOLS or schema_for(n)]


def relevant_names(text: str, limit: int = 6, skip=()) -> list:
    """Tools (built-in commands included) whose name/description match what the user just said, best first."""
    from . import system_prompt
    words = system_prompt.query_words(text)
    if not words:
        return []
    wanted = system_prompt.expand_words(words)
    scored = []
    for name in all_names():
        if name in skip or name in TEXT_ONLY:
            continue
        spec = spec_for(name)
        t = tools_all.get(name)
        parts = set(name.lower().split("_"))
        desc = set(re.findall(r"[a-z0-9]+", (spec.description if spec else "").lower()))
        score = 3 * len(wanted & parts) + len(wanted & desc) + (1 if t and t.category in wanted else 0)
        if score >= 3:
            scored.append((-score, name))
    scored.sort()
    return [n for _, n in scored[:limit]]


class Toolbox:
    """The tools the model can call in ONE request. Starts with the core set plus the few tools that match what the
    user asked; find_tools (or a call to an unloaded tool) loads more, and they stay loaded for the rest of the request."""

    def __init__(self, user_text: str = "", tiny: bool = False, limit_relevant: int = 6, scheduled_run: bool = False):
        self.names: list = list(core_names(tiny))
        self.tiny = tiny
        if scheduled_run and tools_all.get("task_result"):
            self.load(["task_result"])
        if user_text:
            try:
                self.load(relevant_names(user_text, limit=2 if tiny else limit_relevant, skip=set(self.names)))
            except Exception:  # noqa: BLE001 - suggestions are a nicety
                pass

    def load(self, names) -> list:
        added = []
        for n in names:
            if n in TEXT_ONLY or n in self.names or n == FIND_TOOLS:
                continue
            if schema_for(n):
                self.names.append(n)
                added.append(n)
        return added

    def has(self, name: str) -> bool:
        return name in self.names

    def schemas(self) -> list:
        return schemas_for(self.names)

    def search(self, query: str, limit: int = 8) -> list:
        """Names of tools matching `query` (words, or a category), best first."""
        q = (query or "").strip().lower()
        words = [w for w in re.split(r"[\s,]+", q) if w]
        if not words:
            return []
        cats = {t.category for t in tools_all.all_tools().values()}
        scored = []
        for name in all_names():
            t = tools_all.get(name)
            spec = _B.get(name) or spec_for(name)
            text = f"{name.replace('_', ' ')} {spec.description if spec else ''}".lower()
            cat = t.category if t else "basic"
            score = 0
            if q in cats and cat == q:
                score += 5
            for w in words:
                if w in name.split("_"):
                    score += 4
                elif w in name:
                    score += 3
                elif w in text:
                    score += 1
                if cat == w:
                    score += 2
            if score:
                scored.append((-score, name))
        scored.sort()
        return [n for _, n in scored[:limit]]


def find_tools(toolbox: Toolbox, query: str) -> dict:
    """The find_tools tool: search, load the matches into the toolbox, tell the model what it now has."""
    found = toolbox.search(query, limit=10)
    if not found:
        cats = sorted({t.category for t in tools_all.all_tools().values()})
        return {"success": True, "message": f"No tool matches '{query}'. Categories: {', '.join(cats)}. Try other words or a category name. "
                                            "If nothing can do it, tell the user plainly that you can't; never invent a tool."}
    added = toolbox.load(found)
    lines = []
    for n in found:
        spec = _B.get(n) or spec_for(n)
        params = ", ".join(p.name + ("" if p.required else "?") for p in spec.params) if spec else ""
        lines.append(f"{n}({params}) -- {_short(spec.description if spec else '', 90)}")
    return {"success": True, "message": "Loaded these tools; you can call them now:\n" + "\n".join(lines),
            "ui_message": f"Loaded {len(found)} tool(s) for '{query}'."}
