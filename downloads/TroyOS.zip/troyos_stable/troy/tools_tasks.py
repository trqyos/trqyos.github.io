"""
Scheduled-task tools: how the user (through Troy) creates, inspects, changes and cancels
tasks, and how a task run reports back.

    schedule_task:<when>|<instruction>|[title]|[approve]
    list_tasks[:<filter>]            cancel_task:<id or title>
    modify_task:<id>|<field>|<value> pause_task / resume_task / run_task_now : <id>
    task_log:<id>                    task_result:<done|retry|blocked>|<summary>   (only inside a run)

All the real work is in troy/scheduler.py; these just translate the command line into
calls on it and the result into one honest sentence the model can pass on.
"""

from datetime import datetime

from . import config, confirmation, scheduler, sessions, task_context
from .command_parser import split_args
from .schedule_spec import FORMATS_HELP, ScheduleError
from .tools_all import get as _get_tool
from .tools_all import register

_UNAVAILABLE = {"success": False, "message": "Scheduled tasks aren't available right now (they're switched off in Settings, or Troy's scheduler hasn't started)."}
_FIELDS = {"when": "when", "time": "when", "schedule": "when", "prompt": "prompt", "instruction": "prompt", "title": "title", "name": "title",
           "retries": "retries", "max_retries": "retries", "retry_delay": "delay", "delay": "delay"}


def _sched():
    s = scheduler.get()
    return s if (s is not None and config.TASKS_ENABLED) else None


def _when(iso):
    try:
        return datetime.fromisoformat(iso).strftime("%a %b %d %H:%M")
    except (TypeError, ValueError):
        return "-"


def _line(t) -> str:
    bits = [f"{t['id']}", t["status"], f"“{t['title']}”", t["schedule_text"]]
    if t.get("next_run"):
        bits.append("next " + _when(t["next_run"]))
    if t.get("last_outcome"):
        bits.append(f"last: {t['last_outcome']}" + (f" ({t['last_summary'][:60]})" if t.get("last_summary") else ""))
    if t.get("needs_approval"):
        bits.append("NEEDS APPROVAL: " + ", ".join(t["needs_approval"]))
    return " | ".join(bits)


def _parse_approve(text: str):
    """'sleep_computer; shutdown_computer:30' -> (['sleep_computer', 'shutdown_computer:30'], error or None)."""
    commands = []
    for item in [c.strip() for c in (text or "").split(";") if c.strip()]:
        name, _, arg = item.partition(":")
        tool = _get_tool(name.strip())
        if tool is None:
            from . import extra_tools
            if name.strip() in extra_tools.BUILTIN_COMMANDS or name.strip() in extra_tools.catalog():          # a built-in command: real, but it never asks for approval
                return [], f"'{name}' doesn't need approval, so leave it out of the approve list."
            return [], f"'{name}' isn't a tool, so it can't be pre-approved. Use exact tool names (list_extra_tools shows them)."
        if not tool.requires_confirmation:
            return [], f"'{name}' doesn't need approval, so leave it out of the approve list."
        commands.append(task_context.normalise(name, arg))
    return commands, None


def schedule_task(arg: str) -> dict:
    s = _sched()
    if s is None:
        return _UNAVAILABLE
    if task_context.current() is not None:
        return {"success": False, "message": "A scheduled run can't create new scheduled tasks."}
    parts = split_args(arg)
    if len(parts) < 2 or not parts[0] or not parts[1]:
        return {"success": False, "message": "Use schedule_task:<when>|<instruction>|[title]|[approve]. " + FORMATS_HELP}
    if len(parts) > 4:
        return {"success": False, "message": "Too many '|' separators: the instruction itself must not contain '|'."}
    when, prompt = parts[0], parts[1]
    title = parts[2] if len(parts) > 2 else ""
    commands, err = _parse_approve(parts[3]) if len(parts) > 3 else ([], None)
    if err:
        return {"success": False, "message": err}
    try:
        task = s.add(prompt, when, title=title)
    except (ScheduleError, ValueError) as exc:
        return {"success": False, "message": str(exc)}
    if task.get("session_id"):
        try:
            sessions.link_task(task["session_id"], task["id"])
        except Exception:  # noqa: BLE001 - the link is a convenience, the task exists either way
            pass
    msg = f"Scheduled task {task['id']} “{task['title']}”: {task['schedule_text']}; first run {_when(task['next_run'])}."
    if commands:
        shown = ", ".join(commands)

        def apply(_a=""):
            s.grant(task["id"], commands)
            return {"success": True, "message": f"Task {task['id']} may now run unattended: {shown}."}
        confirmation.request("approve_task", task["id"], "medium", apply,
                             f"Let the scheduled task “{task['title']}” ({task['schedule_text']}) run these commands without asking each time: {shown}")
        msg += f" An approval card is showing: the user must approve running {shown} unattended, otherwise the task will report that it needs approval."
    return {"success": True, "message": msg + " Tell the user what was scheduled."}


def list_tasks(arg: str = "") -> dict:
    s = _sched()
    if s is None:
        return _UNAVAILABLE
    needle = (arg or "").strip().lower()
    tasks = s.list()
    if needle in ("active", "pending", "upcoming"):
        tasks = [t for t in tasks if t["status"] in ("scheduled", "retrying", "running", "paused")]
    elif needle in ("finished", "done", "past", "history"):
        tasks = [t for t in tasks if t["status"] in ("completed", "failed", "cancelled", "missed")]
    elif needle:
        tasks = [t for t in tasks if needle in t["title"].lower() or needle in t["prompt"].lower() or needle == t["id"]]
    if not tasks:
        return {"success": True, "message": "No scheduled tasks" + (f" match '{arg}'." if needle else " yet.")}
    shown = tasks[:15]
    return {"success": True, "message": f"{len(tasks)} task(s): " + " ;; ".join(_line(t) for t in shown) + (f" ;; ...and {len(tasks) - 15} more" if len(tasks) > 15 else "")}


def _find(ref):
    s = _sched()
    if s is None:
        return None, None, _UNAVAILABLE
    try:
        return s, s.resolve(ref), None
    except LookupError as exc:
        return s, None, {"success": False, "message": str(exc)}


def cancel_task(arg: str) -> dict:
    s, t, err = _find(arg)
    if err:
        return err
    try:
        s.cancel(t["id"])
    except (LookupError, ValueError) as exc:
        return {"success": False, "message": str(exc)}
    return {"success": True, "message": f"Cancelled task {t['id']} “{t['title']}”."}


def pause_task(arg: str) -> dict:
    s, t, err = _find(arg)
    if err:
        return err
    try:
        s.pause(t["id"])
    except (LookupError, ValueError) as exc:
        return {"success": False, "message": str(exc)}
    return {"success": True, "message": f"Paused task {t['id']} “{t['title']}”. resume_task brings it back."}


def resume_task(arg: str) -> dict:
    s, t, err = _find(arg)
    if err:
        return err
    try:
        v = s.resume(t["id"])
    except (LookupError, ValueError, ScheduleError) as exc:
        return {"success": False, "message": str(exc)}
    return {"success": True, "message": f"Resumed task {t['id']} “{t['title']}”: {v['schedule_text']}, next {_when(v.get('next_run'))}."}


def run_task_now(arg: str) -> dict:
    s, t, err = _find(arg)
    if err:
        return err
    try:
        s.run_now(t["id"])
    except (LookupError, ValueError) as exc:
        return {"success": False, "message": str(exc)}
    return {"success": True, "message": f"Task {t['id']} “{t['title']}” will run now; its result will be reported when it finishes."}


def modify_task(arg: str) -> dict:
    parts = split_args(arg)
    if len(parts) < 3:
        return {"success": False, "message": "Use modify_task:<id or title>|<when|instruction|title|retries|retry_delay>|<new value>."}
    s, t, err = _find(parts[0])
    if err:
        return err
    field = _FIELDS.get(parts[1].strip().lower())
    value = "|".join(parts[2:]).strip()
    if not field or not value:
        return {"success": False, "message": "Fields you can change: when, instruction, title, retries, retry_delay."}
    try:
        kwargs = {"when": lambda: {"when": value}, "prompt": lambda: {"prompt": value}, "title": lambda: {"title": value},
                  "retries": lambda: {"max_retries": int(value)}, "delay": lambda: {"retry_delay": int(value)}}[field]()
        v = s.modify(t["id"], **kwargs)
    except ValueError as exc:
        return {"success": False, "message": str(exc) if not str(exc).startswith("invalid literal") else f"'{value}' should be a whole number."}
    except (LookupError, ScheduleError) as exc:
        return {"success": False, "message": str(exc)}
    return {"success": True, "message": f"Updated task {t['id']} “{v['title']}”: {v['schedule_text']}" + (f", next {_when(v['next_run'])}" if v.get("next_run") else "") + "."}


def task_log(arg: str) -> dict:
    parts = split_args(arg)
    s, t, err = _find(parts[0] if parts else "")
    if err:
        return err
    n = int(parts[1]) if len(parts) > 1 and parts[1].isdigit() else 12
    entries = s.logs(t["id"], n)
    if not entries:
        return {"success": True, "message": f"No log entries yet for task {t['id']}."}
    return {"success": True, "message": " ;; ".join(f"{e['ts'][5:16].replace('T', ' ')} {e['event']}: {e['message'][:110]}" for e in entries)}


def task_result(arg: str) -> dict:
    """The model's own verdict on a scheduled run: done | retry | blocked, plus one sentence for the user."""
    ctx = task_context.current()
    if ctx is None:
        return {"success": False, "message": "task_result only works inside a scheduled run; there is none right now."}
    parts = split_args(arg)
    status = (parts[0] if parts else "").lower()
    status = {"ok": "done", "success": "done", "complete": "done", "completed": "done", "failed": "retry", "fail": "retry", "error": "retry"}.get(status, status)
    if status not in ("done", "retry", "blocked"):
        return {"success": False, "message": "Use task_result:<done|retry|blocked>|<one short sentence for the user>."}
    summary = "|".join(parts[1:]).strip() or {"done": "Done.", "retry": "It failed.", "blocked": "It can't be done."}[status]
    ctx.reported = (status, summary[:300])
    return {"success": True, "message": "Recorded. Now end with done."}


register("schedule_task", schedule_task,
         "Schedules something for later or on a repeat. <when> is natural language ('in 30 minutes', 'tomorrow at 9am', 'every Monday, Wednesday and Friday at 22:00', 'October 25 2026 at 14:30', 'every 2 days'); "
         "<instruction> is a short imperative you write for your future self ('Put the computer to sleep.'); [title] optional; [approve] = exact commands that need approval "
         "to run unattended, ';'-separated ('sleep_computer'). The user sees an approval card for those.",
         category="tasks", arg_hint="<when>|<instruction>|[title]|[approve]")
register("list_tasks", list_tasks, "Lists scheduled tasks with their ids, schedule, next run and last result (filter: active, finished, or a word).",
         category="tasks", info=True, arg_hint="[<filter>]")
register("cancel_task", cancel_task, "Cancels a scheduled task (by id or title).", category="tasks", arg_hint="<id or title>")
register("modify_task", modify_task, "Changes a scheduled task: when, instruction, title, retries or retry_delay.", category="tasks", arg_hint="<id or title>|<field>|<value>")
register("pause_task", pause_task, "Pauses a scheduled task without deleting it.", category="tasks", arg_hint="<id or title>")
register("resume_task", resume_task, "Resumes a paused task.", category="tasks", arg_hint="<id or title>")
register("run_task_now", run_task_now, "Runs a scheduled task right now, in addition to its schedule.", category="tasks", arg_hint="<id or title>")
register("task_log", task_log, "Recent execution log of a task (what ran, retries, failures).", category="tasks", info=True, arg_hint="<id or title>[|<count>]")
register("task_result", task_result,
         "Only inside a scheduled run: reports the outcome. done = fully carried out; retry = failed but trying again may help; blocked = can't be done.",
         category="tasks", arg_hint="<done|retry|blocked>|<one sentence for the user>")
