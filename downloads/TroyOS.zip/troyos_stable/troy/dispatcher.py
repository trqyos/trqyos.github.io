"""
TROYOS STABLE - Command Dispatcher

Maps parsed command names to their executor functions and normalizes their
results into a consistent {"success": bool, "message": str} shape used to
build [OBSERVATION] messages for the LLM. Never raises -- a broken or
unknown command becomes a failed observation instead of crashing Troy.

Command families:
  - built-in tools (troy/tools_all.py) -- every primitive, in one file
  - escalation     (troy/escalation.py)-- last-resort hand-off to Gemini

Risky tools never run from here directly -- see troy/confirmation.py.
tools_all.run() hands them off and returns a "pending" result instead.
"""

import time

from . import escalation, extra_tools, memory, stop_control, tools_all
from .command_parser import split_args
from .logger import logger

# Commands whose entire purpose is handing the model information it doesn't
# already have -- as opposed to action commands (open_app, click, ...) where
# the model already decided what to do and isn't waiting on a result. Used by
# agent.py to decide whether a `done` bundled in the same batch was premature
# and should be overridden so the model actually gets to react.
INFO_COMMANDS = {
    "screenshot", "read_screen_text", "get_active_window", "list_windows",
    "window_exists", "get_time", "get_media_info", "get_storage_info",
    "get_system_stats", "list_dir", "read_file", "find_files", "recall",
    "list_processes", "get_clipboard", "get_weather",
    "locate_on_screen", "escalate", "get_context", "list_tools", "tool_help",
} | tools_all.info_command_names()


def _parse_int_pair(arg: str):
    parts = split_args(arg) if "|" in arg else arg.split(",")
    return int(float(parts[0].strip())), int(float(parts[1].strip()))


def execute(name: str, arg: str) -> dict:
    """Executes a single parsed command. Always returns a result dict."""
    if stop_control.stop_controller.is_stopped():
        return {"success": False, "message": "Stopped by user before this command ran."}

    try:
        if name == "speak":
            return {"success": True, "message": arg, "is_speech": True}

        elif name == "open_app":
            return tools_all.open_app(arg)
        elif name == "close_active_window":
            return tools_all.close_active_window()
        elif name == "minimize_window":
            return tools_all.minimize_active_window()
        elif name == "maximize_window":
            return tools_all.maximize_active_window()
        elif name == "switch_window":
            return tools_all.switch_window()

        elif name == "open_url":
            return tools_all.open_url(arg)
        elif name == "search_newtab":
            return tools_all.search_newtab(arg)

        elif name == "type_text":
            return tools_all.type_text(arg)
        elif name == "press_key":
            return tools_all.press_key(arg)
        elif name == "hotkey":
            return tools_all.hotkey(arg)
        elif name == "click":
            x, y = _parse_int_pair(arg)
            return tools_all.click(x, y)
        elif name == "move_mouse":
            x, y = _parse_int_pair(arg)
            return tools_all.move_mouse(x, y)
        elif name == "scroll":
            return tools_all.scroll(int(arg))

        # coordinate targeting: screenshot -> vision locate -> click, one call
        elif name == "click_target":
            return tools_all.click_target(arg)
        elif name == "locate_on_screen":
            return tools_all.locate_on_screen(arg)

        elif name in ("play_audio", "pause_audio"):
            return tools_all.play_pause()
        elif name == "volume_up":
            return tools_all.volume_up()
        elif name == "volume_down":
            return tools_all.volume_down()
        elif name == "volume_mute":
            return tools_all.volume_mute()

        elif name == "screenshot":
            return tools_all.take_screenshot_and_describe()
        elif name == "read_screen_text":
            return tools_all.read_screen_text()

        elif name == "get_active_window":
            return tools_all.get_active_window()
        elif name == "list_windows":
            return tools_all.list_windows()
        elif name == "window_exists":
            return tools_all.window_exists(arg)

        elif name == "get_time":
            return tools_all.get_current_time()
        elif name == "get_media_info":
            return tools_all.get_media_info()
        elif name == "get_storage_info":
            return tools_all.get_storage_info()
        elif name == "get_system_stats":
            return tools_all.get_system_stats()

        elif name == "create_file":
            return tools_all.create_file(arg)
        elif name == "move_file":
            return tools_all.move_file(arg)
        elif name == "copy_file":
            return tools_all.copy_file(arg)
        elif name == "read_file":
            return tools_all.read_file(arg)
        elif name == "find_files":
            return tools_all.find_files(arg)
        elif name == "list_dir":
            return tools_all.list_dir(arg)

        elif name == "get_clipboard":
            return tools_all.read_clipboard()
        elif name == "set_clipboard":
            return tools_all.set_clipboard(arg)

        elif name == "get_weather":
            return tools_all.get_weather(arg)

        elif name == "list_processes":
            return tools_all.list_processes()
        elif name == "kill_process":
            return tools_all.kill_process(arg)

        elif name == "wait":
            seconds = float(arg) if arg else 1.0
            _interruptible_sleep(seconds)
            return {"success": True, "message": f"Waited {seconds} seconds."}

        elif name == "remember":
            return {"success": True, "message": memory.remember(arg)}
        elif name == "recall":
            return {"success": True, "message": memory.recall(arg)}

        elif name == "get_context":
            return tools_all.get_context_snapshot()
        elif name == "list_tools":
            return tools_all.list_tools(arg.strip())
        elif name == "tool_help":
            return tools_all.tool_help(arg.strip())

        elif name == "escalate":
            return _run_escalate(arg)

        elif name == "done":
            return {"success": True, "message": "", "is_done": True}

        else:
            # Everything else (the ~140-tool extended library) lives in the
            # tools_all registry. Confirmation-gated tools return a
            # "pending" result here instead of running -- see
            # troy/confirmation.py and tools_all.run().
            if tools_all.get(name) is None:
                return extra_tools.unknown_command(name)
            blocked = extra_tools.gate(name, arg)        # an extra tool never shown to the model: usage first, no action
            if blocked is not None:
                return blocked
            result = tools_all.run(name, arg)
            extra_tools.note_use(name, result)
            return result

    except Exception as exc:  # noqa: BLE001 - a broken command shouldn't crash Troy
        logger.exception("Command '%s' raised", name)
        return {"success": False, "message": f"Command '{name}:{arg}' failed: {exc}"}


def _interruptible_sleep(seconds: float, poll: float = 0.25):
    """Like time.sleep(), but checked in small slices against the stop flag
    so a force-stop during a long `wait:` command doesn't have to wait out
    the whole duration."""
    remaining = max(0.0, seconds)
    while remaining > 0:
        if stop_control.stop_controller.is_stopped():
            return
        step = min(poll, remaining)
        time.sleep(step)
        remaining -= step


def _run_escalate(arg: str) -> dict:
    """arg format: 'user_request|current_task|attempted|error|reason'.
    Every field is optional -- missing trailing fields are treated as
    empty, so the model doesn't have to pad the command with blank pipes
    for fields it has nothing to say about."""
    parts = split_args(arg)
    parts += [""] * (5 - len(parts))
    user_request, current_task, attempted, error, reason = parts[:5]
    return escalation.escalate(
        user_request=user_request,
        current_task=current_task,
        attempted=attempted,
        error=error,
        reason=reason,
        stop_check=stop_control.stop_controller.is_stopped,
    )
