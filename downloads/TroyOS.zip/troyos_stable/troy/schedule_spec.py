"""
Schedule specifications: what "every Monday at 22:00" or "in 30 minutes" means.

A schedule is a small JSON-friendly dict (so it can be stored in
troy_tasks.json and edited later). Times are the PC's LOCAL clock, stored as
naive ISO strings -- the same clock the user reads.

    {"kind": "once",     "at": "2026-10-25T14:30:00"}
    {"kind": "interval", "seconds": 5400, "start": "2026-10-19T09:00:00"}      every 90 minutes
    {"kind": "daily",    "time": "22:00", "every": 1, "start": "2026-10-19"}   every N days
    {"kind": "weekdays", "days": [0, 2, 4], "time": "22:00", "every": 1, "start": "2026-10-19"}
    {"kind": "monthly",  "day": 15, "time": "09:00", "every": 1, "start": "2026-10-19"}   day -1 = last day
    {"kind": "yearly",   "month": 3, "day": 3, "time": "09:00", "every": 1, "start": "2026-10-19"}

`days` use Python's weekday numbers (Monday = 0 ... Sunday = 6). `every` is a
step ("every 2 weeks"); `start` anchors that step. A day that doesn't exist in
a month (the 31st in April, Feb 29th in a normal year) runs on the month's last
day instead of being skipped.

Public API
    parse_when(text, now=None)   natural language / JSON text -> spec  (raises ScheduleError)
    validate(spec)               -> normalised spec (raises ScheduleError)
    next_run(spec, after)        -> next datetime strictly after `after`, or None
    occurrences(spec, after, n)  -> the next n run times
    describe(spec)               -> "Every Monday, Wednesday and Friday at 22:00"
    is_recurring(spec)
"""

import calendar
import json
import re
from datetime import date, datetime, time, timedelta


class ScheduleError(ValueError):
    """The text or spec can't be understood; the message says what to write instead."""


KINDS = ("once", "interval", "daily", "weekdays", "monthly", "yearly")
DAY_NAMES = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]
_DAY_WORDS = {
    "monday": 0, "mon": 0, "tuesday": 1, "tue": 1, "tues": 1, "wednesday": 2, "wed": 2,
    "thursday": 3, "thu": 3, "thur": 3, "thurs": 3, "friday": 4, "fri": 4, "saturday": 5, "sat": 5,
    "sunday": 6, "sun": 6,
}
_MONTH_WORDS = {
    "january": 1, "jan": 1, "february": 2, "feb": 2, "march": 3, "mar": 3, "april": 4, "apr": 4, "may": 5,
    "june": 6, "jun": 6, "july": 7, "jul": 7, "august": 8, "aug": 8, "september": 9, "sep": 9, "sept": 9,
    "october": 10, "oct": 10, "november": 11, "nov": 11, "december": 12, "dec": 12,
}
_UNIT_SECONDS = {
    "second": 1, "sec": 1, "s": 1, "minute": 60, "min": 60, "m": 60, "hour": 3600, "hr": 3600, "h": 3600,
    "day": 86400, "d": 86400, "week": 604800, "wk": 604800, "w": 604800,
}
_NUM_WORDS = {"a": 1, "an": 1, "one": 1, "two": 2, "three": 3, "four": 4, "five": 5, "six": 6, "seven": 7,
              "eight": 8, "nine": 9, "ten": 10, "twelve": 12, "fifteen": 15, "twenty": 20, "thirty": 30,
              "forty": 40, "sixty": 60, "half": 0.5}
FORMATS_HELP = (
    "Supported: 'in 30 minutes', 'in 2 hours', 'tomorrow at 9am', 'today at 18:30', 'at 22:00', 'friday at 8pm', "
    "'October 25, 2026 at 14:30', '2026-10-25 14:30', 'every day at 22:00', 'every 2 days at 9am', "
    "'every monday, wednesday and friday at 22:00', 'every weekday at 8:30', 'every 3 hours', 'every 2 weeks on monday at 9am', "
    "'every month on the 15th at 09:00', 'every year on March 3 at 9am', or a JSON spec like "
    "{\"kind\":\"daily\",\"time\":\"22:00\"}."
)


# ---------------------------------------------------------------- helpers
def _parse_dt(value, field="time") -> datetime:
    try:
        return datetime.fromisoformat(str(value))
    except (TypeError, ValueError):
        raise ScheduleError(f"'{value}' isn't a valid {field} (use YYYY-MM-DDTHH:MM:SS).") from None


def _parse_hhmm(value) -> time:
    m = re.fullmatch(r"\s*(\d{1,2}):(\d{2})(?::(\d{2}))?\s*", str(value or ""))
    if not m or int(m.group(1)) > 23 or int(m.group(2)) > 59 or int(m.group(3) or 0) > 59:
        raise ScheduleError(f"'{value}' isn't a valid time of day (use 24-hour HH:MM, e.g. 22:00).")
    return time(int(m.group(1)), int(m.group(2)), int(m.group(3) or 0))


def _start_date(spec, fallback: date) -> date:
    raw = spec.get("start")
    if not raw:
        return fallback
    return _parse_dt(raw, "start").date()


def _clip_day(year: int, month: int, day: int) -> int:
    last = calendar.monthrange(year, month)[1]
    return last if day == -1 else min(day, last)


# ---------------------------------------------------------------- validation
def validate(spec: dict, now: datetime | None = None) -> dict:
    """Returns a cleaned copy of `spec` with defaults filled in (a `start` anchor
    for anything that repeats every N). Raises ScheduleError with a readable reason."""
    if not isinstance(spec, dict):
        raise ScheduleError("A schedule must be an object like {\"kind\": \"daily\", \"time\": \"22:00\"}.")
    now = now or datetime.now()
    kind = str(spec.get("kind", "")).lower()
    if kind not in KINDS:
        raise ScheduleError(f"Unknown schedule kind '{kind}'. Kinds: {', '.join(KINDS)}.")
    out = {"kind": kind}

    def every():
        n = spec.get("every", 1)
        try:
            n = int(n)
        except (TypeError, ValueError):
            raise ScheduleError("'every' must be a whole number.") from None
        if not 1 <= n <= 1000:
            raise ScheduleError("'every' must be between 1 and 1000.")
        return n

    if kind == "once":
        out["at"] = _parse_dt(spec.get("at"), "date and time").replace(microsecond=0).isoformat()
    elif kind == "interval":
        try:
            seconds = int(float(spec.get("seconds", 0)))
        except (TypeError, ValueError):
            raise ScheduleError("'seconds' must be a number.") from None
        if seconds < 10:
            raise ScheduleError("An interval must be at least 10 seconds.")
        out["seconds"] = seconds
        out["start"] = _parse_dt(spec["start"], "start").replace(microsecond=0).isoformat() if spec.get("start") \
            else now.replace(microsecond=0).isoformat()
    else:
        t = _parse_hhmm(spec.get("time") or "09:00")
        out["time"] = t.strftime("%H:%M") if t.second == 0 else t.strftime("%H:%M:%S")
        out["every"] = every()
        out["start"] = _start_date(spec, now.date()).isoformat()
        if kind == "weekdays":
            days = spec.get("days")
            if not isinstance(days, (list, tuple)) or not days:
                raise ScheduleError("'weekdays' needs a list of days, e.g. [0, 2, 4] (Monday = 0).")
            clean = sorted({int(d) for d in days})
            if any(d < 0 or d > 6 for d in clean):
                raise ScheduleError("Weekday numbers run from 0 (Monday) to 6 (Sunday).")
            out["days"] = clean
        elif kind == "monthly":
            try:
                day = int(spec.get("day", 1))
            except (TypeError, ValueError):
                raise ScheduleError("'day' must be a number from 1 to 31 (or -1 for the last day).") from None
            if day != -1 and not 1 <= day <= 31:
                raise ScheduleError("'day' must be from 1 to 31, or -1 for the last day of the month.")
            out["day"] = day
        elif kind == "yearly":
            try:
                month, day = int(spec.get("month")), int(spec.get("day"))
            except (TypeError, ValueError):
                raise ScheduleError("'yearly' needs a month (1-12) and a day (1-31).") from None
            if not 1 <= month <= 12 or not 1 <= day <= 31:
                raise ScheduleError("Month must be 1-12 and day 1-31.")
            out["month"], out["day"] = month, day
    return out


def is_recurring(spec: dict) -> bool:
    return str(spec.get("kind")) != "once"


# ---------------------------------------------------------------- next run
def next_run(spec: dict, after: datetime) -> datetime | None:
    """The first run strictly after `after`; None when a one-time schedule is in the past."""
    kind = spec["kind"]
    if kind == "once":
        at = _parse_dt(spec["at"])
        return at if at > after else None
    if kind == "interval":
        start, step = _parse_dt(spec["start"]), int(spec["seconds"])
        # a recurring "every 2 hours" starts counting from its anchor: the first run is anchor + step
        if after < start:
            return start + timedelta(seconds=step)
        k = int((after - start).total_seconds() // step) + 1
        return start + timedelta(seconds=step * k)

    at_time = _parse_hhmm(spec["time"])
    step = int(spec.get("every", 1))
    start = _start_date(spec, after.date())

    if kind in ("daily", "weekdays"):
        day = max(after.date(), start)
        for _ in range(7 * step * 2 + 400):
            cand = datetime.combine(day, at_time)
            if cand > after:
                if kind == "daily":
                    if (day - start).days % step == 0:
                        return cand
                else:
                    week_gap = ((day - timedelta(days=day.weekday())) - (start - timedelta(days=start.weekday()))).days // 7
                    if day.weekday() in spec["days"] and week_gap % step == 0:
                        return cand
            day += timedelta(days=1)
        return None

    if kind == "monthly":
        y, m = max((after.year, after.month), (start.year, start.month))
        for _ in range(12 * step + 24):
            months_since = (y - start.year) * 12 + (m - start.month)
            if months_since >= 0 and months_since % step == 0:
                cand = datetime.combine(date(y, m, _clip_day(y, m, int(spec["day"]))), at_time)
                if cand > after and cand.date() >= start:
                    return cand
            m += 1
            if m > 12:
                y, m = y + 1, 1
        return None

    if kind == "yearly":
        y = max(after.year, start.year)
        for _ in range(step + 10):
            if (y - start.year) % step == 0:
                cand = datetime.combine(date(y, int(spec["month"]), _clip_day(y, int(spec["month"]), int(spec["day"]))), at_time)
                if cand > after and cand.date() >= start:
                    return cand
            y += 1
        return None
    return None


def occurrences(spec: dict, after: datetime, n: int = 3) -> list:
    out, cursor = [], after
    for _ in range(max(0, n)):
        nxt = next_run(spec, cursor)
        if nxt is None:
            break
        out.append(nxt)
        cursor = nxt
    return out


# ---------------------------------------------------------------- describing
def _clock(t: str) -> str:
    return t[:5]


def _ordinal(n: int) -> str:
    if n == -1:
        return "last day"
    suffix = "th" if 10 <= n % 100 <= 20 else {1: "st", 2: "nd", 3: "rd"}.get(n % 10, "th")
    return f"{n}{suffix}"


def _human_seconds(sec: int) -> str:
    for unit, size in (("week", 604800), ("day", 86400), ("hour", 3600), ("minute", 60)):
        if sec % size == 0:
            n = sec // size
            return f"{n} {unit}{'s' if n != 1 else ''}"
    return f"{sec} seconds"


def _join(words: list) -> str:
    return words[0] if len(words) == 1 else ", ".join(words[:-1]) + " and " + words[-1]


def describe(spec: dict) -> str:
    kind = spec.get("kind")
    every = int(spec.get("every", 1) or 1)
    if kind == "once":
        at = _parse_dt(spec["at"])
        return f"Once, {at.strftime('%a %b')} {at.day} {at.year} at {at.strftime('%H:%M')}"
    if kind == "interval":
        return f"Every {_human_seconds(int(spec['seconds']))}"
    t = _clock(spec.get("time", "09:00"))
    if kind == "daily":
        return f"Every day at {t}" if every == 1 else f"Every {every} days at {t}"
    if kind == "weekdays":
        days = list(spec.get("days", []))
        label = "weekday" if days == [0, 1, 2, 3, 4] else "weekend day" if days == [5, 6] else None
        if label == "weekday" and every == 1:
            return f"Every weekday (Mon-Fri) at {t}"
        if label == "weekend day" and every == 1:
            return f"Every weekend (Sat, Sun) at {t}"
        names = _join([DAY_NAMES[d] for d in days])
        return (f"Every {names} at {t}" if every == 1 else f"Every {every} weeks on {names} at {t}")
    if kind == "monthly":
        return f"On the {_ordinal(int(spec['day']))} of every {'month' if every == 1 else f'{every} months'} at {t}"
    if kind == "yearly":
        month = calendar.month_name[int(spec["month"])]
        return f"Every {'year' if every == 1 else f'{every} years'} on {month} {spec['day']} at {t}"
    return "Unknown schedule"


# ---------------------------------------------------------------- natural language
def _num(token: str):
    token = token.lower()
    if token in _NUM_WORDS:
        return _NUM_WORDS[token]
    try:
        return float(token) if "." in token else int(token)
    except ValueError:
        return None


_TIME_RE = re.compile(r"\b(?:at\s+)?(noon|midnight|(\d{1,2})(?::(\d{2}))?\s*(am|pm|a\.m\.|p\.m\.)?)\b", re.I)


def _find_time(text: str):
    """(time, matched_text) for the clock time in `text`, or (None, ''). A bare number needs am/pm,
    a colon, or the word 'at' in front of it so that '15th' or '2 days' are not read as times."""
    for m in re.finditer(r"(?:\bat\s+)?\b(noon|midnight)\b|(?:\bat\s+)?\b(\d{1,2})(?::(\d{2}))?\s*(a\.?m\.?|p\.?m\.?)?(?![\d:])", text, re.I):
        raw = m.group(0)
        if m.group(1):
            return (time(12, 0) if m.group(1).lower() == "noon" else time(0, 0)), raw
        hour, minute, ampm = int(m.group(2)), int(m.group(3) or 0), (m.group(4) or "").lower().replace(".", "")
        has_at = raw.lower().lstrip().startswith("at")
        if not (ampm or m.group(3) or has_at):
            continue
        after = text[m.end():m.end() + 3].lower().strip()
        if not (ampm or m.group(3)) and re.match(r"(st|nd|rd|th|day|week|hour|min|sec|month|year)", after):
            continue
        if ampm:
            if not 1 <= hour <= 12:
                raise ScheduleError(f"'{raw.strip()}' isn't a valid time.")
            hour = hour % 12 + (12 if ampm == "pm" else 0)
        if hour > 23 or minute > 59:
            raise ScheduleError(f"'{raw.strip()}' isn't a valid time.")
        return time(hour, minute), raw
    return None, ""


def _strip(text: str, piece: str) -> str:
    return re.sub(r"\s+", " ", text.replace(piece, " ", 1)).strip(" ,.")


def _days_in(text: str) -> list:
    found = []
    for word in re.findall(r"[a-z]+", text.lower()):
        if word in _DAY_WORDS and _DAY_WORDS[word] not in found:
            found.append(_DAY_WORDS[word])
    return sorted(found)


def _date_in(text: str, now: datetime):
    """(date, matched) for ISO dates and 'October 25(, 2026)' / '25 October (2026)'."""
    m = re.search(r"\b(\d{4})-(\d{1,2})-(\d{1,2})\b", text)
    if m:
        try:
            return date(int(m.group(1)), int(m.group(2)), int(m.group(3))), m.group(0)
        except ValueError:
            raise ScheduleError(f"'{m.group(0)}' isn't a real date.") from None
    months = "|".join(sorted(_MONTH_WORDS, key=len, reverse=True))
    m = re.search(rf"\b({months})\.?\s+(\d{{1,2}})(?:st|nd|rd|th)?(?:,?\s+(\d{{4}}))?\b", text, re.I) or None
    swapped = False
    if not m:
        m = re.search(rf"\b(\d{{1,2}})(?:st|nd|rd|th)?\s+(?:of\s+)?({months})\.?(?:,?\s+(\d{{4}}))?\b", text, re.I)
        swapped = bool(m)
    if not m:
        return None, ""
    month_word, day_s, year_s = (m.group(2), m.group(1), m.group(3)) if swapped else (m.group(1), m.group(2), m.group(3))
    month, day = _MONTH_WORDS[month_word.lower()], int(day_s)
    year = int(year_s) if year_s else now.year
    try:
        result = date(year, month, day)
    except ValueError:
        raise ScheduleError(f"'{m.group(0)}' isn't a real date.") from None
    if not year_s and result < now.date():
        result = date(year + 1, month, day)
    return result, m.group(0)


def parse_when(text: str, now: datetime | None = None) -> dict:
    """Natural language (or a JSON spec) -> a validated schedule spec."""
    now = (now or datetime.now()).replace(microsecond=0)
    raw = (text or "").strip()
    if not raw:
        raise ScheduleError("Say when: " + FORMATS_HELP)
    if raw.startswith("{"):
        try:
            return validate(json.loads(raw), now)
        except json.JSONDecodeError as exc:
            raise ScheduleError(f"That JSON schedule isn't valid ({exc.msg}).") from None
    low = re.sub(r"\s+", " ", raw.lower().replace("\u2019", "'")).strip(" .")

    # ---- "in 30 minutes", "in an hour and a half", "in 1 hour 30 minutes"
    m = re.fullmatch(r"(?:in|after)\s+(.+)", low)
    if m and not low.startswith(("in the", "in a week on")):
        total, ok = 0.0, False
        rest = m.group(1)
        if rest in ("half an hour", "an hour and a half"):
            total, ok = (1800 if rest == "half an hour" else 5400), True
        else:
            for qty, unit in re.findall(r"(\d+(?:\.\d+)?|a|an|one|two|three|four|five|six|seven|eight|nine|ten|twelve|fifteen|twenty|thirty|forty|sixty)\s*"
                                       r"(seconds?|secs?|minutes?|mins?|hours?|hrs?|days?|weeks?)\b", rest):
                total += _num(qty) * _UNIT_SECONDS[re.sub(r"s$", "", unit) if unit not in ("secs", "mins", "hrs") else unit[:-1]]
                ok = True
        if not ok or total <= 0:
            raise ScheduleError(f"I couldn't read '{raw}' as a delay. " + FORMATS_HELP)
        return validate({"kind": "once", "at": (now + timedelta(seconds=int(total))).isoformat()}, now)

    recurring = bool(re.match(r"(every|each|daily|weekly|monthly|yearly|annually|hourly|on the \d|on the last)", low)) \
        or bool(re.search(r"\b(every|each)\b", low))
    when_time, time_piece = _find_time(low)
    body = _strip(low, time_piece) if time_piece else low

    if recurring:
        return _parse_recurring(raw, low, body, when_time, now)

    # ---- one-time: date and/or day word, plus optional clock time
    if re.search(r"\b(yesterday|ago|last (?:night|week|month|year))\b", low):
        raise ScheduleError(f"'{raw}' is in the past. " + FORMATS_HELP)
    day, piece = _date_in(body, now)
    _reject_leftovers(raw, body, piece)
    if day is None:
        if re.search(r"\btomorrow\b", body):
            day = now.date() + timedelta(days=1)
        elif re.search(r"\b(today|tonight)\b", body):
            day = now.date()
        elif re.search(r"\bday after tomorrow\b", body):
            day = now.date() + timedelta(days=2)
        else:
            wd = _days_in(body)
            if len(wd) == 1:
                ahead = (wd[0] - now.weekday()) % 7
                if ahead == 0 and (when_time is None or datetime.combine(now.date(), when_time) <= now):
                    ahead = 7
                if re.search(r"\bnext\b", body) and ahead < 7 and wd[0] != now.weekday():
                    ahead += 0 if ahead >= 1 else 7
                day = now.date() + timedelta(days=ahead)
    if day is None and when_time is None:
        raise ScheduleError(f"I couldn't read '{raw}' as a time. " + FORMATS_HELP)
    if when_time is None:
        if re.search(r"\btonight\b", low):
            when_time = time(21, 0)
        else:
            raise ScheduleError(f"What time on {day.isoformat()}? Add a clock time, e.g. '{raw} at 9am'.")
    if day is None:                                              # bare "at 22:00": the next time the clock shows it
        cand = datetime.combine(now.date(), when_time)
        day = now.date() if cand > now else now.date() + timedelta(days=1)
    at = datetime.combine(day, when_time)
    if at <= now:
        raise ScheduleError(f"{at.strftime('%a %b %d %Y %H:%M')} is already in the past (it is {now.strftime('%a %b %d %Y %H:%M')} now).")
    return validate({"kind": "once", "at": at.isoformat()}, now)


_FILLER = {"at", "on", "the", "today", "tomorrow", "tonight", "next", "this", "of", "day", "after", "by", "around", "about",
           "in", "and", "me", "please", "remind", "to", "then", "from", "now", "coming", "upcoming", "evening", "morning"}


def _reject_leftovers(raw: str, body: str, date_piece: str) -> None:
    """Words we didn't recognise mean we'd be guessing ('at 5pm sometime next quarter'): better to ask."""
    rest = body.replace(date_piece, " ") if date_piece else body
    unknown = [w for w in re.findall(r"[a-z]+", rest) if w not in _FILLER and w not in _DAY_WORDS and w not in _MONTH_WORDS]
    if unknown:
        raise ScheduleError(f"I didn't understand '{' '.join(unknown)}' in '{raw}'. " + FORMATS_HELP)


def _parse_recurring(raw, low, body, when_time, now):
    t = (when_time or time(9, 0)).strftime("%H:%M")
    step = 1
    m_sec = re.search(r"\bevery\s+(\d+)\s*(?:seconds?|secs?)\b", body)
    if m_sec:
        return validate({"kind": "interval", "seconds": int(m_sec.group(1)), "start": now.isoformat()}, now)
    if re.search(r"\bevery\s+(?:second|sec)\b", body):      # "every second" is almost certainly a mistake
        raise ScheduleError("Intervals must be at least 10 seconds. Try 'every 30 seconds'.")
    m = re.search(r"\bevery\s+(other|\d+|two|three|four|five|six|seven|eight|nine|ten)\s+(minute|min|hour|day|week|month|year)s?\b", body) \
        or re.search(r"\bevery\s+()(minute|min|hour|day|week|month|year)s?\b", body)
    unit = None
    if m:
        qty, unit = m.group(1), m.group(2)
        step = 2 if qty == "other" else (int(_num(qty)) if qty else 1)
    if unit in ("minute", "min", "hour"):
        return validate({"kind": "interval", "seconds": step * _UNIT_SECONDS[unit], "start": now.isoformat()}, now)
    if re.search(r"\bhourly\b", body):
        return validate({"kind": "interval", "seconds": 3600, "start": now.isoformat()}, now)

    days = _days_in(body)
    if re.search(r"\b(weekdays?|workdays?|work days?|business days?)\b", body):
        days = [0, 1, 2, 3, 4]
    elif re.search(r"\bweekends?\b", body):
        days = [5, 6]
    if re.search(r"\b(month|monthly)\b", body) or unit == "month":
        m_day = re.search(r"\b(?:the\s+)?(\d{1,2})(?:st|nd|rd|th)\b", body) or re.search(r"\bon\s+(?:day\s+)?(\d{1,2})\b", body)
        last = bool(re.search(r"\blast day\b", body))
        if not m_day and not last:
            raise ScheduleError("Which day of the month? e.g. 'every month on the 15th at 09:00'. " + FORMATS_HELP)
        return validate({"kind": "monthly", "day": -1 if last else int(m_day.group(1)), "time": t, "every": step, "start": now.date().isoformat()}, now)
    if re.search(r"\b(year|yearly|annually)\b", body) or unit == "year":
        d, _ = _date_in(body, now)
        if d is None:
            raise ScheduleError("Which date each year? e.g. 'every year on March 3 at 9am'.")
        return validate({"kind": "yearly", "month": d.month, "day": d.day, "time": t, "every": step, "start": now.date().isoformat()}, now)
    if days or unit == "week" or re.search(r"\bweekly\b", body):
        if not days:
            days = [now.weekday()]
        return validate({"kind": "weekdays", "days": days, "time": t, "every": step, "start": now.date().isoformat()}, now)
    if unit == "day" or re.search(r"\b(daily|every day|each day|everyday|every night|every morning|every evening)\b", body) or re.search(r"\bevery\b", body):
        if when_time is None and re.search(r"\bevery morning\b", body):
            t = "08:00"
        elif when_time is None and re.search(r"\bevery (evening|night)\b", body):
            t = "20:00" if "evening" in body else "22:00"
        if step > 1 and when_time is None:        # "every 2 days": same time of day as now, counting from today
            t = now.strftime("%H:%M")
        return validate({"kind": "daily", "time": t, "every": step, "start": now.date().isoformat()}, now)
    raise ScheduleError(f"I couldn't read '{raw}' as a repeating schedule. " + FORMATS_HELP)
