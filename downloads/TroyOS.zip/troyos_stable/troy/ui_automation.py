"""
TROYOS STABLE - Windows UI Automation

Gives Troy a structured, ground-truth view of what's actually in a native
Windows application -- the desktop equivalent of what web_read_page/
web_click give it for a web page. Instead of a vision model guessing
pixel coordinates from a screenshot (click_target), this reads the real
accessibility tree Windows itself exposes -- the same API screen readers
use -- so it sees every control's actual name, type, position, and state,
and can click/type into a specific one directly rather than clicking
where it *thinks* that element probably is.

Built on the `uiautomation` package (a pure-Python wrapper over Windows'
UI Automation COM interfaces). Windows-only, like most of this file's
other tools, and degrades to a clear "not installed" message rather than
crashing if it's missing.

Every UIA call is wrapped defensively: COM automation is notoriously
flaky -- a control can vanish mid-read, or throw on a property access
that should be harmless -- so nothing here lets one bad element take down
the whole inspection. Traversal is depth- and count-capped so a huge,
deeply-nested window (a browser, an IDE) can't produce an unusably long
or slow result.
"""

MAX_DEPTH = 6
MAX_ELEMENTS = 150
# Structural container types with no name of their own are pure visual
# noise in a tree listing -- skip them (their children still get walked).
_SKIP_IF_UNNAMED = {"Pane", "Group", "Custom", "Separator"}


def _import_uia():
    try:
        import uiautomation as auto
    except ImportError as exc:
        raise RuntimeError(
            "Desktop UI inspection needs the 'uiautomation' package: pip install uiautomation"
        ) from exc
    return auto


def _safe(fn, default=""):
    try:
        return fn()
    except Exception:  # noqa: BLE001
        return default


def _rect_tuple(control):
    def _read():
        r = control.BoundingRectangle
        return (r.left, r.top, r.width, r.height)
    return _safe(_read, None)


def _describe(control) -> dict:
    return {
        "type": _safe(lambda: control.ControlTypeName, "?"),
        "name": _safe(lambda: control.Name, ""),
        "automation_id": _safe(lambda: control.AutomationId, ""),
        "enabled": _safe(lambda: control.IsEnabled, True),
        "rect": _rect_tuple(control),
    }


def _get_window_control(query: str):
    """query="" -> the current foreground window. Otherwise, the first
    top-level window whose title contains query (case-insensitive)."""
    auto = _import_uia()
    query = (query or "").strip().lower()

    if not query:
        hwnd = _safe(lambda: auto.GetForegroundWindow(), None)
        if not hwnd:
            return None
        return _safe(lambda: auto.ControlFromHandle(hwnd), None)

    desktop = auto.GetRootControl()
    for win in _safe(lambda: list(desktop.GetChildren()), []):
        name = _safe(lambda: win.Name, "")
        if query in name.lower():
            return win
    return None


def _walk(control, depth=0, budget=None):
    """Yields (control, depth), depth- and count-capped."""
    if budget is None:
        budget = [MAX_ELEMENTS]
    if depth > MAX_DEPTH or budget[0] <= 0:
        return
    yield control, depth
    budget[0] -= 1
    for child in _safe(lambda: list(control.GetChildren()), []):
        if budget[0] <= 0:
            return
        yield from _walk(child, depth + 1, budget)


def inspect_window(query: str = "") -> dict:
    """Reads the real control tree of a window -- every element's actual
    type, name, automation id, position, and enabled state -- instead of
    a vision model's guess from a screenshot. query="" inspects whatever
    window currently has focus; otherwise the first top-level window
    whose title contains query."""
    try:
        window = _get_window_control(query)
    except RuntimeError as exc:
        return {"success": False, "message": str(exc)}
    if window is None:
        target = f"matching '{query}'" if query else "in the foreground"
        return {"success": False, "message": f"No window {target} found."}

    lines = []
    for control, depth in _walk(window):
        info = _describe(control)
        if not info["name"] and info["type"] in _SKIP_IF_UNNAMED:
            continue
        indent = "  " * depth
        rect = f" @{info['rect']}" if info["rect"] else ""
        state = "" if info["enabled"] else " (disabled)"
        aid = f" [id={info['automation_id']}]" if info["automation_id"] else ""
        lines.append(f"{indent}{info['type']}: \"{info['name']}\"{aid}{rect}{state}")

    title = _safe(lambda: window.Name, "(untitled)")
    if not lines:
        return {
            "success": True,
            "message": f"'{title}' has no readable controls -- it may be a canvas/game/custom-rendered UI (try screenshot instead).",
        }
    return {"success": True, "message": f"'{title}':\n" + "\n".join(lines)}


def _find_element(window, query: str):
    """Exact name/automation-id match wins immediately; otherwise the
    first substring match found while walking (breadth-first-ish, since
    _walk yields parents before children)."""
    query = (query or "").strip().lower()
    best = None
    for control, _depth in _walk(window):
        name = _safe(lambda: control.Name, "")
        aid = _safe(lambda: control.AutomationId, "")
        if query == name.lower() or (aid and query == aid.lower()):
            return control
        if best is None and (query in name.lower() or (aid and query in aid.lower())):
            best = control
    return best


def click_element(arg: str) -> dict:
    """arg: '<element name/description>' or '<element>|<window title>'.
    Finds the real control by its accessible name and clicks it directly
    -- reliable for native Windows apps where click_target would have to
    guess pixel coordinates from a screenshot."""
    try:
        _import_uia()
    except RuntimeError as exc:
        return {"success": False, "message": str(exc)}

    parts = arg.split("|", 1)
    element_query = parts[0].strip()
    window_query = parts[1].strip() if len(parts) > 1 else ""
    if not element_query:
        return {"success": False, "message": "click_element needs an element name/description."}

    window = _get_window_control(window_query)
    if window is None:
        target = f"matching '{window_query}'" if window_query else "in the foreground"
        return {"success": False, "message": f"No window {target} found."}

    element = _find_element(window, element_query)
    if element is None:
        window_name = _safe(lambda: window.Name, "?")
        return {"success": False, "message": f"No element matching '{element_query}' found in '{window_name}'."}

    try:
        element.Click()
    except Exception as exc:  # noqa: BLE001
        return {"success": False, "message": f"Found '{element_query}' but couldn't click it: {exc}"}

    name = _safe(lambda: element.Name, element_query)
    return {"success": True, "message": f"Clicked '{name}'."}


def type_into_element(arg: str) -> dict:
    """arg: '<element>|<text>' or '<element>|<text>|<window title>'.
    Prefers setting the value directly through the accessibility API (no
    simulated keystrokes, works even if the control isn't focused);
    falls back to a real click + keystrokes for controls that don't
    support that."""
    try:
        _import_uia()
    except RuntimeError as exc:
        return {"success": False, "message": str(exc)}

    parts = arg.split("|", 2)
    if len(parts) < 2:
        return {"success": False, "message": "type_into_element needs '<element>|<text>[|<window>]'."}
    element_query, text = parts[0].strip(), parts[1]
    window_query = parts[2].strip() if len(parts) > 2 else ""
    if not element_query:
        return {"success": False, "message": "type_into_element needs an element to type into."}

    window = _get_window_control(window_query)
    if window is None:
        target = f"matching '{window_query}'" if window_query else "in the foreground"
        return {"success": False, "message": f"No window {target} found."}

    element = _find_element(window, element_query)
    if element is None:
        return {"success": False, "message": f"No element matching '{element_query}' found."}

    try:
        value_pattern = element.GetValuePattern()
        if value_pattern is None:
            raise RuntimeError("control doesn't support the Value pattern")
        value_pattern.SetValue(text)
        return {"success": True, "message": f"Set '{element_query}' to the given text."}
    except Exception:  # noqa: BLE001 - fall through to click + keystrokes
        pass

    try:
        element.Click()
        element.SendKeys(text)
        return {"success": True, "message": f"Typed into '{element_query}'."}
    except Exception as exc:  # noqa: BLE001
        return {"success": False, "message": f"Found '{element_query}' but couldn't type into it: {exc}"}


def get_foreground_window_info(_arg: str = "") -> dict:
    """A quick, structural (non-visual) answer to 'what actually has
    focus right now' -- name, window class, and exact bounding box."""
    try:
        auto = _import_uia()
    except RuntimeError as exc:
        return {"success": False, "message": str(exc)}

    hwnd = _safe(lambda: auto.GetForegroundWindow(), None)
    if not hwnd:
        return {"success": True, "message": "No window currently has focus."}
    control = _safe(lambda: auto.ControlFromHandle(hwnd), None)
    if control is None:
        return {"success": True, "message": "A window has focus but its details couldn't be read."}

    name = _safe(lambda: control.Name, "(untitled)")
    class_name = _safe(lambda: control.ClassName, "?")
    rect = _rect_tuple(control)
    rect_str = f", bounds {rect}" if rect else ""
    return {"success": True, "message": f"'{name}' (class={class_name}{rect_str})"}
