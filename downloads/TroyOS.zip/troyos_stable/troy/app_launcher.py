"""
Launching programs directly, without driving the keyboard.

The original open_app pressed the Windows key, typed the name and pressed
Enter. That works, but it steals keyboard focus, races with whatever the user
is typing, and misfires if the Start menu is slow. This module starts the
program itself:

  1. a URI / existing path           -> opened with the OS handler
  2. well-known aliases ("calculator" -> calc, "vs code" -> code, ...)
  3. PATH, then the Windows "App Paths" registry keys
  4. Start Menu shortcuts (.lnk) matched by name, tolerant of typos
  5. Microsoft Store / UWP apps (Get-StartApps -> shell:AppsFolder)
  6. macOS `open -a` and Linux `gtk-launch` / PATH

Which method open_app uses is the APP_LAUNCH_MODE setting; the model-facing
command is always just open_app:<name>.
"""

import difflib
import json
import os
import re
import shutil
import subprocess
import sys
import threading
import time
import webbrowser

from . import config
from .logger import logger

IS_WINDOWS = sys.platform == "win32"
IS_MAC = sys.platform == "darwin"

# spoken/typed name -> things to try, best first
ALIASES = {
    "firefox": ["firefox"], "mozilla firefox": ["firefox"],
    "chrome": ["chrome", "google-chrome", "google chrome"], "google chrome": ["chrome", "google-chrome"],
    "edge": ["msedge", "microsoft-edge"], "microsoft edge": ["msedge"], "brave": ["brave", "brave-browser"],
    "notepad": ["notepad"], "calculator": ["calc", "gnome-calculator"], "calc": ["calc"],
    "paint": ["mspaint"], "explorer": ["explorer"], "file explorer": ["explorer"], "files": ["explorer", "nautilus"],
    "terminal": ["wt", "gnome-terminal"], "windows terminal": ["wt"], "cmd": ["cmd"], "command prompt": ["cmd"],
    "powershell": ["powershell"], "task manager": ["taskmgr"], "control panel": ["control"],
    "settings": ["ms-settings:"], "windows settings": ["ms-settings:"],
    "vscode": ["code"], "vs code": ["code"], "visual studio code": ["code"], "code": ["code"],
    "word": ["winword"], "excel": ["excel"], "powerpoint": ["powerpnt"], "outlook": ["outlook"], "onenote": ["onenote"],
    "spotify": ["spotify"], "discord": ["discord"], "steam": ["steam"], "vlc": ["vlc"], "obs": ["obs64", "obs"],
    "telegram": ["telegram"], "slack": ["slack"], "zoom": ["zoom"], "teams": ["teams", "ms-teams"],
    "snipping tool": ["snippingtool"], "camera": ["microsoft.windows.camera:"],
}
_SCHEME = re.compile(r"^[a-z][a-z0-9+.-]+:[^\\/]", re.IGNORECASE)


def _norm(text: str) -> str:
    return re.sub(r"[^a-z0-9]+", " ", text.lower()).strip()


def _spawn(argv, shell=False, cwd=None):
    kwargs = {"cwd": cwd, "close_fds": True, "stdin": subprocess.DEVNULL, "stdout": subprocess.DEVNULL, "stderr": subprocess.DEVNULL}
    if IS_WINDOWS:
        kwargs["creationflags"] = 0x00000008 | 0x00000200      # DETACHED_PROCESS | CREATE_NEW_PROCESS_GROUP
    else:
        kwargs["start_new_session"] = True
    subprocess.Popen(argv, shell=shell, **kwargs)


def _startfile(target: str):
    if IS_WINDOWS:
        os.startfile(target)                                    # noqa: S606 - user-directed launch
    elif IS_MAC:
        subprocess.Popen(["open", target])
    else:
        subprocess.Popen(["xdg-open", target], stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)


# ---------------------------------------------------------------- lookups
def _app_paths_lookup(exe_name: str):
    """Windows 'App Paths' registry: where an installer registered an exe."""
    if not IS_WINDOWS:
        return None
    try:
        import winreg
    except ImportError:
        return None
    key = exe_name if exe_name.lower().endswith(".exe") else exe_name + ".exe"
    for hive in (winreg.HKEY_CURRENT_USER, winreg.HKEY_LOCAL_MACHINE):
        try:
            with winreg.OpenKey(hive, rf"SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\{key}") as k:
                path, _ = winreg.QueryValueEx(k, "")
                path = os.path.expandvars(str(path).strip('"'))
                if os.path.exists(path):
                    return path
        except OSError:
            continue
    return None


def find_executable(name: str):
    """PATH, then App Paths, then the usual install folders."""
    found = shutil.which(name)
    if found:
        return found
    found = _app_paths_lookup(name)
    if found:
        return found
    if IS_WINDOWS:
        base = name.lower().replace(".exe", "")
        roots = [os.environ.get(v, "") for v in ("ProgramFiles", "ProgramFiles(x86)", "LOCALAPPDATA")]
        guesses = {
            "firefox": [r"Mozilla Firefox\firefox.exe"], "chrome": [r"Google\Chrome\Application\chrome.exe"],
            "msedge": [r"Microsoft\Edge\Application\msedge.exe"], "brave": [r"BraveSoftware\Brave-Browser\Application\brave.exe"],
        }.get(base, [])
        for root in roots:
            for rel in guesses:
                candidate = os.path.join(root, rel)
                if root and os.path.exists(candidate):
                    return candidate
    return None


_index_cache = {"at": 0.0, "items": {}}


def _start_menu_roots():
    roots = []
    for var, rel in (("ProgramData", r"Microsoft\Windows\Start Menu\Programs"), ("APPDATA", r"Microsoft\Windows\Start Menu\Programs")):
        base = os.environ.get(var)
        if base:
            roots.append(os.path.join(base, rel))
    return roots


def start_menu_index(roots=None, refresh=False) -> dict:
    """normalized shortcut name -> path, for every .lnk/.url/.appref-ms in the Start Menu."""
    now = time.time()
    if roots is None and not refresh and now - _index_cache["at"] < 120 and _index_cache["items"]:
        return _index_cache["items"]
    items = {}
    for root in (roots if roots is not None else _start_menu_roots()):
        for folder, _dirs, files in os.walk(root):
            for f in files:
                stem, ext = os.path.splitext(f)
                if ext.lower() in (".lnk", ".url", ".appref-ms"):
                    key = _norm(stem)
                    if key and not re.search(r"uninstall|readme|help|license", key):
                        items.setdefault(key, os.path.join(folder, f))
    if roots is None:
        _index_cache.update(at=now, items=items)
    return items


def best_match(query: str, names, cutoff: float = 0.72):
    """Exact > prefix > word match > substring > fuzzy. Returns a key from `names` or None."""
    q = _norm(query)
    if not q:
        return None
    names = list(names)
    if q in names:
        return q
    for test in (lambda n: n.startswith(q), lambda n: q in n.split(), lambda n: q in n):
        hits = sorted((n for n in names if test(n)), key=len)
        if hits:
            return hits[0]
    close = difflib.get_close_matches(q, names, n=1, cutoff=cutoff)
    return close[0] if close else None


_uwp_cache = {"at": 0.0, "apps": {}}


def uwp_apps() -> dict:
    """Store / UWP apps: normalized name -> AppUserModelID (Windows only; cached)."""
    if not IS_WINDOWS:
        return {}
    now = time.time()
    if now - _uwp_cache["at"] < 600 and _uwp_cache["apps"]:
        return _uwp_cache["apps"]
    apps = {}
    try:
        out = subprocess.run(
            ["powershell", "-NoProfile", "-NonInteractive", "-Command", "Get-StartApps | ConvertTo-Json -Compress"],
            capture_output=True, text=True, timeout=10, encoding="utf-8", errors="replace",
        ).stdout
        data = json.loads(out) if out.strip() else []
        if isinstance(data, dict):
            data = [data]
        for entry in data:
            if entry.get("Name") and entry.get("AppID"):
                apps.setdefault(_norm(entry["Name"]), entry["AppID"])
    except Exception as exc:  # noqa: BLE001 - optional discovery
        logger.debug("Get-StartApps failed: %s", exc)
    _uwp_cache.update(at=now, apps=apps)
    return apps


# ----------------------------------------------------------------- launch
def launch(name: str) -> dict:
    """Starts `name` directly. Returns {"success", "message"}; never raises."""
    name = (name or "").strip().strip('"')
    if not name:
        return {"success": False, "message": "open_app called with no app name."}
    try:
        return _launch(name)
    except Exception as exc:  # noqa: BLE001
        logger.warning("Direct launch of %r failed: %s", name, exc)
        return {"success": False, "message": f"Couldn't launch '{name}' directly: {exc}"}


def _ok(name, how):
    return {"success": True, "message": f"Opened '{name}' directly ({how})."}


def _launch(name: str) -> dict:
    # 1. a URI such as ms-settings: or an existing file/folder
    if _SCHEME.match(name) or (name.endswith(":") and " " not in name):
        _startfile(name)
        return _ok(name, "URI")
    expanded = os.path.expandvars(os.path.expanduser(name))
    if os.path.exists(expanded):
        _startfile(expanded)
        return _ok(name, "path")

    # 2/3. aliases, PATH, App Paths
    key = _norm(name)
    candidates = list(ALIASES.get(key, [])) + [name, key.replace(" ", ""), key.replace(" ", "-")]
    for cand in dict.fromkeys(candidates):
        if cand.endswith(":"):
            _startfile(cand)
            return _ok(name, f"URI {cand}")
        exe = find_executable(cand)
        if exe:
            lower = exe.lower()
            if lower.endswith((".cmd", ".bat")):
                _spawn(f'"{exe}"', shell=True, cwd=os.path.dirname(exe))
            elif lower.endswith((".lnk", ".url")):
                _startfile(exe)
            else:
                _spawn([exe], cwd=os.path.dirname(exe) or None)
            return _ok(name, exe)

    # 4. Start Menu shortcuts
    if IS_WINDOWS:
        index = start_menu_index()
        hit = best_match(name, index)
        if hit:
            _startfile(index[hit])
            return _ok(name, f"Start Menu shortcut '{hit}'")
        # 5. Store apps
        apps = uwp_apps()
        hit = best_match(name, apps)
        if hit:
            subprocess.Popen(["explorer.exe", rf"shell:AppsFolder\{apps[hit]}"])
            return _ok(name, f"Store app '{hit}'")
    elif IS_MAC:
        if subprocess.run(["open", "-a", name], capture_output=True).returncode == 0:
            return _ok(name, "open -a")
    else:
        gtk = shutil.which("gtk-launch")
        if gtk and subprocess.run([gtk, key.replace(" ", "-")], capture_output=True).returncode == 0:
            return _ok(name, "gtk-launch")
    return {"success": False, "message": f"Couldn't find an app called '{name}' to launch directly."}


# ---------------------------------------------------------------- browsers
BROWSERS = {
    "firefox": (["firefox"], lambda exe, url: [exe, "-new-tab", url]),
    "chrome": (["chrome", "google-chrome", "google-chrome-stable", "chromium"], lambda exe, url: [exe, "--new-tab", url]),
    "edge": (["msedge", "microsoft-edge"], lambda exe, url: [exe, "--new-tab", url]),
    "brave": (["brave", "brave-browser"], lambda exe, url: [exe, "--new-tab", url]),
}


def launch_browser_url(url: str, browser: str = None) -> dict:
    """Opens `url` in a NEW TAB of a specific browser (Firefox by default for
    YouTube), falling back to the system default browser if it isn't installed."""
    url = (url or "").strip()
    if not re.match(r"^https?://", url, re.IGNORECASE):
        return {"success": False, "message": f"Refusing to open '{url[:60]}': only http(s) links can be opened."}
    browser = (browser or config.YOUTUBE_BROWSER or "default").strip().lower()
    spec = BROWSERS.get(browser)
    if spec:
        names, build = spec
        for n in names:
            exe = find_executable(n)
            if exe:
                try:
                    _spawn(build(exe, url))
                    return {"success": True, "message": f"Opened {url} in a new {browser} tab."}
                except Exception as exc:  # noqa: BLE001
                    logger.warning("Launching %s failed: %s", browser, exc)
                    break
        note = f" ({browser} wasn't found, so the default browser was used)"
    else:
        note = ""
    webbrowser.open_new_tab(url)
    return {"success": True, "message": f"Opened {url} in the default browser{note}."}
