"""
Ways to reach Troy from other devices.

Right now there are three "transports" for the phone page:
  * LAN        http://<this PC's Wi-Fi address>:<port>
  * LAN HTTPS  https://<same address>:<port+1> -- a self-signed certificate served
               by Troy itself (troy/tls.py) purely so the phone's browser will
               allow the microphone on plain Wi-Fi
  * Tailscale  http://<100.x tailnet address>:<port>, or -- if `tailscale serve`
               is on -- https://<pc>.<tailnet>.ts.net, which works from
               anywhere (mobile data, another network), is end-to-end
               encrypted by WireGuard, and is a "secure context" so phone
               browsers allow voice input and install-to-home-screen.

Everything that wants to know "how can a device connect?" calls access_urls(),
so adding another transport later (a Cloudflare tunnel, a relay, ...) means
adding one function here and one entry there -- no UI or server changes.

Tailscale is driven through its own CLI (no API keys). Every call has a short
timeout and degrades to "not installed" rather than raising.
"""

import json
import os
import re
import shutil
import subprocess
import sys
import time

from . import config, mobile_server
from .logger import logger

_cache = {"at": 0.0, "value": None}
_TTL = 5.0


def find_tailscale_cli():
    found = shutil.which("tailscale")
    if found:
        return found
    candidates = []
    if sys.platform == "win32":
        for var in ("ProgramFiles", "ProgramFiles(x86)"):
            if os.environ.get(var):
                candidates.append(os.path.join(os.environ[var], "Tailscale", "tailscale.exe"))
    elif sys.platform == "darwin":
        candidates.append("/Applications/Tailscale.app/Contents/MacOS/Tailscale")
    for c in candidates:
        if os.path.exists(c):
            return c
    return None


def _run(args, timeout=6):
    cli = find_tailscale_cli()
    if not cli:
        raise FileNotFoundError("tailscale")
    kwargs = {"capture_output": True, "text": True, "timeout": timeout, "encoding": "utf-8", "errors": "replace"}
    if sys.platform == "win32":
        kwargs["creationflags"] = 0x08000000                   # CREATE_NO_WINDOW
    return subprocess.run([cli, *args], **kwargs)


def tailscale_status(force: bool = False) -> dict:
    """{installed, running, state, ip, dns_name, tailnet, hostname, peers: [...], error}"""
    now = time.time()
    if not force and _cache["value"] is not None and now - _cache["at"] < _TTL:
        return _cache["value"]
    info = {"installed": False, "running": False, "state": "NotInstalled", "ip": "", "dns_name": "", "tailnet": "",
            "hostname": "", "peers": [], "serving": False, "error": ""}
    if find_tailscale_cli():
        info["installed"], info["state"] = True, "Unknown"
        try:
            out = _run(["status", "--json"])
            data = json.loads(out.stdout or "{}")
            info["state"] = data.get("BackendState", "Unknown")
            info["running"] = info["state"] == "Running"
            me = data.get("Self") or {}
            ips = me.get("TailscaleIPs") or data.get("TailscaleIPs") or []
            info["ip"] = next((i for i in ips if "." in i), ips[0] if ips else "")
            info["dns_name"] = (me.get("DNSName") or "").rstrip(".")
            info["hostname"] = me.get("HostName", "")
            info["tailnet"] = (data.get("CurrentTailnet") or {}).get("Name", "")
            for peer in (data.get("Peer") or {}).values():
                pip = next((i for i in (peer.get("TailscaleIPs") or []) if "." in i), "")
                info["peers"].append({"name": (peer.get("HostName") or "").strip(), "ip": pip, "os": peer.get("OS", ""), "online": bool(peer.get("Online"))})
            info["peers"].sort(key=lambda p: (not p["online"], p["name"].lower()))
            if info["state"] == "NeedsLogin":
                info["error"] = "Tailscale is installed but signed out. Open Tailscale and log in."
            elif info["state"] == "Stopped":
                info["error"] = "Tailscale is turned off. Turn it on from the tray icon."
        except subprocess.TimeoutExpired:
            info["error"] = "Tailscale didn't answer in time."
        except (OSError, ValueError) as exc:
            info["error"] = f"Couldn't read Tailscale's status: {exc}"
        info["serving"] = _serving_https() if info["running"] else False
    _cache.update(at=now, value=info)
    return info


def _serving_https() -> bool:
    try:
        out = _run(["serve", "status"], timeout=4)
        return "https://" in (out.stdout or "") and str(mobile_server.current_port() or "") in (out.stdout or "")
    except Exception:  # noqa: BLE001 - older CLIs: treat as not serving
        return False


def tailscale_serve(enable: bool, port: int = None) -> dict:
    """Turns HTTPS-over-Tailscale on or off for the phone page.
    Needs HTTPS enabled once for the tailnet in Tailscale's admin console."""
    port = port or mobile_server.current_port() or config.MOBILE_UI_PORT
    if not find_tailscale_cli():
        return {"success": False, "message": "Tailscale isn't installed. Get it from https://tailscale.com/download"}
    try:
        if not enable:
            for args in (["serve", "reset"], ["serve", "--https=443", "off"]):
                out = _run(args)
                if out.returncode == 0:
                    break
            _cache["value"] = None
            return {"success": True, "message": "HTTPS sharing turned off."}
        attempts = (["serve", "--bg", "--https=443", f"http://127.0.0.1:{port}"], ["serve", "--bg", str(port)])
        last = ""
        for args in attempts:                       # the CLI's syntax changed between versions
            out = _run(args, timeout=20)
            text = ((out.stdout or "") + (out.stderr or "")).strip()
            if out.returncode == 0:
                _cache["value"] = None
                url = re.search(r"https://[^\s]+", text)
                return {"success": True, "message": "HTTPS sharing is on.", "url": url.group(0).rstrip("/") if url else ""}
            last = text
        hint = ""
        if "https" in last.lower() and ("not enabled" in last.lower() or "enable" in last.lower()):
            hint = " Enable HTTPS certificates for your tailnet at https://login.tailscale.com/admin/dns first."
        return {"success": False, "message": (last[:240] or "tailscale serve failed.") + hint}
    except subprocess.TimeoutExpired:
        return {"success": False, "message": "Tailscale didn't answer in time. If it is waiting for you to approve something, check your browser."}
    except OSError as exc:
        return {"success": False, "message": f"Couldn't run Tailscale: {exc}"}


def access_urls(token: str = "") -> list:
    """Every address the phone page can be reached at, best first:
    [{kind, label, url, recommended, detail}]."""
    port = mobile_server.current_port()
    if not port:
        return []
    suffix = f"/?t={token}" if token else "/"
    urls = []
    ts = tailscale_status()
    if ts["running"] and ts["dns_name"] and ts["serving"]:
        urls.append({"kind": "tailscale-https", "label": "Tailscale (HTTPS, from anywhere)", "url": f"https://{ts['dns_name']}{suffix}",
                     "detail": "Encrypted, works on mobile data, allows voice input."})
    https_url = mobile_server.https_url()
    if https_url:
        urls.append({"kind": "lan-https", "label": "Wi-Fi (HTTPS, same network)", "url": https_url,
                     "detail": "Lets the phone use its microphone. Self-signed: expect one browser warning, then accept it."})
    if ts["running"] and ts["ip"]:
        urls.append({"kind": "tailscale", "label": "Tailscale (from anywhere)", "url": f"http://{ts['ip']}:{port}{suffix}",
                     "detail": f"Needs Tailscale on the phone{' (' + ts['tailnet'] + ')' if ts['tailnet'] else ''}."})
    lan = mobile_server.lan_ip()
    if lan:
        urls.append({"kind": "lan", "label": "Wi-Fi (same network)", "url": f"http://{lan}:{port}{suffix}", "detail": "Only works while the phone is on the same Wi-Fi."})
    if urls:
        urls[0]["recommended"] = True
    for u in urls[1:]:
        u["recommended"] = False
    return urls
