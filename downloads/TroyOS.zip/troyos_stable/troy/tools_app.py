"""
Troy controlling its own app.

The user can already do all of this by clicking; these tools let Troy do it when
asked ("switch to widget mode", "start a new chat", "turn on power saving",
"make the voice faster", "use the light theme"). Everything goes through the same
code paths as the UI: settings through settings_store (validated, saved, announced
to every window), interface actions through troy/ui_bridge.py as `ui.command`
events that main.js and the renderers carry out.

Guard rails: secrets and the model-switching permission can't be changed from
here, and settings that expose this PC to the network need a click on the
approval card.
"""

from . import config, confirmation, power, settings_store, ui_bridge
from .command_parser import split_args
from .tools_all import register

VIEWS = ("chat", "memory", "tasks", "tools", "logs", "settings")
PANES = ("providers", "models", "performance", "general", "voice", "integrations", "appearance", "widget", "power", "remote", "about")
THEMES = ("dark", "light", "auto")
ACCENTS = ("periwinkle", "aqua", "mint", "rose", "amber")
LAYOUTS = ("split", "focus", "chat")
WIDGET_OPTIONS = {"onTop": bool, "autoCollapse": bool, "hotkey": str}

# Troy may not touch these itself.
_REFUSED = {"ALLOW_MODEL_SWITCH": "That switch decides whether I may change my own model, so only you can flip it (Settings > Models)."}
# Exposing this PC on the network: allowed, but only after an explicit click.
_NEEDS_APPROVAL = {"MOBILE_SCREEN_ENABLED", "MOBILE_VOICE_ENABLED", "MOBILE_HTTPS_ENABLED", "BROWSER_HEADLESS", "LMSTUDIO_ENABLED", "VACUUM_ENABLED", "VACUUM_HOST"}
_BOOL_WORDS = {"on": True, "true": True, "yes": True, "1": True, "enable": True, "off": False, "false": False, "no": False, "0": False, "disable": False}


def _announce(keys, source="troy"):
    settings_store.notify(set(keys), source)


def _show(value):
    return "set" if value not in ("", None) else "empty"


# ------------------------------------------------------------------ widget / full app
def show_widget(_arg: str = "") -> dict:
    """Switches to widget mode: the small always-on-top pill at the top of the screen (the full app hides)."""
    ok = ui_bridge.command("mode", mode="widget")
    return {"success": ok, "message": "Switched to the widget (the full app is hidden)." if ok else "The interface isn't connected right now."}


def hide_widget(_arg: str = "") -> dict:
    """Hides the widget completely (the global hotkey or the tray icon brings it back)."""
    ok = ui_bridge.command("mode", mode="hidden")
    return {"success": ok, "message": "Widget hidden. The hotkey or tray icon brings it back." if ok else "The interface isn't connected right now."}


def toggle_widget(_arg: str = "") -> dict:
    ok = ui_bridge.command("mode", mode="toggle")
    return {"success": ok, "message": "Toggled the widget." if ok else "The interface isn't connected right now."}


def open_full_app(_arg: str = "") -> dict:
    """Opens the full Troy window (the widget hides while it is open)."""
    ok = ui_bridge.command("mode", mode="app")
    return {"success": ok, "message": "Opened the full app (the widget is hidden meanwhile)." if ok else "The interface isn't connected right now."}


def ui_status(_arg: str = "") -> dict:
    """What the user is looking at right now, plus power saving and the voice/model basics."""
    s = ui_bridge.state()
    p = power.status()
    mode = {"widget": "the widget", "app": "the full app", "hidden": "nothing (widget hidden)"}.get(s.get("mode"), "unknown")
    bits = [f"showing: {mode}"]
    for key, label in (("view", "view"), ("theme", "theme"), ("layout", "layout")):
        if s.get(key):
            bits.append(f"{label}: {s[key]}")
    bits.append(f"power saving: {p['mode']}{' (active)' if p['active'] else ''}{' on battery' if p['on_battery'] else ''}")
    bits.append(f"model: {config.TEXT_MODEL_OVERRIDE or 'automatic'} (primary provider {config.PRIMARY_PROVIDER})")
    return {"success": True, "message": " | ".join(bits)}


# ------------------------------------------------------------------ chats and views
def new_chat(_arg: str = "") -> dict:
    """Starts a fresh chat (after this reply is finished)."""
    when = ui_bridge.request_new_chat()
    return {"success": True, "message": "Started a new chat." if when == "now" else "I'll start a fresh chat as soon as I finish this reply."}


def open_view(arg: str) -> dict:
    """Opens a screen of the full app: chat, memory, tools, logs, settings (settings also takes a pane)."""
    parts = [p.strip().lower() for p in split_args(arg) if p.strip()]
    view = parts[0] if parts else ""
    if view in PANES and view not in VIEWS:       # "open_view:voice" means Settings > Voice
        parts, view = ["settings", view], "settings"
    if view not in VIEWS:
        return {"success": False, "message": f"Unknown view '{view}'. Views: {', '.join(VIEWS)}; settings panes: {', '.join(PANES)}."}
    pane = parts[1] if len(parts) > 1 else ""
    if pane and pane not in PANES:
        return {"success": False, "message": f"Unknown settings pane '{pane}'. Panes: {', '.join(PANES)}."}
    ui_bridge.command("view", view=view, pane=pane)
    return {"success": True, "message": f"Opened {view}{' > ' + pane if pane else ''} in the full app."}


def set_appearance(arg: str) -> dict:
    """Theme / accent colour / layout of the full app: set_appearance:<theme|accent|layout>|<value>."""
    parts = [p.strip().lower() for p in split_args(arg)]
    if len(parts) < 2:
        return {"success": False, "message": f"Use set_appearance:<theme|accent|layout>|<value>. Themes: {', '.join(THEMES)}; accents: {', '.join(ACCENTS)}; layouts: {', '.join(LAYOUTS)}."}
    key, value = parts[0], parts[1]
    allowed = {"theme": THEMES, "accent": ACCENTS, "layout": LAYOUTS}
    if key not in allowed:
        return {"success": False, "message": f"Unknown appearance option '{key}'. Options: theme, accent, layout."}
    if value not in allowed[key]:
        return {"success": False, "message": f"'{value}' isn't a valid {key}. Choose one of: {', '.join(allowed[key])}."}
    ui_bridge.command("appearance", key=key, value=value)
    return {"success": True, "message": f"Changed the {key} to {value}."}


def set_widget_option(arg: str) -> dict:
    """Widget behaviour: set_widget_option:<onTop|autoCollapse|hotkey>|<value>."""
    parts = split_args(arg)
    if len(parts) < 2 or parts[0].strip() not in WIDGET_OPTIONS:
        return {"success": False, "message": "Use set_widget_option:<onTop|autoCollapse|hotkey>|<value> (booleans: on/off; hotkey like Ctrl+Alt+T)."}
    key, raw = parts[0].strip(), parts[1].strip()
    if WIDGET_OPTIONS[key] is bool:
        if raw.lower() not in _BOOL_WORDS:
            return {"success": False, "message": f"{key} takes on or off."}
        value = _BOOL_WORDS[raw.lower()]
    else:
        if not raw or len(raw) > 40 or "+" not in raw:
            return {"success": False, "message": "A hotkey looks like Ctrl+Alt+T (modifier + key)."}
        value = raw
    ui_bridge.command("widget_option", key=key, value=value)
    return {"success": True, "message": f"Widget {key} set to {value}."}


# ------------------------------------------------------------------ settings + power
def list_settings(arg: str = "") -> dict:
    """Every setting Troy can read or change, with its current value (API keys are never shown)."""
    needle = (arg or "").strip().lower()
    rows = []
    for key in sorted(settings_store.SETTINGS):
        if needle and needle not in key.lower():
            continue
        val = getattr(config, key, "")
        rows.append(f"{key}={'<empty>' if val == '' else val}")
    if not rows:
        return {"success": False, "message": f"No setting matches '{arg}'."}
    return {"success": True, "message": "; ".join(rows[:60]) + ("; ..." if len(rows) > 60 else "") + "  -- change with change_setting:<KEY>|<value>"}


def change_setting(arg: str) -> dict:
    """Changes one setting exactly like the Settings screen does (validated, saved, announced)."""
    parts = split_args(arg)
    if len(parts) < 2:
        return {"success": False, "message": "Use change_setting:<KEY>|<value>. See list_settings."}
    key, raw = parts[0].strip().upper(), "|".join(parts[1:]).strip()
    if key in settings_store.SECRETS:
        return {"success": False, "message": "API keys can only be entered by the user (Settings > Providers)."}
    if key in _REFUSED:
        return {"success": False, "message": _REFUSED[key]}
    if key not in settings_store.SETTINGS:
        import difflib
        close = difflib.get_close_matches(key, list(settings_store.SETTINGS), n=3, cutoff=0.5)
        return {"success": False, "message": f"No setting called {key}." + (f" Did you mean {', '.join(close)}?" if close else " Use list_settings.")}
    try:
        value = settings_store._coerce(settings_store.SETTINGS[key], raw)
        settings_store.validate(key, value)
    except (TypeError, ValueError) as exc:
        return {"success": False, "message": str(exc) or f"Invalid value for {key}: {raw!r}"}

    def apply(_a=""):
        settings_store.apply_settings({key: value})
        _announce({key})
        note = " (applies after a restart)" if key in settings_store.RESTART_REQUIRED else ""
        return {"success": True, "message": f"{key} is now {value}{note}."}

    if key in _NEEDS_APPROVAL:
        confirmation.request("change_setting", f"{key}|{raw}", "medium", apply, f"Troy wants to change {key} to {value}. This affects what this PC exposes or runs.")
        return {"success": True, "pending": True, "message": f"Asked the user to approve changing {key} to {value}."}
    return apply()


def set_power_saving(arg: str) -> dict:
    """Power saving: off | auto (on while on battery) | on."""
    value = (arg or "").strip().lower()
    value = {"true": "on", "enable": "on", "yes": "on", "false": "off", "disable": "off", "no": "off", "battery": "auto"}.get(value, value)
    if value not in power.MODES:
        return {"success": False, "message": "Power saving is off, auto (on battery) or on."}
    settings_store.apply_settings({"POWER_SAVING": value})
    _announce({"POWER_SAVING"})
    s = power.status()
    return {"success": True, "message": f"Power saving is {value}" + (" and active right now." if s["active"] else (" (it will switch on when the laptop runs on battery)." if value == "auto" else "."))}


def power_status(_arg: str = "") -> dict:
    s = power.status()
    return {"success": True, "message": f"Power saving mode: {s['mode']}; active now: {s['active']}; on battery: {s['on_battery'] if s['on_battery'] is not None else 'unknown'}."}


register("show_widget", show_widget, "Switches Troy to widget mode: the small always-on-top pill at the top-centre of the screen (the full app hides).", category="app")
register("hide_widget", hide_widget, "Hides the widget completely (the global hotkey or tray icon brings it back).", category="app")
register("toggle_widget", toggle_widget, "Shows the widget if it's hidden, hides it if it's showing.", category="app")
register("open_full_app", open_full_app, "Opens the full Troy window (the widget hides while it's open).", category="app")
register("ui_status", ui_status, "What Troy's own interface is showing (widget or full app, view, theme), power saving, and the current model.", category="app", info=True)
register("new_chat", new_chat, "Starts a fresh chat (takes effect when this reply is finished).", category="app")
register("open_view", open_view, "Opens a screen of the full app: chat, memory, tools, logs or settings (+ pane: providers, models, performance, general, voice, integrations, appearance, widget, power, remote, about).", category="app", arg_hint="<view>[|<pane>]")
register("set_appearance", set_appearance, "Changes the full app's theme (dark/light/auto), accent colour or layout (split/focus/chat).", category="app", arg_hint="<theme|accent|layout>|<value>")
register("set_widget_option", set_widget_option, "Widget behaviour: stay above other windows (onTop), auto-collapse after replies (autoCollapse), or the global hotkey.", category="app", arg_hint="<onTop|autoCollapse|hotkey>|<value>")
register("list_settings", list_settings, "Lists Troy's settings and their current values (optionally filtered by a word).", category="app", info=True, arg_hint="[<filter>]")
register("change_setting", change_setting, "Changes one of Troy's settings like the Settings screen does (e.g. TTS_RATE|200, USER_NAME|Alex, VOICE_OUTPUT_ENABLED|on). Can't touch API keys.", category="app", arg_hint="<KEY>|<value>")
register("set_power_saving", set_power_saving, "Turns power saving off, auto (on while on battery) or on: calmer visuals and slower live updates.", category="app", arg_hint="<off|auto|on>")
register("power_status", power_status, "Whether power saving is active and whether the laptop is on battery.", category="app", info=True)
