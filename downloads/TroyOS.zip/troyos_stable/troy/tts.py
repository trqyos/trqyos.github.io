"""
Speech output.

Three things live here:

  * Engines turn a sentence into audio bytes. Windows' built-in voices ("sapi"),
    Microsoft's neural voices ("edge": natural, needs internet) and Piper
    (natural, fully offline). Every engine is optional; whichever isn't
    installed is skipped, and the chain always ends at the built-in voices.
  * A Player plays those bytes and can be cut off instantly (barge-in).
  * The Speaker ties them together as a small pipeline: a reply is cleaned for
    speech, split into sentences, and the NEXT sentence is synthesized while the
    current one is playing -- so speech starts after the first sentence is
    ready, not after the whole reply. stop() flushes everything at once.

The Speaker can also send sentences to a "sink" instead of the PC's speakers,
which is how Troy speaks through a phone (see troy/voice_mode.py).
"""

import os
import queue
import sys
import tempfile
import threading
import time

from . import config, speech_text
from .logger import logger

WAV, MP3 = "wav", "mp3"


# ---------------------------------------------------------------- engines
class Engine:
    name = "base"

    def available(self) -> tuple:
        return False, "not implemented"

    def voices(self) -> list:
        return []

    def synth(self, text: str) -> tuple:
        """-> (audio bytes, "wav" | "mp3")"""
        raise NotImplementedError


class SapiEngine(Engine):
    """Windows' built-in voices through pyttsx3, rendered to a WAV so the same
    pipeline (prefetch, barge-in, phone sink) works for every engine."""
    name = "sapi"

    def __init__(self):
        self._engine = None
        self._lock = threading.Lock()

    def _get(self):
        if self._engine is None:
            import pyttsx3
            self._engine = pyttsx3.init()
        return self._engine

    def available(self):
        try:
            import pyttsx3  # noqa: F401
            return True, ""
        except Exception as exc:  # noqa: BLE001
            return False, "pip install pyttsx3"

    def voices(self):
        try:
            with self._lock:
                return [{"id": v.id, "name": v.name} for v in self._get().getProperty("voices")]
        except Exception:  # noqa: BLE001
            return []

    def synth(self, text):
        with self._lock:
            eng = self._get()
            eng.setProperty("rate", config.TTS_RATE)
            if config.TTS_VOICE_ID:
                eng.setProperty("voice", config.TTS_VOICE_ID)
            fd, path = tempfile.mkstemp(suffix=".wav")
            os.close(fd)
            try:
                eng.save_to_file(text, path)
                eng.runAndWait()
                with open(path, "rb") as f:
                    data = f.read()
            finally:
                try:
                    os.remove(path)
                except OSError:
                    pass
        if len(data) < 100:
            raise RuntimeError("the built-in voice produced no audio")
        return data, WAV


class EdgeEngine(Engine):
    name = "edge"

    def available(self):
        try:
            import edge_tts  # noqa: F401
            return True, ""
        except Exception:  # noqa: BLE001
            return False, "pip install edge-tts"

    def voices(self):
        try:
            import asyncio
            import edge_tts
            return [{"id": v["ShortName"], "name": f"{v['ShortName']} ({v.get('Gender', '')})"}
                    for v in asyncio.run(edge_tts.list_voices()) if v.get("Locale", "").startswith(("en", "tr", "de", "fr", "es", "it"))][:80]
        except Exception:  # noqa: BLE001
            return []

    def synth(self, text):
        import asyncio
        import edge_tts
        rate = f"{int((config.TTS_RATE - 185) / 185 * 100):+d}%"

        async def run():
            out = b""
            async for chunk in edge_tts.Communicate(text, config.EDGE_VOICE, rate=rate).stream():
                if chunk["type"] == "audio":
                    out += chunk["data"]
            return out
        data = asyncio.run(run())
        if not data:
            raise RuntimeError("Edge returned no audio (offline?)")
        return data, MP3


class PiperEngine(Engine):
    name = "piper"

    def __init__(self):
        self._voice, self._path = None, None

    def available(self):
        if not config.PIPER_MODEL or not os.path.exists(config.PIPER_MODEL):
            return False, "set a Piper voice file (.onnx) in Settings > Voice"
        try:
            import piper  # noqa: F401
            return True, ""
        except Exception:  # noqa: BLE001
            return False, "pip install piper-tts"

    def synth(self, text):
        import io
        import wave
        from piper import PiperVoice
        if self._voice is None or self._path != config.PIPER_MODEL:
            self._voice, self._path = PiperVoice.load(config.PIPER_MODEL), config.PIPER_MODEL
        buf = io.BytesIO()
        with wave.open(buf, "wb") as w:
            self._voice.synthesize_wav(text, w) if hasattr(self._voice, "synthesize_wav") else self._voice.synthesize(text, w)
        return buf.getvalue(), WAV


_ENGINES = {"sapi": SapiEngine(), "edge": EdgeEngine(), "piper": PiperEngine()}


def engine_report() -> list:
    """For the settings screen: which engines can run here, and why not."""
    out = []
    for name, eng in _ENGINES.items():
        ok, why = eng.available()
        out.append({"id": name, "available": ok, "reason": why})
    return out


def engine_chain(preference: str = None) -> list:
    """Usable engines for `preference`, best first; the built-in voice is always the last resort."""
    pref = (preference or config.TTS_ENGINE or "auto").lower()
    order = {"auto": ["piper", "sapi"], "piper": ["piper", "sapi"], "edge": ["edge", "sapi"], "sapi": ["sapi"]}.get(pref, ["sapi"])
    return [_ENGINES[n] for n in order if _ENGINES[n].available()[0]]


def list_voices(engine: str = "sapi") -> list:
    eng = _ENGINES.get(engine)
    return eng.voices() if eng and eng.available()[0] else []


# ---------------------------------------------------------------- players
class Player:
    def play(self, data: bytes, fmt: str):
        raise NotImplementedError

    def stop(self):
        pass


class NullPlayer(Player):
    def play(self, data, fmt):
        logger.debug("NullPlayer: would play %d bytes of %s", len(data), fmt)


class WindowsPlayer(Player):
    """WAV through winsound, MP3 through the Windows media (MCI) API: no extra packages."""

    def __init__(self):
        self._alias = None
        self._stop = threading.Event()

    def play(self, data, fmt):
        self._stop.clear()
        if fmt == WAV:
            import winsound
            winsound.PlaySound(data, winsound.SND_MEMORY | winsound.SND_NODEFAULT)
            return
        import ctypes
        mci = ctypes.windll.winmm.mciSendStringW
        fd, path = tempfile.mkstemp(suffix=".mp3")
        os.close(fd)
        with open(path, "wb") as f:
            f.write(data)
        alias = f"troy{int(time.time() * 1000) % 100000}"
        try:
            mci(f'open "{path}" type mpegvideo alias {alias}', None, 0, None)
            self._alias = alias
            mci(f"play {alias}", None, 0, None)
            buf = ctypes.create_unicode_buffer(32)
            while not self._stop.is_set():
                mci(f"status {alias} mode", buf, 32, None)
                if buf.value != "playing":
                    break
                time.sleep(0.05)
        finally:
            mci(f"close {alias}", None, 0, None)
            self._alias = None
            try:
                os.remove(path)
            except OSError:
                pass

    def stop(self):
        self._stop.set()
        try:
            import winsound
            winsound.PlaySound(None, winsound.SND_PURGE)
        except Exception:  # noqa: BLE001
            pass


class SoundDevicePlayer(Player):
    """Cross-platform WAV playback (development machines, Linux, macOS)."""

    def play(self, data, fmt):
        if fmt != WAV:
            raise RuntimeError("this player only handles WAV")
        import sounddevice as sd
        from . import audio_in
        pcm, rate = audio_in.wav_to_pcm(data)
        sd.play(pcm, rate)
        sd.wait()

    def stop(self):
        try:
            import sounddevice as sd
            sd.stop()
        except Exception:  # noqa: BLE001
            pass


def default_player() -> Player:
    if sys.platform == "win32":
        return WindowsPlayer()
    try:
        import sounddevice  # noqa: F401
        return SoundDevicePlayer()
    except Exception:  # noqa: BLE001
        return NullPlayer()


# ---------------------------------------------------------------- speaker
class Speaker:
    """Sentence-streaming speech with instant interruption.

    on_speaking(bool): fired when audio starts / when everything has finished
                       (the microphone uses it to ignore Troy's own voice).
    sink(sentence, audio_or_None, fmt): when set, sentences go there instead of
                       the PC speakers (phone playback). `sink.wants_audio` says
                       whether it needs synthesized audio or just the text."""

    def __init__(self, engines=None, player: Player = None, on_speaking=None, prefetch: int = 2):
        self._engines = engines          # callable -> list[Engine]; None = engine_chain
        self.player = player or default_player()
        self.on_speaking = on_speaking or (lambda speaking: None)
        self.sink = None
        self._gen = 0
        self._lock = threading.Lock()
        self._todo = queue.Queue()
        self._ready = queue.Queue(maxsize=max(1, prefetch))
        self._pending = 0                # sentences not yet finished
        self._playing = False
        self._idle = threading.Event(); self._idle.set()
        self._threads = []
        self._warned = False

    # --- public
    @property
    def speaking(self) -> bool:
        return self._pending > 0

    def say(self, text: str, interrupt: bool = False, clean: bool = True) -> int:
        if interrupt:
            self.stop()
        speakable = speech_text.clean_for_speech(text) if clean else (text or "").strip()
        sentences = speech_text.split_sentences(speakable)
        if not sentences:
            return 0
        self._ensure_threads()
        with self._lock:
            gen = self._gen
            self._pending += len(sentences)
            self._idle.clear()
        for s in sentences:
            self._todo.put((gen, s))
        return len(sentences)

    def stop(self):
        """Silence now: drop everything queued and cut the audio that's playing."""
        with self._lock:
            self._gen += 1                     # anything still in flight belongs to a dead generation
            for q in (self._todo, self._ready):
                while True:
                    try:
                        q.get_nowait()
                    except queue.Empty:
                        break
            self._pending = 0
            self._idle.set()
        try:
            self.player.stop()
        except Exception:  # noqa: BLE001
            pass

    def wait_idle(self, timeout: float = None) -> bool:
        return self._idle.wait(timeout)

    # --- internals
    def _ensure_threads(self):
        if self._threads and all(t.is_alive() for t in self._threads):
            return
        self._threads = [threading.Thread(target=self._synth_loop, daemon=True, name="troy-tts-synth"),
                         threading.Thread(target=self._play_loop, daemon=True, name="troy-tts-play")]
        for t in self._threads:
            t.start()

    def _chain(self):
        return self._engines() if self._engines else engine_chain()

    def _finish_one(self, gen):
        with self._lock:
            if gen == self._gen:
                self._pending = max(0, self._pending - 1)
            if self._pending == 0 and self._ready.empty() and self._todo.empty():
                self._idle.set()

    def _synth_loop(self):
        while True:
            gen, sentence = self._todo.get()
            if gen != self._gen:
                continue
            wants_audio = True if self.sink is None else getattr(self.sink, "wants_audio", True)
            audio, fmt = None, WAV
            if wants_audio:
                for eng in self._chain():
                    try:
                        audio, fmt = eng.synth(sentence)
                        break
                    except Exception as exc:  # noqa: BLE001 - fall through to the next engine
                        logger.warning("Speech engine '%s' failed: %s", eng.name, exc)
                if audio is None:
                    if not self._warned:
                        logger.warning("No speech engine produced audio; replies will be silent.")
                        self._warned = True
                    self._finish_one(gen)
                    continue
            if gen != self._gen:
                continue
            try:
                self._ready.put((gen, sentence, audio, fmt), timeout=30)
            except queue.Full:
                self._finish_one(gen)

    def _play_loop(self):
        while True:
            gen, sentence, audio, fmt = self._ready.get()
            if gen != self._gen:
                continue
            with self._lock:
                first = not self._playing
                self._playing = True
            if first:
                self._safe_cb(True)
            try:
                if self.sink is not None:
                    self.sink(sentence, audio, fmt)
                else:
                    self.player.play(audio, fmt)
            except Exception as exc:  # noqa: BLE001
                logger.warning("Playback failed: %s", exc)
            self._finish_one(gen)
            with self._lock:
                done = self._pending == 0 and self._ready.empty() and self._todo.empty()
                if done:
                    self._playing = False
            if done:
                self._safe_cb(False)

    def _safe_cb(self, speaking):
        try:
            self.on_speaking(speaking)
        except Exception:  # noqa: BLE001
            logger.debug("on_speaking callback failed", exc_info=True)
