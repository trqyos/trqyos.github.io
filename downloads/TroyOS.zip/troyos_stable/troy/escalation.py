"""
Troy Assistant - Escalation

A last resort for when Troy genuinely can't do something itself: open
Gemini's web app (https://gemini.google.com/app), submit a structured
description of the problem as a plain-text prompt, and read the reply back
off the screen. Nothing more clever than that -- no API integration, no
headless browser, just the same web page a person would use, driven the
same way Troy drives everything else (webbrowser + pyautogui).

Reading the reply is text-only-first: OCR (troy/tools_all.py) runs against
the page before anything else, since it's free, local, and returns exact
text. If OCR comes back empty or clearly too short to be a real answer,
this falls back to a vision-model screenshot description
(troy/tools_all.py) as a second attempt.

This is intentionally best-effort. Gemini's UI can change, page load times
vary, and clicking at an estimated position is inherently fragile compared
to a real accessibility-tree integration -- but it satisfies the actual
goal: hand the problem to a second, more capable model, and bring back
something Troy can act on or relay to the user.

Suggested flow (see system_prompt.py for how this is described to the LLM):

    task fails
        -> escalate:<user_request>|<current_task>|<attempted>|<error>|<reason>
        -> Gemini's answer comes back as an [OBSERVATION]
        -> Troy tries the suggested solution
"""

import time

import pyautogui

from . import config, llm_client
from .logger import logger
from . import tools_all

try:
    import pyperclip
except ImportError:  # pragma: no cover - degrades to slower typewrite fallback
    pyperclip = None


ASSISTANT_CAPABILITIES = (
    "open and control desktop applications, browse the web, type and click, "
    "manage local files, read the screen (via OCR and a vision model), and "
    "remember durable facts about the user"
)


def build_prompt(
    model_name: str,
    user_request: str,
    current_task: str,
    attempted: str,
    error: str,
    reason: str,
) -> str:
    """Builds the structured prompt handed to Gemini. Keeping this in its
    own function (rather than inlined in escalate()) makes it easy to unit
    test or tweak the wording without touching the browser-automation part."""
    return f"""You are assisting an AI desktop assistant named Troy.

Troy is a private, personal desktop AI assistant. There is no public
documentation about its implementation, and you will not find information
about it online -- everything you need to know is in this message.

Troy can: {ASSISTANT_CAPABILITIES}.
Troy is currently running on: {model_name}

USER REQUEST:
{user_request or "(not provided)"}

CURRENT TASK:
{current_task or "(not provided)"}

WHAT TROY ALREADY ATTEMPTED:
{attempted or "(nothing specific attempted yet)"}

CURRENT ERROR / LIMITATION:
{error or "(no specific error -- Troy determined it cannot do this itself)"}

WHY TROY IS ESCALATING:
{reason or "(not provided)"}

Provide the best possible solution.

Your response MUST use this exact structure:

SOLUTION:
[practical solution, described plainly]

STEPS:
[numbered steps]

IF TROY CAN IMPLEMENT IT:
[concrete implementation instructions Troy could follow using only the
capabilities listed above]

IF TROY CANNOT IMPLEMENT IT:
[a clear, honest response Troy can relay directly to its user]

RISKS OR WARNINGS:
[important warnings, or NONE]

Do not assume undocumented capabilities.
Do not invent APIs or tools that were not listed above.
Prefer simple and reliable solutions over clever ones.
Keep the whole response under 250 words.
"""


def _submit_via_clipboard_or_typing(prompt: str):
    """Pastes if pyperclip is available (fast, exact), otherwise types the
    prompt out character by character (slower, and risks autocorrect/IME
    interference, but works with zero extra dependencies)."""
    if pyperclip is not None:
        try:
            pyperclip.copy(prompt)
            pyautogui.hotkey("ctrl", "v")
            return
        except Exception as exc:  # noqa: BLE001
            logger.warning("Clipboard paste failed, falling back to typing: %s", exc)
    pyautogui.typewrite(prompt, interval=0.005)


def _read_reply(stop_check=None) -> str:
    """Text-only OCR first (cheap, exact, no network call); vision model as
    a fallback if OCR didn't find enough to be a real answer."""
    ocr_result = tools_all.read_screen_text()
    text = ocr_result.get("message", "") if ocr_result.get("success") else ""
    if text and len(text) > 60 and "No readable text" not in text:
        return text

    if stop_check is not None and stop_check():
        return text or "(stopped before a full reply could be read)"

    try:
        vision_result = tools_all.take_screenshot_and_describe()
        vision_text = vision_result.get("message", "")
        if vision_result.get("success") and vision_text:
            return vision_text
    except Exception as exc:  # noqa: BLE001
        logger.warning("Vision fallback during escalation failed: %s", exc)

    return text or "(couldn't read a reply off the screen)"


def escalate(
    user_request: str = "",
    current_task: str = "",
    attempted: str = "",
    error: str = "",
    reason: str = "",
    stop_check=None,
) -> dict:
    if not config.ESCALATION_ENABLED:
        return {"success": False, "message": "Escalation is disabled in configuration."}

    prompt = build_prompt(
        llm_client.current_text_model_label(),
        user_request,
        current_task,
        attempted,
        error,
        reason,
    )

    logger.info("Escalating to Gemini. Reason: %s", reason or "(none given)")

    try:
        import webbrowser
        import pyperclip

        webbrowser.open(config.ESCALATION_URL)

        # Give Gemini time to load.
        time.sleep(4.5)

        if stop_check is not None and stop_check():
            return {
                "success": False,
                "message": "Escalation stopped by user before the prompt was sent.",
            }

        # ---------------------------------------------------------
        # Gemini compose box position
        #
        # Based on the Gemini layout:
        #   X ~= 58% of screen width
        #   Y ~= 52% of screen height
        #
        # Example on 1536x922:
        #   X ~= 891
        #   Y ~= 479
        # ---------------------------------------------------------
        screen_w, screen_h = pyautogui.size()

        compose_x = int(screen_w * 0.58)
        compose_y = int(screen_h * 0.52)

        logger.info(
            "Clicking Gemini compose box at (%d, %d) on %dx%d screen",
            compose_x,
            compose_y,
            screen_w,
            screen_h,
        )

        pyautogui.click(compose_x, compose_y)
        time.sleep(0.4)

        # Put the entire prompt into the clipboard.
        pyperclip.copy(prompt)

        # Explicit Ctrl+V paste.
        pyautogui.hotkey("ctrl", "v")
        time.sleep(0.8)

        if stop_check is not None and stop_check():
            return {
                "success": False,
                "message": "Escalation stopped by user before submission.",
            }

        # Send the prompt.
        pyautogui.press("enter")

        # Poll for a reply instead of one long fixed sleep.
        waited = 0.0
        while waited < 20.0:
            if stop_check is not None and stop_check():
                return {
                    "success": False,
                    "message": "Escalation stopped by user while waiting for a reply.",
                }

            time.sleep(1.0)
            waited += 1.0

        reply = _read_reply(stop_check=stop_check)

        logger.info(
            "Escalation reply captured (%d chars).",
            len(reply),
        )

        return {
            "success": True,
            "message": reply,
        }

    except Exception as exc:  # noqa: BLE001
        logger.exception("Escalation failed")
        return {
            "success": False,
            "message": f"Escalation failed: {exc}",
        }