"""
Local MIoT client: the encrypted miIO UDP protocol (port 54321) that Xiaomi/Mijia devices speak on the LAN.

Why this exists instead of `python-miio`: that package drags in a dozen dependencies, is unmaintained and breaks on
new Python versions. The protocol itself is tiny, and Troy already ships `cryptography`, so this is ~200 lines with
nothing new to install. It is synchronous on purpose (Troy's tools are plain functions running on worker threads).

Wire format (all integers big-endian):

    0   2  magic 0x2131
    2   2  total packet length (header + encrypted payload)
    4   4  unknown, always 0
    8   4  device id            (from the hello reply)
    12  4  stamp                (device clock in seconds; must keep increasing)
    16 16  checksum = MD5(header[0:16] + token + payload)   (the hello packet is all 0xFF)
    32  n  payload = AES-128-CBC(JSON + NUL), key = MD5(token), iv = MD5(key + token), PKCS7

Conversation: send the 32-byte hello, learn (device id, stamp), then send requests {"id", "method", "params"} and
read the reply with the same id.

Things the real S20+ taught the people who wrote about it (see docs/VACUUM.md), all handled here:
  * the hello can be dropped now and then            -> the handshake retries;
  * a busy robot accepts a command but never acks it -> `MiotAckTimeout`, which callers treat as "verify the state";
  * the robot answers `code: 0` even to payloads it ignores -> never trust an ack alone (the controller checks state).
"""

import hashlib
import json
import socket
import struct
import threading
import time

from cryptography.hazmat.primitives import padding
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes

PORT = 54321
MAGIC = 0x2131
HELLO = bytes.fromhex("21310020") + b"\xff" * 28
# Properties per get_properties request. Several Xiaomi robots refuse big batches; 5 is what other integrations use.
CHUNK = 5


class MiotError(Exception):
    """Base class for everything this module raises."""


class MiotConnectionError(MiotError):
    """Nothing (valid) came back: wrong IP, robot offline, firewall, or UDP 54321 blocked."""


class MiotTokenError(MiotError):
    """The robot answers the hello but ignores/garbles everything else. A real robot silently drops packets whose
    checksum doesn't match, so this is what a wrong token looks like (a busy or sleeping robot can look the same)."""


class MiotAckTimeout(MiotError):
    """The robot said "user ack timeout": it received the command but did not acknowledge it. Often still executed."""


class MiotDeviceError(MiotError):
    def __init__(self, code, message=""):
        super().__init__(f"device error {code}: {message}".strip())
        self.code = code
        self.message = message


def parse_token(token) -> bytes:
    """32 hex characters -> 16 bytes. Raises ValueError with a message meant for the user."""
    text = str(token or "").strip().replace(" ", "")
    if len(text) == 96:
        raise ValueError("That is a 96-character (encrypted Bluetooth) token. The WiFi token is 32 hex characters.")
    if len(text) != 32:
        raise ValueError(f"The token must be 32 hexadecimal characters (it has {len(text)}).")
    try:
        return bytes.fromhex(text)
    except ValueError:
        raise ValueError("The token may only contain 0-9 and a-f.") from None


def _md5(data: bytes) -> bytes:
    return hashlib.md5(data).digest()  # noqa: S324 - the protocol mandates MD5


def _key_iv(token: bytes):
    key = _md5(token)
    return key, _md5(key + token)


def encrypt(plain: bytes, token: bytes) -> bytes:
    key, iv = _key_iv(token)
    padder = padding.PKCS7(128).padder()
    enc = Cipher(algorithms.AES(key), modes.CBC(iv)).encryptor()
    return enc.update(padder.update(plain) + padder.finalize()) + enc.finalize()


def decrypt(data: bytes, token: bytes) -> bytes:
    key, iv = _key_iv(token)
    dec = Cipher(algorithms.AES(key), modes.CBC(iv)).decryptor()
    unpadder = padding.PKCS7(128).unpadder()
    return unpadder.update(dec.update(data) + dec.finalize()) + unpadder.finalize()


def frame(device_id: bytes, stamp: int, token: bytes, plaintext: bytes) -> bytes:
    """Header + checksum + encrypted payload for an already-serialized request (NUL terminator included by the caller)."""
    data = encrypt(plaintext, token)
    header = struct.pack(">HHI4sI", MAGIC, 32 + len(data), 0, device_id, stamp & 0xFFFFFFFF)
    return header + _md5(header + token + data) + data


def build_packet(device_id: bytes, stamp: int, token: bytes, payload: dict) -> bytes:
    return frame(device_id, stamp, token, json.dumps(payload, separators=(",", ":")).encode() + b"\x00")


def parse_packet(packet: bytes, token: bytes):
    """-> (device_id, stamp, payload_dict_or_None). Raises MiotTokenError on a bad checksum / undecryptable payload."""
    if len(packet) < 32 or struct.unpack(">H", packet[:2])[0] != MAGIC:
        raise MiotConnectionError("Got a reply that isn't a miIO packet.")
    length = struct.unpack(">H", packet[2:4])[0]
    device_id, stamp = packet[8:12], struct.unpack(">I", packet[12:16])[0]
    data = packet[32:length]
    if not data:
        return device_id, stamp, None
    if _md5(packet[:16] + token + data) != packet[16:32]:
        raise MiotTokenError("The robot's reply failed verification: the token is wrong.")
    try:
        raw = decrypt(data, token).rstrip(b"\x00")
    except ValueError:
        raise MiotTokenError("Couldn't decrypt the robot's reply: the token is wrong.") from None
    return device_id, stamp, _loads(raw)


def _loads(raw: bytes):
    # Some firmwares emit slightly malformed JSON (doubled commas, leading zeros); python-miio carries the same fixes.
    for fixed in (raw, raw.replace(b",,", b","), raw.replace(b'"value":00', b'"value":0')):
        try:
            return json.loads(fixed.decode("utf-8", "replace"))
        except ValueError:
            continue
    raise MiotConnectionError("The robot sent a reply that isn't valid JSON.")


class MiotClient:
    """One robot. Thread-safe (calls are serialized); each exchange uses a fresh socket, so a changed network or a
    stale socket can never wedge it."""

    def __init__(self, host: str, token, port: int = PORT, timeout: float = 3.0, handshake_tries: int = 3):
        self.host = str(host or "").strip()
        if not self.host:
            raise ValueError("No IP address set for the robot.")
        self.token = token if isinstance(token, bytes) else parse_token(token)
        self.port, self.timeout, self.handshake_tries = port, float(timeout), max(1, int(handshake_tries))
        self._lock = threading.Lock()
        self._id = int(time.time()) % 9000 + 100
        self._device_id = None
        self._skew = 0
        self._session_at = 0.0

    # ------------------------------------------------------------------ transport
    def _stamp(self) -> int:
        return int(time.time()) + self._skew

    def _recv(self, sock, deadline):
        while True:
            left = deadline - time.monotonic()
            if left <= 0:
                raise socket.timeout()
            sock.settimeout(left)
            data, addr = sock.recvfrom(4096)
            if addr[0] == self.host:
                return data

    def _handshake(self, sock):
        last = None
        for _ in range(self.handshake_tries):
            try:
                sock.sendto(HELLO, (self.host, self.port))
                reply = self._recv(sock, time.monotonic() + min(self.timeout, 1.5))
            except OSError as exc:  # timeout is an OSError too
                last = exc
                continue
            if len(reply) < 32 or struct.unpack(">H", reply[:2])[0] != MAGIC:
                last = MiotConnectionError("Unexpected reply to the hello.")
                continue
            self._device_id = reply[8:12]
            self._skew = struct.unpack(">I", reply[12:16])[0] - int(time.time())
            self._session_at = time.monotonic()
            return
        raise MiotConnectionError(
            f"The robot at {self.host} didn't answer. Check the IP address, that it is online, "
            f"and that nothing blocks UDP port {self.port}." + (f" ({last})" if isinstance(last, OSError) and last.args else ""))

    def _exchange(self, method: str, params, *, tries: int):
        """One request/response. `tries` is how many times the packet may be sent (1 for anything not idempotent)."""
        with self._lock:
            sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            try:
                if self._device_id is None or time.monotonic() - self._session_at > 20:
                    self._handshake(sock)
                self._id += 1
                req_id = self._id
                payload = {"id": req_id, "method": method, "params": params}
                for attempt in range(tries):
                    try:
                        sock.sendto(build_packet(self._device_id, self._stamp(), self.token, payload), (self.host, self.port))
                        deadline = time.monotonic() + self.timeout
                        while True:
                            _, _, body = parse_packet(self._recv(sock, deadline), self.token)
                            if isinstance(body, dict) and body.get("id") == req_id:
                                return body
                    except socket.timeout:
                        if attempt + 1 < tries:
                            self._handshake(sock)     # the stamp may have gone stale; resync, then resend
                            continue
                        self._device_id = None        # force a fresh handshake next time
                        if tries > 1:                 # reads/sets were retried: the robot is there but not answering
                            raise MiotTokenError(
                                "The robot is reachable but ignored the request. The usual cause is a wrong token "
                                "(a real robot silently drops packets it can't verify); a sleeping or busy robot can do it too.") from None
                        raise MiotAckTimeout("The robot did not reply in time.") from None
                    except OSError as exc:
                        self._device_id = None
                        raise MiotConnectionError(f"Network error talking to {self.host}: {exc}") from None
                raise MiotAckTimeout("The robot did not reply in time.")
            finally:
                sock.close()

    def call(self, method: str, params=None, *, idempotent: bool = True):
        body = self._exchange(method, [] if params is None else params, tries=3 if idempotent else 1)
        err = body.get("error")
        if err:
            code = err.get("code") if isinstance(err, dict) else err
            msg = err.get("message", "") if isinstance(err, dict) else ""
            if code == -9999 or "ack timeout" in str(msg).lower():
                raise MiotAckTimeout(msg or "user ack timeout")
            raise MiotDeviceError(code, msg)
        return body.get("result")

    # ------------------------------------------------------------------ MIoT
    def info(self) -> dict:
        """miIO.info: model, firmware, MAC. A successful reply also proves host and token are right."""
        result = self.call("miIO.info")
        return result if isinstance(result, dict) else {}

    def get_properties(self, props) -> dict:
        """[(siid, piid), ...] -> {(siid, piid): value}. Properties the robot doesn't have (code != 0) are left out."""
        props, out = list(props), {}
        for i in range(0, len(props), CHUNK):
            part = props[i:i + CHUNK]
            result = self.call("get_properties", [{"did": f"{s}-{p}", "siid": s, "piid": p} for s, p in part]) or []
            for item in result:
                if isinstance(item, dict) and item.get("code") == 0 and "value" in item:
                    out[(item.get("siid"), item.get("piid"))] = item["value"]
        return out

    def set_property(self, siid: int, piid: int, value) -> None:
        result = self.call("set_properties", [{"did": f"{siid}-{piid}", "siid": siid, "piid": piid, "value": value}]) or []
        item = result[0] if result and isinstance(result[0], dict) else {}
        if item.get("code", 0) not in (0, 1):
            raise MiotDeviceError(item.get("code"), "the robot refused that value")

    def action(self, siid: int, aiid: int, args=()) -> dict:
        """Runs an action. `args` entries are bare values or {"piid": n, "value": v}. Sent exactly once (not idempotent);
        a MiotAckTimeout means "probably delivered": check the robot's state."""
        result = self.call("action", {"did": f"call-{siid}-{aiid}", "siid": siid, "aiid": aiid, "in": list(args)}, idempotent=False)
        if isinstance(result, dict) and result.get("code", 0) != 0:
            raise MiotDeviceError(result.get("code"), "the robot refused that action")
        return result if isinstance(result, dict) else {}
