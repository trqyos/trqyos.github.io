"""
TROYOS STABLE - Voice

Speech-to-text has two interchangeable engines (config.STT_ENGINE):

  "google" (default) -- the free, keyless Google Web Speech endpoint via
    the `SpeechRecognition` package. Needs only an internet connection and
    `pip install SpeechRecognition` -- no account, no API key, no model
    download. This is what Google's own Chrome dictation feature uses
    under the hood. It's rate-limited and not meant for heavy/commercial
    use, but for a personal assistant it's the simplest thing that works.

  "whisper" -- faster-whisper, running fully offline/locally (GPU if
    ctranslate2 detects a CUDA one, CPU otherwise). No internet needed
    once the model's downloaded, no rate limit, nothing leaves the
    machine -- at the cost of a one-time model download and meaningfully
    more setup than the Google option. See README > Voice setup.

Both take the same input (a mono int16 PCM numpy array + its sample rate)
and return the same thing (recognized text, or "" if nothing was said) --
troy/wake_listener.py doesn't need to know or care which one is active.

Text-to-speech is unchanged: pyttsx3, driving Windows' own SAPI5 voices --
offline, no model download, no GPU needed.

Every piece here degrades to a clear, one-time log message (not a crash)
if its optional dependency isn't installed, since none of them are
required for the rest of the app to work.
"""

import queue
import threading

from . import config
from .logger import logger


class VoiceError(Exception):
    pass


# ---------------------------------------------------------------------------
# Speech-to-text
# ---------------------------------------------------------------------------

_whisper_model = None
_whisper_lock = threading.Lock()


def transcribe(audio_int16, samplerate: int) -> str:
    """Recognizes speech from a mono int16 PCM numpy array using whichever
    engine config.STT_ENGINE selects. Returns "" (never raises) if nothing
    usable was heard or the engine failed -- the caller (wake_listener)
    treats that as silence, not an error to surface."""
    if audio_int16 is None or audio_int16.size < samplerate // 4:  # under ~0.25s
        return ""
    engine = (config.STT_ENGINE or "google").strip().lower()
    try:
        if engine == "whisper":
            return _transcribe_whisper(audio_int16, samplerate)
        return _transcribe_google(audio_int16, samplerate)
    except VoiceError as exc:
        logger.warning(str(exc))
        return ""
    except Exception as exc:  # noqa: BLE001
        logger.warning("Transcription failed (%s engine): %s", engine, exc)
        return ""


def _transcribe_google(audio_int16, samplerate: int) -> str:
    try:
        import speech_recognition as sr
    except ImportError as exc:
        raise VoiceError(
            "Google speech-to-text needs the 'SpeechRecognition' package: pip install SpeechRecognition"
        ) from exc

    recognizer = sr.Recognizer()
    audio_data = sr.AudioData(audio_int16.tobytes(), samplerate, 2)  # 2 bytes/sample = int16
    try:
        kwargs = {"language": config.STT_LANGUAGE} if config.STT_LANGUAGE else {}
        return recognizer.recognize_google(audio_data, **kwargs).strip()
    except sr.UnknownValueError:
        return ""  # recognized silence/noise -- not an error
    except sr.RequestError as exc:
        raise VoiceError(f"Google speech-to-text request failed (are you online?): {exc}") from exc


def _get_whisper_model():
    global _whisper_model
    with _whisper_lock:
        if _whisper_model is not None:
            return _whisper_model
        try:
            from faster_whisper import WhisperModel
        except ImportError as exc:
            raise VoiceError(
                "Whisper speech-to-text needs the 'faster-whisper' package: pip install faster-whisper"
            ) from exc

        device_attempts = (
            [("cuda", "float16"), ("cpu", "int8")]
            if config.WHISPER_DEVICE == "auto"
            else [(config.WHISPER_DEVICE, "float16" if config.WHISPER_DEVICE == "cuda" else "int8")]
        )
        last_error = None
        for device, compute_type in device_attempts:
            try:
                _whisper_model = WhisperModel(config.WHISPER_MODEL_SIZE, device=device, compute_type=compute_type)
                logger.info("Whisper model '%s' loaded on %s.", config.WHISPER_MODEL_SIZE, device)
                return _whisper_model
            except Exception as exc:  # noqa: BLE001 - fall through to the next candidate device
                last_error = exc
                continue
        raise VoiceError(
            f"Couldn't load the Whisper model on any device: {last_error}. "
            f"First run downloads it from Hugging Face -- check your connection, "
            f"or switch Settings > Voice > Speech engine to Google instead."
        )


def _transcribe_whisper(audio_int16, samplerate: int) -> str:
    import numpy as np
    model = _get_whisper_model()
    if samplerate != 16000:
        # wake_listener always captures at 16kHz; this only matters if
        # transcribe() is ever called directly with something else.
        logger.warning("Whisper expects 16kHz audio, got %dHz -- results may be poor.", samplerate)
    audio_float = audio_int16.astype(np.float32) / 32768.0
    segments, _info = model.transcribe(audio_float, language=config.STT_LANGUAGE or None, vad_filter=True,
                                         initial_prompt=f"{config.WAKE_WORD or 'Troy'}. Open, close, volume, YouTube, Firefox, weather.", condition_on_previous_text=False)
    return " ".join(seg.text.strip() for seg in segments).strip()


# ---------------------------------------------------------------------------
# Text-to-speech
# ---------------------------------------------------------------------------

_tts_engine = None
_tts_queue: "queue.Queue" = queue.Queue()
_tts_thread = None
_tts_lock = threading.Lock()


def _tts_worker():
    global _tts_engine
    try:
        import pyttsx3
    except ImportError:
        logger.warning("Voice output needs the 'pyttsx3' package (pip install pyttsx3).")
        return
    try:
        _tts_engine = pyttsx3.init()
        _tts_engine.setProperty("rate", config.TTS_RATE)
        if config.TTS_VOICE_ID:
            _tts_engine.setProperty("voice", config.TTS_VOICE_ID)
    except Exception as exc:  # noqa: BLE001
        logger.warning("Couldn't initialize text-to-speech: %s", exc)
        return

    while True:
        text = _tts_queue.get()
        if text is None:  # shutdown sentinel
            break
        try:
            # Re-applied before every utterance so changing the rate or
            # voice in settings takes effect immediately, not after a restart.
            _tts_engine.setProperty("rate", config.TTS_RATE)
            if config.TTS_VOICE_ID:
                _tts_engine.setProperty("voice", config.TTS_VOICE_ID)
            _tts_engine.say(text)
            _tts_engine.runAndWait()
        except Exception as exc:  # noqa: BLE001
            logger.warning("Text-to-speech failed: %s", exc)


def speak(text: str):
    """Queues text to be read aloud. Non-blocking -- returns immediately;
    a dedicated worker thread does the actual (blocking) speech so this
    never stalls the GUI thread it's typically called from."""
    global _tts_thread
    text = (text or "").strip()
    if not text:
        return
    with _tts_lock:
        if _tts_thread is None or not _tts_thread.is_alive():
            _tts_thread = threading.Thread(target=_tts_worker, daemon=True, name="troy-tts")
            _tts_thread.start()
    _tts_queue.put(text)


def list_voices() -> list:
    """Returns [(id, name), ...] for the Settings dropdown. Safe to call
    even if pyttsx3 isn't installed (returns an empty list)."""
    try:
        import pyttsx3
        engine = pyttsx3.init()
        voices = [(v.id, v.name) for v in engine.getProperty("voices")]
        engine.stop()
        return voices
    except Exception:  # noqa: BLE001
        return []


def stt_status() -> dict:
    """Can speech-to-text run here, with the engine that's selected?"""
    engine = config.STT_ENGINE
    try:
        if engine == "whisper":
            import faster_whisper  # noqa: F401
        else:
            import speech_recognition  # noqa: F401
        return {"engine": engine, "available": True, "reason": ""}
    except Exception:  # noqa: BLE001
        need = "faster-whisper" if engine == "whisper" else "SpeechRecognition"
        return {"engine": engine, "available": False, "reason": f"pip install {need}"}
