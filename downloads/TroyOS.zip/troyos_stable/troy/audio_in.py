"""
Microphone audio helpers shared by the PC microphone and the phone.

Endpointer is the heart: it watches a stream of small audio frames and cuts it
into utterances -- when does speech start, when has the person finished.
Getting this right is most of what makes a voice assistant feel good:

  * the noise floor is learned continuously, so a quiet room and a noisy one
    both work without a threshold to tune;
  * speech must last a moment to count (a cough or a door isn't a command);
  * a short pre-roll is kept, so the first syllable isn't clipped;
  * it waits ~0.7 s of silence before deciding you're finished, but gives up
    after `max_seconds` so a TV in the background can't make it listen forever.

It works on 16-bit mono PCM and has no hardware or network dependency, so it's
tested with synthetic audio.
"""

import io
import struct
import wave

import numpy as np

RATE = 16000


def rms(pcm: np.ndarray) -> float:
    if pcm.size == 0:
        return 0.0
    x = pcm.astype(np.float32)
    return float(np.sqrt(np.mean(x * x)))


def to_int16(data) -> np.ndarray:
    """bytes (little-endian int16) or an array -> int16 array."""
    if isinstance(data, (bytes, bytearray, memoryview)):
        return np.frombuffer(bytes(data), dtype="<i2")
    return np.asarray(data).astype(np.int16)


def resample(pcm: np.ndarray, src_rate: int, dst_rate: int = RATE) -> np.ndarray:
    """Linear resampling of mono int16 audio (plenty for speech recognition)."""
    if src_rate == dst_rate or pcm.size == 0:
        return pcm
    n = int(round(pcm.size * dst_rate / src_rate))
    x_old = np.linspace(0.0, 1.0, pcm.size, endpoint=False)
    x_new = np.linspace(0.0, 1.0, n, endpoint=False)
    return np.interp(x_new, x_old, pcm.astype(np.float32)).astype(np.int16)


def wav_bytes(pcm: np.ndarray, rate: int = RATE) -> bytes:
    buf = io.BytesIO()
    with wave.open(buf, "wb") as w:
        w.setnchannels(1); w.setsampwidth(2); w.setframerate(rate)
        w.writeframes(to_int16(pcm).tobytes())
    return buf.getvalue()


def wav_to_pcm(data: bytes):
    """-> (int16 mono array, rate) from WAV bytes."""
    with wave.open(io.BytesIO(data), "rb") as w:
        rate, ch = w.getframerate(), w.getnchannels()
        pcm = np.frombuffer(w.readframes(w.getnframes()), dtype="<i2")
        if ch > 1:
            pcm = pcm.reshape(-1, ch).mean(axis=1).astype(np.int16)
    return pcm, rate


class Endpointer:
    def __init__(self, rate: int = RATE, frame_ms: int = 30, start_ms: int = 150, end_silence_ms: int = 700,
                 preroll_ms: int = 300, min_seconds: float = 0.4, max_seconds: float = 20.0,
                 margin: float = 2.6, abs_min: float = 220.0, floor_init: float = 120.0, calibrate_ms: int = 360):
        self.rate = rate
        self.frame = int(rate * frame_ms / 1000)
        self.frame_ms = frame_ms
        self.start_frames = max(1, start_ms // frame_ms)
        self.end_frames = max(1, end_silence_ms // frame_ms)
        self.preroll_frames = max(0, preroll_ms // frame_ms)
        self.min_samples = int(rate * min_seconds)
        self.max_samples = int(rate * max_seconds)
        self.margin, self.abs_min = margin, abs_min
        self.floor = floor_init
        self.calibration_frames = max(0, calibrate_ms // frame_ms)      # first moments: just listen to the room
        self._seen = 0
        self.sensitivity = 1.0              # >1 = needs louder speech (used while Troy is talking)
        self.reset()

    def reset(self):
        self._buf = np.zeros(0, dtype=np.int16)         # leftover samples < one frame
        self._pre = []                                  # recent quiet frames
        self._speech = []                               # frames of the utterance in progress
        self._voiced_run = 0
        self._quiet_run = 0
        self.in_speech = False

    @property
    def threshold(self) -> float:
        return max(self.abs_min, self.floor * self.margin) * self.sensitivity

    def feed(self, data) -> list:
        """Feed raw samples; returns events: ("level", rms) per frame,
        ("start",) when speech begins, ("end", int16 audio) when it finishes,
        ("discard", reason) for blips too short to be speech."""
        events = []
        pcm = np.concatenate([self._buf, to_int16(data)])
        n = pcm.size // self.frame
        for i in range(n):
            frame = pcm[i * self.frame:(i + 1) * self.frame]
            level = rms(frame)
            events.append(("level", level))
            if self._seen < self.calibration_frames:
                self._seen += 1
                self.floor = 0.55 * self.floor + 0.45 * level            # learn the room's noise level quickly
                continue
            voiced = level > self.threshold
            if not self.in_speech:
                if not voiced:
                    self.floor = 0.96 * self.floor + 0.04 * level        # learn the room
                    self._voiced_run = 0
                    self._pre.append(frame)
                    self._pre = self._pre[-(self.preroll_frames + self.start_frames):]
                    continue
                self._voiced_run += 1
                self._pre.append(frame)
                if self._voiced_run >= self.start_frames:
                    self.in_speech = True
                    self._speech = list(self._pre[-(self.preroll_frames + self._voiced_run):])
                    self._quiet_run = 0
                    events.append(("start",))
            else:
                self._speech.append(frame)
                self._quiet_run = 0 if voiced else self._quiet_run + 1
                total = sum(f.size for f in self._speech)
                if self._quiet_run >= self.end_frames or total >= self.max_samples:
                    audio = np.concatenate(self._speech)
                    keep = audio.size - self._quiet_run * self.frame                  # trim most of the trailing silence
                    audio = audio[:max(self.min_samples, keep + self.frame * 3)]
                    events.append(("end", audio) if audio.size >= self.min_samples else ("discard", "too short"))
                    self._speech, self._pre, self._voiced_run, self._quiet_run, self.in_speech = [], [], 0, 0, False
        self._buf = pcm[n * self.frame:]
        return events


def has_speech(pcm: np.ndarray, rate: int = RATE) -> bool:
    """Server-side sanity check on an uploaded utterance: is anything in it
    clearly louder than its own quiet parts? (Stops silence and hiss being sent to speech-to-text.)"""
    if pcm.size < rate * 0.25:
        return False
    frame = int(rate * 0.03)
    levels = np.array([rms(pcm[i:i + frame]) for i in range(0, pcm.size - frame, frame)])
    if levels.size == 0:
        return False
    floor = max(np.percentile(levels, 20), 60.0)
    loud = np.sum(levels > max(250.0, floor * 2.5))
    return bool(loud >= 4)
