"""
TROYOS STABLE - Phone web page server

A small stdlib-only HTTP server (no extra dependency) that serves the phone
page -- the same look as the desktop app, with Troy's animated face, the chat,
approvals, and a live view of the PC's screen -- and bridges it to the SAME
TroyAgent the desktop app is running. Not a second assistant, not a cloud
relay: anything sent from the phone runs through the same agent loop, tools
and memory, and both surfaces see the same conversation live (Server-Sent
Events).

Reach it over the same Wi-Fi, or from anywhere through Tailscale (see
troy/remote.py, which also knows the right URLs). Everything except the page's
own static files needs the access token, which is generated once and kept in
troy_mobile_token.txt so a link saved on the phone keeps working.

Endpoints
  GET  /                      the page (static)         GET /assets/<file>  its scripts/styles
  GET  /api/state             history, status, pending approvals, screen + voice info
  GET  /api/stream            Server-Sent Events: messages, tool steps, state, approvals, voice
  POST /api/send {text}       send a message            POST /api/stop      stop the current task
  POST /api/rpc {method, params}   the phone's Chats / Tasks / Memory / Settings screens: an allow-list
                              of the PC app's own methods (PHONE_METHODS) -- see below
  POST /api/confirm {id,approved}   approve or deny a risky action
  POST /api/voice/start|stop|interrupt|event   phone-as-microphone voice session
  POST /api/voice/utterance?rate=16000        one utterance, raw 16-bit PCM body
  GET  /api/voice/audio/<id>  a synthesized sentence to play on the phone
  GET  /api/screen/info       monitors and quality presets
  GET  /screen.mjpg           live screen as MJPEG (view only)  GET /api/screen/shot  one JPEG frame

The phone's microphone only works from a "secure context", so when
MOBILE_HTTPS_ENABLED is on the same page is ALSO served over https
(self-signed certificate, see troy/tls.py) on MOBILE_UI_PORT + 1.

Threading: handler threads are separate from whatever thread runs the agent.
Every call back into the app goes through the Bridge's callables.
"""

import json
import mimetypes
import os
import re
import secrets
import socket
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from queue import Empty, Queue
from urllib.parse import parse_qs, urlparse

from . import config, power, screencast
from .logger import logger

WEB_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "web", "phone")
TOKEN_FILE = os.path.join(config.PROJECT_ROOT, "troy_mobile_token.txt")
_STATIC = {"phone.css", "phone.js", "views.js", "avatar.js", "icon.png", "manifest.webmanifest"}

# What the phone page may ask the PC app to do. Read-mostly plus the everyday actions; nothing that
# touches API keys, the phone's own access (mobile_ui.*), the shell, the microphone devices or logs.
PHONE_METHODS = frozenset({
    "session.list", "session.load", "session.reset", "session.rename", "session.delete", "session.search",
    "memory.list", "memory.add", "memory.delete",
    "tasks.list", "tasks.get", "tasks.preview", "tasks.create", "tasks.modify", "tasks.cancel", "tasks.pause",
    "tasks.resume", "tasks.run_now", "tasks.delete", "tasks.clear_finished", "tasks.approve", "tasks.logs",
    "settings.get", "settings.update", "settings.set",
    "provider.list", "provider.set_primary", "model.set",
    "agent.status", "power.status", "face.relay",
})
# The only settings the phone may change (everything else: use the PC app).
PHONE_SETTINGS = frozenset({
    "USER_NAME", "PRIMARY_PROVIDER", "TEXT_MODEL_OVERRIDE", "VISION_MODEL_OVERRIDE", "ESCALATION_ENABLED",
    "POWER_SAVING", "VOICE_OUTPUT_ENABLED", "VOICE_BARGE_IN", "VOICE_SPOKEN_STYLE", "VOICE_PHONE_SPEAKER",
    "LLM_FAST", "ALLOW_MODEL_SWITCH", "TASKS_ENABLED", "EXTRA_TOOLS_ENABLED", "MAX_STEPS_PER_TURN",
})
MAX_STREAMS = 3
MAX_POST_BYTES = 64 * 1024
MAX_VOICE_BYTES = 2 * 1024 * 1024       # ~60 s of 16 kHz 16-bit mono: one whole utterance

_server = None
_server_thread = None
_https_server = None
_https_thread = None
_bridge = None
_subscribers = set()
_subscribers_lock = threading.Lock()
_stop_streams = threading.Event()
_viewers = {}                       # stream id -> {"ip": ...}
_viewers_lock = threading.Lock()


def _load_token() -> str:
    """A fixed token from TROY_MOBILE_UI_TOKEN, else one generated on first run
    and remembered, so the phone's saved link survives restarts."""
    if config.MOBILE_UI_TOKEN:
        return config.MOBILE_UI_TOKEN
    try:
        with open(TOKEN_FILE, "r", encoding="utf-8") as f:
            token = f.read().strip()
            if len(token) >= 16:
                return token
    except OSError:
        pass
    token = secrets.token_urlsafe(18)
    try:
        with open(TOKEN_FILE, "w", encoding="utf-8") as f:
            f.write(token)
        os.chmod(TOKEN_FILE, 0o600)
    except OSError:
        logger.warning("Couldn't save the phone access token; the link will change on restart.")
    return token


_session_token = _load_token()


def get_token() -> str:
    return _session_token


def regenerate_token() -> str:
    """Invalidates every saved phone link."""
    global _session_token
    _session_token = secrets.token_urlsafe(18)
    try:
        with open(TOKEN_FILE, "w", encoding="utf-8") as f:
            f.write(_session_token)
    except OSError:
        pass
    return _session_token


class Bridge:
    """Everything the HTTP handlers need from the running app. troy/ipc_host.py
    builds one and calls configure() at startup."""

    def __init__(self, enqueue_turn, get_display_log, get_status, stop_turn=None, list_confirmations=None,
                 resolve_confirmation=None, on_viewers=None, get_info=None,
                 voice_start=None, voice_stop=None, voice_interrupt=None, voice_event=None,
                 voice_audio=None, voice_audio_get=None, rpc=None):
        self.enqueue_turn = enqueue_turn                  # (text) -> None, thread-safe, non-blocking
        self.get_display_log = get_display_log            # () -> list[dict]
        self.get_status = get_status                      # () -> dict
        self.stop_turn = stop_turn or (lambda: None)      # () -> None
        self.list_confirmations = list_confirmations or (lambda: [])      # () -> [{id,name,arg,risk_level,description}]
        self.resolve_confirmation = resolve_confirmation or (lambda cid, approved: None)
        self.on_viewers = on_viewers or (lambda count: None)              # (count) -> None
        self.get_info = get_info or (lambda: {})          # () -> {"user_name":..., "version":...}
        # Voice session on the phone (see troy/voice_mode.py): the phone's mic
        # and speaker instead of -- or as well as -- the PC's.
        self.voice_start = voice_start or (lambda: {"ok": False, "error": "voice isn't wired up"})   # () -> {ok, speaker, engine}
        self.voice_stop = voice_stop or (lambda: None)                    # () -> None
        self.voice_interrupt = voice_interrupt or (lambda: None)          # () -> None
        self.voice_event = voice_event or (lambda data: None)             # ({speaking: bool}) -> None
        self.voice_audio = voice_audio or (lambda pcm, rate: {"action": "ignored", "reason": "unavailable"})  # (bytes, int) -> dict
        self.voice_audio_get = voice_audio_get or (lambda aid: None)      # (id) -> (bytes, fmt) | None
        self.rpc = rpc or (lambda method, params: (_ for _ in ()).throw(ValueError("not available")))   # (method, params) -> dict


def configure(bridge: Bridge):
    global _bridge
    _bridge = bridge


def broadcast(event: dict):
    """Pushes an event to every connected phone over its open SSE connection."""
    with _subscribers_lock:
        subscribers = list(_subscribers)
    for q in subscribers:
        q.put(event)


def lan_ip() -> str:
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.connect(("8.8.8.8", 80))  # doesn't actually send anything
        return s.getsockname()[0]
    except OSError:
        return "127.0.0.1"
    finally:
        s.close()


def current_port():
    return _server.server_address[1] if _server is not None else None


def lan_url() -> str:
    if not config.MOBILE_UI_ENABLED:
        return ""
    return f"http://{lan_ip()}:{current_port() or config.MOBILE_UI_PORT}/?t={_session_token}"


def https_port():
    """The https port the phone page is (or would be) served on: MOBILE_UI_PORT + 1,
    or the http server's port + 1 when the port was chosen at runtime."""
    if _https_server is not None:
        return _https_server.server_address[1]
    return (current_port() or config.MOBILE_UI_PORT) + 1


def https_url() -> str:
    """The https link for the phone, or "" when https isn't running. Needed because
    browsers only hand out the microphone on a secure context."""
    if _https_server is None or not config.MOBILE_UI_ENABLED:
        return ""
    return f"https://{lan_ip()}:{https_port()}/?t={_session_token}"


def https_running() -> bool:
    return _https_server is not None


def voice_info() -> dict:
    """The phone page's voice capabilities, sent with /api/state so the page can
    decide whether to offer its microphone button and where to point it."""
    https = https_url()
    return {
        "enabled": bool(config.MOBILE_VOICE_ENABLED),
        "speaker": config.VOICE_PHONE_SPEAKER,
        "https": https,
        "https_running": bool(https),
        "https_enabled": bool(config.MOBILE_HTTPS_ENABLED),
    }


def viewer_count() -> int:
    with _viewers_lock:
        return len(_viewers)


def _set_viewer(key, ip=None):
    with _viewers_lock:
        if ip is None:
            _viewers.pop(key, None)
        else:
            _viewers[key] = {"ip": ip}
        count = len(_viewers)
    try:
        if _bridge:
            _bridge.on_viewers(count)
    except Exception:  # noqa: BLE001
        logger.debug("viewer callback failed", exc_info=True)


def _check_token(token: str) -> bool:
    return bool(token) and secrets.compare_digest(str(token), _session_token)


class _Handler(BaseHTTPRequestHandler):
    server_version = "TroyPhone/2.0"
    protocol_version = "HTTP/1.1"

    def log_message(self, fmt, *args):  # noqa: N802 - silence default stderr access log
        logger.debug("phone: " + fmt, *args)

    # -------------------------------------------------------------- helpers
    def _headers(self, status, ctype, length=None, extra=None):
        self.send_response(status)
        self.send_header("Content-Type", ctype)
        if length is not None:
            self.send_header("Content-Length", str(length))
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Referrer-Policy", "no-referrer")
        for k, v in (extra or {}).items():
            self.send_header(k, v)
        self.end_headers()

    def _json(self, payload, status=200):
        body = json.dumps(payload).encode("utf-8")
        self._headers(status, "application/json; charset=utf-8", len(body), {"Cache-Control": "no-store"})
        self.wfile.write(body)

    def _token(self, query):
        return self.headers.get("X-Troy-Token", "") or (query.get("t") or [""])[0]

    def _authorized(self, query) -> bool:
        if _check_token(self._token(query)):
            return True
        self._json({"error": "bad token"}, 401)
        return False

    def _static(self, name, ctype=None, cache="no-cache"):
        path = os.path.join(WEB_DIR, name)
        try:
            with open(path, "rb") as f:
                body = f.read()
        except OSError:
            self._headers(404, "text/plain", 0)
            return
        ctype = ctype or mimetypes.guess_type(name)[0] or "application/octet-stream"
        if ctype.startswith("text/") or ctype in ("application/javascript", "application/manifest+json"):
            ctype += "; charset=utf-8"
        self._headers(200, ctype, len(body), {"Cache-Control": cache})
        self.wfile.write(body)

    # ----------------------------------------------------------------- GET
    def do_GET(self):  # noqa: N802
        parsed = urlparse(self.path)
        query = parse_qs(parsed.query)
        path = parsed.path

        if path in ("/", "/index.html"):
            return self._static("index.html", "text/html")
        if path == "/manifest.webmanifest":
            return self._static("manifest.webmanifest", "application/manifest+json")
        if path in ("/icon.png", "/apple-touch-icon.png", "/favicon.ico"):
            return self._static("icon.png", "image/png", "max-age=86400")
        if path.startswith("/assets/"):
            name = path[len("/assets/"):]
            if name in _STATIC:
                return self._static(name)
            return self._headers(404, "text/plain", 0)

        if path == "/api/state":
            if not self._authorized(query):
                return
            b = _bridge
            return self._json({
                "history": b.get_display_log() if b else [], "status": b.get_status() if b else {},
                "confirmations": b.list_confirmations() if b else [], "info": b.get_info() if b else {},
                "screen": {"enabled": config.MOBILE_SCREEN_ENABLED, "max_fps": power.phone_fps(config.MOBILE_SCREEN_MAX_FPS)},
                "voice": voice_info(),
                "now": int(time.time() * 1000),            # lets the page line its animations up with the PC's clock
            })
        m = re.fullmatch(r"/api/voice/audio/(\d+)", path)
        if m:
            if not self._authorized(query):
                return
            return self._voice_audio(int(m.group(1)))
        if path == "/api/stream":
            if self._authorized(query):
                self._stream_events()
            return
        if path == "/api/screen/info":
            if not self._authorized(query):
                return
            return self._screen_info()
        if path == "/api/screen/shot":
            if not self._authorized(query):
                return
            return self._screen_shot(query)
        if path == "/screen.mjpg":
            if self._authorized(query):
                self._screen_stream(query)
            return
        self._headers(404, "text/plain", 0)

    # ---------------------------------------------------------------- POST
    def do_POST(self):  # noqa: N802
        parsed = urlparse(self.path)
        query = parse_qs(parsed.query)
        length = int(self.headers.get("Content-Length", 0) or 0)
        # One utterance from the phone's microphone: raw little-endian int16
        # mono PCM in the body (NOT JSON), so it gets its own size limit and
        # its own token check (the body can't carry one).
        if parsed.path == "/api/voice/utterance":
            return self._voice_utterance(query, length)
        if length > MAX_POST_BYTES:
            return self._json({"error": "too large"}, 413)
        raw = self.rfile.read(length) if length else b""
        try:
            data = json.loads(raw.decode("utf-8")) if raw else {}
        except (json.JSONDecodeError, UnicodeDecodeError):
            data = {}
        if not (_check_token(self.headers.get("X-Troy-Token", "")) or _check_token(data.get("token", ""))):
            return self._json({"error": "bad token"}, 401)
        b = _bridge
        if b is None:
            return self._json({"error": "Troy isn't ready yet"}, 503)

        if parsed.path == "/api/send":
            text = (data.get("text") or "").strip()
            if not text:
                return self._json({"error": "empty message"}, 400)
            try:
                b.enqueue_turn(text[:4000])
            except Exception as exc:  # noqa: BLE001
                return self._json({"error": str(exc)}, 409)
            return self._json({"ok": True})
        if parsed.path == "/api/stop":
            b.stop_turn()
            return self._json({"ok": True})
        if parsed.path == "/api/rpc":
            method = str(data.get("method") or "")
            if method not in PHONE_METHODS:
                return self._json({"error": f"The phone can't call {method or '(nothing)'}."}, 403)
            params = data.get("params")
            try:
                result = b.rpc(method, params if isinstance(params, dict) else {})
            except Exception as exc:  # noqa: BLE001 - becomes the message the page shows
                return self._json({"error": str(exc) or exc.__class__.__name__}, 400)
            return self._json({"ok": True, "result": result})
        if parsed.path == "/api/confirm":
            try:
                b.resolve_confirmation(int(data.get("id")), bool(data.get("approved")))
            except Exception as exc:  # noqa: BLE001
                return self._json({"error": str(exc)}, 400)
            return self._json({"ok": True})

        # -------- phone voice session (start/stop/interrupt/event are JSON) ----
        if parsed.path == "/api/voice/start":
            try:
                result = b.voice_start() or {}
            except Exception as exc:  # noqa: BLE001 - e.g. STT not installed on the PC
                return self._json({"error": str(exc)}, 400)
            if not result.get("ok", result.get("started", False)) and result.get("error"):
                return self._json({"error": result["error"]}, 400)
            return self._json(result)
        if parsed.path == "/api/voice/stop":
            try:
                b.voice_stop()
            except Exception as exc:  # noqa: BLE001
                return self._json({"error": str(exc)}, 400)
            return self._json({"ok": True})
        if parsed.path == "/api/voice/interrupt":
            b.voice_interrupt()
            return self._json({"ok": True})
        if parsed.path == "/api/voice/event":
            b.voice_event({k: data[k] for k in ("speaking",) if k in data})
            return self._json({"ok": True})
        self._json({"error": "not found"}, 404)

    # ------------------------------------------------------------ phone voice
    def _voice_utterance(self, query, length):
        """Raw PCM16 upload: the phone did the endpointing client-side, the
        server checks the token (header or ?t=), hands the audio to voice
        mode and answers with what to do next."""
        if length > MAX_VOICE_BYTES:
            self.close_connection = True
            return self._json({"error": "too large"}, 413)
        raw = self.rfile.read(length) if length else b""
        if not (_check_token(self.headers.get("X-Troy-Token", "")) or _check_token((query.get("t") or [""])[0])):
            return self._json({"error": "bad token"}, 401)
        b = _bridge
        if b is None:
            return self._json({"error": "Troy isn't ready yet"}, 503)
        try:
            rate = int((query.get("rate") or ["16000"])[0])
        except (TypeError, ValueError):
            rate = 16000
        if rate < 8000 or rate > 48000:
            return self._json({"error": "bad sample rate"}, 400)
        try:
            return self._json(b.voice_audio(raw, rate))
        except Exception as exc:  # noqa: BLE001 - e.g. voice mode never started
            return self._json({"error": str(exc)}, 400)

    def _voice_audio(self, audio_id):
        """One synthesized sentence, when the phone is set to play Troy's own
        voice instead of its local speechSynthesis one."""
        b = _bridge
        item = b.voice_audio_get(audio_id) if b else None
        if not item:
            return self._json({"error": "no such audio"}, 404)
        audio, fmt = item
        ctype = "audio/wav" if fmt == "wav" else "audio/mpeg"
        self._headers(200, ctype, len(audio), {"Cache-Control": "no-store"})
        self.wfile.write(audio)

    # ---------------------------------------------------------------- SSE
    def _stream_events(self):
        q = Queue()
        with _subscribers_lock:
            _subscribers.add(q)
        try:
            self._headers(200, "text/event-stream", None, {"Cache-Control": "no-cache", "Connection": "close", "X-Accel-Buffering": "no"})
            self.close_connection = True
            self.wfile.write(b"retry: 2000\n\n: hello\n\n")
            self.wfile.flush()
            while not _stop_streams.is_set():
                try:
                    event = q.get(timeout=15)
                    chunk = f"data: {json.dumps(event)}\n\n".encode("utf-8")
                except Empty:
                    chunk = b": keepalive\n\n"
                try:
                    self.wfile.write(chunk)
                    self.wfile.flush()
                except (BrokenPipeError, ConnectionResetError, OSError):
                    break
        finally:
            with _subscribers_lock:
                _subscribers.discard(q)

    # -------------------------------------------------------------- screen
    def _screen_info(self):
        monitors = []
        try:
            g = screencast.Grabber()
            monitors = g.monitors()
            g.close()
        except Exception as exc:  # noqa: BLE001
            logger.debug("monitor listing failed: %s", exc)
        self._json({"enabled": config.MOBILE_SCREEN_ENABLED, "monitors": monitors, "max_fps": power.phone_fps(config.MOBILE_SCREEN_MAX_FPS),
                    "presets": {k: screencast.preset(k) for k in ("saver", "balanced", "sharp")}, "viewers": viewer_count()})

    def _screen_params(self, query):
        base = screencast.preset((query.get("preset") or ["balanced"])[0])

        def num(name, default, lo, hi):
            try:
                return max(lo, min(hi, int((query.get(name) or [default])[0])))
            except (TypeError, ValueError):
                return default
        return {"width": num("w", base["width"], 320, 2560), "quality": num("q", base["quality"], 20, 90),
                "fps": num("fps", base["fps"], 1, 30), "monitor": num("monitor", 1, 0, 8)}

    def _screen_shot(self, query):
        if not config.MOBILE_SCREEN_ENABLED:
            return self._json({"error": "Screen sharing is turned off on the PC."}, 403)
        p = self._screen_params(query)
        try:
            frame = screencast.snapshot(p["width"], p["quality"], p["monitor"])
        except Exception as exc:  # noqa: BLE001
            return self._json({"error": f"Couldn't capture the screen: {exc}"}, 500)
        self._headers(200, "image/jpeg", len(frame), {"Cache-Control": "no-store", "Content-Disposition": 'inline; filename="screen.jpg"'})
        self.wfile.write(frame)

    def _screen_stream(self, query):
        if not config.MOBILE_SCREEN_ENABLED:
            return self._json({"error": "Screen sharing is turned off on the PC."}, 403)
        with _viewers_lock:
            if len(_viewers) >= MAX_STREAMS:
                return self._json({"error": "Too many screens are already being watched."}, 429)
        p = self._screen_params(query)
        key = object()
        _set_viewer(key, self.client_address[0])
        try:
            self._headers(200, "multipart/x-mixed-replace; boundary=troyframe", None,
                          {"Cache-Control": "no-store, no-cache, must-revalidate", "Pragma": "no-cache", "Connection": "close"})
            self.close_connection = True
            for frame in screencast.stream_frames(p["width"], p["quality"], p["fps"], p["monitor"],
                                                  should_stop=lambda: _stop_streams.is_set() or not config.MOBILE_SCREEN_ENABLED,
                                                  max_fps=power.phone_fps(config.MOBILE_SCREEN_MAX_FPS)):
                try:
                    self.wfile.write(b"--troyframe\r\nContent-Type: image/jpeg\r\nContent-Length: " + str(len(frame)).encode() + b"\r\n\r\n")
                    self.wfile.write(frame)
                    self.wfile.write(b"\r\n")
                    self.wfile.flush()
                except (BrokenPipeError, ConnectionResetError, OSError):
                    break
        except screencast.ScreenError:
            pass
        finally:
            _set_viewer(key, None)


class _Server(ThreadingHTTPServer):
    daemon_threads = True
    allow_reuse_address = True


def _serve_forever(server, name):
    try:
        server.serve_forever()
    except Exception as exc:  # noqa: BLE001 - a dead server must never crash the app
        logger.warning("%s stopped: %s", name, exc)


def start(port: int = None):
    global _server, _server_thread
    if _server is not None:
        return
    port = port or config.MOBILE_UI_PORT
    _stop_streams.clear()
    _server = _Server(("0.0.0.0", port), _Handler)
    _server_thread = threading.Thread(target=_serve_forever, args=(_server, "phone http"), daemon=True, name="troy-phone-http")
    _server_thread.start()
    logger.info("Phone page listening on port %s", port)
    start_https()


def start_https(port: int = None):
    """The same page, encrypted, on port+1 -- what lets the phone's microphone
    work on plain Wi-Fi (browsers only allow getUserMedia on https). Silently
    skips when turned off or when the certificate can't be made."""
    global _https_server, _https_thread
    if _https_server is not None or _server is None:
        return
    if not config.MOBILE_HTTPS_ENABLED:
        return
    from . import tls
    ctx = tls.ssl_context()
    if ctx is None:
        return
    port = port or https_port()
    try:
        srv = _Server(("0.0.0.0", port), _Handler)
        srv.socket = ctx.wrap_socket(srv.socket, server_side=True)
    except OSError as exc:
        logger.warning("Phone page HTTPS couldn't start on port %s: %s", port, exc)
        return
    _https_server = srv
    _https_thread = threading.Thread(target=_serve_forever, args=(_https_server, "phone https"), daemon=True, name="troy-phone-https")
    _https_thread.start()
    logger.info("Phone page HTTPS listening on port %s (self-signed; expect one browser warning)", port)


def stop():
    global _server, _server_thread, _https_server, _https_thread
    if _server is not None:
        _stop_streams.set()
        _server.shutdown()
        _server.server_close()
        _server = None
        _server_thread = None
    if _https_server is not None:
        _https_server.shutdown()
        _https_server.server_close()
        _https_server = None
        _https_thread = None


def is_running() -> bool:
    return _server is not None
